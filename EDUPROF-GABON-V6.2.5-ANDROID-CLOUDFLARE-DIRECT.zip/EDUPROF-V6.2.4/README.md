# EduProf Gabon V6.2.4 — Cloudflare Native Hardened

Application pédagogique gabonaise (CM2 → Terminale) + Maël (professeur IA).

## Stack

| Couche | Technologie |
|--------|-------------|
| Frontend | React 18 + Vite + PWA |
| API | Cloudflare Workers |
| Données | Cloudflare D1 |
| Cache / rate limit | Cloudflare KV |
| Fichiers | Cloudflare R2 |
| Auth | JWT HS256 (`jose`) |
| Cron | Cloudflare Triggers `0 2 * * *` |

## Développement local

```bash
npm install
export ALLOW_INSECURE_JWT_DEV=1
npm run dev          # frontend Vite
npm run typecheck
npm test
npm run build
```

## Déploiement Cloudflare

Voir `docs/CLOUDFLARE-SETUP.md`.

```bash
wrangler login
wrangler secret put JWT_SECRET
wrangler secret put OWNER_EMAILS
# kamaemomo@gmail.com,auraconfort.studio@gmail.com
npm run build
npm run db:migrate
npm run cf:deploy
```

## Owner

Rôles Owner assignés **uniquement côté serveur** via le secret `OWNER_EMAILS`.
Jamais codés dans le frontend.

## Modèle commercial

Pas de paiement Premium individuel dans l'app élève.
Établissement → activation → durée → expiration → renouvellement.

## Documentation

- `docs/CLOUDFLARE-SETUP.md`
- `docs/NETLIFY-REMOVAL-AUDIT.md` (historique migration)
- `V6.2.4-VALIDATION-REPORT.md`


## Termux / Android
Voir limitation workerd dans docs/CLOUDFLARE-SETUP.md.
npm install --ignore-scripts puis typecheck/test/build.


## Deploy Cloudflare
```bash
npm run deploy:check
npm run deploy   # build + wrangler deploy (plateforme supportée)
```
Voir docs/CLOUDFLARE-SETUP.md
