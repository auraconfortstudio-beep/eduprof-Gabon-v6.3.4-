-- V6.2 : index supplémentaires pour activations/memberships (schéma déjà dans 0001)
CREATE INDEX IF NOT EXISTS idx_act_user_est ON activations(user_id, establishment_id);
CREATE INDEX IF NOT EXISTS idx_mem_user_est ON memberships(user_id, establishment_id);
CREATE INDEX IF NOT EXISTS idx_audit_action ON audit_logs(action);
