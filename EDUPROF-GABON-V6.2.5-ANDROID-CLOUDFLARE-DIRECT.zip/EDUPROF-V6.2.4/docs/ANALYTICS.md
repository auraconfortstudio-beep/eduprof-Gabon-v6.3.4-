# Analytics V4.4

- **OWNER** : `GET /api/analytics/overview?period=7d|30d|90d|all`
- **ESTABLISHMENT_ADMIN** : même route, scope forcé via `resolveEstablishmentContext`
- Données : établissements, activations, audit mémoire, XP users
- **Limite** : store mémoire → pas d’historique long terme réel
