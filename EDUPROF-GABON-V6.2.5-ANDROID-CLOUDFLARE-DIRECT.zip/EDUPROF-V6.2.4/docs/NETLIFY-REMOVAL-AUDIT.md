# Anti-Netlify V6.1

## Opérationnel
0 dépendance `@netlify/*`.
0 `netlify.toml`.
0 dossier `netlify/`.

## Documentaire
Mentions historiques uniquement dans ce fichier et rapports de migration.
