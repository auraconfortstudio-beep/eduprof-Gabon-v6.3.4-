# Monitoring V4.7

## Logger
logInfo / logWarn / logError — JSON, sanitisation secrets/paths.

## Request ID
Header X-Request-Id (incoming valide ou UUID genere).

## Metriques process-local
Ring buffer 200 · GET /api/health · GET /api/metrics (OWNER/ADMIN)

## Limites
Pas de backend APM distribue. Metriques perdues au cold start Netlify.
