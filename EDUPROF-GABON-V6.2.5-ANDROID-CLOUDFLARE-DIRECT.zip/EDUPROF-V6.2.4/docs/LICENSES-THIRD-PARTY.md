# Notices — sources open source utilisées en V4.1.0

## Step-Wise (HildoBijl/stepwise)
- Licence : MIT
- URL : https://github.com/HildoBijl/stepwise
- Usage EduProf : **inspiration / réimplémentation** des concepts skill tree, prérequis, suivi de maîtrise.
- Aucun package `@step-wise/*` installé. Aucune copie de code source Step-Wise dans le runtime.
- Notice MIT à conserver pour la référence conceptuelle.

## OATutor (CAHLR/OATutor)
- Licence : MIT (Copyright 2023 Zachary A. Pardos / CAHL)
- URL : https://github.com/CAHLR/OATutor
- Fichier inspecté : `src/models/BKT/BKT-brain.js`
- Usage EduProf : **réimplémentation TypeScript** de la formule BKT (probMastery, probSlip, probGuess, probTransit).
- Aucun contenu pédagogique OATutor, Firebase, ni frontend copié.

## LearnGraph (fenago/LearnGraph)
- Licence : MIT (package.json)
- URL : https://github.com/fenago/LearnGraph
- Fichiers inspectés : `src/models/types.ts`, `src/db/EducationGraphDB.ts`
- Usage EduProf : **inspiration** ConceptNode, PrerequisiteEdge, KnowledgeState, gap/recommendation.
- **Non importé** : psychométrie 39 dimensions, Big Five, Dark Triad, frontend Next.js, base de données complète.
