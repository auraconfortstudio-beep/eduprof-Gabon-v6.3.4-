# Sources multi-tenant V4.3.0

| Source | Licence | Étudié | Code copié | Réimplémenté |
|--------|---------|--------|------------|--------------|
| donchi4all/multi-tenant-rbac | MIT | tenant isolation, membership, RBAC | NON | OUI (concepts) |
| mhmdhussein/tenantflow | MIT | tenant lifecycle, filtering, jobs | NON | OUI (concepts) |
| aws-samples/sample-bedrock-agentcore-multitenant | AWS samples | principe user→tenant→data | NON | inspiration isolation |
| Netlify Scheduled Functions / Blobs docs | Docs Netlify | schedule, blobs | NON | config préparée |
