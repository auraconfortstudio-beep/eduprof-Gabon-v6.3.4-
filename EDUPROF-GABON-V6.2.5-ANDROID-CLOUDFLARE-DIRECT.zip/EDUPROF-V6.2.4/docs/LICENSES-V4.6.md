# Licences V4.6

| Source | Licence | Usage |
|--------|---------|--------|
| OWASP ASVS 5.0 | CC BY-SA 4.0 | Checklist sécurité — pas de copie |
| OWASP Cheat Sheet Series | (OWASP) | Auth, upload, API — inspiration |
| jose | MIT | Déjà utilisé ; alg HS256 forcé |
| express-rate-limit | MIT | Inspiration uniquement — **non installé** |
