# Sources admin V4.2.0 — licences

## Anupam4058/RBAC-dashboard
- Licence : MIT
- Usage : inspiration UI RBAC / dashboard — aucune copie de code

## Ghaithsy418/School-Management-Dashboard
- Licence : non trouvée en racine (README only) → **inspiration uniquement, pas de copie**

## cybernazmul/RBACStack
- Licence : Apache-2.0
- Usage : inspiration concepts permissions / rôles — **réimplémentation native EduProf**, pas d'import du stack
