# Sources V4.4

| Source | Licence | Inspecté | Copié | Réimplémenté | Contenu importé |
|--------|---------|----------|-------|--------------|-----------------|
| CAHLR/OATutor | MIT | BKT, mastery (déjà V4.1) | NON | principes mastery analytics | NON |
| HildoBijl/stepwise | MIT | skill-tracking concepts | NON | progression/mastery labels | NON |
| react-analytics-dashboard | MIT | KPI cards, tables | NON | KPI SVG natif | NON |
| react-component/notification | MIT | toast principle | NON | non utilisé (pas de dépendance) | NON |
