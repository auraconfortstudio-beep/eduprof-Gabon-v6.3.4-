# Licences V4.5

| Source | Licence | URL | Utilisation | Type |
|--------|---------|-----|-------------|------|
| vite-plugin-pwa | MIT | github.com/vite-pwa/vite-plugin-pwa | idées manifest/SW update | inspiration |
| Workbox | MIT | github.com/GoogleChrome/workbox | cache strategy | inspiration |
| react-dropzone | MIT | github.com/react-dropzone/react-dropzone | accept/reject UX | inspiration |
| react-hot-toast | MIT | github.com/timolins/react-hot-toast | toast API | réimplémenté natif |
