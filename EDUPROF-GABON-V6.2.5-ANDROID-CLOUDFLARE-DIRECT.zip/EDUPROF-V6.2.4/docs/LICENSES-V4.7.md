# Licences V4.7

| Source | Licence | Usage |
|--------|---------|--------|
| pino (architecture) | MIT | Inspiration logger JSON — non installe |
| winston (architecture) | MIT | Inspiration niveaux — non installe |
| OpenTelemetry concepts | Apache-2.0 | Inspiration correlation ID — non installe |

Aucune dependance nouvelle. Reimplementation native.
