# Attachments V4.5

Améliore le système existant (pas un second store).

- MIME + extension alignés
- Extensions dangereuses refusées
- Taille max 4 Mo
- Isolation userId (existante)
- Maël : métadonnées sans secrets
