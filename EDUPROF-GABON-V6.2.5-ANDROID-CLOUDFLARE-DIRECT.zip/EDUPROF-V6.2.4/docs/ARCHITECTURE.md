# EduProf Gabon — Architecture (V4.0.0 socle)

## Stack

- **Frontend** : React 18 + TypeScript + Vite + Tailwind
- **Backend** : Netlify Functions (`api.ts`, `ai-tutor.ts`)
- **Stockage** : Netlify Blobs (prod) / fichiers ou Map en mémoire (dev)
- **Auth** : JWT (`jose`) + bcryptjs — pas de Supabase / Firebase

## Arborescence utile

```
src/
  components/     # Pages UI (Home, Level, Subject, Maël, Annales…)
  data/           # Contenu pédagogique & annales (client)
  lib/            # api, auth, progress, errors, constants
  types/          # Rôles & User (socle V4)
netlify/functions/
  api.ts          # REST auth, progress, annales, admin, conversations, attachments
  ai-tutor.ts     # Maël
  _shared/        # auth, store, pedagogy, ai providers, attachments
```

## Principes

1. **UI ≠ métier** : appels réseau via `src/lib/api.ts` uniquement.
2. **Secrets serveur** : clés IA / JWT uniquement en variables d’environnement Netlify (jamais `VITE_*`).
3. **Isolation utilisateur** : conversations, mémoire, pièces jointes filtrées par `userId`.
4. **Rôles actifs** : `OWNER` | `ADMIN` | `USER`. Rôles futurs déclarés mais non branchés.
5. **Annales** : aucun sujet inventé présenté comme officiel.

## Scripts

| Script | Rôle |
|--------|------|
| `npm run dev` | Vite seul (UI) |
| `npm run dev:netlify` | UI + Functions locales |
| `npm run typecheck` | TS app + functions |
| `npm test` | Vitest |
| `npm run build` | Build production |

## Blocs futurs (ne pas implémenter ici)

RBAC établissements, activation, multi-établissements, analytics, notifications, etc. — voir plan V4 blocs 2–24.
