# NPM Security V5.0.0

## Audit initial (registry.npmjs.org)

| Package | Sévérité | Directe ? | Fix disponible | Breaking |
|---------|----------|-----------|----------------|----------|
| vitest | critical | oui (dev) | vitest@5.0.0 | OUI (major) |
| @vitest/mocker | moderate | non | via vitest@5 | OUI |
| vite-node | moderate | non | via vitest@5 | OUI |
| vite | high | oui (dev) | vite@8.3.0 | OUI (major) |
| esbuild | moderate | non | via vite@8 | OUI |

## Corrections effectuées
Aucune mise à jour majeure forcée (interdit par la politique du projet).
Les vulnérabilités concernent **uniquement des dépendances de développement**
(vite, vitest) — **non présentes dans le bundle de production** servi aux élèves.

## Vulnérabilités restantes
Conservées volontairement pour éviter breaking changes sur Vite 5 / Vitest 2
qui sont stables pour le pipeline QA actuel (199+ tests).

Mitigation :
- ne pas exposer Vitest UI en production
- ne pas exposer le serveur de dev Vite sur Internet
- build de production non affecté

## Dépendances runtime (production)
@netlify/blobs, @netlify/functions, bcryptjs, jose, lucide-react, react, react-dom
— aucune vulnérabilité signalée sur le périmètre runtime dans cet audit.
