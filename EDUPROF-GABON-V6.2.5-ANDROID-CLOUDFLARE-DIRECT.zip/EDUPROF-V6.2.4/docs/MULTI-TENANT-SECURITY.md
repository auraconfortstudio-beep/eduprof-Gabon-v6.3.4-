# Sécurité multi-tenant V4.3

## Règle d'or
Le serveur dérive le tenant via `resolveEstablishmentContext(actor, requestedId?)`.
Un `establishmentId` client n'est accepté que s'il est autorisé pour l'acteur.

## Matrice

| Acteur | Voir A | Modifier A | Voir B |
|--------|--------|------------|--------|
| ESTABLISHMENT_ADMIN A | oui | oui (si A active) | **non 403** |
| OWNER | oui | oui | oui |
| STUDENT A | ses données | non admin | **non** |

## Attaques couvertes par tests
adminA → studentB (read/activate/renew/revoke/import/audit/stats) → 403
