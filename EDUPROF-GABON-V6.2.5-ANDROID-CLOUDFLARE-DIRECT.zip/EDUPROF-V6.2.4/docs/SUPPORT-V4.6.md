# Support V4.6

Tickets : OPEN → IN_PROGRESS → WAITING_USER → RESOLVED / CLOSED

API :
- GET/POST /support/tickets
- GET /support/tickets/get?id=
- POST /support/tickets/status
- POST /support/tickets/reply

Isolation : user = ses tickets ; ESTABLISHMENT_ADMIN = établissement ; OWNER/ADMIN = global.
Notifications SUPPORT via système V4.5.
