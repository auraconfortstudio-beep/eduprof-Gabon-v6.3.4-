# UX / PWA V4.5

- Service worker `/sw.js` : precache, SKIP_WAITING, network-first API
- manifest.json standalone
- OfflineBanner (honnête : API indisponible offline)
- PWAUpdatePrompt
- ToastHost natif
- Bottom nav tactile + page Notifications
