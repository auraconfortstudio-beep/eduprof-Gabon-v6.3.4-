# Progression / gamification V4.4

## XP (inchangé)
- Leçon = 10
- Exercice = 15
- Quiz ≤ 50

## Niveaux
`XP floor(level) = 50 * (level-1) * level / 2`

## Badges
FIRST_LESSON, FIRST_EXERCISE, FIRST_QUIZ, QUIZ_MASTER, STREAK_7/30, XP_100/500/1000, SUBJECT_MASTER

## Streak
Géré côté API existante (`updateStreak`) — jour UTC ISO date.

## API élève
`GET /api/student/progress`
