# Notifications V4.5

In-app uniquement. Push désactivé (`PushNotificationProvider.enabled = false`).

API :
- GET /notifications
- POST /notifications/read
- POST /notifications/read-all
- POST /notifications/create (admin tenant-aware)
