# Scalabilite V4.7

Stores memoire identifies :
- institutional (establishments, activations, audit)
- notifications
- support tickets
- rate limit local
- attachments dev map
- metrics buffer

Abstraction : InstitutionalRepository (memory -> futur netlify-blobs)
Helpers : trimMap / trimArray

Risques Netlify : cold start, pas d etat partage entre isolates.
