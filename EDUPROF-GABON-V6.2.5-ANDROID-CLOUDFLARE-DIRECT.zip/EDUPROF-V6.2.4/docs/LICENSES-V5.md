# Licences V5

Voir aussi LICENSES-V4.6.md et antérieurs.

Open source consulté pour le modèle institutionnel :
- multi-tenant-rbac (MIT) — inspiration
- tenantflow (MIT) — inspiration
- RBAC-dashboard (MIT) — inspiration

Aucune copie de code.
