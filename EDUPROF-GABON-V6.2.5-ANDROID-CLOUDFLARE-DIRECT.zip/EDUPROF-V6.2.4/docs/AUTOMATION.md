# Automatisation institutionnelle V4.3

## Job
`runInstitutionalMaintenance()` :
- ACTIVE + expiresAt < now → EXPIRED
- compteurs expiringSoon (1/3/7 j)
- audit MAINTENANCE_RUN + ACTIVATION_EXPIRED
- **idempotent**

## Déclenchement
1. POST `/api/institutional/maintenance` (OWNER/ADMIN)
2. Netlify Scheduled Function `institutional-maintenance.ts` — cron `0 2 * * *`
   (actif seulement après déploiement Netlify avec scheduled functions)

## Limites
Sans déploiement Netlify, le schedule n'est **pas** exécuté en production automatiquement.
Le job est testable localement.
