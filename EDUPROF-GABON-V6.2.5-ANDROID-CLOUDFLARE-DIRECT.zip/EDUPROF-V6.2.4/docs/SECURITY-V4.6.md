# Sécurité V4.6

- JWT HS256 uniquement (`algorithms: ['HS256']`)
- Headers : nosniff, Referrer-Policy, X-Frame-Options, Permissions-Policy, CSP de base
- Rate limit : login IP, signup, AI, upload, support, admin (store mémoire/blobs — **non distribué**)
- Upload : MIME, extension, double extension, danger, 4 Mo
- Erreurs publiques via `publicErrorMessage`
- Multi-tenant : `resolveEstablishmentContext` + `canAccessTicket`

Limites : CORS `*` historique (PWA), rate limit non cluster-wide.
