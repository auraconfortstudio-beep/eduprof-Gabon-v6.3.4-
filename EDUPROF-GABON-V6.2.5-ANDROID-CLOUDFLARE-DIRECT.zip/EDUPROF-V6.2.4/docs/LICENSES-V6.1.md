# Licences V6.1

| Package | Licence |
|---------|---------|
| react, react-dom | MIT |
| jose | MIT |
| bcryptjs | MIT |
| lucide-react | ISC |

Aucune dépendance Netlify. Aucun code propriétaire copié.
