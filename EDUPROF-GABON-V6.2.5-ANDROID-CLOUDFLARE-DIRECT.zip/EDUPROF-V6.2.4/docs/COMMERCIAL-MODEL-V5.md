# Modèle commercial institutionnel V5.0.0

## Principe
PAS de paiement Premium individuel dans l'application élève.

Flux :
Établissement partenaire
→ administration établissement (ESTABLISHMENT_ADMIN)
→ liste des élèves ayant payé (CSV ou manuel)
→ activation des comptes (durée définie)
→ accès institutionnel actif
→ expiration automatique (maintenance)
→ renouvellement / désactivation

## Rôles
- OWNER / ADMIN EduProf : global
- ESTABLISHMENT_ADMIN : son établissement uniquement
- TEACHER : lecture limitée
- STUDENT / USER legacy : élève

## Accès
`checkInstitutionalAccess(user)` :
- staff = toujours autorisé
- sans establishmentId = legacy_open
- avec establishmentId = nécessite activation active non expirée

## API
GET /api/access/status
