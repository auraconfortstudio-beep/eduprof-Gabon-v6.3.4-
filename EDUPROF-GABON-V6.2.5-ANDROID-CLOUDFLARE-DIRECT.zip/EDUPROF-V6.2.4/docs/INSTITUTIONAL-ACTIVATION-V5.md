# Activation institutionnelle V5

Fonctions existantes (V4.2/V4.3) conservées :
- activate / deactivate / renew / revoke / bulk
- maintenance d\'expiration idempotente
- memberships ACTIVE/REVOKED

Gate V5 : checkInstitutionalAccess

États élève : pending, active, expired, suspended, revoked
