# Audit avancé V4.4

Étend l’audit institutionnel V4.2/V4.3.

`GET /api/analytics/audit?page=1&pageSize=20&action=&establishmentId=`

Filtres tenant via `resolveEstablishmentContext`. Aucun secret stocké/exposé.
