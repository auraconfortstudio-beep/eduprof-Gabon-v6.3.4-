# Modèle de données multi-établissements (V4.3)

```
OWNER / ADMIN (global)
        │
        ▼
  Establishment (tenant)
        │
        ├── Membership (userId, establishmentId, role, status)
        ├── StudentActivation (userId, establishmentId, status, expiresAt)
        └── Audit (targetEstablishmentId)
```

## Portée des données

| Donnée | Portée |
|--------|--------|
| Catalogue pédagogique, annales, graphe concepts | **globale** |
| Mastery / progression / conversations / attachments | **user-scoped** |
| Establishment, Membership, Activation, audit institutionnel | **tenant-scoped** |
| Users (compte) | global avec `establishmentId` optionnel |

## Stockage actuel
`InstitutionalRepository.backend = "memory"` (Map).

## Stockage futur
Netlify Blobs, clés du type `institution:{establishmentId}:activations`.
