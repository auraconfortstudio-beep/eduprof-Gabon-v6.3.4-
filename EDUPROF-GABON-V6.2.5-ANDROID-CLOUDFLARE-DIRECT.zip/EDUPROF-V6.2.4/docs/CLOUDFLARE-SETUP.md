# Cloudflare Setup — EduProf Gabon V6.2.4 (Worker natif)

**CODE PRÊT POUR DÉPLOIEMENT WRANGLER — VALIDATION CLOUDFLARE RÉELLE À EFFECTUER SUR PLATEFORME SUPPORTÉE**

## Architecture

```
Frontend (Vite → dist)
        ↓
Cloudflare Worker (workers/index.ts)
  fetch(request, env, ctx)
  scheduled(controller, env, ctx)
        ↓
  API / Auth / Owner / RBAC
        ↓
  D1 · KV · R2 · Secrets · Cron
```

Pas de Netlify. Pas de serveur Vite en production.

## Termux / Android

| Action | Termux ARM64 |
|--------|----------------|
| `npm install --ignore-scripts` | OK |
| `npm run typecheck` / `test` / `build` | OK |
| `wrangler deploy` / `workerd` | **Non supporté** (android arm64 LE) |

Le déploiement réel doit se faire depuis **Linux x64/arm64, macOS, ou CI Cloudflare** — pas un mock.

## Déploiement (machine compatible Wrangler)

```bash
# 1. Install
npm install

# 2. Login
wrangler login

# 3. Créer ressources
wrangler d1 create eduprof-db
wrangler kv namespace create eduprof-kv
# R2 : dashboard → bucket eduprof-attachments

# 4. Mettre database_id et kv id dans wrangler.toml

# 5. Secrets (valeurs jamais dans le repo)
wrangler secret put JWT_SECRET
wrangler secret put OWNER_EMAILS
# kamaemomo@gmail.com,auraconfort.studio@gmail.com

wrangler secret put GEMINI_API_KEY   # optionnel
wrangler secret put GROQ_API_KEY
wrangler secret put MISTRAL_API_KEY
wrangler secret put CEREBRAS_API_KEY

# 6. Migrations
npm run db:migrate:local
npm run db:migrate

# 7. Build + deploy
npm run deploy
# = npm run build && wrangler deploy

# 8. Vérifier
curl -s https://<worker>.workers.dev/api/health
```

## Checklist Cloudflare

- [ ] D1 créé + `database_id` dans wrangler.toml
- [ ] Migrations appliquées (remote)
- [ ] KV créé + `id` dans wrangler.toml
- [ ] R2 bucket `eduprof-attachments`
- [ ] JWT_SECRET
- [ ] OWNER_EMAILS
- [ ] Clés IA selon besoin
- [ ] `npm run build` puis `wrangler deploy`
- [ ] Cron `0 2 * * *` actif
- [ ] Test Owner / établissement / activation / isolation

## Premium

Premium individuel conservé temporairement pour tests commerciaux.
Modèle cible : institutionnel (établissement paie, admin active élèves).

## Owner

Uniquement via secret `OWNER_EMAILS` côté Worker.
Jamais hardcodé dans le frontend.
