#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
echo '=== EduProf Gabon — préparation Cloudflare depuis Android ==='
command -v node >/dev/null || { echo 'Node.js manque. Dans Termux: pkg install nodejs'; exit 1; }
command -v npm >/dev/null || { echo 'npm manque. Installe Node.js dans Termux.'; exit 1; }
echo '[1/3] Installation des dépendances…'
npm install --ignore-scripts

echo '[2/3] Construction de la version production…'
npm run build

test -f dist/index.html || { echo 'ERREUR: dist/index.html absent après le build.'; exit 1; }
echo '[3/3] Build terminé.'
echo
echo 'IMPORTANT: Cloudflare Direct Upload accepte le ZIP/folder pré-construit, pas le code source.'
echo 'Ouvre Cloudflare > Workers & Pages > Create application > Pages > Direct Upload,'
echo 'puis sélectionne le dossier dist/ (ou compresse dist/ en ZIP).'
echo
echo 'Le backend D1/KV/R2 et les secrets doivent ensuite être liés au Worker/Pages.'
echo 'Ce script ne met AUCUNE clé API dans le projet.'
