/**
 * Génère workers/_shared/lesson-catalog.json
 * Source de vérité = getLevels() (même arbre que la navigation).
 * Usage: node --import tsx scripts/rebuild-lesson-catalog.mjs
 *        npm run build:index
 */
import { writeFileSync } from 'fs';
import { getLevels } from '../src/data/curriculum.ts';

const catalog = {
  generatedAt: new Date().toISOString(),
  lessons: {},
  byChapter: {},
  stats: {
    totalLessons: 0,
    byLevel: {},
    bySeries: {},
    shared: 0,
    legacy: 0,
    verified: 0,
    aConfirmer: 0,
  },
};

function classifyStatus(levelId, seriesId, subjectId) {
  if (!seriesId) return { status: 'VERIFIE', legacy: false, shared: !seriesId };
  // Packs seriesPedagogy (préfixes levelId dans subject id)
  if (
    /-(a1|a2|le|plus)-/.test(subjectId) ||
    subjectId.includes('premiere-a1') ||
    subjectId.includes('premiere-a2') ||
    subjectId.includes('premiere-b') ||
    subjectId.includes('premiere-s') ||
    subjectId.includes('terminale-a1') ||
    subjectId.includes('terminale-a2') ||
    subjectId.includes('terminale-b') ||
    subjectId.includes('seconde-le') ||
    subjectId.includes('seconde-s') ||
    subjectId.includes('terminale-c-plus') ||
    subjectId.includes('terminale-d-plus')
  ) {
    return { status: 'VERIFIE', legacy: false, shared: false };
  }
  if (seriesId === 'serie-a' || subjectId.includes('premiere-a') || subjectId.includes('terminale-a')) {
    // Ancien pack littéraire non subdivisé
    if (!subjectId.includes('a1') && !subjectId.includes('a2')) {
      return { status: 'A_CONFIRMER', legacy: true, shared: false };
    }
  }
  if (seriesId === 'serie-c' || seriesId === 'serie-d') {
    return { status: 'VERIFIE', legacy: true, shared: false };
  }
  // Tronc commun seconde / collège sans série
  if (levelId === 'seconde' && (seriesId === 'serie-le' || seriesId === 'serie-s')) {
    // Contenu avec id seconde-mathematiques (pas seconde-le) = partagé
    if (subjectId.startsWith('seconde-') && !subjectId.startsWith('seconde-le') && !subjectId.startsWith('seconde-s')) {
      return { status: 'PARTAGE', legacy: false, shared: true };
    }
  }
  return { status: 'VERIFIE', legacy: false, shared: false };
}

function allowedSeriesFor(levelId, seriesId, status, shared) {
  if (!seriesId) return [];
  if (shared && levelId === 'seconde') {
    return ['serie-le', 'serie-s'];
  }
  // Contenu littéraire A_CONFIRMER : accessible via serie-a et, en lecture seule legacy,
  // aussi via a1/a2/b car attaché comme base — mais retrieval strict préférera le pack spécifique.
  // Pour isolation stricte : allowedSeries = [seriesId] uniquement sauf PARTAGE.
  if (status === 'PARTAGE' && levelId === 'seconde') {
    return ['serie-le', 'serie-s'];
  }
  return [seriesId];
}

function ingestLesson(meta) {
  const {
    levelId,
    seriesId,
    subjectId,
    subjectName,
    chapterId,
    chapterTitle,
    lesson,
  } = meta;

  if (!lesson?.id) return;

  const { status, legacy, shared } = classifyStatus(levelId, seriesId, subjectId);
  const allowedSeries = allowedSeriesFor(levelId, seriesId, status, shared);

  const entry = {
    lessonId: lesson.id,
    levelId,
    seriesId: seriesId || null,
    allowedSeries,
    subjectId,
    subjectName,
    chapterId,
    chapterTitle: chapterTitle || '',
    title: lesson.title || '',
    objective: lesson.objective || '',
    content: lesson.content || '',
    example: lesson.example || '',
    keyPoints: Array.isArray(lesson.keyPoints) ? lesson.keyPoints : [],
    exercises: (lesson.exercises || []).map((ex) => ({
      id: ex.id,
      question: ex.question,
      difficulty: ex.difficulty,
      // pas de correctAnswer dans le catalogue exposé au prompt (sécurité pédagogique)
    })),
    quiz: (lesson.quiz || []).map((q) => ({
      id: q.id,
      question: q.question,
    })),
    status,
    source: 'getLevels',
    legacy: !!legacy,
    shared: !!shared,
  };

  // Doublons : même lessonId — conserver le plus spécifique (non shared prioritaire)
  const prev = catalog.lessons[lesson.id];
  if (prev) {
    if (prev.shared && !entry.shared) {
      catalog.lessons[lesson.id] = entry;
    } else if (prev.status === 'A_CONFIRMER' && entry.status === 'VERIFIE') {
      catalog.lessons[lesson.id] = entry;
    }
    // sinon garder prev
  } else {
    catalog.lessons[lesson.id] = entry;
  }

  if (chapterId) {
    catalog.byChapter[chapterId] = lesson.id;
  }
}

for (const L of getLevels()) {
  const walkSubjects = (subjects, seriesId) => {
    for (const s of subjects || []) {
      for (const ch of s.chapters || []) {
        for (const les of ch.lessons || []) {
          ingestLesson({
            levelId: L.id,
            seriesId: seriesId || null,
            subjectId: s.id,
            subjectName: s.name,
            chapterId: ch.id,
            chapterTitle: ch.title,
            lesson: les,
          });
        }
      }
    }
  };

  if (L.subjects?.length) walkSubjects(L.subjects, null);
  for (const ser of L.series || []) walkSubjects(ser.subjects, ser.id);
  for (const f of L.filieres || []) walkSubjects(f.subjects, null);
}

// Stats
const lessons = Object.values(catalog.lessons);
catalog.stats.totalLessons = lessons.length;
for (const les of lessons) {
  catalog.stats.byLevel[les.levelId] = (catalog.stats.byLevel[les.levelId] || 0) + 1;
  const sk = les.seriesId || '(none)';
  catalog.stats.bySeries[sk] = (catalog.stats.bySeries[sk] || 0) + 1;
  if (les.shared) catalog.stats.shared++;
  if (les.legacy) catalog.stats.legacy++;
  if (les.status === 'VERIFIE') catalog.stats.verified++;
  if (les.status === 'A_CONFIRMER') catalog.stats.aConfirmer++;
  if (les.status === 'PARTAGE') catalog.stats.shared++;
}

const outPath = new URL('../workers/_shared/lesson-catalog.json', import.meta.url);
writeFileSync(outPath, JSON.stringify(catalog));
console.log(JSON.stringify(catalog.stats, null, 2));
console.log('written', outPath.pathname);
