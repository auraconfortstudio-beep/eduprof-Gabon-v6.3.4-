/**
 * Régénère workers/_shared/content-index.json
 * Source de vérité = getLevels() (même arbre que le frontend).
 * Usage: node --import tsx scripts/rebuild-content-index.mjs
 *    ou: npm run build:index
 */
import { writeFileSync } from 'fs';
import { getLevels } from '../src/data/curriculum.ts';

const index = {
  lessons: {},
  exercises: {},
  quizzes: {},
  quizQuestions: {},
};

function ingest(levelId, subject) {
  for (const ch of subject.chapters || []) {
    for (const les of ch.lessons || []) {
      if (les.id) {
        index.lessons[les.id] = { levelId, subjectId: subject.id || '' };
      }
      const quizEntries = [];
      for (const ex of les.exercises || []) {
        if (ex.id != null && typeof ex.correctAnswer === 'number') {
          index.exercises[ex.id] = ex.correctAnswer;
        }
      }
      for (const q of les.quiz || []) {
        if (q.id != null && typeof q.correctAnswer === 'number') {
          index.quizQuestions[q.id] = q.correctAnswer;
          quizEntries.push({ id: q.id, correctAnswer: q.correctAnswer });
        }
      }
      if (les.id) {
        index.quizzes[les.id] = quizEntries;
        index.quizzes[`${les.id}-quiz`] = quizEntries;
      }
      if (ch.id) index.quizzes[ch.id] = quizEntries;
    }
  }
}

for (const L of getLevels()) {
  for (const s of L.subjects || []) ingest(L.id, s);
  for (const ser of L.series || []) {
    for (const s of ser.subjects || []) ingest(L.id, s);
  }
  for (const f of L.filieres || []) {
    for (const s of f.subjects || []) ingest(L.id, s);
  }
}

const out = new URL('../workers/_shared/content-index.json', import.meta.url);
writeFileSync(out, JSON.stringify(index));
console.log(
  JSON.stringify(
    {
      lessons: Object.keys(index.lessons).length,
      exercises: Object.keys(index.exercises).length,
      quizQuestions: Object.keys(index.quizQuestions).length,
      quizzes: Object.keys(index.quizzes).length,
      path: out.pathname,
    },
    null,
    2
  )
);
