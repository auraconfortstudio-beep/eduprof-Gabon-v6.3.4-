import { describe, it, expect } from 'vitest';
import {
  validateAttachmentInput,
  isAllowedMime,
  ATTACHMENT_MAX_SIZE_BYTES,
  saveAttachment,
  getAttachmentMeta,
  getAttachmentBinary,
  deleteAttachment,
} from '../workers/_shared/attachments.ts';

describe('attachments validation', () => {
  it('accepte JPG/PNG/WEBP/PDF', async () => {
    expect(isAllowedMime('image/jpeg')).toBe(true);
    expect(isAllowedMime('image/png')).toBe(true);
    expect(isAllowedMime('image/webp')).toBe(true);
    expect(isAllowedMime('application/pdf')).toBe(true);
    expect(isAllowedMime('application/msword')).toBe(false);
    expect(isAllowedMime('text/plain')).toBe(false);
  });

  it('refuse taille excessive', async () => {
    const r = validateAttachmentInput({
      fileName: 'big.jpg',
      mimeType: 'image/jpeg',
      size: ATTACHMENT_MAX_SIZE_BYTES + 1,
    });
    expect(r.ok).toBe(false);
  });

  it('refuse MIME interdit', async () => {
    const r = validateAttachmentInput({
      fileName: 'x.exe',
      mimeType: 'application/octet-stream',
      size: 100,
    });
    expect(r.ok).toBe(false);
  });

  it('nettoie le nom de fichier', async () => {
    const r = validateAttachmentInput({
      fileName: '../../etc/passwd.png',
      mimeType: 'image/png',
      size: 50,
    });
    expect(r.ok).toBe(true);
    if (r.ok) expect(r.fileName).not.toContain('..');
  });
});

describe('attachments isolation (dev store)', () => {
  it('user A ne lit pas le fichier de user B', async () => {
    const tiny = Buffer.from('fake-image-bytes').toString('base64');
    const saved = await saveAttachment({
      userId: 'user-a',
      fileName: 'exo.jpg',
      mimeType: 'image/jpeg',
      size: 16,
      base64Data: tiny,
    });
    expect(saved.ok).toBe(true);
    if (!saved.ok) return;

    const metaB = await getAttachmentMeta('user-b', saved.meta.id);
    expect(metaB).toBeNull();

    const binB = await getAttachmentBinary('user-b', saved.meta.id);
    expect(binB).toBeNull();

    const binA = await getAttachmentBinary('user-a', saved.meta.id);
    expect(binA).not.toBeNull();
    expect(binA!.meta.fileName).toBe('exo.jpg');

    await deleteAttachment('user-a', saved.meta.id);
  });

  it('utilisateur non authentifié (userId vide) est refusé', async () => {
    const r = await saveAttachment({
      userId: '',
      fileName: 'x.png',
      mimeType: 'image/png',
      size: 10,
      base64Data: 'aaaa',
    });
    expect(r.ok).toBe(false);
  });
});
