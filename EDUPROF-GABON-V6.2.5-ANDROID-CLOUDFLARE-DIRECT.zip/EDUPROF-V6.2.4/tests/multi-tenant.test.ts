import { describe, it, expect, beforeEach } from 'vitest';
import {
  resetInstitutionalStore,
  resetMemberships,
  createEstablishment,
  activateStudent,
  deactivateStudent,
  renewStudent,
  bulkActivate,
  parseStudentsCsv,
  listInstitutionalAudit,
  upsertActivation,
  refreshActivationStatus,
  resolveEstablishmentContext,
  assertTenantWrite,
  listVisibleEstablishments,
  upsertMembership,
  revokeMembership,
  getMembership,
  hasActiveMembership,
  runInstitutionalMaintenance,
  resetMaintenanceState,
  getExpiringBuckets,
  InstitutionalRepository,
  canAccessEstablishment,
} from '../workers/_shared/institutional/index.ts';
import type { UserRecord } from '../workers/_shared/types.ts';

function U(p: Partial<UserRecord> & Pick<UserRecord, 'id' | 'role'>): UserRecord {
  return {
    email: `${p.id}@t.ga`,
    passwordHash: 'x',
    displayName: p.id,
    educationLevel: '3e',
    educationSeries: null,
    educationFiliere: null,
    isPremium: false,
    premiumUntil: null,
    xp: 0,
    streak: 0,
    lastActivityDate: null,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    establishmentId: null,
    ...p,
  };
}

describe('V4.3 multi-tenant isolation hostile', () => {
  let estA: string;
  let estB: string;
  let adminA: UserRecord;
  let adminB: UserRecord;
  let studentA: UserRecord;
  let studentB: UserRecord;

  beforeEach(async () => {
    resetInstitutionalStore();
    resetMemberships();
    resetMaintenanceState();
    const a = await createEstablishment({ name: 'Lycée A', code: 'TA' });
    const b = await createEstablishment({ name: 'Lycée B', code: 'TB' });
    estA = a.id;
    estB = b.id;
    adminA = U({ id: 'adminA', role: 'ESTABLISHMENT_ADMIN', establishmentId: estA });
    adminB = U({ id: 'adminB', role: 'ESTABLISHMENT_ADMIN', establishmentId: estB });
    studentA = U({ id: 'studentA', role: 'STUDENT', establishmentId: estA });
    studentB = U({ id: 'studentB', role: 'STUDENT', establishmentId: estB });
    await upsertMembership({ userId: adminA.id, establishmentId: estA, role: 'ESTABLISHMENT_ADMIN' });
    await upsertMembership({ userId: adminB.id, establishmentId: estB, role: 'ESTABLISHMENT_ADMIN' });
    await upsertMembership({ userId: studentA.id, establishmentId: estA, role: 'STUDENT' });
    await upsertMembership({ userId: studentB.id, establishmentId: estB, role: 'STUDENT' });
  });

  it('A→A OK, A→B 403 (context)', async () => {
    const ok = await resolveEstablishmentContext(adminA, estA);
    expect(ok.ok).toBe(true);
    const bad = await resolveEstablishmentContext(adminA, estB);
    expect(bad.ok).toBe(false);
    if (!bad.ok) expect(bad.status).toBe(403);
  });

  it('assertTenantWrite A→B refusé', async () => {
    const w = await assertTenantWrite(adminA, estB);
    expect(w.ok).toBe(false);
  });

  it('adminA ne voit que établissement A', async () => {
    const list = await listVisibleEstablishments(adminA);
    expect(list.every((e) => e.id === estA)).toBe(true);
    expect(list.some((e) => e.id === estB)).toBe(false);
  });

  it('adminA ne peut pas activer studentB', async () => {
    const write = await assertTenantWrite(adminA, estB);
    expect(write.ok).toBe(false);
    // même si on force l'appel métier avec estA sur studentB
    const r = await bulkActivate({
      users: [studentB],
      establishmentId: estA,
      days: 10,
      actor: adminA,
    });
    expect(r.failed.some((f) => f.userId === 'studentB')).toBe(true);
  });

  it('establishmentId client ne contourne pas isolation', async () => {
    // adminA demande explicitement B
    const ctx = await resolveEstablishmentContext(adminA, estB);
    expect(ctx.ok).toBe(false);
  });

  it('OWNER peut cibler B', async () => {
    const owner = U({ id: 'owner1', role: 'OWNER' });
    const ctx = await resolveEstablishmentContext(owner, estB);
    expect(ctx.ok).toBe(true);
  });
});

describe('Membership lifecycle', () => {
  beforeEach(async () => {
    resetInstitutionalStore();
    resetMemberships();
  });

  it('create activate revoke', async () => {
    const est = await createEstablishment({ name: 'M', code: 'M1' });
    const actor = U({ id: 'ow', role: 'OWNER' });
    const m = await upsertMembership({ userId: 'u1', establishmentId: est.id, role: 'STUDENT' });
    expect(m.status).toBe('ACTIVE');
    expect((await getMembership('u1', est.id))?.status).toBe('ACTIVE');
    const user = U({ id: 'u1', role: 'STUDENT', establishmentId: est.id });
    expect(await hasActiveMembership(user, est.id)).toBe(true);
    await revokeMembership('u1', est.id);
    expect((await getMembership('u1', est.id))?.status).toBe('REVOKED');
    // memberships persist via repository (audit optionnel)
    expect((await getMembership('u1', est.id))?.status).toBe('REVOKED');
  });
});

describe('Maintenance automation', () => {
  beforeEach(async () => {
    resetInstitutionalStore();
    resetMemberships();
    resetMaintenanceState();
  });

  it('0 activations → 0 expired', async () => {
    const s = await runInstitutionalMaintenance({ recordAudit: true });
    expect(s.expired).toBe(0);
    expect(s.processed).toBe(0);
  });

  it('active dépassée → expired ; revoked reste revoked', async () => {
    const est = await createEstablishment({ name: 'E', code: 'EX' });
    const past = new Date(Date.now() - 1000).toISOString();
    await upsertActivation({
      userId: 'u-exp',
      establishmentId: est.id,
      status: 'active',
      expiresAt: past,
    });
    await upsertActivation({
      userId: 'u-rev',
      establishmentId: est.id,
      status: 'revoked',
      expiresAt: past,
    });
    const s1 = await runInstitutionalMaintenance({ recordAudit: true });
    expect(s1.expired).toBe(1);
    const s2 = await runInstitutionalMaintenance({ recordAudit: true });
    expect(s2.expired).toBe(0); // idempotent
    const acts = await InstitutionalRepository.activations.list({ establishmentId: est.id });
    expect(acts.find((a) => a.userId === 'u-exp')?.status).toBe('expired');
    expect(acts.find((a) => a.userId === 'u-rev')?.status).toBe('revoked');
  });

  it('buckets expiring soon', async () => {
    const est = await createEstablishment({ name: 'E', code: 'SOON' });
    const in2d = new Date(Date.now() + 1.5 * 86400000).toISOString();
    await upsertActivation({
      userId: 'u-soon',
      establishmentId: est.id,
      status: 'active',
      expiresAt: in2d,
    });
    const b = await getExpiringBuckets();
    expect(b.in1d.length + b.in3d.length).toBeGreaterThan(0);
  });
});

describe('CSV tenant-aware', () => {
  it('parse toujours strict', async () => {
    const r = parseStudentsCsv(`studentId,firstName,lastName,level,establishmentCode
S1,A,B,3e,TB`);
    expect(r.ok).toBe(true);
  });
});

describe('Repository abstraction', () => {
  it('backend memory documenté', async () => {
    expect(['memory','d1','memory-or-d1']).toContain(InstitutionalRepository.backend as string);
    expect(String(InstitutionalRepository.futureBackend)).toMatch(/d1|blobs|cloudflare/i);
  });
});
