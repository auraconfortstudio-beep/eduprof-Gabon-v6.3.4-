import { describe, it, expect, beforeEach } from 'vitest';
import {
  createNotification,
  listNotifications,
  markNotificationRead,
  markAllNotificationsRead,
  deleteNotification,
  resetNotifications,
  PushNotificationProvider,
} from '../workers/_shared/notifications.ts';

describe('notifications', () => {
  beforeEach(async () => resetNotifications());

  it('création et list', async () => {
    createNotification({
      userId: 'u1',
      type: 'SYSTEM',
      title: 'Bienvenue',
      message: 'Hello',
      metadata: { password: 'secret', days: 3 },
    });
    const r = listNotifications('u1');
    expect(r.total).toBe(1);
    expect(r.unread).toBe(1);
    expect(r.items[0].metadata?.password).toBeUndefined();
    expect(r.items[0].metadata?.days).toBe(3);
  });

  it('mark read + all', async () => {
    const n = createNotification({ userId: 'u1', type: 'COURSE', title: 'T', message: 'M' });
    expect(markNotificationRead('u1', n.id)).toBe(true);
    expect(listNotifications('u1').unread).toBe(0);
    createNotification({ userId: 'u1', type: 'QUIZ', title: 'Q', message: 'M' });
    expect(markAllNotificationsRead('u1')).toBe(1);
  });

  it('isolation user', async () => {
    createNotification({ userId: 'a', type: 'ADMIN', title: 'A', message: 'x' });
    createNotification({ userId: 'b', type: 'ADMIN', title: 'B', message: 'y' });
    expect(listNotifications('a').items.every((n) => n.userId === 'a')).toBe(true);
    expect(listNotifications('b').total).toBe(1);
  });

  it('push désactivé', async () => {
    expect(PushNotificationProvider.enabled).toBe(false);
  });

  it('delete', async () => {
    const n = createNotification({ userId: 'u1', type: 'SYSTEM', title: 'T', message: 'M' });
    expect(deleteNotification('u1', n.id)).toBe(true);
    expect(listNotifications('u1').total).toBe(0);
  });
});
