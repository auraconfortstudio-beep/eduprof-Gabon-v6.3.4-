/**
 * Security & XP unit tests (Vitest)
 * These test pure logic modules without Netlify runtime.
 */
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { readFileSync, existsSync } from 'fs';
import { join } from 'path';

const indexPath = join(process.cwd(), 'workers/_shared/content-index.json');

describe('Content index', () => {
  it('exists and has lessons', async () => {
    expect(existsSync(indexPath)).toBe(true);
    const idx = JSON.parse(readFileSync(indexPath, 'utf-8'));
    expect(Object.keys(idx.lessons).length).toBeGreaterThan(20);
    expect(Object.keys(idx.exercises).length).toBeGreaterThan(20);
    expect(Object.keys(idx.quizQuestions || {}).length).toBeGreaterThan(50);
  });

  it('known lesson id is present', async () => {
    const idx = JSON.parse(readFileSync(indexPath, 'utf-8'));
    // Curriculum 2024-2025
    expect(idx.lessons['cm2-mathematiques-c1-nombres-et-operations-lecon1']).toBeTruthy();
  });

  it('FAKE ids are absent', async () => {
    const idx = JSON.parse(readFileSync(indexPath, 'utf-8'));
    expect(idx.lessons['FAKE']).toBeUndefined();
    expect(idx.exercises['exerciseId=FAKE']).toBeUndefined();
    expect(idx.exercises['FAKE']).toBeUndefined();
  });
});

describe('Constants', () => {
  it('premium prices fixed', async () => {
    const src = readFileSync(join(process.cwd(), 'src/lib/constants.ts'), 'utf-8');
    expect(src).toMatch(/PREMIUM_DAILY\s*=\s*500/);
    expect(src).toMatch(/PREMIUM_MONTHLY\s*=\s*4000/);
    expect(src).toMatch(/065607226/);
  });

  it('XP values centralized', async () => {
    const src = readFileSync(join(process.cwd(), 'src/lib/constants.ts'), 'utf-8');
    expect(src).toMatch(/XP_LESSON\s*=\s*10/);
    expect(src).toMatch(/XP_EXERCISE\s*=\s*15/);
    expect(src).toMatch(/XP_QUIZ_MAX\s*=\s*50/);
  });
});

describe('No Supabase dependency', () => {
  it('package.json has no supabase', async () => {
    const pkg = JSON.parse(readFileSync(join(process.cwd(), 'package.json'), 'utf-8'));
    const all = { ...pkg.dependencies, ...pkg.devDependencies };
    expect(Object.keys(all).some((k) => k.includes('supabase'))).toBe(false);
  });

  it('no VITE_SUPABASE in vite-env', async () => {
    const src = readFileSync(join(process.cwd(), 'src/vite-env.d.ts'), 'utf-8');
    expect(src).not.toMatch(/VITE_SUPABASE/);
  });
});

describe('API source guards (static)', () => {
  it('progress endpoints reject client wasCorrect trust pattern', async () => {
    const api = readFileSync(join(process.cwd(), 'workers/api.ts'), 'utf-8');
    // Server must compute wasCorrect from selectedAnswer
    expect(api).toMatch(/selectedAnswer/);
    expect(api).toMatch(/getExerciseCorrectAnswer/);
    expect(api).toMatch(/getLesson/);
    expect(api).toMatch(/getQuizQuestions/);
    // Must not award XP solely from body.wasCorrect
    expect(api).not.toMatch(/if \(wasCorrect\) \{\s*xpGain = 15/);
  });

  it('AI requires auth', async () => {
    const ai = readFileSync(join(process.cwd(), 'workers/ai-tutor.ts'), 'utf-8');
    // JWT obligatoire : header Authorization et/ou body.token, toujours verifyToken
    expect(ai).toMatch(/verifyToken/);
    expect(ai).toMatch(/getUserById|getAuthUser/);
    expect(ai).toMatch(/Connexion requise/);
    expect(ai).toMatch(/checkRateLimit/);
    // Pas de bypass : token body doit passer par verifyToken
    expect(ai).toMatch(/body\.token/);
  });

  it('OWNER protections present', async () => {
    const api = readFileSync(join(process.cwd(), 'workers/api.ts'), 'utf-8');
    expect(api).toMatch(/Impossible de supprimer l'OWNER/);
    expect(api).toMatch(/Impossible de modifier le rôle de l'OWNER/);
    expect(api).toMatch(/Seul l'OWNER peut gérer les rôles/);
  });
});

describe('Rate limit middleware (static)', () => {
  const rlPath = join(process.cwd(), 'workers/_shared/rateLimit.ts');

  it('exports middleware helpers and preserves auth lockout', async () => {
    const src = readFileSync(rlPath, 'utf-8');
    expect(src).toMatch(/export async function checkRateLimit/);
    expect(src).toMatch(/export async function enforceRateLimit/);
    expect(src).toMatch(/export function rateLimitResponse/);
    expect(src).toMatch(/export function getClientIp/);
    expect(src).toMatch(/export const RATE_PRESETS/);
    expect(src).toMatch(/export async function recordFailedLogin/);
    expect(src).toMatch(/export async function isLoginBlocked/);
    expect(src).toMatch(/export async function clearFailedLogin/);
  });

  it('presets include signup and write limits', async () => {
    const src = readFileSync(rlPath, 'utf-8');
    expect(src).toMatch(/SIGNUP_IP/);
    expect(src).toMatch(/API_WRITE_IP/);
    expect(src).toMatch(/PREMIUM_REQUEST_USER/);
  });

  it('api uses enforceRateLimit on signup and progress writes', async () => {
    const api = readFileSync(join(process.cwd(), 'workers/api.ts'), 'utf-8');
    expect(api).toMatch(/enforceRateLimit/);
    expect(api).toMatch(/RATE_PRESETS\.SIGNUP_IP/);
    expect(api).toMatch(/RATE_PRESETS\.API_WRITE_IP/);
    expect(api).toMatch(/RATE_PRESETS\.PREMIUM_REQUEST_USER/);
    expect(api).toMatch(/isLoginBlocked/);
    expect(api).toMatch(/recordFailedLogin/);
  });

  it('AI keeps dedicated limits and uses rateLimitResponse', async () => {
    const ai = readFileSync(join(process.cwd(), 'workers/ai-tutor.ts'), 'utf-8');
    expect(ai).toMatch(/AI_RATE_LIMIT_PER_MINUTE/);
    expect(ai).toMatch(/AI_RATE_LIMIT_PER_DAY/);
    expect(ai).toMatch(/ai:user:/);
    expect(ai).toMatch(/ai:ip:/);
    expect(ai).toMatch(/rateLimitResponse/);
    expect(ai).toMatch(/getClientIp/);
  });

  it('429 responses include Retry-After via rateLimitResponse', async () => {
    const src = readFileSync(rlPath, 'utf-8');
    expect(src).toMatch(/Retry-After/);
    expect(src).toMatch(/status: 429/);
  });
});

describe('V3.5.1 AI Tutor routing & timeout', () => {
  it('frontend calls /api/ai-tutor (not bare /.workers)', async () => {
    const src = readFileSync(join(process.cwd(), 'src/lib/api.ts'), 'utf-8');
    expect(src).toMatch(/\$\{API_BASE\}\/ai-tutor|\/api\/ai-tutor/);
    expect(src).not.toMatch(/fetch\('\/\.netlify\/functions\/ai-tutor'/);
    expect(src).toMatch(/AbortController/);
    expect(src).toMatch(/25_000|25000/);
  });

  it('vite dev plugin routes /api/ai-tutor to ai-tutor.ts', async () => {
    const src = readFileSync(join(process.cwd(), 'vite.config.ts'), 'utf-8');
    expect(src).toMatch(/ai-tutor\.ts/);
    expect(src).toMatch(/\/api\/ai-tutor/);
  });

  it('wrangler.toml Workers + cron Cloudflare', async () => {
    const src = readFileSync(join(process.cwd(), 'wrangler.toml'), 'utf-8');
    expect(src).toMatch(/workers\/index/);
    expect(src).toMatch(/crons/);
    expect(src).toMatch(/eduprof/);
  });

  it('AITutorPage persists history in sessionStorage', async () => {
    const src = readFileSync(join(process.cwd(), 'src/components/AITutorPage.tsx'), 'utf-8');
    expect(src).toMatch(/sessionStorage/);
    expect(src).toMatch(/eduprof_ai_chat/);
    expect(src).toMatch(/loadHistory|STORAGE_KEY/);
  });

  it('AITutorPage always clears loading in finally', async () => {
    const src = readFileSync(join(process.cwd(), 'src/components/AITutorPage.tsx'), 'utf-8');
    expect(src).toMatch(/finally\s*\{[\s\S]*setLoading\(false\)/);
  });
});

describe('V3.5.1 Progress page anti-flicker', () => {
  it('does not call refreshProfile inside load effect', async () => {
    const src = readFileSync(join(process.cwd(), 'src/components/ProgressPage.tsx'), 'utf-8');
    expect(src).not.toMatch(/await refreshProfile\(/);
    expect(src).toMatch(/user\?\.id/);
  });

  it('App waits for authLoading before progress/auth switch', async () => {
    const src = readFileSync(join(process.cwd(), 'src/App.tsx'), 'utf-8');
    expect(src).toMatch(/authLoading/);
    expect(src).toMatch(/loading:\s*authLoading/);
  });
});

describe('V3.5.2 Progress XP recovery', () => {
  it('ProgressPage loads XP from GET /progress profile (not loadedForUser skip)', async () => {
    const src = readFileSync(join(process.cwd(), 'src/components/ProgressPage.tsx'), 'utf-8');
    // V3.5.1 bug: loadedForUser early-return blocked StrictMode re-fetch
    expect(src).not.toMatch(/loadedForUser/);
    expect(src).toMatch(/getProgress/);
    expect(src).toMatch(/setServerXp/);
    expect(src).toMatch(/data\.profile\.xp/);
    expect(src).toMatch(/myRank/);
    expect(src).toMatch(/api\.leaderboard/);
  });

  it('api.leaderboard types include myRank', async () => {
    const src = readFileSync(join(process.cwd(), 'src/lib/api.ts'), 'utf-8');
    expect(src).toMatch(/myRank/);
    expect(src).toMatch(/getProgress/);
  });

  it('backend progress endpoint returns profile with xp', async () => {
    const api = readFileSync(join(process.cwd(), 'workers/api.ts'), 'utf-8');
    expect(api).toMatch(/path === '\/progress'/);
    expect(api).toMatch(/fullProfile\(user\)/);
    expect(api).toMatch(/getProgress\(user\.id\)/);
  });

  it('backend leaderboard returns myRank', async () => {
    const api = readFileSync(join(process.cwd(), 'workers/api.ts'), 'utf-8');
    expect(api).toMatch(/myRank/);
    expect(api).toMatch(/rank:\s*idx\s*\+\s*1/);
  });
});

describe('V3.5.3 Annales navigation', () => {
  it('HomePage navigates to annales', async () => {
    const src = readFileSync(join(process.cwd(), 'src/components/HomePage.tsx'), 'utf-8');
    expect(src).toMatch(/onNavigate\(['"]annales['"]\)/);
    expect(src).toMatch(/label="Annales"/);
  });

  it('App routes page annales to AnnalesPage', async () => {
    const src = readFileSync(join(process.cwd(), 'src/App.tsx'), 'utf-8');
    expect(src).toMatch(/case ['"]annales['"]/);
    expect(src).toMatch(/<AnnalesPage/);
    expect(src).toMatch(/navigate\(['"]annales['"]\)/);
  });

  it('AnnalesPage exports and uses local catalog fallback', async () => {
    const src = readFileSync(join(process.cwd(), 'src/components/AnnalesPage.tsx'), 'utf-8');
    expect(src).toMatch(/ANNALES_CATALOG/);
    expect(src).toMatch(/export function AnnalesPage/);
  });
});

describe('V3.5.4 Annales non-blocking catalog', () => {
  it('AnnalesPage initializes from ANNALES_CATALOG immediately', async () => {
    const src = readFileSync(join(process.cwd(), 'src/components/AnnalesPage.tsx'), 'utf-8');
    expect(src).toMatch(/useState<AnnaleEntry\[\]>\(\(\) =>/);
    expect(src).toMatch(/ANNALES_CATALOG/);
    expect(src).not.toMatch(/Chargement des annales/);
  });

  it('API failure does not clear local catalog', async () => {
    const src = readFileSync(join(process.cwd(), 'src/components/AnnalesPage.tsx'), 'utf-8');
    expect(src).toMatch(/api\.getAnnales/);
    expect(src).toMatch(/catch/);
    expect(src).not.toMatch(/setItems\(\[\]\)/);
  });

  it('API success with non-empty list can replace local catalog', async () => {
    const src = readFileSync(join(process.cwd(), 'src/components/AnnalesPage.tsx'), 'utf-8');
    expect(src).toMatch(/mapped\.length > 0/);
    expect(src).toMatch(/setItems\(mapped\)/);
    expect(src).toMatch(/setSource\(['"]api['"]\)/);
  });

  it('local placeholders remain non-official', async () => {
    const data = readFileSync(join(process.cwd(), 'src/data/annales.ts'), 'utf-8');
    expect(data).toMatch(/official:\s*false/);
    expect(data).toMatch(/verificationStatus:\s*['"]placeholder['"]/);
    expect(data).not.toMatch(/verificationStatus:\s*['"]verified_official['"]/);
  });

  it('server annales write routes stay admin-protected', async () => {
    const api = readFileSync(join(process.cwd(), 'workers/api.ts'), 'utf-8');
    expect(api).toMatch(/\/annales/);
    expect(api).toMatch(/isAdminOrOwner/);
  });
});

describe('V3.5.3 Progress isolation by userId', () => {
  it('local lesson storage is keyed by userId', async () => {
    const src = readFileSync(join(process.cwd(), 'src/lib/progress.ts'), 'utf-8');
    expect(src).toMatch(/eduprof_completed_lessons:uid:/);
    expect(src).toMatch(/function storageKey/);
    expect(src).toMatch(/isLessonCompletedLocally\(lessonId: string, userId/);
    // Ancienne clé globale ne doit plus être écrite
    expect(src).toMatch(/LEGACY_GLOBAL_KEY/);
    expect(src).toMatch(/clearLegacyGlobalLessonProgress/);
  });

  it('SubjectPage passes userId to lesson completion', async () => {
    const src = readFileSync(join(process.cwd(), 'src/components/SubjectPage.tsx'), 'utf-8');
    expect(src).toMatch(/completeLesson\(lesson\.id,\s*userId\)/);
    expect(src).toMatch(/userId=\{user\?\.id/);
    expect(src).not.toMatch(/setCompleted\(true\);\s*onComplete\(\)/);
  });

  it('server progress is keyed by user.id', async () => {
    const api = readFileSync(join(process.cwd(), 'workers/api.ts'), 'utf-8');
    expect(api).toMatch(/getProgress\(user\.id\)/);
    expect(api).toMatch(/saveProgress\(progress\)/);
  });
});

describe('V3.5.3 Owner/Admin server protection', () => {
  it('admin routes require isAdminOrOwner or isOwner on server', async () => {
    const api = readFileSync(join(process.cwd(), 'workers/api.ts'), 'utf-8');
    expect(api).toMatch(/\/admin\/users/);
    expect(api).toMatch(/isAdminOrOwner/);
    expect(api).toMatch(/Seul l'OWNER peut gérer les rôles/);
    expect(api).toMatch(/Seul l'OWNER peut supprimer/);
  });

  it('auth helpers define OWNER and ADMIN roles', async () => {
    const auth = readFileSync(join(process.cwd(), 'workers/_shared/auth.ts'), 'utf-8');
    expect(auth).toMatch(/export function isOwner/);
    expect(auth).toMatch(/export function isAdminOrOwner/);
    expect(auth).toMatch(/isOwnerEmail/);
    expect(auth).toMatch(/role === 'OWNER'/);
    expect(auth).toMatch(/role === 'ADMIN'/);
  });

  it('App gates admin page on isAdmin (UI only)', async () => {
    const src = readFileSync(join(process.cwd(), 'src/App.tsx'), 'utf-8');
    expect(src).toMatch(/case ['"]admin['"]/);
    expect(src).toMatch(/isAdmin \?/);
  });

  it('frontend isAdmin is not the only protection — server checks exist', async () => {
    const api = readFileSync(join(process.cwd(), 'workers/api.ts'), 'utf-8');
    // Au moins 3 protections serveur distinctes
    const matches = api.match(/isAdminOrOwner\(user\)/g) || [];
    expect(matches.length).toBeGreaterThanOrEqual(3);
  });
});

describe('V3.5.4.1 LOT1 QuizView hooks + progression', () => {
  const subjectSrc = () =>
    readFileSync(join(process.cwd(), 'src/components/SubjectPage.tsx'), 'utf-8');
  const progressSrc = () =>
    readFileSync(join(process.cwd(), 'src/lib/progress.ts'), 'utf-8');

  it('QuizView keeps every hook above early returns', async () => {
    const src = subjectSrc();
    const start = src.indexOf('function QuizView');
    expect(start).toBeGreaterThan(-1);
    const body = src.slice(start);
    const useEffectPos = body.indexOf('useEffect(');
    const emptyReturnPos = body.search(/if\s*\(!quiz\.length\)/);
    const finishedReturnPos = body.search(/if\s*\(finished\)/);
    expect(useEffectPos).toBeGreaterThan(-1);
    expect(emptyReturnPos).toBeGreaterThan(-1);
    expect(finishedReturnPos).toBeGreaterThan(-1);
    expect(useEffectPos).toBeLessThan(emptyReturnPos);
    expect(useEffectPos).toBeLessThan(finishedReturnPos);
    expect(body).toMatch(/useCallback/);
    expect(body).toMatch(/useRef\(false\)/);
  });

  it('LessonView does not mark completed before server confirmation', async () => {
    const src = subjectSrc();
    const start = src.indexOf('function LessonView');
    const body = src.slice(start, src.indexOf('function ExercisesView'));
    expect(body).toMatch(/setSaving\(true\)/);
    expect(body).toMatch(/completeLesson\(lesson\.id,\s*userId\)/);
    expect(body).toMatch(/if \(res\.completed\)/);
    expect(body).toMatch(/setCompleted\(true\)/);
    expect(body).toMatch(/setCompleted\(false\)/);
    expect(body).toMatch(/Réessayer/);
    expect(body).not.toMatch(/setCompleted\(true\);\s*onComplete/);
  });

  it('completeLesson writes local cache only after server success for logged-in users', async () => {
    const src = progressSrc();
    expect(src).toMatch(/const completed = res\.completed === true/);
    expect(src).toMatch(/if \(completed\) \{\s*markLessonCompletedLocally/s);
    expect(src).toMatch(/completed:\s*false/);
    expect(src).toMatch(/error:\s*message/);
    // Must not still treat API failure as success
    expect(src).not.toMatch(/completed:\s*true,\s*\n\s*xpAwarded:\s*false,\s*\n\s*xpGain:\s*0,\s*\n\s*error:/);
  });

  it('quiz submit exposes recorded=false + error and UI can retry', async () => {
    const progress = progressSrc();
    expect(progress).toMatch(/recorded:\s*false/);
    expect(progress).toMatch(/xpAmount:\s*0/);
    const src = subjectSrc();
    expect(src).toMatch(/submitState === 'error'/);
    expect(src).toMatch(/Réessayer l['']enregistrement|Réessayer l'enregistrement/);
    expect(src).toMatch(/submittedRef\.current = false/);
    expect(src).toMatch(/submitState === 'saved'/);
    expect(src).toMatch(/Score enregistré/);
  });
});

describe('V3.5.4.1 LOT1 completeLesson runtime', () => {
  beforeEach(async () => {
    const mem = new Map<string, string>();
    vi.stubGlobal('localStorage', {
      getItem: (k: string) => (mem.has(k) ? mem.get(k)! : null),
      setItem: (k: string, v: string) => {
        mem.set(k, v);
      },
      removeItem: (k: string) => {
        mem.delete(k);
      },
      clear: () => mem.clear(),
      key: () => null,
      get length() {
        return mem.size;
      },
    });
  });

  afterEach(() => {
    vi.unstubAllGlobals();
    vi.restoreAllMocks();
    vi.resetModules();
  });

  it('guest persists locally without calling the API', async () => {
    const fetchMock = vi.fn();
    vi.stubGlobal('fetch', fetchMock);
    const { completeLesson, isLessonCompletedLocally } = await import('../src/lib/progress');
    const res = await completeLesson('lesson-guest-1', null);
    expect(res.completed).toBe(true);
    expect(res.localOnly).toBe(true);
    expect(isLessonCompletedLocally('lesson-guest-1', null)).toBe(true);
    expect(fetchMock).not.toHaveBeenCalled();
  });

  it('logged-in failure does not mark the lesson complete locally', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn().mockResolvedValue({
        ok: false,
        status: 500,
        json: async () => ({ error: 'panne serveur' }),
      })
    );
    const { completeLesson, isLessonCompletedLocally } = await import('../src/lib/progress');
    const res = await completeLesson('lesson-user-1', 'user-abc');
    expect(res.completed).toBe(false);
    expect(res.error).toMatch(/panne serveur|Erreur 500/);
    expect(isLessonCompletedLocally('lesson-user-1', 'user-abc')).toBe(false);
  });

  it('logged-in success writes the local cache', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn().mockResolvedValue({
        ok: true,
        status: 200,
        json: async () => ({ completed: true, xpAwarded: true, xp: 10, xpGain: 10 }),
      })
    );
    const { completeLesson, isLessonCompletedLocally } = await import('../src/lib/progress');
    const res = await completeLesson('lesson-user-2', 'user-abc');
    expect(res.completed).toBe(true);
    expect(isLessonCompletedLocally('lesson-user-2', 'user-abc')).toBe(true);
  });
});
