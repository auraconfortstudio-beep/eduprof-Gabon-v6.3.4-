import { describe, it, expect, beforeEach } from 'vitest';
import {
  hasPermission,
  canAccessEstablishment,
  assertEstablishmentAccess,
  createEstablishment,
  getEstablishmentByCode,
  listEstablishments,
  updateEstablishment,
  resetInstitutionalStore,
  resetMemberships,
  parseStudentsCsv,
  activateStudent,
  deactivateStudent,
  renewStudent,
  bulkActivate,
  listActivations,
  listInstitutionalAudit,
  refreshActivationStatus,
  upsertActivation,
} from '../workers/_shared/institutional/index.ts';
import type { UserRecord } from '../workers/_shared/types.ts';

function fakeUser(partial: Partial<UserRecord> & Pick<UserRecord, 'id' | 'role'>): UserRecord {
  return {
    email: `${partial.id}@test.ga`,
    passwordHash: 'x',
    displayName: partial.id,
    educationLevel: '3e',
    educationSeries: null,
    educationFiliere: null,
    isPremium: false,
    premiumUntil: null,
    xp: 0,
    streak: 0,
    lastActivityDate: null,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    establishmentId: null,
    ...partial,
  };
}

describe('RBAC permissions', () => {
  it('OWNER a tous les droits', async () => {
    const u = fakeUser({ id: 'o1', role: 'OWNER' });
    expect(hasPermission(u, 'roles.manage')).toBe(true);
    expect(hasPermission(u, 'csv.import')).toBe(true);
  });

  it('ESTABLISHMENT_ADMIN ne gère pas les rôles globaux', async () => {
    const u = fakeUser({ id: 'ea1', role: 'ESTABLISHMENT_ADMIN', establishmentId: 'est-a' });
    expect(hasPermission(u, 'students.activate')).toBe(true);
    expect(hasPermission(u, 'roles.manage')).toBe(false);
    expect(hasPermission(u, 'establishments.create')).toBe(false);
  });

  it('STUDENT sans permission admin', async () => {
    const u = fakeUser({ id: 's1', role: 'STUDENT' });
    expect(hasPermission(u, 'students.read')).toBe(false);
  });
});

describe('isolation multi-établissement', () => {
  beforeEach(async () => resetInstitutionalStore());

  it('A peut A, A ne peut pas B', async () => {
    const estA = await createEstablishment({ name: 'Lycée A', code: 'LYA' });
    const estB = await createEstablishment({ name: 'Lycée B', code: 'LYB' });
    const adminA = fakeUser({
      id: 'admin-a',
      role: 'ESTABLISHMENT_ADMIN',
      establishmentId: estA.id,
    });
    expect(canAccessEstablishment(adminA, estA.id)).toBe(true);
    expect(canAccessEstablishment(adminA, estB.id)).toBe(false);
    const denied = assertEstablishmentAccess(adminA, estB.id);
    expect(denied.ok).toBe(false);
    if (!denied.ok) expect(denied.status).toBe(403);
  });
});

describe('établissements', () => {
  beforeEach(async () => resetInstitutionalStore());

  it('création + code unique', async () => {
    const e = await createEstablishment({ name: 'Collège Test', code: 'col-test', type: 'college' });
    expect(e.code).toBe('COL-TEST');
    expect((await getEstablishmentByCode('col-test'))?.id).toBe(e.id);
    await expect(createEstablishment({ name: 'Dup', code: 'COL-TEST' })).rejects.toThrow();
    expect((await listEstablishments()).length).toBe(1);
  });

  it('update status', async () => {
    const e = await createEstablishment({ name: 'X', code: 'XX1' });
    const u = await updateEstablishment(e.id, { status: 'suspended' });
    expect(u?.status).toBe('suspended');
  });
});

describe('activation cycle de vie', () => {
  beforeEach(async () => resetInstitutionalStore());

  it('activate → renew → revoke', async () => {
    const est = await createEstablishment({ name: 'E', code: 'E1' });
    const student = fakeUser({ id: 'st1', role: 'USER', establishmentId: est.id });
    const actor = fakeUser({ id: 'act1', role: 'ESTABLISHMENT_ADMIN', establishmentId: est.id });
    const a = await activateStudent({ user: student, establishmentId: est.id, days: 30, actor });
    expect(a.ok).toBe(true);
    if (a.ok) expect(a.activation.status).toBe('active');
    expect(student.accessStatus).toBe('active');
    const r = await renewStudent({ user: student, establishmentId: est.id, days: 60, actor });
    expect(r.ok).toBe(true);
    await deactivateStudent({ user: student, establishmentId: est.id, actor, status: 'revoked' });
    expect(student.accessStatus).toBe('revoked');
    const logs = await listInstitutionalAudit({ establishmentId: est.id });
    expect(logs.some((l) => l.action === 'STUDENT_ACTIVATED')).toBe(true);
    expect(logs.some((l) => l.action === 'STUDENT_REVOKED')).toBe(true);
  });

  it('expiration serveur', async () => {
    const est = await createEstablishment({ name: 'E', code: 'E2' });
    const past = new Date(Date.now() - 86400000).toISOString();
    const act = await upsertActivation({
      userId: 'u-exp',
      establishmentId: est.id,
      status: 'active',
      expiresAt: past,
    });
    const refreshed = await refreshActivationStatus(act);
    expect(refreshed.status).toBe('expired');
  });

  it('bulk activation succès/échecs', async () => {
    const est = await createEstablishment({ name: 'E', code: 'E3' });
    const other = await createEstablishment({ name: 'O', code: 'O3' });
    const actor = fakeUser({ id: 'bulk-a', role: 'ADMIN' });
    const s1 = fakeUser({ id: 'b1', role: 'STUDENT', establishmentId: est.id });
    const s2 = fakeUser({ id: 'b2', role: 'STUDENT', establishmentId: other.id });
    const res = await bulkActivate({ users: [s1, s2], establishmentId: est.id, days: 10, actor });
    expect(res.success).toContain('b1');
    expect(res.failed.some((f) => f.userId === 'b2')).toBe(true);
  });
});

describe('CSV import', () => {
  it('CSV valide', async () => {
    const csv = `studentId,firstName,lastName,level,establishmentCode
S001,Jean,Mba,3e,LYA
S002,Aline,Nzue,cm2,LYA`;
    const r = parseStudentsCsv(csv);
    expect(r.ok).toBe(true);
    expect(r.rows.length).toBe(2);
  });

  it('CSV vide', async () => {
    const r = parseStudentsCsv('   ');
    expect(r.ok).toBe(false);
  });

  it('CSV malformé / colonnes manquantes', async () => {
    const r = parseStudentsCsv('a,b,c\n1,2,3');
    expect(r.ok).toBe(false);
  });

  it('doublons et niveau inconnu', async () => {
    const csv = `studentId,firstName,lastName,level,establishmentCode
S001,A,B,3e,LYA
S001,C,D,3e,LYA
S003,E,F,niveauZ,LYA`;
    const r = parseStudentsCsv(csv);
    expect(r.errors.length).toBeGreaterThan(0);
    expect(r.duplicatesInFile).toContain('S001');
  });

  it('champs manquants', async () => {
    const csv = `studentId,firstName,lastName,level,establishmentCode
S001,,Mba,3e,LYA`;
    const r = parseStudentsCsv(csv);
    expect(r.errors.some((e) => e.reason.includes('manquants'))).toBe(true);
  });
});
