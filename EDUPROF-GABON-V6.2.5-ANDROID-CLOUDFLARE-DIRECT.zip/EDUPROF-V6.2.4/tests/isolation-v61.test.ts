import { describe, it, expect, beforeEach } from 'vitest';
import {
  createEstablishment,
  resetInstitutionalStore,
  resetMemberships,
  activateStudent,
  assertEstablishmentAccess,
  canAccessEstablishment,
  listActivations,
} from '../workers/_shared/institutional/index.ts';
import { saveAttachment, getAttachmentMeta } from '../workers/_shared/attachments.ts';
import type { UserRecord } from '../workers/_shared/types.ts';

function U(p: Partial<UserRecord> & Pick<UserRecord, 'id' | 'role'>): UserRecord {
  return {
    email: `${p.id}@t.ga`,
    passwordHash: 'x',
    displayName: p.id,
    educationLevel: '3e',
    educationSeries: null,
    educationFiliere: null,
    isPremium: false,
    premiumUntil: null,
    xp: 0,
    streak: 0,
    lastActivityDate: null,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    establishmentId: null,
    ...p,
  };
}

describe('Isolation multi-tenant V6.1', () => {
  beforeEach(async () => {
    resetInstitutionalStore();
    resetMemberships();
  });

  it('OWNER accède A et B', async () => {
    const a = await createEstablishment({ name: 'A', code: 'IA' });
    const b = await createEstablishment({ name: 'B', code: 'IB' });
    const owner = U({ id: 'own', role: 'OWNER' });
    expect(canAccessEstablishment(owner, a.id)).toBe(true);
    expect(canAccessEstablishment(owner, b.id)).toBe(true);
  });

  it('ADMIN établissement A interdit sur B', async () => {
    const a = await createEstablishment({ name: 'A', code: 'IA2' });
    const b = await createEstablishment({ name: 'B', code: 'IB2' });
    const admA = U({ id: 'admA', role: 'ESTABLISHMENT_ADMIN', establishmentId: a.id });
    expect(canAccessEstablishment(admA, a.id)).toBe(true);
    expect(canAccessEstablishment(admA, b.id)).toBe(false);
    const denied = assertEstablishmentAccess(admA, b.id);
    expect(denied.ok).toBe(false);
    if (!denied.ok) expect(denied.status).toBe(403);
  });

  it('STUDENT A ne voit pas activations B', async () => {
    const a = await createEstablishment({ name: 'A', code: 'IA3' });
    const b = await createEstablishment({ name: 'B', code: 'IB3' });
    const stA = U({ id: 'stA', role: 'STUDENT', establishmentId: a.id });
    const stB = U({ id: 'stB', role: 'STUDENT', establishmentId: b.id });
    const actorA = U({ id: 'adm3', role: 'ESTABLISHMENT_ADMIN', establishmentId: a.id });
    await activateStudent({ user: stA, establishmentId: a.id, days: 30, actor: actorA });
    const actsB = await listActivations({ establishmentId: b.id, userId: stB.id });
    expect(actsB.length).toBe(0);
    const actsA = await listActivations({ establishmentId: a.id, userId: stA.id });
    expect(actsA.length).toBe(1);
  });

  it('Attachment A inaccessible à B', async () => {
    const tiny = btoa('hello');
    const saved = await saveAttachment({
      userId: 'userA',
      fileName: 'ex.jpg',
      mimeType: 'image/jpeg',
      base64Data: tiny,
      size: 5,
    });
    expect(saved.ok).toBe(true);
    if (!saved.ok) return;
    const metaB = await getAttachmentMeta('userB', saved.id);
    expect(metaB).toBeNull();
    const metaA = await getAttachmentMeta('userA', saved.id);
    expect(metaA).not.toBeNull();
  });
});
