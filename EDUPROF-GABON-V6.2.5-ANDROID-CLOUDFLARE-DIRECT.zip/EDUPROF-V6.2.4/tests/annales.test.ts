import { describe, it, expect } from 'vitest';
import {
  ANNALES_CATALOG,
  examDisplayName,
  examMatchesFilter,
  filterAnnales,
  getAnnaleById,
  hasCorrectionText,
  hasSubjectText,
  isOfficialAnnale,
  levelIdForExam,
  examForLevelId,
  listYearsForExam,
  listSubjectsForExamYear,
  buildAnnaleTutorContext,
  annalesStats,
  statusLabel,
} from '../src/data/annales';

describe('catalogue annales CEP / BEPC / BAC', () => {
  it('contient au moins une entrée CEP/CEPE, BEPC et BAC', async () => {
    const exams = new Set(ANNALES_CATALOG.map((a) => a.exam));
    expect(exams.has('CEPE') || exams.has('CEP')).toBe(true);
    expect(exams.has('BEPC')).toBe(true);
    expect(exams.has('BAC')).toBe(true);
  });

  it('IDs uniques, pas de doublons', async () => {
    const ids = ANNALES_CATALOG.map((a) => a.id);
    expect(new Set(ids).size).toBe(ids.length);
  });

  it('stats cohérentes', async () => {
    const s = annalesStats();
    expect(s.total).toBe(ANNALES_CATALOG.length);
    expect(s.total).toBeGreaterThan(10);
    expect(s.withSubjectText).toBeGreaterThan(5);
  });

  it('aucune annale inventée comme officielle sans statut vérifié', async () => {
    for (const a of ANNALES_CATALOG) {
      if (a.official) {
        expect(a.verificationStatus).toBe('verified_official');
      }
      if (a.verificationStatus !== 'verified_official') {
        expect(isOfficialAnnale(a)).toBe(false);
      }
    }
  });
});

describe('filtres année / matière', () => {
  it('examMatchesFilter CEP ↔ CEPE', async () => {
    expect(examMatchesFilter('CEPE', 'CEP')).toBe(true);
    expect(examMatchesFilter('CEP', 'CEPE')).toBe(true);
    expect(examMatchesFilter('BEPC', 'CEP')).toBe(false);
  });

  it('listYearsForExam et listSubjectsForExamYear', async () => {
    const years = listYearsForExam('BEPC');
    expect(years.length).toBeGreaterThan(0);
    const y = years[0];
    const subjects = listSubjectsForExamYear('BEPC', y);
    expect(subjects.length).toBeGreaterThan(0);
  });

  it('filterAnnales par examen et matière', async () => {
    const bepc = filterAnnales(ANNALES_CATALOG, { exam: 'BEPC' });
    expect(bepc.every((a) => a.exam === 'BEPC')).toBe(true);
    const maths = filterAnnales(ANNALES_CATALOG, { exam: 'BAC', subject: 'Mathématiques' });
    expect(maths.every((a) => a.subject === 'Mathématiques')).toBe(true);
  });

  it('getAnnaleById', async () => {
    const first = ANNALES_CATALOG[0];
    expect(getAnnaleById(first.id)?.id).toBe(first.id);
    expect(getAnnaleById('inexistant-xyz')).toBeUndefined();
  });
});

describe('énoncé / correction', () => {
  it('entrainement avec texte a énoncé', async () => {
    const withText = ANNALES_CATALOG.filter(hasSubjectText);
    expect(withText.length).toBeGreaterThan(0);
  });

  it('placeholder sans énoncé signalé correctement', async () => {
    const placeholders = ANNALES_CATALOG.filter((a) => a.verificationStatus === 'placeholder');
    for (const p of placeholders) {
      expect(hasSubjectText(p)).toBe(false);
    }
  });

  it('hasCorrectionText cohérent', async () => {
    for (const a of ANNALES_CATALOG) {
      if (hasCorrectionText(a)) {
        expect(a.correctionText!.trim().length).toBeGreaterThan(0);
      }
    }
  });
});

describe('lien parcours + Maël', () => {
  it('CEP → cm2, BEPC → 3e, BAC → terminale', async () => {
    expect(levelIdForExam('CEPE')).toBe('cm2');
    expect(levelIdForExam('CEP')).toBe('cm2');
    expect(levelIdForExam('BEPC')).toBe('3e');
    expect(levelIdForExam('BAC')).toBe('terminale');
    expect(examForLevelId('cm2')).toBe('CEPE');
    expect(examForLevelId('3e')).toBe('BEPC');
    expect(examForLevelId('terminale')).toBe('BAC');
  });

  it('buildAnnaleTutorContext ne présente pas un entraînement comme officiel', async () => {
    const training = ANNALES_CATALOG.find((a) => a.verificationStatus === 'edu_prof_training');
    expect(training).toBeTruthy();
    const ctx = buildAnnaleTutorContext(training!);
    expect(ctx.questionPrefix.toLowerCase()).toMatch(/non officiel|entraînement|entrainement/);
    expect(ctx.subjectName).toBe(training!.subject);
    expect(statusLabel('edu_prof_training')).toMatch(/Entraînement/i);
  });

  it('examDisplayName CEPE → CEP', async () => {
    expect(examDisplayName('CEPE')).toBe('CEP');
    expect(examDisplayName('BAC')).toBe('BAC');
  });
});
