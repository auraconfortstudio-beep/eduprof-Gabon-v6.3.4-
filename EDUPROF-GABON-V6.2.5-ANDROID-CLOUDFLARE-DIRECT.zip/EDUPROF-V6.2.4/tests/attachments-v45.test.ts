import { describe, it, expect } from 'vitest';
import {
  validateAttachmentInput,
  isDangerousExtension,
  extensionMatchesMime,
  sanitizeFileName,
  ATTACHMENT_MAX_SIZE_BYTES,
} from '../workers/_shared/attachments.ts';

describe('attachments v4.5 validation', () => {
  it('accepte image/pdf', async () => {
    expect(validateAttachmentInput({ fileName: 'a.png', mimeType: 'image/png', size: 100 }).ok).toBe(true);
    expect(validateAttachmentInput({ fileName: 'a.pdf', mimeType: 'application/pdf', size: 100 }).ok).toBe(true);
  });

  it('refuse mauvais MIME', async () => {
    const r = validateAttachmentInput({ fileName: 'a.exe', mimeType: 'application/octet-stream', size: 10 });
    expect(r.ok).toBe(false);
  });

  it('refuse extension dangereuse', async () => {
    expect(isDangerousExtension('x.sh')).toBe(true);
    const r = validateAttachmentInput({ fileName: 'x.js', mimeType: 'image/png', size: 10 });
    expect(r.ok).toBe(false);
  });

  it('refuse extension incompatible MIME', async () => {
    const r = validateAttachmentInput({ fileName: 'photo.pdf', mimeType: 'image/png', size: 10 });
    expect(r.ok).toBe(false);
  });

  it('refuse taille excessive', async () => {
    const r = validateAttachmentInput({
      fileName: 'big.png',
      mimeType: 'image/png',
      size: ATTACHMENT_MAX_SIZE_BYTES + 1,
    });
    expect(r.ok).toBe(false);
  });

  it('sanitize nom', async () => {
    expect(sanitizeFileName('../../etc/passwd.png')).not.toContain('..');
    expect(sanitizeFileName('../../etc/passwd.png')).toMatch(/\.png$/);
  });
});
