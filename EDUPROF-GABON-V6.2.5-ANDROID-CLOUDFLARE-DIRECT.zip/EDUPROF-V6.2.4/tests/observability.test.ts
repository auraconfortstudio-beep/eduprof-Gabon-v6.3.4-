import { describe, it, expect, beforeEach } from 'vitest';
import {
  sanitizeLogValue,
  sanitizeMeta,
  logInfo,
  getOrCreateRequestId,
  recordRequest,
  getMetricsSnapshot,
  resetMetrics,
  buildHealthReport,
  trimMap,
  trimArray,
} from '../workers/_shared/observability/index.ts';

describe('log sanitization', () => {
  it('redacte secrets et chemins', async () => {
    expect(sanitizeLogValue('Bearer abc.def.ghi')).toBe('[REDACTED]');
    expect(sanitizeLogValue('password=secret')).toBe('[REDACTED]');
    expect(sanitizeLogValue('/home/workdir/x')).toBe('[REDACTED_PATH]');
    expect(sanitizeLogValue('ok-message')).toBe('ok-message');
  });

  it('sanitize meta keys', async () => {
    const m = sanitizeMeta({ token: 'xyz', days: 3 });
    expect(m?.token).toBe('[REDACTED]');
    expect(m?.days).toBe(3);
  });

  it('logInfo ne throw pas', async () => {
    expect(() => logInfo('test', { meta: { password: 'x' } })).not.toThrow();
  });
});

describe('request id', () => {
  it('genere UUID si absent', async () => {
    const id = getOrCreateRequestId({});
    expect(id.length).toBeGreaterThan(8);
  });
  it('accepte header valide', async () => {
    const h = new Headers({ 'x-request-id': 'abc12345-reqid01' });
    expect(getOrCreateRequestId(h)).toBe('abc12345-reqid01');
  });
  it('rejette header trop court', async () => {
    const h = new Headers({ 'x-request-id': 'short' });
    expect(getOrCreateRequestId(h).length).toBeGreaterThan(8);
  });
});

describe('metrics + health', () => {
  beforeEach(async () => resetMetrics());

  it('enregistre et borne le buffer', async () => {
    for (let i = 0; i < 250; i++) {
      recordRequest({ route: '/x', status: 200, durationMs: 5, ts: Date.now() });
    }
    const s = getMetricsSnapshot();
    expect(s.bufferSize).toBeLessThanOrEqual(s.bufferCap);
    expect(s.totalRequests).toBe(250);
  });

  it('compte erreurs 500', async () => {
    recordRequest({ route: '/x', status: 500, durationMs: 1, ts: Date.now(), error: true });
    expect(getMetricsSnapshot().totalErrors).toBe(1);
  });

  it('health report', async () => {
    const h = buildHealthReport();
    expect(h.version).toMatch(/^6\./);
    expect(['ok', 'degraded']).toContain(h.status);
    expect(['memory','d1','memory-or-d1']).toContain(h.stores.institutional);
  });
});

describe('bounded store', () => {
  it('trimMap', async () => {
    const m = new Map<number, string>();
    for (let i = 0; i < 10; i++) m.set(i, 'v');
    expect(trimMap(m, 5)).toBe(5);
    expect(m.size).toBe(5);
  });
  it('trimArray', async () => {
    const a = [1, 2, 3, 4, 5, 6];
    expect(trimArray(a, 3)).toBe(3);
    expect(a.length).toBe(3);
  });
});
