import { describe, it, expect } from 'vitest';
import { runWithEnv, isOwnerEmail, getOwnerEmails, getJwtSecret } from '../workers/platform/env.ts';

const OWNERS = 'kamaemomo@gmail.com,auraconfort.studio@gmail.com';

describe('Owner multi-email serveur (V6.2.2)', () => {
  it('Owner 1 accepté', () => {
    runWithEnv({ OWNER_EMAILS: OWNERS }, () => {
      expect(isOwnerEmail('kamaemomo@gmail.com')).toBe(true);
    });
  });
  it('Owner 2 accepté', () => {
    runWithEnv({ OWNER_EMAILS: OWNERS }, () => {
      expect(isOwnerEmail('auraconfort.studio@gmail.com')).toBe(true);
    });
  });
  it('autre email refusé', () => {
    runWithEnv({ OWNER_EMAILS: OWNERS }, () => {
      expect(isOwnerEmail('eleve@exemple.ga')).toBe(false);
    });
  });
  it('placeholder refusé', () => {
    runWithEnv({ OWNER_EMAIL: 'owner@eduprof-gabon.ga' }, () => {
      expect(isOwnerEmail('owner@eduprof-gabon.ga')).toBe(false);
      expect(getOwnerEmails()).toEqual([]);
    });
  });
  it('absence OWNER_EMAILS = refus', () => {
    runWithEnv({}, () => {
      expect(isOwnerEmail('kamaemomo@gmail.com')).toBe(false);
    });
  });
  it('email null refusé', () => {
    runWithEnv({ OWNER_EMAILS: OWNERS }, () => {
      expect(isOwnerEmail(null)).toBe(false);
    });
  });
  it('JWT_SECRET manquant lève', () => {
    runWithEnv({}, () => {
      expect(() => getJwtSecret()).toThrow(/JWT_SECRET/);
    });
  });
  it('JWT_SECRET ≥ 32 ok', () => {
    const s = 'a'.repeat(32);
    runWithEnv({ JWT_SECRET: s }, () => {
      expect(getJwtSecret()).toBe(s);
    });
  });
});
