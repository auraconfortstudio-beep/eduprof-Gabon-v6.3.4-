import { describe, it, expect, beforeEach } from 'vitest';
import { getLevels } from '../src/data/curriculum';
import { retrieveLesson, formatLessonContextForPrompt } from '../workers/_shared/lessonRetrieval';
import {
  listConversations,
  getConversation,
  createConversation,
  appendMessages,
  deleteConversation,
} from '../workers/_shared/pedagogy/conversationStore';
import { runLocalPedagogy } from '../workers/_shared/pedagogy/localEngine';
import { loadPedagogicalMemory } from '../workers/_shared/pedagogy/memoryStore';
import { shouldPreferLocalEngine } from '../workers/_shared/pedagogy/demo';

function findDemoChapter() {
  const terminale = getLevels().find((l) => l.id === 'terminale')!;
  const serieB = terminale.series?.find((s) => s.id === 'serie-b');
  const math = serieB?.subjects.find((s) => s.id === 'terminale-b-mathematiques');
  return math?.chapters.find((c) => c.id === 'terminale-b-mathematiques-c1-fonctions');
}

describe('1. Un chapitre peut contenir plusieurs leçons', () => {
  it('le chapitre Fonctions (Terminale B) a 5 leçons distinctes', async () => {
    const chapter = findDemoChapter();
    expect(chapter).toBeDefined();
    expect(chapter!.lessons.length).toBe(5);
  });
});

describe("2. Deux leçons d'un même chapitre ont des identifiants distincts", () => {
  it('les 5 IDs de leçon du chapitre Fonctions sont tous uniques', async () => {
    const chapter = findDemoChapter()!;
    const ids = chapter.lessons.map((l) => l.id);
    expect(new Set(ids).size).toBe(ids.length);
  });
});

describe('3. Une leçon peut être récupérée individuellement', () => {
  it("retrieveLesson() renvoie la leçon 'Limites' par son seul lessonId", async () => {
    const result = retrieveLesson({
      lessonId: 'terminale-b-mathematiques-c1-fonctions-lecon3',
      seriesId: 'serie-b',
      subjectId: null,
      levelId: 'terminale',
      chapterId: null,
    });
    expect(result.ok).toBe(true);
    if (result.ok) expect(result.lesson.title).toBe('Limites');
  });
});

describe('4. Le contexte de leçon est correctement construit', () => {
  it('formatLessonContextForPrompt inclut matière, chapitre et titre de la leçon', async () => {
    const result = retrieveLesson({
      lessonId: 'terminale-b-mathematiques-c1-fonctions-lecon1',
      seriesId: 'serie-b',
      subjectId: null,
      levelId: 'terminale',
      chapterId: null,
    });
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    const block = formatLessonContextForPrompt(result.lesson);
    expect(block).toContain('Mathématiques');
    expect(block).toContain('Fonctions');
    expect(block).toContain('Généralités sur les fonctions');
  });
});

describe('5 & 6. Conversations liées ou non à une leçon', () => {
  it('une conversation peut être créée avec un lessonId', async () => {
    const conv = await createConversation(
      'user-test-A',
      { lessonId: 'terminale-b-mathematiques-c1-fonctions-lecon3', levelId: 'terminale', seriesId: 'serie-b' },
      'Je ne comprends pas les limites'
    );
    expect(conv.lessonId).toBe('terminale-b-mathematiques-c1-fonctions-lecon3');
    expect(conv.userId).toBe('user-test-A');
  });

  it('une conversation générale peut exister sans lessonId', async () => {
    const conv = await createConversation('user-test-A', {}, 'Comment calcule-t-on une dérivée ?');
    expect(conv.lessonId ?? null).toBeNull();
    expect(conv.id).toBeTruthy();
  });
});

describe('7. La mémoire/les conversations sont isolées par utilisateur', () => {
  it("un utilisateur ne peut pas récupérer la conversation d'un autre", async () => {
    const convA = await createConversation('user-iso-A', {}, 'Question de A');
    const gotByB = await getConversation('user-iso-B', convA.id);
    expect(gotByB).toBeNull();
    const gotByA = await getConversation('user-iso-A', convA.id);
    expect(gotByA).not.toBeNull();
  });

  it("la liste des conversations d'un utilisateur ne contient jamais celles d'un autre", async () => {
    await createConversation('user-iso-C', {}, 'Question de C');
    await createConversation('user-iso-D', {}, 'Question de D');
    const listC = await listConversations('user-iso-C');
    const listD = await listConversations('user-iso-D');
    expect(listC.every((c) => c.userId === 'user-iso-C')).toBe(true);
    expect(listD.every((c) => c.userId === 'user-iso-D')).toBe(true);
    expect(listC.some((c) => listD.map((d) => d.id).includes(c.id))).toBe(false);
  });

  it('la mémoire pédagogique de deux utilisateurs différents ne se mélange jamais', async () => {
    const memA = await loadPedagogicalMemory('user-mem-A');
    const memB = await loadPedagogicalMemory('user-mem-B');
    expect(memA.userId).toBe('user-mem-A');
    expect(memB.userId).toBe('user-mem-B');
  });
});

describe('8. Le moteur local fonctionne sans API externe', () => {
  it('shouldPreferLocalEngine renvoie true quand aucun provider réel n\'est configuré', async () => {
    expect(shouldPreferLocalEngine(false)).toBe(true);
  });

  it('runLocalPedagogy répond directement, sans provider, pour une question simple', async () => {
    const memory = await loadPedagogicalMemory('user-local-engine');
    const res = runLocalPedagogy({
      userId: 'user-local-engine',
      question: 'bonjour',
      levelId: 'cm2',
      memory,
    });
    expect(typeof res.reply).toBe('string');
    expect(res.reply.length).toBeGreaterThan(0);
  });

  it("runLocalPedagogy s'appuie sur le contenu de leçon fourni quand il est présent", async () => {
    const memory = await loadPedagogicalMemory('user-local-engine-2');
    const res = runLocalPedagogy({
      userId: 'user-local-engine-2',
      question: 'Explique-moi cette leçon',
      levelId: 'terminale',
      seriesId: 'serie-b',
      lessonId: 'terminale-b-mathematiques-c1-fonctions-lecon4',
      lessonTitle: 'Continuité',
      lessonContent: 'Une fonction f est continue en a si lim(x→a) f(x) = f(a).',
      retrievalOk: true,
      memory,
    });
    expect(res.reply.length).toBeGreaterThan(0);
  });
});

describe("9. Le contexte de leçon n'est pas mélangé entre élèves", () => {
  it('deux conversations de deux élèves différents sur deux leçons différentes restent distinctes', async () => {
    const convEleve1 = await createConversation(
      'eleve-1',
      { lessonId: 'terminale-b-mathematiques-c1-fonctions-lecon2', lessonTitle: 'Ensemble de définition' },
      'Aide-moi'
    );
    const convEleve2 = await createConversation(
      'eleve-2',
      { lessonId: 'terminale-b-mathematiques-c1-fonctions-lecon5', lessonTitle: 'Applications' },
      'Aide-moi aussi'
    );
    expect(convEleve1.lessonId).not.toBe(convEleve2.lessonId);

    const reloaded1 = await getConversation('eleve-1', convEleve1.id);
    const reloaded2 = await getConversation('eleve-2', convEleve2.id);
    expect(reloaded1?.lessonId).toBe('terminale-b-mathematiques-c1-fonctions-lecon2');
    expect(reloaded2?.lessonId).toBe('terminale-b-mathematiques-c1-fonctions-lecon5');
    // Croisement interdit : eleve-1 ne doit jamais accéder à la conversation de eleve-2
    expect(await getConversation('eleve-1', convEleve2.id)).toBeNull();
  });
});

describe('Conversations — cycle de vie complet', () => {
  const userId = 'user-lifecycle';

  it('création → ajout de messages → titre auto-dérivé du premier message utilisateur', async () => {
    const conv = await createConversation(userId, {}, 'Peux-tu m\'expliquer les limites de fonctions ?');
    const updated = await appendMessages(userId, conv.id, [
      { role: 'user', content: "Peux-tu m'expliquer les limites de fonctions ?" },
      { role: 'assistant', content: 'Bien sûr, une limite décrit...' },
    ]);
    expect(updated).not.toBeNull();
    expect(updated!.messages.length).toBe(2);
    expect(updated!.title.length).toBeGreaterThan(0);
  });

  it('une conversation peut être listée puis supprimée', async () => {
    const conv = await createConversation(userId, {}, 'Question à supprimer');
    let list = await listConversations(userId);
    expect(list.some((c) => c.id === conv.id)).toBe(true);
    const ok = await deleteConversation(userId, conv.id);
    expect(ok).toBe(true);
    expect(await getConversation(userId, conv.id)).toBeNull();
  });
});
