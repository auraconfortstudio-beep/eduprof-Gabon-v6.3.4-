import { describe, it, expect } from 'vitest';
import { readFileSync } from 'fs';
import { join } from 'path';

const root = join(__dirname, '..');

describe('PWA assets', () => {
  it('manifest cohérent', async () => {
    const m = JSON.parse(readFileSync(join(root, 'public/manifest.json'), 'utf8'));
    expect(m.name).toBeTruthy();
    expect(m.short_name).toBeTruthy();
    expect(m.display).toBe('standalone');
    expect(m.start_url).toBe('/');
    expect(m.icons?.length).toBeGreaterThan(0);
  });

  it('service worker SKIP_WAITING et cache', async () => {
    const sw = readFileSync(join(root, 'public/sw.js'), 'utf8');
    expect(sw).toContain('SKIP_WAITING');
    expect(sw).toContain('caches');
    expect(sw).toContain('/api');
  });

  it('index.html enregistre SW + manifest', async () => {
    const html = readFileSync(join(root, 'index.html'), 'utf8');
    expect(html).toContain('manifest.json');
    expect(html).toContain('serviceWorker');
  });
});
