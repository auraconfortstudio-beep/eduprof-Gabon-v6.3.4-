import { describe, it, expect, beforeEach } from 'vitest';
import {
  createBktParams,
  updateBkt,
  masteryLabelFromProb,
  DEFAULT_BKT,
  upsertConcept,
  getConcept,
  addPrerequisite,
  getDirectPrerequisites,
  getPrerequisiteChain,
  resetKnowledgeGraph,
  seedMinimalMathGraph,
  ensureGraphSeeded,
  resetMasteryStore,
  getOrInitMastery,
  applyObservation,
  getConceptMastery,
  listUserMastery,
  masteryProb,
  assertIsolated,
  detectGaps,
  getNextLearningRecommendation,
  buildMaelPedagogyContext,
} from '../workers/_shared/pedagogy/engine/index.ts';

describe('compétences / concepts', () => {
  beforeEach(async () => {
    resetKnowledgeGraph();
    resetMasteryStore();
  });

  it('crée une compétence/concept', async () => {
    const c = upsertConcept({
      id: 'c1',
      name: 'Test Notion',
      prerequisiteIds: [],
      prerequisiteStatus: 'unknown',
    });
    expect(getConcept('c1')?.name).toBe('Test Notion');
    expect(c.prerequisiteStatus).toBe('unknown');
  });

  it('relation concept/prérequis', async () => {
    upsertConcept({ id: 'a', name: 'A', prerequisiteIds: [], prerequisiteStatus: 'known' });
    upsertConcept({ id: 'b', name: 'B', prerequisiteIds: [], prerequisiteStatus: 'unknown' });
    const r = addPrerequisite('a', 'b');
    expect(r.ok).toBe(true);
    expect(getDirectPrerequisites('b').map((x) => x.id)).toContain('a');
    expect(getConcept('b')?.prerequisiteStatus).toBe('known');
  });

  it('chaîne de prérequis seed maths', async () => {
    seedMinimalMathGraph();
    const chain = getPrerequisiteChain('math-systemes');
    expect(chain).toContain('math-equations');
    expect(getConcept('math-equations')?.prerequisiteIds.length).toBeGreaterThan(0);
  });
});

describe('BKT', () => {
  it('mastery initial', async () => {
    const p = createBktParams();
    expect(p.probMastery).toBe(DEFAULT_BKT.probMastery);
    expect(masteryLabelFromProb(p.probMastery)).toBe('unknown');
  });

  it('mise à jour BKT correcte augmente la maîtrise', async () => {
    let p = createBktParams({ probMastery: 0.2 });
    const before = p.probMastery;
    p = updateBkt(p, true);
    expect(p.probMastery).toBeGreaterThan(before);
  });

  it('mise à jour BKT incorrecte diminue ou plafonne la maîtrise relative', async () => {
    let p = createBktParams({ probMastery: 0.6 });
    const before = p.probMastery;
    p = updateBkt(p, false);
    expect(p.probMastery).toBeLessThan(before);
  });
});

describe('mastery store + isolation', () => {
  beforeEach(async () => {
    resetMasteryStore();
    resetKnowledgeGraph();
    seedMinimalMathGraph();
  });

  it('observation correcte stockée par user', async () => {
    const m0 = getOrInitMastery('u1', 'math-equations');
    expect(m0.observations).toBe(0);
    const m1 = applyObservation('u1', 'math-equations', true);
    expect(m1!.observations).toBe(1);
    expect(m1!.correctCount).toBe(1);
    expect(m1!.bkt.probMastery).toBeGreaterThan(m0.bkt.probMastery);
  });

  it('isolation entre deux utilisateurs', async () => {
    applyObservation('user-a', 'math-fractions', true);
    applyObservation('user-a', 'math-fractions', true);
    applyObservation('user-b', 'math-fractions', false);
    const a = masteryProb('user-a', 'math-fractions');
    const b = masteryProb('user-b', 'math-fractions');
    expect(a).not.toBe(b);
    expect(listUserMastery('user-a').every((x) => x.userId === 'user-a')).toBe(true);
    expect(listUserMastery('user-b').every((x) => x.userId === 'user-b')).toBe(true);
    expect(assertIsolated('user-a', 'user-b')).toBe(true);
    expect(getConceptMastery('user-b', 'math-fractions')!.userId).toBe('user-b');
  });
});

describe('lacunes et recommandations', () => {
  beforeEach(async () => {
    resetMasteryStore();
    resetKnowledgeGraph();
    seedMinimalMathGraph();
  });

  it('détecte des lacunes', async () => {
    const gaps = detectGaps('u1');
    expect(gaps.length).toBeGreaterThan(0);
  });

  it('recommande un prérequis fragile avant équations', async () => {
    // leave distributivity low, ask focus equations
    const rec = getNextLearningRecommendation('u1', { focusConceptId: 'math-equations' });
    expect(rec.conceptId).toBeTruthy();
    expect(rec.recommendedActivity).not.toBe('none');
    // should prefer a prerequisite
    expect(['math-distributivite', 'math-fractions', 'math-arithmetique']).toContain(rec.conceptId);
  });

  it('pas de recommandation forcée sans userId', async () => {
    const rec = getNextLearningRecommendation('');
    expect(rec.recommendedActivity).toBe('none');
    expect(rec.conceptId).toBeNull();
  });
});

describe('Maël contexte pédagogique', () => {
  beforeEach(async () => {
    resetMasteryStore();
    resetKnowledgeGraph();
    ensureGraphSeeded();
  });

  it('construit un contexte avec résumé pour prompt', async () => {
    applyObservation('eleve1', 'math-equations', false);
    const ctx = buildMaelPedagogyContext({
      userId: 'eleve1',
      levelId: '3e',
      subjectName: 'Mathématiques',
      question: 'Je ne comprends pas les équations',
    });
    expect(ctx.conceptId).toBe('math-equations');
    expect(ctx.summaryForPrompt.length).toBeGreaterThan(10);
    expect(ctx.recommendation).toBeTruthy();
  });
});
