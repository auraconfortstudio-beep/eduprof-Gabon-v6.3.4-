import { describe, it, expect, beforeEach } from 'vitest';
import {
  getLevelFromXp,
  getXpToNextLevel,
  getXpFloorForLevel,
  evaluateBadges,
  awardXpIdempotent,
  makeEventKey,
  XP_LESSON,
  XP_EXERCISE,
  XP_QUIZ_MAX,
} from '../workers/_shared/progression/index.ts';
import {
  createEstablishment,
  resetInstitutionalStore,
  resetMemberships,
  upsertMembership,
  appendInstitutionalAudit,
  resolveEstablishmentContext,
} from '../workers/_shared/institutional/index.ts';
import {
  computeOwnerAnalytics,
  computeEstablishmentAnalytics,
  queryAudit,
  sanitizeAuditForClient,
} from '../workers/_shared/analytics/index.ts';
import type { UserRecord, UserProgress } from '../workers/_shared/types.ts';

function U(p: Partial<UserRecord> & Pick<UserRecord, 'id' | 'role'>): UserRecord {
  return {
    email: `${p.id}@t.ga`,
    passwordHash: 'x',
    displayName: p.id,
    educationLevel: '3e',
    educationSeries: null,
    educationFiliere: null,
    isPremium: false,
    premiumUntil: null,
    xp: 0,
    streak: 0,
    lastActivityDate: null,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    establishmentId: null,
    ...p,
  };
}

describe('XP constants', () => {
  it('valeurs EduProf', async () => {
    expect(XP_LESSON).toBe(10);
    expect(XP_EXERCISE).toBe(15);
    expect(XP_QUIZ_MAX).toBe(50);
  });
});

describe('niveaux', () => {
  it('seuils déterministes', async () => {
    expect(getLevelFromXp(0)).toBe(1);
    expect(getXpFloorForLevel(2)).toBe(50);
    expect(getXpFloorForLevel(3)).toBe(150);
    expect(getLevelFromXp(50)).toBe(2);
    expect(getLevelFromXp(150)).toBe(3);
  });
  it('xp to next', async () => {
    const info = getXpToNextLevel(50);
    expect(info.level).toBe(2);
    expect(info.remaining).toBe(100);
  });
});

describe('XP idempotent', () => {
  it('double award impossible', async () => {
    let progress: UserProgress = { userId: 'u', lessons: [], exercises: [], quizzes: [], xpHistory: [] };
    const key = makeEventKey('lesson', 'L1');
    const r1 = awardXpIdempotent(progress, XP_LESSON, key);
    expect(r1.xpGain).toBe(10);
    progress = r1.progress;
    const r2 = awardXpIdempotent(progress, XP_LESSON, key);
    expect(r2.xpGain).toBe(0);
    expect(r2.alreadyAwarded).toBe(true);
  });
});

describe('badges', () => {
  it('attribution set unique', async () => {
    const b = evaluateBadges({
      xp: 1000,
      streak: 30,
      lessonsCompleted: 1,
      exercisesCorrect: 1,
      quizzesTaken: 1,
      perfectQuiz: true,
      masteredConcepts: 3,
    });
    expect(new Set(b).size).toBe(b.length);
    expect(b).toContain('XP_1000');
    expect(b).toContain('SUBJECT_MASTER');
  });
  it('aucun badge sans données', async () => {
    expect(
      evaluateBadges({
        xp: 0,
        streak: 0,
        lessonsCompleted: 0,
        exercisesCorrect: 0,
        quizzesTaken: 0,
        perfectQuiz: false,
        masteredConcepts: 0,
      }).length
    ).toBe(0);
  });
});

describe('analytics multi-tenant', () => {
  beforeEach(async () => {
    resetInstitutionalStore();
    resetMemberships();
  });

  it('owner global et A ne voit pas B via context', async () => {
    const a = await createEstablishment({ name: 'A', code: 'AA4' });
    const b = await createEstablishment({ name: 'B', code: 'BB4' });
    const adminA = U({ id: 'aa4', role: 'ESTABLISHMENT_ADMIN', establishmentId: a.id });
    await upsertMembership({ userId: adminA.id, establishmentId: a.id, role: 'ESTABLISHMENT_ADMIN' });
    const bad = await resolveEstablishmentContext(adminA, b.id);
    expect(bad.ok).toBe(false);
    const ga = await computeEstablishmentAnalytics(a.id, 'all');
    expect(ga.establishmentId).toBe(a.id);
    const go = await computeOwnerAnalytics('30d');
    expect(go.establishments).toBeGreaterThanOrEqual(2);
    expect(go.period).toBe('30d');
  });
});

describe('audit query', () => {
  beforeEach(async () => resetInstitutionalStore());

  it('pagination et sanitize secrets', async () => {
    const est = await createEstablishment({ name: 'A', code: 'AUD4' });
    for (let i = 0; i < 5; i++) {
      await appendInstitutionalAudit({
        actorUserId: 'x',
        action: 'STUDENT_ACTIVATED',
        targetEstablishmentId: est.id,
        metadata: { password: 'secret', days: 1 },
      });
    }
    const q = await queryAudit({ establishmentId: est.id, page: 1, pageSize: 2 });
    expect(q.items.length).toBe(2);
    expect(q.total).toBe(5);
    const s = sanitizeAuditForClient(q.items[0]);
    expect(s.metadata?.password).toBeUndefined();
    expect(s.metadata?.days).toBe(1);
  });
});
