import { describe, it, expect } from 'vitest';
import { detectIntent } from '../workers/_shared/pedagogy/intents';
import { runLocalPedagogy } from '../workers/_shared/pedagogy/localEngine';
import type { PedagogicalMemory } from '../workers/_shared/pedagogy/types';
import { upsertNotion, buildRecommendations } from '../workers/_shared/pedagogy/memoryStore';

function emptyMem(id: string): PedagogicalMemory {
  return { userId: id, updatedAt: new Date().toISOString(), notions: [], recentActivity: [], recommendations: [] };
}

describe('intents', () => {
  it('greetings variants', async () => {
    expect(detectIntent('Bonjour')).toBe('greeting');
    expect(detectIntent('Salut Maël')).toBe('greeting');
    expect(detectIntent('Bonsoir professeur')).toBe('greeting');
  });
  it('capabilities', async () => {
    expect(detectIntent('Que peux-tu faire ?')).toBe('capabilities');
  });
  it('explain', async () => {
    expect(detectIntent('Explique-moi cette leçon')).toBe('explain');
    expect(detectIntent('Je ne comprends pas')).toBe('explain');
  });
  it('exercise', async () => {
    expect(detectIntent('Donne-moi un exercice')).toBe('exercise');
  });
  it('recommendation', async () => {
    expect(detectIntent('Que dois-je réviser ?')).toBe('recommendation');
  });
});

describe('local engine + memory', () => {
  it('explains from EduProf content', async () => {
    const r = runLocalPedagogy({
      userId: 'u1',
      question: 'Explique-moi',
      levelId: 'premiere',
      seriesId: 'serie-s',
      subjectName: 'Mathématiques',
      lessonTitle: 'Suites',
      lessonContent: 'Une suite arithmétique a une raison constante r.',
      lessonKeyPoints: ['raison r', 'u_n+1 = u_n + r'],
      retrievalOk: true,
      memory: emptyMem('u1'),
      exercises: [{ question: 'u0=1 r=2. u1=?', difficulty: 'facile' }],
    });
    expect(r.source).toBe('eduprof');
    expect(r.reply).toMatch(/suite|EduProf|raison/i);
  });

  it('exercise from catalog data', async () => {
    const r = runLocalPedagogy({
      userId: 'u1',
      question: 'Donne-moi un exercice',
      retrievalOk: true,
      lessonTitle: 'Test',
      exercises: [{ question: 'Calcule 2+2', difficulty: 'facile' }],
      memory: emptyMem('u1'),
    });
    expect(r.reply).toContain('Calcule 2+2');
  });

  it('memory isolation shape', async () => {
    let a = emptyMem('user-A');
    let b = emptyMem('user-B');
    a = upsertNotion(a, { notion: 'dérivation', subjectName: 'Maths', error: true });
    b = upsertNotion(b, { notion: 'conjugaison', subjectName: 'Français', success: true });
    expect(a.userId).toBe('user-A');
    expect(b.userId).toBe('user-B');
    expect(a.notions[0].notion).toBe('dérivation');
    expect(b.notions[0].notion).toBe('conjugaison');
    buildRecommendations(a);
    expect(a.recommendations.length).toBeGreaterThan(0);
  });

  it('recommendation uses fragile notions', async () => {
    let m = emptyMem('u');
    m = upsertNotion(m, { notion: 'fonctions', error: true });
    m = upsertNotion(m, { notion: 'fonctions', error: true });
    const r = runLocalPedagogy({
      userId: 'u',
      question: 'Que dois-je réviser ?',
      memory: m,
    });
    expect(r.intent).toBe('recommendation');
    expect(r.reply.toLowerCase()).toMatch(/révis|prioris|fragile|fonctions/);
  });
});
