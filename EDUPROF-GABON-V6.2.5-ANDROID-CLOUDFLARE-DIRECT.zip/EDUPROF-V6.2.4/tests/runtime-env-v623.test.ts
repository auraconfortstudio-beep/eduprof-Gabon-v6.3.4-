/**
 * V6.2.3 — détection runtime Cloudflare (pas de Netlify CONTEXT littéral "").
 */
import { describe, it, expect } from 'vitest';
import { runWithEnv } from '../workers/platform/env.ts';
import {
  loadPedagogicalMemory,
  savePedagogicalMemory,
} from '../workers/_shared/pedagogy/memoryStore.ts';
import {
  listConversations,
  createConversation,
  getConversation,
  deleteConversation,
} from '../workers/_shared/pedagogy/conversationStore.ts';

describe('Runtime env V6.2.3 — pedagogy stores sans bindings', () => {
  it('mémoire pédagogique : Map isolée sans KV', async () => {
    await runWithEnv({}, async () => {
      await savePedagogicalMemory({
        userId: 'u-test-1',
        notions: [],
        recentActivity: [],
        recommendations: [],
      });
      const m = await loadPedagogicalMemory('u-test-1');
      expect(m.userId).toBe('u-test-1');
      const other = await loadPedagogicalMemory('u-test-2');
      expect(other.userId).toBe('u-test-2');
      expect(other.notions).toEqual([]);
    });
  });

  it('conversations : isolation userId sans KV', async () => {
    await runWithEnv({}, async () => {
      const c = await createConversation('user-a', {
        initialMessages: [{ role: 'user', content: 'Bonjour Maël' }],
      });
      expect(c.userId).toBe('user-a');
      const listA = await listConversations('user-a');
      expect(listA.some((x) => x.id === c.id)).toBe(true);
      const listB = await listConversations('user-b');
      expect(listB.length).toBe(0);
      const stolen = await getConversation('user-b', c.id);
      expect(stolen).toBeNull();
      await deleteConversation('user-a', c.id);
      expect(await getConversation('user-a', c.id)).toBeNull();
    });
  });
});
