import { describe, it, expect } from 'vitest';
import {
  validateAttachmentInput,
  hasDoubleDangerousExtension,
  isDangerousExtension,
  ATTACHMENT_MAX_SIZE_BYTES,
} from '../workers/_shared/attachments.ts';
import { securityHeaders, publicErrorMessage } from '../workers/_shared/securityHeaders.ts';
import { RATE_PRESETS } from '../workers/_shared/rateLimit.ts';
import { canAccessTicket, createTicket, resetSupportTickets } from '../workers/_shared/support.ts';
import { resolveEstablishmentContext, createEstablishment, resetInstitutionalStore, resetMemberships, upsertMembership } from '../workers/_shared/institutional/index.ts';
import type { UserRecord } from '../workers/_shared/types.ts';

function U(p: Partial<UserRecord> & Pick<UserRecord, 'id' | 'role'>): UserRecord {
  return {
    email: `${p.id}@t.ga`,
    passwordHash: 'x',
    displayName: p.id,
    educationLevel: '3e',
    educationSeries: null,
    educationFiliere: null,
    isPremium: false,
    premiumUntil: null,
    xp: 0,
    streak: 0,
    lastActivityDate: null,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    establishmentId: null,
    ...p,
  };
}

describe('security headers', () => {
  it('headers de base présents', async () => {
    const h = securityHeaders();
    expect(h['X-Content-Type-Options']).toBe('nosniff');
    expect(h['X-Frame-Options']).toBe('DENY');
    expect(h['Content-Security-Policy']).toContain("default-src 'self'");
  });
});

describe('public errors', () => {
  it('masque secrets et chemins', async () => {
    expect(publicErrorMessage(new Error('JWT secret leaked'))).toBe('Erreur serveur');
    expect(publicErrorMessage(new Error('/home/workdir/secret'))).toBe('Erreur serveur');
    expect(publicErrorMessage(new Error('Ticket introuvable'))).toContain('Ticket');
  });
});

describe('upload hostile', () => {
  it.each([
    ['x.exe', 'application/octet-stream'],
    ['x.sh', 'image/png'],
    ['x.js', 'image/png'],
    ['x.html', 'text/html'],
    ['x.svg', 'image/svg+xml'],
  ])('refuse %s', (name, mime) => {
    expect(validateAttachmentInput({ fileName: name, mimeType: mime, size: 10 }).ok).toBe(false);
  });

  it('double extension jpg.php', async () => {
    expect(hasDoubleDangerousExtension('photo.jpg.php')).toBe(true);
    expect(validateAttachmentInput({ fileName: 'photo.jpg.php', mimeType: 'image/jpeg', size: 10 }).ok).toBe(false);
  });

  it('path traversal sanitised / oversize', async () => {
    const r = validateAttachmentInput({
      fileName: '../../etc/passwd.png',
      mimeType: 'image/png',
      size: 100,
    });
    expect(r.ok).toBe(true);
    if (r.ok) expect(r.fileName).not.toContain('..');
    expect(
      validateAttachmentInput({
        fileName: 'big.png',
        mimeType: 'image/png',
        size: ATTACHMENT_MAX_SIZE_BYTES + 1,
      }).ok
    ).toBe(false);
  });

  it('MIME falsifié png as pdf name', async () => {
    expect(validateAttachmentInput({ fileName: 'a.pdf', mimeType: 'image/png', size: 10 }).ok).toBe(false);
  });
});

describe('rate presets support/upload/login', () => {
  it('présets définis', async () => {
    expect(RATE_PRESETS.SUPPORT_USER.limit).toBeGreaterThan(0);
    expect(RATE_PRESETS.UPLOAD_USER.limit).toBeGreaterThan(0);
    expect(RATE_PRESETS.LOGIN_IP.limit).toBeGreaterThan(0);
  });
});

describe('cross-tenant context', () => {
  it('A ne résout pas B', async () => {
    resetInstitutionalStore();
    resetMemberships();
    const a = await createEstablishment({ name: 'A', code: 'SA' });
    const b = await createEstablishment({ name: 'B', code: 'SB' });
    const adminA = U({ id: 'admA', role: 'ESTABLISHMENT_ADMIN', establishmentId: a.id });
    await upsertMembership({ userId: adminA.id, establishmentId: a.id, role: 'ESTABLISHMENT_ADMIN' });
    const bad = await resolveEstablishmentContext(adminA, b.id);
    expect(bad.ok).toBe(false);
  });
});
