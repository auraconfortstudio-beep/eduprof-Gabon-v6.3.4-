import { describe, it, expect, beforeEach } from 'vitest';
import {
  createTicket,
  getTicket,
  listTicketsForUser,
  listTicketsForEstablishment,
  updateTicketStatus,
  replyToTicket,
  canAccessTicket,
  resetSupportTickets,
} from '../workers/_shared/support.ts';
import { resetNotifications, listNotifications } from '../workers/_shared/notifications.ts';

describe('support tickets', () => {
  beforeEach(async () => {
    resetSupportTickets();
    resetNotifications();
  });

  it('création + notif', async () => {
    const t = createTicket({
      userId: 'u1',
      establishmentId: 'estA',
      subject: 'Problème accès',
      message: 'Je ne peux pas me connecter',
      category: 'ACCESS',
    });
    expect(t.status).toBe('OPEN');
    expect(listTicketsForUser('u1').length).toBe(1);
    expect(listNotifications('u1').total).toBeGreaterThan(0);
  });

  it('isolation tenant list', async () => {
    createTicket({ userId: 'a', establishmentId: 'A', subject: 'A', message: 'm' });
    createTicket({ userId: 'b', establishmentId: 'B', subject: 'B', message: 'm' });
    expect(listTicketsForEstablishment('A').every((x) => x.establishmentId === 'A')).toBe(true);
    expect(listTicketsForUser('a').every((x) => x.userId === 'a')).toBe(true);
  });

  it('canAccessTicket IDOR', async () => {
    const t = createTicket({ userId: 'owner1', establishmentId: 'A', subject: 'S', message: 'm' });
    expect(canAccessTicket(t, { id: 'owner1', role: 'STUDENT', establishmentId: 'A' })).toBe(true);
    expect(canAccessTicket(t, { id: 'other', role: 'STUDENT', establishmentId: 'A' })).toBe(false);
    expect(canAccessTicket(t, { id: 'adminB', role: 'ESTABLISHMENT_ADMIN', establishmentId: 'B' })).toBe(false);
    expect(canAccessTicket(t, { id: 'adminA', role: 'ESTABLISHMENT_ADMIN', establishmentId: 'A' })).toBe(true);
    expect(canAccessTicket(t, { id: 'own', role: 'OWNER' })).toBe(true);
  });

  it('reply + resolve', async () => {
    const t = createTicket({ userId: 'u1', subject: 'S', message: 'm' });
    replyToTicket(t.id, 'admin1', 'Voici la réponse');
    expect(getTicket(t.id)?.status).toBe('IN_PROGRESS');
    updateTicketStatus(t.id, 'RESOLVED', 'admin1');
    expect(getTicket(t.id)?.status).toBe('RESOLVED');
  });
});
