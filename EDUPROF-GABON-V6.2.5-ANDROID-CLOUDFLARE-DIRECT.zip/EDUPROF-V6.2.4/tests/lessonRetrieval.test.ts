import { describe, it, expect, beforeEach } from 'vitest';
import { readFileSync, existsSync } from 'fs';
import { join } from 'path';
import {
  retrieveLesson,
  formatLessonContextForPrompt,
  catalogStats,
  _resetCatalogCache,
  normSeries,
} from '../workers/_shared/lessonRetrieval';

const catalogPath = join(process.cwd(), 'workers/_shared/lesson-catalog.json');

function loadCatalog() {
  return JSON.parse(readFileSync(catalogPath, 'utf-8'));
}

describe('lesson catalog coverage', () => {
  it('catalog exists with substantial coverage', async () => {
    expect(existsSync(catalogPath)).toBe(true);
    const data = loadCatalog();
    const n = Object.keys(data.lessons || {}).length;
    expect(n).toBeGreaterThan(100);
  });

  it('stats present', async () => {
    _resetCatalogCache();
    const s = catalogStats();
    expect(s).toBeTruthy();
    expect((s as any).totalLessons).toBeGreaterThan(100);
  });
});

describe('retrieveLesson isolation', () => {
  beforeEach(async () => _resetCatalogCache());

  it('normSeries maps legacy', async () => {
    expect(normSeries('A1')).toBe('serie-a1');
    expect(normSeries('C')).toBe('serie-c');
    expect(normSeries('serie-le')).toBe('serie-le');
  });

  it('A1 lesson ok for serie-a1', async () => {
    const data = loadCatalog();
    const id = Object.keys(data.lessons).find((k) => data.lessons[k].seriesId === 'serie-a1');
    expect(id).toBeTruthy();
    const r = retrieveLesson({ lessonId: id!, seriesId: 'serie-a1' });
    expect(r.ok).toBe(true);
  });

  it('A1 specific lesson rejected for S when not allowed', async () => {
    const data = loadCatalog();
    const id = Object.keys(data.lessons).find(
      (k) =>
        data.lessons[k].seriesId === 'serie-a1' &&
        !(data.lessons[k].allowedSeries || []).includes('serie-s') &&
        data.lessons[k].shared !== true
    );
    expect(id).toBeTruthy();
    const r = retrieveLesson({ lessonId: id!, seriesId: 'serie-s' });
    expect(r.ok).toBe(false);
    if (!r.ok) expect(r.reason).toBe('series_mismatch');
  });

  it('S lesson rejected for A1 when exclusive', async () => {
    const data = loadCatalog();
    const id = Object.keys(data.lessons).find(
      (k) =>
        data.lessons[k].seriesId === 'serie-s' &&
        data.lessons[k].levelId === 'premiere' &&
        !(data.lessons[k].allowedSeries || []).includes('serie-a1')
    );
    if (!id) return; // skip if none
    const r = retrieveLesson({ lessonId: id, seriesId: 'serie-a1' });
    expect(r.ok).toBe(false);
  });

  it('C vs D isolation', async () => {
    const data = loadCatalog();
    const cId = Object.keys(data.lessons).find(
      (k) => data.lessons[k].seriesId === 'serie-c' && data.lessons[k].shared !== true
    );
    const dId = Object.keys(data.lessons).find(
      (k) => data.lessons[k].seriesId === 'serie-d' && data.lessons[k].shared !== true
    );
    if (cId) {
      const r = retrieveLesson({ lessonId: cId, seriesId: 'serie-d' });
      // unless allowedSeries includes d
      const allowed = data.lessons[cId].allowedSeries || [data.lessons[cId].seriesId];
      if (!allowed.includes('serie-d')) {
        expect(r.ok).toBe(false);
      }
    }
    if (dId) {
      const r = retrieveLesson({ lessonId: dId, seriesId: 'serie-c' });
      const allowed = data.lessons[dId].allowedSeries || [data.lessons[dId].seriesId];
      if (!allowed.includes('serie-c')) {
        expect(r.ok).toBe(false);
      }
    }
  });

  it('college lesson without series is retrievable', async () => {
    const data = loadCatalog();
    const id = Object.keys(data.lessons).find((k) => data.lessons[k].levelId === '5e');
    expect(id).toBeTruthy();
    const r = retrieveLesson({ lessonId: id! });
    expect(r.ok).toBe(true);
    if (r.ok) {
      expect(r.lesson.content.length + r.lesson.title.length).toBeGreaterThan(0);
    }
  });

  it('formats context', async () => {
    const data = loadCatalog();
    const id = Object.keys(data.lessons)[0];
    const block = formatLessonContextForPrompt(data.lessons[id]);
    expect(block).toContain('CONTENU EDUPROF');
  });

  it('fake id not found', async () => {
    const r = retrieveLesson({ lessonId: 'totally-fake-id-xyz' });
    expect(r.ok).toBe(false);
    if (!r.ok) expect(r.reason).toBe('not_found');
  });
});

describe('premium unchanged', () => {
  it('prices', async () => {
    const src = readFileSync(join(process.cwd(), 'src/lib/constants.ts'), 'utf-8');
    expect(src).toMatch(/PREMIUM_DAILY\s*=\s*500/);
    expect(src).toMatch(/PREMIUM_MONTHLY\s*=\s*4000/);
  });
});
