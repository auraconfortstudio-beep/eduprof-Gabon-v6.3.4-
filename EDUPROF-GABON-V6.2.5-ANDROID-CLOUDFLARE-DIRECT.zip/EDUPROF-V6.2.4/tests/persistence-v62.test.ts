import { describe, it, expect, beforeEach } from 'vitest';
import {
  createEstablishment,
  getEstablishment,
  listEstablishments,
  resetInstitutionalStore,
  upsertActivation,
  listActivations,
  refreshActivationStatus,
  activateStudent,
  renewStudent,
} from '../workers/_shared/institutional/index.ts';
import { upsertMembership, listMemberships, resetMemberships } from '../workers/_shared/institutional/memberships.ts';
import type { UserRecord } from '../workers/_shared/types.ts';

/**
 * Ces tests prouvent le contrat repository async indépendant d'une Map "globale"
 * en simulant une "nouvelle instance" via reset + relecture.
 * TEST D1 RÉEL NON EXÉCUTÉ (pas de binding Cloudflare dans le sandbox).
 */
function U(p: Partial<UserRecord> & Pick<UserRecord, 'id' | 'role'>): UserRecord {
  return {
    email: `${p.id}@t.ga`, passwordHash: 'x', displayName: p.id, educationLevel: '3e',
    educationSeries: null, educationFiliere: null, isPremium: false, premiumUntil: null,
    xp: 0, streak: 0, lastActivityDate: null, createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(), establishmentId: null, ...p,
  };
}

describe('Persistance institutionnelle V6.2 (contrat repository)', () => {
  beforeEach(async () => {
    resetInstitutionalStore();
    resetMemberships();
  });

  it('création + lecture établissement', async () => {
    const est = await createEstablishment({ name: 'Lycée Test', code: 'LT62' });
    const got = await getEstablishment(est.id);
    expect(got?.code).toBe('LT62');
    const list = await listEstablishments();
    expect(list.some((e) => e.id === est.id)).toBe(true);
  });

  it('membership + activation persistés dans le repository', async () => {
    const est = await createEstablishment({ name: 'A', code: 'PA' });
    await upsertMembership({ userId: 'u1', establishmentId: est.id, role: 'STUDENT' });
    const mems = await listMemberships({ establishmentId: est.id });
    expect(mems).toHaveLength(1);
    const student = U({ id: 'u1', role: 'STUDENT', establishmentId: est.id });
    const actor = U({ id: 'adm', role: 'ESTABLISHMENT_ADMIN', establishmentId: est.id });
    await activateStudent({ user: student, establishmentId: est.id, days: 10, actor });
    const acts = await listActivations({ userId: 'u1', establishmentId: est.id });
    expect(acts[0]?.status).toBe('active');
  });

  it('expiration déterministe via refresh', async () => {
    const est = await createEstablishment({ name: 'B', code: 'PB' });
    const past = new Date(Date.now() - 5000).toISOString();
    await upsertActivation({
      userId: 'u2', establishmentId: est.id, status: 'active', expiresAt: past,
    });
    const acts = await listActivations({ userId: 'u2' });
    const refreshed = await refreshActivationStatus(acts[0]);
    expect(refreshed.status).toBe('expired');
  });

  it('renouvellement restaure active', async () => {
    const est = await createEstablishment({ name: 'C', code: 'PC' });
    const student = U({ id: 'u3', role: 'STUDENT', establishmentId: est.id, accessStatus: 'expired' });
    const actor = U({ id: 'adm2', role: 'ADMIN' });
    const r = await renewStudent({ user: student, establishmentId: est.id, days: 5, actor });
    expect(r.ok).toBe(true);
  });

  it('isolation A/B après activation', async () => {
    const a = await createEstablishment({ name: 'A', code: 'XA' });
    const b = await createEstablishment({ name: 'B', code: 'XB' });
    const stA = U({ id: 'sa', role: 'STUDENT', establishmentId: a.id });
    const actor = U({ id: 'admA', role: 'ESTABLISHMENT_ADMIN', establishmentId: a.id });
    await activateStudent({ user: stA, establishmentId: a.id, days: 3, actor });
    expect((await listActivations({ establishmentId: b.id })).length).toBe(0);
    expect((await listActivations({ establishmentId: a.id })).length).toBe(1);
  });
});
