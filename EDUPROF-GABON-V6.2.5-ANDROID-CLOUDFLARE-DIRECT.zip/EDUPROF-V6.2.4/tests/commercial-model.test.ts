import { describe, it, expect, beforeEach } from 'vitest';
import {
  createEstablishment,
  resetInstitutionalStore,
  resetMemberships,
  activateStudent,
  deactivateStudent,
  renewStudent,
  listActivations,
  refreshActivationStatus,
  upsertActivation,
  checkInstitutionalAccess,
} from '../workers/_shared/institutional/index.ts';
import type { UserRecord } from '../workers/_shared/types.ts';

function U(p: Partial<UserRecord> & Pick<UserRecord, 'id' | 'role'>): UserRecord {
  return {
    email: `${p.id}@t.ga`,
    passwordHash: 'x',
    displayName: p.id,
    educationLevel: '3e',
    educationSeries: null,
    educationFiliere: null,
    isPremium: false,
    premiumUntil: null,
    xp: 0,
    streak: 0,
    lastActivityDate: null,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    establishmentId: null,
    ...p,
  };
}

describe('modèle commercial institutionnel V5', () => {
  beforeEach(async () => {
    resetInstitutionalStore();
    resetMemberships();
  });

  it('legacy USER sans établissement = accès libre', async () => {
    const u = U({ id: 'legacy', role: 'USER' });
    const g = await checkInstitutionalAccess(u);
    expect(g.allowed).toBe(true);
    expect(g.status).toBe('legacy_open');
  });

  it('élève pending = accès refusé', async () => {
    const est = await createEstablishment({ name: 'Lycée', code: 'COM1' });
    const s = U({ id: 'st1', role: 'STUDENT', establishmentId: est.id, accessStatus: 'pending' });
    const g = await checkInstitutionalAccess(s);
    expect(g.allowed).toBe(false);
    expect(g.status).toBe('pending');
  });

  it('activation puis accès autorisé', async () => {
    const est = await createEstablishment({ name: 'Lycée', code: 'COM2' });
    const s = U({ id: 'st2', role: 'STUDENT', establishmentId: est.id, accessStatus: 'pending' });
    const actor = U({ id: 'adm', role: 'ESTABLISHMENT_ADMIN', establishmentId: est.id });
    await activateStudent({ user: s, establishmentId: est.id, days: 30, actor });
    const g = await checkInstitutionalAccess(s);
    expect(g.allowed).toBe(true);
    expect(g.status).toBe('active');
    expect(g.expiresAt).toBeTruthy();
  });

  it('expiration déterministe', async () => {
    const est = await createEstablishment({ name: 'Lycée', code: 'COM3' });
    const past = new Date(Date.now() - 1000).toISOString();
    await upsertActivation({
      userId: 'st3',
      establishmentId: est.id,
      status: 'active',
      expiresAt: past,
    });
    const acts = await listActivations({ userId: 'st3' });
    const refreshed = await refreshActivationStatus(acts[0]);
    expect(refreshed.status).toBe('expired');
    const s = U({
      id: 'st3',
      role: 'STUDENT',
      establishmentId: est.id,
      accessStatus: 'expired',
      accessExpiresAt: past,
    });
    expect((await checkInstitutionalAccess(s)).allowed).toBe(false);
  });

  it('renouvellement restaure accès', async () => {
    const est = await createEstablishment({ name: 'Lycée', code: 'COM4' });
    const s = U({ id: 'st4', role: 'STUDENT', establishmentId: est.id, accessStatus: 'expired' });
    const actor = U({ id: 'adm4', role: 'ADMIN' });
    const r = await renewStudent({ user: s, establishmentId: est.id, days: 15, actor });
    expect(r.ok).toBe(true);
    expect((await checkInstitutionalAccess(s)).allowed).toBe(true);
  });

  it('révocation bloque accès', async () => {
    const est = await createEstablishment({ name: 'Lycée', code: 'COM5' });
    const s = U({ id: 'st5', role: 'STUDENT', establishmentId: est.id });
    const actor = U({ id: 'adm5', role: 'ESTABLISHMENT_ADMIN', establishmentId: est.id });
    await activateStudent({ user: s, establishmentId: est.id, days: 30, actor });
    await deactivateStudent({ user: s, establishmentId: est.id, actor, status: 'revoked' });
    expect((await checkInstitutionalAccess(s)).allowed).toBe(false);
    expect((await checkInstitutionalAccess(s)).status).toBe('revoked');
  });

  it('activation A ne touche pas élève B', async () => {
    const estA = await createEstablishment({ name: 'A', code: 'CA' });
    const estB = await createEstablishment({ name: 'B', code: 'CB' });
    const sB = U({ id: 'stB', role: 'STUDENT', establishmentId: estB.id, accessStatus: 'pending' });
    const actorA = U({ id: 'admA2', role: 'ESTABLISHMENT_ADMIN', establishmentId: estA.id });
    const sA = U({ id: 'stA', role: 'STUDENT', establishmentId: estA.id, accessStatus: 'pending' });
    await activateStudent({ user: sA, establishmentId: estA.id, days: 10, actor: actorA });
    expect(sB.accessStatus).toBe('pending');
    expect(sA.accessStatus).toBe('active');
  });
});
