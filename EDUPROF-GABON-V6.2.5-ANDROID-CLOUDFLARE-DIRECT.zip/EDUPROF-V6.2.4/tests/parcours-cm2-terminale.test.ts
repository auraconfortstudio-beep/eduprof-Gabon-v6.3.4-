/**
 * Parcours scolaire principal CM2 → Terminale
 * Garantit structure, IDs, et présence minimale de contenu (sans inventer de leçons).
 */
import { describe, it, expect } from 'vitest';
import { readFileSync, existsSync } from 'fs';
import { join } from 'path';
import { getLevels, getLevelById } from '../src/data/curriculum';
import { seriesChoicesForLevel, levelRequiresSeries, normalizeSeriesId } from '../src/data/seriesRegistry';

const MAIN_PATH = ['cm2', '6e', '5e', '4e', '3e', 'seconde', 'premiere', 'terminale'] as const;

describe('parcours scolaire CM2 → Terminale', () => {
  const levels = getLevels();

  it('expose les 8 niveaux du parcours principal dans l’ordre', async () => {
    const main = levels.filter((l) => MAIN_PATH.includes(l.id as (typeof MAIN_PATH)[number]));
    expect(main.map((l) => l.id)).toEqual([...MAIN_PATH]);
  });

  it('chaque niveau principal a un nom et une catégorie cohérents', async () => {
    const expectedCat: Record<string, string> = {
      cm2: 'primaire',
      '6e': 'college',
      '5e': 'college',
      '4e': 'college',
      '3e': 'college',
      seconde: 'lycee',
      premiere: 'lycee',
      terminale: 'lycee',
    };
    for (const id of MAIN_PATH) {
      const L = getLevelById(id);
      expect(L, id).toBeTruthy();
      expect(L!.category).toBe(expectedCat[id]);
      expect(L!.name.length).toBeGreaterThan(1);
    }
  });

  it('collège / primaire : matières avec au moins 1 chapitre et 1 leçon', async () => {
    for (const id of ['cm2', '6e', '5e', '4e', '3e'] as const) {
      const L = getLevelById(id)!;
      expect(L.subjects && L.subjects.length > 0, `${id} subjects`).toBe(true);
      const withContent = (L.subjects || []).filter(
        (s) => s.chapters?.some((c) => (c.lessons?.length || 0) > 0)
      );
      expect(withContent.length, `${id} with content`).toBeGreaterThan(0);
    }
  });

  it('lycée : séries présentes et matières non vides', async () => {
    for (const id of ['seconde', 'premiere', 'terminale'] as const) {
      const L = getLevelById(id)!;
      expect(L.hasSeries).toBe(true);
      expect(L.series && L.series.length > 0, id).toBe(true);
      for (const ser of L.series!) {
        const withContent = ser.subjects.filter(
          (s) => s.chapters?.some((c) => (c.lessons?.length || 0) > 0)
        );
        expect(withContent.length, `${id}/${ser.id}`).toBeGreaterThan(0);
      }
    }
  });

  it('IDs de leçons uniques au sein de chaque matière', async () => {
    for (const L of levels.filter((l) => MAIN_PATH.includes(l.id as any))) {
      const subjects = [
        ...(L.subjects || []),
        ...(L.series || []).flatMap((s) => s.subjects),
      ];
      for (const sub of subjects) {
        const ids = new Set<string>();
        for (const ch of sub.chapters || []) {
          for (const les of ch.lessons || []) {
            expect(ids.has(les.id), `dup ${les.id} in ${sub.id}`).toBe(false);
            ids.add(les.id);
          }
        }
      }
    }
  });

  it('seriesRegistry : secondes/première/terminale exigent une série', async () => {
    expect(levelRequiresSeries('seconde')).toBe(true);
    expect(levelRequiresSeries('premiere')).toBe(true);
    expect(levelRequiresSeries('terminale')).toBe(true);
    expect(levelRequiresSeries('cm2')).toBe(false);
    expect(seriesChoicesForLevel('seconde').length).toBeGreaterThan(0);
    expect(seriesChoicesForLevel('terminale').length).toBeGreaterThan(0);
  });

  it('normalizeSeriesId mappe les alias legacy', async () => {
    expect(normalizeSeriesId('terminale', 'C')).toBe('serie-c');
    expect(normalizeSeriesId('premiere', 'A1')).toBe('serie-a1');
  });
});

describe('catalogue serveur aligné sur le parcours', () => {
  const catalogPath = join(process.cwd(), 'workers/_shared/lesson-catalog.json');

  it('catalog présente des leçons pour chaque niveau CM2→Terminale', async () => {
    expect(existsSync(catalogPath)).toBe(true);
    const data = JSON.parse(readFileSync(catalogPath, 'utf-8'));
    const byLevel = data.stats?.byLevel || {};
    for (const id of MAIN_PATH) {
      expect(Number(byLevel[id] || 0), `catalog ${id}`).toBeGreaterThan(0);
    }
  });

  it('aucune leçon catalogue sans contenu textuel', async () => {
    const data = JSON.parse(readFileSync(catalogPath, 'utf-8'));
    const lessons = Object.values(data.lessons || {}) as { content?: string; lessonId?: string }[];
    const empty = lessons.filter((l) => !(l.content || '').trim());
    expect(empty.map((e) => e.lessonId)).toEqual([]);
  });
});
