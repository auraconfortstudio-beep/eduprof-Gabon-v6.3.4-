import { useState, useEffect, useRef, useCallback } from 'react';
import { getLevelById } from '@/data/curriculum';
import { getIcon } from '@/lib/icons';
import { ArrowLeft, BookOpen, Pencil, HelpCircle, CheckCircle2, XCircle, Lightbulb, RotateCcw } from 'lucide-react';
import type { Level, Subject, Chapter, Lesson, Exercise } from '@/data/types';
import { useAuth } from '@/lib/auth';
import { completeLesson, completeExercise, submitQuiz, isLessonCompletedLocally } from '@/lib/progress';
import { theme } from '@/lib/colors';

interface Props {
  levelId: string;
  subjectId: string;
  seriesId?: string;
  onNavigate: (page: string, params?: Record<string, string>) => void;
}

export function SubjectPage({ levelId, subjectId, seriesId, onNavigate }: Props) {
  const { user } = useAuth();
  const [view, setView] = useState<'chapters' | 'lesson' | 'exercises' | 'quiz'>('chapters');
  const [, setActiveChapter] = useState<Chapter | null>(null);
  const [activeLesson, setActiveLesson] = useState<Lesson | null>(null);

  const level = getLevelById(levelId) as Level | undefined;
  const subject = findSubject(level, subjectId, seriesId);

  if (!level || !subject) {
    return (
      <div className="p-8 text-center text-gray-500">
        Matière introuvable.
        <button onClick={() => onNavigate('home')} className="block mt-4 text-blue-600">Retour à l'accueil</button>
      </div>
    );
  }

  const Icon = getIcon(subject.icon);

  function openMael(extra: Record<string, string> = {}) {
    if (!subject) return;
    onNavigate('ai-tutor', {
      levelId,
      subjectId: subject.id,
      subjectName: subject.name,
      ...(seriesId ? { seriesId } : {}),
      ...(activeLesson
        ? { lessonId: activeLesson.id, lessonTitle: activeLesson.title }
        : {}),
      ...extra,
    });
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <div className={`bg-gradient-to-r ${theme(subject.color).gradientFrom} ${theme(subject.color).gradientTo} text-white px-4 py-6`}>
        <div className="max-w-4xl mx-auto">
          <button onClick={() => view === 'chapters' ? onNavigate('level', { levelId, ...(seriesId ? { seriesId } : {}) }) : setView('chapters')} className="flex items-center gap-1 text-white/80 hover:text-white text-sm mb-3">
            <ArrowLeft className="w-4 h-4" /> {view === 'chapters' ? level.name : subject.name}
          </button>
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center">
              <Icon className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">{subject.name}</h1>
              <p className="text-white/80 text-sm">{subject.description}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-6">
        <p className="text-xs text-gray-500 mb-3">
          Parcours : {level.name} › {subject.name}
          {activeLesson ? ` › ${activeLesson.title}` : ''}
          {view === 'lesson' ? ' › Cours' : ''}
          {view === 'exercises' ? ' › Exercices' : ''}
          {view === 'quiz' ? ' › Quiz' : ''}
        </p>
        {view === 'chapters' && (
          <div className="space-y-3">
            {subject.chapters.map((chapter, idx) => (
              <div key={chapter.id} className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
                <div className="p-4 border-b border-gray-50">
                  <div className="flex items-center gap-2 mb-1">
                    <span className={`text-xs font-bold ${theme(subject.color).text600} ${theme(subject.color).bg100} px-2 py-0.5 rounded`}>Ch.{idx + 1}</span>
                    <h3 className="font-bold text-gray-800">{chapter.title}</h3>
                  </div>
                </div>
                <div className="divide-y divide-gray-50">
                  {chapter.lessons.map(lesson => (
                    <div key={lesson.id} className="p-3">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="text-sm font-medium text-gray-700">{lesson.title}</h4>
                      </div>
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                        <ActionBtn icon={BookOpen} label="Cours" color={subject.color} onClick={() => { setActiveChapter(chapter); setActiveLesson(lesson); setView('lesson'); }} />
                        <ActionBtn icon={Pencil} label="Exercices" color={subject.color} onClick={() => { setActiveChapter(chapter); setActiveLesson(lesson); setView('exercises'); }} />
                        <ActionBtn icon={HelpCircle} label="Quiz" color={subject.color} onClick={() => { setActiveChapter(chapter); setActiveLesson(lesson); setView('quiz'); }} />
                        <ActionBtn icon={Lightbulb} label="Maël" color={subject.color} onClick={() => onNavigate('ai-tutor', {
                          levelId,
                          subjectId: subject.id,
                          subjectName: subject.name,
                          chapterId: chapter.id,
                          chapterName: chapter.title,
                          lessonId: lesson.id,
                          lessonTitle: lesson.title,
                        })} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}

        {view === 'lesson' && activeLesson && (
          <div>
            <div className="mb-3 flex justify-end">
              <button
                type="button"
                onClick={() =>
                  openMael({
                    lessonId: activeLesson.id,
                    lessonTitle: activeLesson.title,
                  })
                }
                className="text-xs px-3 py-1.5 rounded-lg bg-violet-50 text-violet-700 border border-violet-100 font-medium"
              >
                Expliquer cette leçon avec Maël
              </button>
              <button
                type="button"
                onClick={() =>
                  openMael({
                    lessonId: activeLesson.id,
                    lessonTitle: activeLesson.title,
                  })
                }
                className="text-xs px-3 py-1.5 rounded-lg bg-emerald-50 text-emerald-700 border border-emerald-100 font-medium ml-2"
              >
                📷 Montrer un exercice à Maël
              </button>
            </div>
            <LessonView
              key={activeLesson.id}
              lesson={activeLesson}
              subject={subject}
              userId={user?.id ?? null}
            />
          </div>
        )}

        {view === 'exercises' && activeLesson && (
          <div>
            <div className="mb-3 flex justify-end">
              <button
                type="button"
                onClick={() =>
                  openMael({
                    lessonId: activeLesson.id,
                    lessonTitle: activeLesson.title,
                  })
                }
                className="text-xs px-3 py-1.5 rounded-lg bg-violet-50 text-violet-700 border border-violet-100 font-medium"
              >
                Demander à Maël sur ces exercices
              </button>
            </div>
            <ExercisesView key={activeLesson.id} lesson={activeLesson} subject={subject} />
          </div>
        )}

        {view === 'quiz' && activeLesson && (
          <div>
            <div className="mb-3 flex justify-end">
              <button
                type="button"
                onClick={() =>
                  openMael({
                    lessonId: activeLesson.id,
                    lessonTitle: activeLesson.title,
                    quizId: `${activeLesson.id}-quiz`,
                  })
                }
                className="text-xs px-3 py-1.5 rounded-lg bg-violet-50 text-violet-700 border border-violet-100 font-medium"
              >
                Réviser ce quiz avec Maël
              </button>
            </div>
            <QuizView key={activeLesson.id} lesson={activeLesson} subject={subject} />
          </div>
        )}
      </div>
    </div>
  );
}

function findSubject(
  level: Level | undefined,
  subjectId: string,
  seriesId?: string
): Subject | undefined {
  if (!level) return undefined;
  if (level.subjects) {
    const direct = level.subjects.find((s) => s.id === subjectId);
    if (direct) return direct;
  }
  if (level.series) {
    // Préférer la série demandée (évite collision d'IDs entre séries)
    if (seriesId) {
      const ser = level.series.find((s) => s.id === seriesId);
      const found = ser?.subjects.find((sub) => sub.id === subjectId);
      if (found) return found;
    }
    for (const s of level.series) {
      const found = s.subjects.find((sub) => sub.id === subjectId);
      if (found) return found;
    }
  }
  if (level.filieres) {
    for (const f of level.filieres) {
      const found = f.subjects.find((sub) => sub.id === subjectId);
      if (found) return found;
    }
  }
  return undefined;
}

function ActionBtn({ icon: Icon, label, color, onClick }: { icon: typeof BookOpen; label: string; color: string; onClick: () => void }) {
  const c = theme(color);
  return (
    <button
      type="button"
      onClick={onClick}
      className={`flex items-center justify-center gap-1.5 py-2.5 px-3 min-h-[44px] rounded-lg ${c.bg50} ${c.borderHover} ${c.text700} text-xs font-medium transition-colors border border-transparent`}
    >
      <Icon className="w-4 h-4" />
      {label}
    </button>
  );
}

function LessonView({
  lesson,
  subject,
  userId,
}: {
  lesson: Lesson;
  subject: Subject;
  userId?: string | null;
}) {
  const isGuest = !userId;
  const [completed, setCompleted] = useState(() => isLessonCompletedLocally(lesson.id, userId));
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [xpGain, setXpGain] = useState(0);
  const [xpAwarded, setXpAwarded] = useState(false);

  useEffect(() => {
    setCompleted(isLessonCompletedLocally(lesson.id, userId));
    setSaving(false);
    setError(null);
    setXpGain(0);
    setXpAwarded(false);
  }, [lesson.id, userId]);

  async function handleComplete() {
    if (saving || completed) return;
    setSaving(true);
    setError(null);
    try {
      const res = await completeLesson(lesson.id, userId);
      if (res.completed) {
        setCompleted(true);
        setError(null);
        setXpAwarded(res.xpAwarded === true);
        setXpGain(res.xpGain ?? 0);
      } else {
        setCompleted(false);
        setXpAwarded(false);
        setXpGain(0);
        setError(
          res.error ||
            "La leçon n'a pas pu être enregistrée. Vérifie ta connexion et réessaie."
        );
      }
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
      <div className={`${theme(subject.color).text600} ${theme(subject.color).bg100} inline-block text-xs font-bold px-2 py-0.5 rounded mb-3`}>Objectif</div>
      <p className="text-gray-600 text-sm mb-4">{lesson.objective}</p>

      <h3 className="font-bold text-gray-800 text-lg mb-2">Cours</h3>
      <p className="text-gray-700 text-sm leading-relaxed mb-4">{lesson.content}</p>

      <h3 className="font-bold text-gray-800 text-lg mb-2">Exemple</h3>
      <div className={`${theme(subject.color).bg50} border ${theme(subject.color).border100} rounded-lg p-3 mb-4`}>
        <p className="text-gray-700 text-sm">{lesson.example}</p>
      </div>

      <h3 className="font-bold text-gray-800 text-lg mb-2">Points importants</h3>
      <ul className="space-y-2 mb-4">
        {lesson.keyPoints.map((point, i) => (
          <li key={i} className="flex items-start gap-2 text-sm text-gray-700">
            <CheckCircle2 className={`${theme(subject.color).text600} w-4 h-4 flex-shrink-0 mt-0.5`} />
            {point}
          </li>
        ))}
      </ul>

      {completed ? (
        <div className={`${theme(subject.color).bg50} ${theme(subject.color).text700} flex items-center justify-center gap-2 py-3 font-medium rounded-lg`}>
          <CheckCircle2 className="w-5 h-5" />
          {isGuest
            ? 'Leçon lue'
            : xpAwarded && xpGain > 0
              ? `Leçon enregistrée · +${xpGain} XP`
              : 'Leçon complétée !'}
        </div>
      ) : (
        <div>
          {error && (
            <p className="text-sm text-red-600 bg-red-50 border border-red-100 rounded-lg px-3 py-2 mb-3">
              {error}
            </p>
          )}
          <button
            type="button"
            onClick={() => void handleComplete()}
            disabled={saving}
            className={`${theme(subject.color).bg600} w-full py-3 text-white font-semibold rounded-lg transition-colors disabled:opacity-60`}
          >
            {saving
              ? 'Enregistrement…'
              : error
                ? isGuest
                  ? 'Réessayer'
                  : 'Réessayer (+10 XP)'
                : isGuest
                  ? 'Marquer comme lu'
                  : 'Marquer comme lu (+10 XP)'}
          </button>
        </div>
      )}
    </div>
  );
}

function ExercisesView({ lesson, subject }: { lesson: Lesson; subject: Subject }) {
  const { user } = useAuth();
  const [currentIdx, setCurrentIdx] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [results, setResults] = useState<{ correct: boolean; exercise: Exercise }[]>([]);
  const [xpNote, setXpNote] = useState<string | null>(null);

  const exercises = lesson.exercises || [];
  const exercise = exercises[currentIdx];
  const finished = exercises.length > 0 && currentIdx >= exercises.length;

  if (!exercises.length) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 text-center">
        <h3 className="font-bold text-gray-800 text-lg mb-2">Contenu en cours d'enrichissement</h3>
        <p className="text-gray-600 text-sm">Aucun exercice n'est encore disponible pour cette leçon.</p>
      </div>
    );
  }

  if (finished || !exercise) {
    const correctCount = results.filter(r => r.correct).length;
    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 text-center">
        <h3 className="font-bold text-gray-800 text-lg mb-2">Exercices terminés !</h3>
        <p className="text-gray-600 text-sm mb-4">Score: {correctCount} / {exercises.length}</p>
        <button
          type="button"
          onClick={() => { setCurrentIdx(0); setSelectedAnswer(null); setShowResult(false); setResults([]); setXpNote(null); }}
          className={`px-6 py-2.5 ${theme(subject.color).bg600} text-white font-semibold rounded-lg transition-colors inline-flex items-center gap-2`}
        >
          <RotateCcw className="w-4 h-4" /> Recommencer
        </button>
      </div>
    );
  }

  function handleAnswer() {
    if (selectedAnswer === null || !exercise) return;
    const isCorrect = selectedAnswer === exercise.correctAnswer;
    setShowResult(true);
    setXpNote(null);
    setResults([...results, { correct: isCorrect, exercise }]);
    if (user) {
      void completeExercise(exercise.id, selectedAnswer).then((res) => {
        if (res.recorded && res.xpAwarded) {
          setXpNote(`+${res.xpGain} XP enregistrés`);
        } else if (res.error) {
          setXpNote("XP non enregistré — vérifie ta connexion.");
        } else if (res.recorded && isCorrect) {
          setXpNote('Déjà enregistré — pas de XP supplémentaire');
        }
      });
    }
  }

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
      <div className="flex items-center justify-between mb-4">
        <span className="text-xs text-gray-500">Exercice {currentIdx + 1} / {exercises.length}</span>
        <span className={`${theme(subject.color).bg100} ${theme(subject.color).text700} text-xs font-medium px-2 py-0.5 rounded`}>{exercise.difficulty}</span>
      </div>

      <h3 className="font-bold text-gray-800 mb-4">{exercise.question}</h3>

      <div className="space-y-2 mb-4">
        {exercise.options.map((option, i) => {
          let style = 'border-gray-200 hover:border-gray-300';
          if (showResult) {
            if (i === exercise.correctAnswer) style = 'border-green-500 bg-green-50';
            else if (i === selectedAnswer) style = 'border-red-500 bg-red-50';
            else style = 'border-gray-100 opacity-50';
          } else if (i === selectedAnswer) {
            style = `${theme(subject.color).border500} ${theme(subject.color).bg50}`;
          }
          return (
            <button
              key={i}
              type="button"
              disabled={showResult}
              onClick={() => setSelectedAnswer(i)}
              className={`w-full text-left p-3 border-2 rounded-lg transition-all text-sm ${style}`}
            >
              {option}
            </button>
          );
        })}
      </div>

      {showResult && (
        <div className={`p-4 rounded-lg mb-4 ${selectedAnswer === exercise.correctAnswer ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200'}`}>
          <div className="flex items-center gap-2 mb-2">
            {selectedAnswer === exercise.correctAnswer ? (
              <><CheckCircle2 className="w-5 h-5 text-green-600" /><span className="font-bold text-green-700">Correct !</span></>
            ) : (
              <><XCircle className="w-5 h-5 text-red-600" /><span className="font-bold text-red-700">Pas tout à fait...</span></>
            )}
          </div>
          {xpNote && <p className="text-xs text-gray-600 mb-2">{xpNote}</p>}
          <p className="text-sm text-gray-700 mb-2">{exercise.explanation}</p>
          <div className="flex items-start gap-2 mt-2">
            <Lightbulb className="w-4 h-4 text-amber-500 flex-shrink-0 mt-0.5" />
            <p className="text-xs text-gray-600"><strong>Méthode:</strong> {exercise.method}</p>
          </div>
        </div>
      )}

      {!showResult ? (
        <button
          type="button"
          onClick={handleAnswer}
          disabled={selectedAnswer === null}
          className={`${theme(subject.color).bg600} w-full py-3 text-white font-semibold rounded-lg transition-colors disabled:opacity-50`}
        >
          Valider ma réponse
        </button>
      ) : (
        <button
          type="button"
          onClick={() => { setCurrentIdx(currentIdx + 1); setSelectedAnswer(null); setShowResult(false); setXpNote(null); }}
          className={`${theme(subject.color).bg600} w-full py-3 text-white font-semibold rounded-lg transition-colors`}
        >
          {currentIdx + 1 < exercises.length ? 'Exercice suivant →' : 'Voir mon score'}
        </button>
      )}
    </div>
  );
}

function QuizView({ lesson, subject }: { lesson: Lesson; subject: Subject }) {
  const { user } = useAuth();
  const [currentIdx, setCurrentIdx] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [answers, setAnswers] = useState<number[]>([]);
  const [xpGained, setXpGained] = useState(0);
  const [submitState, setSubmitState] = useState<'idle' | 'saving' | 'saved' | 'error'>('idle');
  const [submitError, setSubmitError] = useState<string | null>(null);
  const submittedRef = useRef(false);

  const quiz = lesson.quiz || [];
  const question = quiz[currentIdx];
  const finished = quiz.length > 0 && currentIdx >= quiz.length;
  const correctCount = finished
    ? answers.filter((a, i) => a === quiz[i]?.correctAnswer).length
    : 0;
  const totalQuestions = quiz.length;

  const persistQuiz = useCallback(async () => {
    if (!user) return;
    submittedRef.current = true;
    setSubmitState('saving');
    setSubmitError(null);
    const res = await submitQuiz(subject.id, lesson.id, answers);
    if (res.recorded) {
      setXpGained(res.xpAmount ?? 0);
      setSubmitState('saved');
    } else {
      submittedRef.current = false;
      setXpGained(0);
      setSubmitState('error');
      setSubmitError(
        res.error ||
          "Le score n'a pas pu être enregistré. Vérifie ta connexion et réessaie."
      );
    }
  }, [user, subject.id, lesson.id, answers]);

  // Hooks (useState / useRef / useCallback / useEffect) MUST stay above every return.
  useEffect(() => {
    if (!finished || !user || submittedRef.current) return;
    void persistQuiz();
  }, [finished, user, persistQuiz]);

  if (!quiz.length) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 text-center">
        <h3 className="font-bold text-gray-800 text-lg mb-2">Aucun quiz pour ce cours</h3>
        <p className="text-gray-600 text-sm">Ce chapitre n'a pas encore de quiz. Revenez au cours ou choisissez un autre chapitre.</p>
      </div>
    );
  }

  if (finished) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <h3 className="font-bold text-gray-800 text-lg text-center mb-2">Quiz terminé !</h3>
        <div className="text-center mb-6">
          <div className={`text-4xl font-bold ${correctCount >= totalQuestions * 0.5 ? 'text-green-600' : 'text-orange-600'}`}>
            {correctCount} / {totalQuestions}
          </div>
          {!user && (
            <p className="text-sm text-gray-500 mt-1">Connecte-toi pour enregistrer tes XP</p>
          )}
          {user && submitState === 'saving' && (
            <p className="text-sm text-gray-500 mt-1">Enregistrement du score…</p>
          )}
          {user && submitState === 'saved' && (
            <p className="text-sm text-gray-500 mt-1">
              {xpGained > 0 ? `+${xpGained} XP gagnés` : 'Score enregistré'}
            </p>
          )}
          {user && submitState === 'error' && (
            <div className="mt-3 text-left">
              <p className="text-sm text-red-600 bg-red-50 border border-red-100 rounded-lg px-3 py-2 mb-2">
                {submitError}
              </p>
              <button
                type="button"
                onClick={() => void persistQuiz()}
                className="w-full py-2.5 bg-red-600 text-white text-sm font-semibold rounded-lg"
              >
                Réessayer l'enregistrement
              </button>
            </div>
          )}
        </div>

        <div className="space-y-3 mb-6">
          {quiz.map((q, i) => {
            const userAnswer = answers[i];
            const isCorrect = userAnswer === q.correctAnswer;
            return (
              <div key={q.id} className={`p-3 rounded-lg border ${isCorrect ? 'border-green-200 bg-green-50' : 'border-red-200 bg-red-50'}`}>
                <div className="flex items-start gap-2 mb-1">
                  {isCorrect ? <CheckCircle2 className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" /> : <XCircle className="w-4 h-4 text-red-600 flex-shrink-0 mt-0.5" />}
                  <p className="text-sm text-gray-700">{q.question}</p>
                </div>
                {!isCorrect && (
                  <p className="text-xs text-gray-500 ml-6">{q.explanation}</p>
                )}
              </div>
            );
          })}
        </div>

        <button
          type="button"
          onClick={() => {
            setCurrentIdx(0);
            setSelectedAnswer(null);
            setShowResult(false);
            setAnswers([]);
            setXpGained(0);
            setSubmitState('idle');
            setSubmitError(null);
            submittedRef.current = false;
          }}
          className="w-full py-3 bg-gray-100 text-gray-700 rounded-xl font-medium hover:bg-gray-200 transition-colors flex items-center justify-center gap-2"
        >
          <RotateCcw className="w-4 h-4" /> Recommencer
        </button>
      </div>
    );
  }

  if (!question) {
    return null;
  }

  function handleAnswer() {
    if (selectedAnswer === null) return;
    setShowResult(true);
  }

  function handleNext() {
    if (selectedAnswer === null) return;
    setAnswers(prev => {
      const next = [...prev];
      next[currentIdx] = selectedAnswer;
      return next;
    });
    setSelectedAnswer(null);
    setShowResult(false);
    setCurrentIdx(currentIdx + 1);
  }

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
      <div className="flex items-center justify-between mb-4">
        <span className="text-xs text-gray-500">Question {currentIdx + 1} / {quiz.length}</span>
        <div className="flex gap-1">
          {quiz.map((_, i) => (
            <div key={i} className={`w-2 h-2 rounded-full ${i < currentIdx ? 'bg-green-500' : i === currentIdx ? 'bg-blue-500' : 'bg-gray-200'}`} />
          ))}
        </div>
      </div>

      <p className="font-medium text-gray-800 mb-4">{question.question}</p>

      <div className="space-y-2 mb-4">
        {question.options.map((opt, i) => {
          let style = 'border-gray-200 hover:border-gray-300 bg-white';
          if (showResult) {
            if (i === question.correctAnswer) style = 'border-green-500 bg-green-50';
            else if (i === selectedAnswer) style = 'border-red-500 bg-red-50';
            else style = 'border-gray-100 bg-gray-50 opacity-60';
          } else if (selectedAnswer === i) {
            style = 'border-blue-500 bg-blue-50';
          }
          return (
            <button
              key={i}
              type="button"
              onClick={() => !showResult && setSelectedAnswer(i)}
              disabled={showResult}
              className={`w-full text-left p-3 rounded-xl border-2 text-sm transition-colors ${style}`}
            >
              {opt}
            </button>
          );
        })}
      </div>

      {showResult && (
        <div className={`p-3 rounded-lg mb-4 text-sm ${selectedAnswer === question.correctAnswer ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'}`}>
          {selectedAnswer === question.correctAnswer ? 'Correct ! ' : 'Incorrect. '}
          {question.explanation}
        </div>
      )}

      {!showResult ? (
        <button
          type="button"
          onClick={handleAnswer}
          disabled={selectedAnswer === null}
          className={`${theme(subject.color).bg600} w-full py-3 text-white font-semibold rounded-lg transition-colors disabled:opacity-50`}
        >
          Valider
        </button>
      ) : (
        <button
          type="button"
          onClick={handleNext}
          className={`${theme(subject.color).bg600} w-full py-3 text-white font-semibold rounded-lg transition-colors`}
        >
          {currentIdx + 1 < quiz.length ? 'Question suivante →' : 'Voir mon score'}
        </button>
      )}
    </div>
  );
}
