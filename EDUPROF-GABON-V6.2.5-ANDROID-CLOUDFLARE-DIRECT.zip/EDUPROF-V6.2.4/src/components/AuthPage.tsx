import { useState } from 'react';
import { useAuth } from '@/lib/auth';
import { Mail, Lock, User, AlertCircle, GraduationCap, Sparkles } from 'lucide-react';
import { getLevels } from '@/data/curriculum';
import {
  seriesChoicesForLevel,
  levelRequiresSeries,
  normalizeSeriesId,
} from '@/data/seriesRegistry';

interface Props {
  onNavigate: (page: string) => void;
}

export function AuthPage({ onNavigate }: Props) {
  const { signIn, signUp, startDemo } = useAuth();
  const [mode, setMode] = useState<'login' | 'signup'>('signup');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [signupLevel, setSignupLevel] = useState('cm2');
  const [signupSeries, setSignupSeries] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [demoLoading, setDemoLoading] = useState(false);

  const signupLevels = getLevels().filter((l) => l.category !== 'universite');
  const signupSeriesOptions = seriesChoicesForLevel(signupLevel);

  async function handleDemo() {
    setError(null);
    setDemoLoading(true);
    const { error } = await startDemo();
    if (error) setError(error);
    else onNavigate('ai-tutor');
    setDemoLoading(false);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);

    if (mode === 'signup') {
      if (!displayName.trim()) {
        setError('Veuillez entrer votre nom');
        setLoading(false);
        return;
      }
      if (!email.trim() || !email.includes('@')) {
        setError('Veuillez entrer un email valide');
        setLoading(false);
        return;
      }
      if (password.length < 6) {
        setError('Le mot de passe doit faire au moins 6 caractères');
        setLoading(false);
        return;
      }
      const common = { email, password, displayName: displayName.trim() };
      if (levelRequiresSeries(signupLevel)) {
        const norm = normalizeSeriesId(signupLevel, signupSeries);
        if (!norm) {
          setError('Veuillez choisir votre série');
          setLoading(false);
          return;
        }
        const { error } = await signUp(
          common.email,
          common.password,
          common.displayName,
          signupLevel,
          norm
        );
        if (error) setError(error);
        else onNavigate('home');
      } else {
        const { error } = await signUp(
          common.email,
          common.password,
          common.displayName,
          signupLevel,
          null
        );
        if (error) setError(error);
        else onNavigate('home');
      }
    } else {
      const { error } = await signIn(email, password);
      if (error) setError(error);
      else onNavigate('home');
    }
    setLoading(false);
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-600 via-blue-700 to-indigo-800 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-8">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-blue-600 mb-4">
            <GraduationCap className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900">EduProf Gabon</h1>
          <p className="text-gray-500 mt-1 text-sm">
            {mode === 'signup' ? 'Créez votre compte' : 'Connectez-vous'}
          </p>
        </div>

        <button
          type="button"
          onClick={handleDemo}
          disabled={demoLoading}
          className="w-full mb-6 py-3 bg-amber-50 border-2 border-amber-300 text-amber-800 font-semibold rounded-lg hover:bg-amber-100 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
        >
          <Sparkles className="w-5 h-5" />
          {demoLoading ? 'Lancement…' : 'Essayer Maël en mode démo'}
        </button>
        <p className="text-center text-xs text-gray-400 -mt-4 mb-6">
          Sans inscription — accès limité au Professeur IA pour découvrir
        </p>

        {error && (
          <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg flex items-start gap-2">
            <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
            <p className="text-sm text-red-700">{error}</p>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {mode === 'signup' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Nom / Prénom</label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  value={displayName}
                  onChange={e => setDisplayName(e.target.value)}
                  placeholder="Votre nom"
                  className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-lg outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                />
              </div>
            </div>
          )}
          {mode === 'signup' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Niveau scolaire</label>
              <div className="relative">
                <GraduationCap className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <select
                  value={signupLevel}
                  onChange={(e) => {
                    setSignupLevel(e.target.value);
                    setSignupSeries('');
                  }}
                  className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-lg outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 bg-white text-gray-700"
                >
                  {signupLevels.map((l) => (
                    <option key={l.id} value={l.id}>
                      {l.name}
                    </option>
                  ))}
                </select>
              </div>
              {signupSeriesOptions.length > 0 && (
                <div className="mt-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Série</label>
                  <select
                    value={signupSeries}
                    onChange={(e) => setSignupSeries(e.target.value)}
                    className="w-full px-3 py-2.5 border border-gray-200 rounded-lg outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 bg-white text-gray-700"
                  >
                    <option value="">— Choisir —</option>
                    {signupSeriesOptions.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.label}
                        {s.classificationPending ? ' (contenu littéraire commun)' : ''}
                      </option>
                    ))}
                  </select>
                </div>
              )}
            </div>
          )}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="email"
                required
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="votre@email.com"
                className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-lg outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Mot de passe</label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="password"
                required
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="Au moins 6 caractères"
                className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-lg outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
          >
            {loading ? 'Chargement...' : mode === 'signup' ? 'Créer mon compte' : 'Se connecter'}
          </button>
        </form>

        <p className="text-center text-sm text-gray-500 mt-6">
          {mode === 'signup' ? 'Déjà un compte ?' : 'Pas encore de compte ?'}{' '}
          <button
            onClick={() => { setMode(mode === 'signup' ? 'login' : 'signup'); setError(null); }}
            className="text-blue-600 font-medium hover:underline"
          >
            {mode === 'signup' ? 'Se connecter' : 'Créer un compte'}
          </button>
        </p>

        <p className="text-center text-xs text-gray-400 mt-4">
          Un compte = un accès individuel. Ne partagez pas vos identifiants.
        </p>
      </div>
    </div>
  );
}
