import { useEffect, useMemo, useState } from 'react';
import {
  ArrowLeft,
  Award,
  BookOpen,
  ChevronRight,
  ExternalLink,
  Info,
  RefreshCw,
  Search,
  Sparkles,
} from 'lucide-react';
import { api } from '@/lib/api';
import {
  ANNALES_CATALOG,
  OFFICIAL_SOURCE_HINTS,
  type AnnaleEntry,
  examDisplayName,
  examMatchesFilter,
  filterAnnales,
  getAnnaleById,
  hasCorrectionText,
  hasSubjectText,
  listSubjectsForExamYear,
  listYearsForExam,
  statusLabel,
  buildAnnaleTutorContext,
  levelIdForExam,
} from '@/data/annales';

interface Props {
  onNavigate: (page: string, params?: Record<string, string>) => void;
  /** Préfiltre depuis un niveau (cm2 → CEP, 3e → BEPC, terminale → BAC) */
  initialExam?: string;
  /** Ouvrir directement une annale par id */
  initialAnnaleId?: string;
}

type Step = 'exams' | 'years' | 'subjects' | 'list' | 'detail';

function mapApiItem(row: Record<string, unknown>): AnnaleEntry | null {
  const id = typeof row.id === 'string' ? row.id : null;
  const exam = typeof row.exam === 'string' ? row.exam : null;
  const year = typeof row.year === 'string' ? row.year : String(row.year || '');
  const level = typeof row.level === 'string' ? row.level : '';
  const subject = typeof row.subject === 'string' ? row.subject : '';
  if (!id || !exam || !subject) return null;
  return {
    id,
    exam,
    year: year || '—',
    level: level || '—',
    series: (row.series as string) || null,
    subject,
    session: (row.session as string) || null,
    official: !!row.official,
    verificationStatus: (row.verificationStatus as AnnaleEntry['verificationStatus']) || 'unverified',
    source: typeof row.source === 'string' ? row.source : 'API',
    url: typeof row.url === 'string' ? row.url : undefined,
    subjectText: typeof row.subjectText === 'string' ? row.subjectText : null,
    correctionText: typeof row.correctionText === 'string' ? row.correctionText : null,
  };
}

const EXAM_CARDS: { id: string; label: string; subtitle: string; level: string; color: string }[] = [
  { id: 'CEP', label: 'CEP', subtitle: 'Certificat d’études primaires', level: 'CM2', color: 'emerald' },
  { id: 'BEPC', label: 'BEPC', subtitle: 'Brevet collège', level: '3ème', color: 'blue' },
  { id: 'BAC', label: 'BAC', subtitle: 'Baccalauréat', level: 'Terminale', color: 'violet' },
];

export function AnnalesPage({ onNavigate, initialExam, initialAnnaleId }: Props) {
  const [items, setItems] = useState<AnnaleEntry[]>(() =>
    Array.isArray(ANNALES_CATALOG) && ANNALES_CATALOG.length > 0 ? [...ANNALES_CATALOG] : []
  );
  const [source, setSource] = useState<'api' | 'local'>('local');
  const [syncing, setSyncing] = useState(true);
  const [apiNote, setApiNote] = useState<string | null>(null);

  const [exam, setExam] = useState<string | null>(() => {
    if (initialExam === 'CEPE') return 'CEP';
    if (initialExam && ['CEP', 'BEPC', 'BAC'].includes(initialExam)) return initialExam;
    return null;
  });
  const [year, setYear] = useState<string | null>(null);
  const [subject, setSubject] = useState<string | null>(null);
  const [selectedId, setSelectedId] = useState<string | null>(initialAnnaleId || null);
  const [search, setSearch] = useState('');

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setSyncing(true);
      setApiNote(null);
      try {
        const res = await api.getAnnales();
        if (cancelled) return;
        const list = Array.isArray(res?.annales) ? res.annales : [];
        const mapped = list
          .map((row) => mapApiItem(row as Record<string, unknown>))
          .filter((x): x is AnnaleEntry => x !== null);
        if (mapped.length > 0) {
          setItems(mapped);
          setSource('api');
        }
      } catch {
        if (!cancelled) {
          setApiNote('API Annales indisponible. Catalogue local affiché.');
        }
      } finally {
        if (!cancelled) setSyncing(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  // Ouvrir une annale demandée en paramètre
  useEffect(() => {
    if (!initialAnnaleId) return;
    const found = getAnnaleById(initialAnnaleId, items);
    if (found) {
      setSelectedId(found.id);
      setExam(examDisplayName(found.exam) === 'CEP' ? 'CEP' : found.exam);
      setYear(found.year);
      setSubject(found.subject);
    }
  }, [initialAnnaleId, items]);

  const step: Step = selectedId
    ? 'detail'
    : !exam
      ? 'exams'
      : !year
        ? 'years'
        : !subject
          ? 'subjects'
          : 'list';

  const years = useMemo(() => (exam ? listYearsForExam(exam, items) : []), [exam, items]);
  const subjects = useMemo(
    () => (exam && year ? listSubjectsForExamYear(exam, year, items) : []),
    [exam, year, items]
  );

  const list = useMemo(() => {
    if (search.trim()) {
      return filterAnnales(items, { exam: exam || 'all', q: search });
    }
    return filterAnnales(items, {
      exam: exam || 'all',
      year: year || undefined,
      subject: subject || undefined,
    });
  }, [items, exam, year, subject, search]);

  const selected = selectedId ? getAnnaleById(selectedId, items) : undefined;

  function resetToExams() {
    setExam(null);
    setYear(null);
    setSubject(null);
    setSelectedId(null);
    setSearch('');
  }

  function openMael(a: AnnaleEntry) {
    const ctx = buildAnnaleTutorContext(a);
    const levelId = levelIdForExam(a.exam) || ctx.level;
    onNavigate('ai-tutor', {
      levelId,
      level: levelId,
      subjectName: ctx.subjectName,
      subjectId: `annale-${a.id}`,
      seriesId: a.series || '',
      series: a.series || '',
      lessonTitle: ctx.lessonTitle,
      lessonId: `annale-${a.id}`,
      chapterName: `${examDisplayName(a.exam)} ${a.year}`,
      annaleId: a.id,
      annaleExam: examDisplayName(a.exam),
      annaleYear: a.year,
      // Préremplit une question utile pour l’élève
      prefillQuestion: a.subjectText
        ? `${ctx.questionPrefix}\n\nVoici l'énoncé de l'annale. Explique-moi la démarche pour la première question, étape par étape.\n\n---\n${a.subjectText.slice(0, 3500)}`
        : `${ctx.questionPrefix}\n\nAide-moi à me préparer pour ${examDisplayName(a.exam)} ${a.year} en ${a.subject}.`,
    });
  }

  function breadcrumb() {
    const parts: { label: string; onClick?: () => void }[] = [
      { label: 'Annales', onClick: resetToExams },
    ];
    if (exam) {
      parts.push({
        label: exam,
        onClick: () => {
          setYear(null);
          setSubject(null);
          setSelectedId(null);
        },
      });
    }
    if (year) {
      parts.push({
        label: year,
        onClick: () => {
          setSubject(null);
          setSelectedId(null);
        },
      });
    }
    if (subject) {
      parts.push({
        label: subject,
        onClick: () => setSelectedId(null),
      });
    }
    if (selected) {
      parts.push({ label: selected.session || selected.subject });
    }
    return parts;
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      <div className="bg-gradient-to-r from-orange-600 to-amber-700 text-white px-4 py-6">
        <div className="max-w-4xl mx-auto">
          <button
            type="button"
            onClick={() => {
              if (step === 'exams') onNavigate('home');
              else if (step === 'detail') setSelectedId(null);
              else if (step === 'list') setSubject(null);
              else if (step === 'subjects') setYear(null);
              else if (step === 'years') setExam(null);
            }}
            className="flex items-center gap-1 text-white/80 hover:text-white text-sm mb-3 min-h-[44px]"
          >
            <ArrowLeft className="w-4 h-4" />{' '}
            {step === 'exams' ? 'Accueil' : 'Retour'}
          </button>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Award className="w-7 h-7" /> Annales
          </h1>
          <p className="text-white/80 text-sm mt-1">
            CEP · BEPC · BAC — entraînement et références (sources indiquées)
          </p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-4 space-y-4">
        {/* Fil d'Ariane */}
        <nav className="flex flex-wrap items-center gap-1 text-xs text-gray-500">
          {breadcrumb().map((b, i) => (
            <span key={i} className="inline-flex items-center gap-1">
              {i > 0 && <ChevronRight className="w-3 h-3 text-gray-300" />}
              {b.onClick ? (
                <button type="button" onClick={b.onClick} className="text-orange-700 font-medium">
                  {b.label}
                </button>
              ) : (
                <span className="text-gray-700 font-medium">{b.label}</span>
              )}
            </span>
          ))}
        </nav>

        <div className="bg-blue-50 border border-blue-100 rounded-xl p-3">
          <p className="text-xs text-blue-800 flex items-start gap-2">
            <Info className="w-4 h-4 shrink-0 mt-0.5" />
            <span>
              Les sujets marqués <strong>Entraînement EduProf</strong> sont originaux et non officiels.
              Aucune annale n&apos;est présentée comme officielle sans source vérifiée. Source données :{' '}
              <strong>{source === 'api' ? 'API' : 'catalogue local'}</strong>
              {syncing ? (
                <span className="inline-flex items-center gap-1 ml-1">
                  <RefreshCw className="w-3 h-3 animate-spin" /> …
                </span>
              ) : null}
              .
            </span>
          </p>
          <ul className="mt-2 text-[11px] text-blue-700 space-y-0.5 pl-6">
            {OFFICIAL_SOURCE_HINTS.map((s) => (
              <li key={s.name}>
                <a href={s.url} target="_blank" rel="noopener noreferrer" className="underline">
                  {s.name}
                </a>
              </li>
            ))}
          </ul>
        </div>

        {apiNote && (
          <p className="text-xs text-amber-800 bg-amber-50 border border-amber-100 rounded-lg px-3 py-2">
            {apiNote}
          </p>
        )}

        {/* Recherche globale */}
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Rechercher examen, matière, année…"
            className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-gray-200 text-sm bg-white"
          />
        </div>

        {/* Étape examens */}
        {step === 'exams' && !search.trim() && (
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {EXAM_CARDS.map((c) => {
              const count = items.filter((a) => examMatchesFilter(a.exam, c.id)).length;
              const withText = items.filter(
                (a) => examMatchesFilter(a.exam, c.id) && hasSubjectText(a)
              ).length;
              return (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => {
                    setExam(c.id);
                    setYear(null);
                    setSubject(null);
                  }}
                  className="bg-white rounded-xl p-4 shadow-sm border border-gray-100 text-left hover:shadow-md min-h-[88px]"
                >
                  <p className="text-lg font-bold text-gray-900">{c.label}</p>
                  <p className="text-xs text-gray-500 mt-0.5">{c.subtitle}</p>
                  <p className="text-xs text-orange-700 mt-2 font-medium">
                    Niveau {c.level} · {withText}/{count} sujet{count > 1 ? 's' : ''} avec énoncé
                  </p>
                </button>
              );
            })}
          </div>
        )}

        {/* Années */}
        {step === 'years' && (
          <div className="space-y-2">
            <h2 className="font-bold text-gray-800">Choisir une année / session</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {years.map((y) => {
                const n = filterAnnales(items, { exam: exam!, year: y }).length;
                return (
                  <button
                    key={y}
                    type="button"
                    onClick={() => setYear(y)}
                    className="bg-white border border-gray-100 rounded-xl px-4 py-3 text-left hover:border-orange-200 min-h-[52px]"
                  >
                    <span className="font-bold text-gray-900">{y}</span>
                    <span className="block text-xs text-gray-500">{n} entrée{n > 1 ? 's' : ''}</span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Matières */}
        {step === 'subjects' && (
          <div className="space-y-2">
            <h2 className="font-bold text-gray-800">
              Matières — {exam} {year}
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {subjects.map((s) => {
                const n = filterAnnales(items, { exam: exam!, year: year!, subject: s }).length;
                return (
                  <button
                    key={s}
                    type="button"
                    onClick={() => setSubject(s)}
                    className="bg-white border border-gray-100 rounded-xl px-4 py-3 text-left hover:border-orange-200 flex items-center justify-between min-h-[52px]"
                  >
                    <span className="font-medium text-gray-900">{s}</span>
                    <span className="text-xs text-gray-500">{n}</span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Liste sujets */}
        {(step === 'list' || search.trim()) && (
          <div className="space-y-3">
            <h2 className="font-bold text-gray-800">
              {search.trim()
                ? `Résultats (${list.length})`
                : `${exam} · ${year} · ${subject}`}
            </h2>
            {list.length === 0 ? (
              <p className="text-sm text-gray-500 bg-white border border-gray-100 rounded-xl p-4">
                Aucune annale pour ce filtre. Les sujets officiels seront ajoutés lorsqu&apos;ils
                seront disponibles et vérifiés.
              </p>
            ) : (
              list.map((e) => (
                <button
                  key={e.id}
                  type="button"
                  onClick={() => {
                    setSelectedId(e.id);
                    if (!exam) setExam(examDisplayName(e.exam) === 'CEP' ? 'CEP' : e.exam);
                    if (!year) setYear(e.year);
                    if (!subject) setSubject(e.subject);
                  }}
                  className="w-full bg-white rounded-xl p-4 shadow-sm border border-gray-100 text-left hover:shadow-md"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="font-bold text-gray-900 text-sm">
                        {examDisplayName(e.exam)} {e.year} — {e.subject}
                      </p>
                      <p className="text-xs text-gray-500 mt-0.5">
                        {e.level}
                        {e.series ? ` · ${e.series}` : ''}
                        {e.session ? ` · ${e.session}` : ''}
                      </p>
                      <span
                        className={`inline-block mt-2 text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                          e.verificationStatus === 'edu_prof_training'
                            ? 'bg-violet-50 text-violet-700'
                            : e.verificationStatus === 'verified_official'
                              ? 'bg-emerald-50 text-emerald-700'
                              : 'bg-gray-100 text-gray-600'
                        }`}
                      >
                        {statusLabel(e.verificationStatus)}
                      </span>
                    </div>
                    <ChevronRight className="w-5 h-5 text-gray-300 shrink-0" />
                  </div>
                  <p className="text-[11px] text-gray-500 mt-2">
                    {hasSubjectText(e)
                      ? hasCorrectionText(e)
                        ? 'Énoncé + corrigé disponibles'
                        : 'Énoncé disponible · correction non disponible'
                      : 'Sujet non disponible pour le moment'}
                  </p>
                </button>
              ))
            )}
          </div>
        )}

        {/* Détail */}
        {step === 'detail' && selected && (
          <div className="space-y-4">
            <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-4">
              <p className="text-xs text-orange-700 font-semibold">
                {examDisplayName(selected.exam)} · {selected.year}
                {selected.series ? ` · Série ${selected.series}` : ''}
              </p>
              <h2 className="text-lg font-bold text-gray-900 mt-1">{selected.subject}</h2>
              <p className="text-xs text-gray-500 mt-1">
                {selected.level}
                {selected.session ? ` · ${selected.session}` : ''}
              </p>
              <p className="text-[11px] text-gray-500 mt-2">{selected.source}</p>
              <span
                className={`inline-block mt-2 text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                  selected.verificationStatus === 'edu_prof_training'
                    ? 'bg-violet-50 text-violet-700'
                    : selected.verificationStatus === 'verified_official'
                      ? 'bg-emerald-50 text-emerald-700'
                      : 'bg-gray-100 text-gray-600'
                }`}
              >
                {statusLabel(selected.verificationStatus)}
              </span>
            </div>

            {selected.url ? (
              <a
                href={selected.url}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 w-full py-3 rounded-xl bg-orange-600 text-white text-sm font-semibold min-h-[44px]"
              >
                Voir le sujet en ligne <ExternalLink className="w-4 h-4" />
              </a>
            ) : null}

            {hasSubjectText(selected) ? (
              <div className="bg-white rounded-xl border border-gray-100 p-4">
                <div className="flex items-center gap-2 mb-2">
                  <BookOpen className="w-4 h-4 text-orange-600" />
                  <h3 className="font-bold text-gray-900 text-sm">Énoncé</h3>
                </div>
                <pre className="text-xs text-gray-800 whitespace-pre-wrap font-sans leading-relaxed max-h-[28rem] overflow-y-auto">
                  {selected.subjectText}
                </pre>
              </div>
            ) : (
              <div className="bg-gray-50 border border-gray-200 rounded-xl p-4 text-sm text-gray-600">
                Sujet non disponible pour le moment. Structure prête pour ajout ultérieur dès
                qu&apos;une source vérifiée sera intégrée.
              </div>
            )}

            {hasSubjectText(selected) ? (
              hasCorrectionText(selected) ? (
                <div className="bg-white rounded-xl border border-emerald-100 p-4">
                  <h3 className="font-bold text-emerald-800 text-sm mb-2">Correction</h3>
                  <p className="text-[11px] text-emerald-700 mb-2">
                    Corrigé indicatif EduProf — ne pas confondre avec une correction officielle
                    d&apos;examen.
                  </p>
                  <pre className="text-xs text-gray-800 whitespace-pre-wrap font-sans leading-relaxed max-h-80 overflow-y-auto">
                    {selected.correctionText}
                  </pre>
                </div>
              ) : (
                <div className="bg-amber-50 border border-amber-100 rounded-xl p-4 text-sm text-amber-900">
                  Correction non disponible pour cette annale.
                </div>
              )
            ) : null}

            <button
              type="button"
              onClick={() => openMael(selected)}
              className="w-full flex items-center justify-center gap-2 py-3.5 rounded-xl bg-violet-600 hover:bg-violet-700 text-white text-sm font-semibold min-h-[48px] shadow-sm"
            >
              <Sparkles className="w-5 h-5" /> Demander à Maël d&apos;expliquer
            </button>
            <p className="text-[11px] text-center text-gray-500">
              Maël reçoit le contexte (examen, année, matière) et t&apos;aide pédagogiquement —
              sans se présenter comme correction officielle si ce n&apos;en est pas une.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
