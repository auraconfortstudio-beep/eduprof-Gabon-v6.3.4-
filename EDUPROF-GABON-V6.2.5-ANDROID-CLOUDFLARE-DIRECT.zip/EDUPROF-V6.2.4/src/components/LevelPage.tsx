import { useMemo, useState } from 'react';
import { theme } from '@/lib/colors';
import { getLevelById } from '@/data/curriculum';
import { getIcon } from '@/lib/icons';
import { ChevronRight, ArrowLeft } from 'lucide-react';
import type { Level, Series, Subject } from '@/data/types';
import { normalizeSeriesId, seriesChoicesForLevel } from '@/data/seriesRegistry';

interface Props {
  levelId: string;
  seriesId?: string;
  onNavigate: (page: string, params?: Record<string, string>) => void;
}

/** Matières avec au moins une leçon réelle (évite les cartes vides). */
function subjectsWithContent(subjects: Subject[]): Subject[] {
  return subjects.filter((s) =>
    (s.chapters || []).some((c) => (c.lessons || []).length > 0)
  );
}

function SubjectGrid({
  subjects,
  levelId,
  seriesId,
  onNavigate,
}: {
  subjects: Subject[];
  levelId: string;
  seriesId?: string;
  onNavigate: Props['onNavigate'];
}) {
  const list = subjectsWithContent(subjects);
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
      {list.map((subject) => {
        const Icon = getIcon(subject.icon);
        return (
          <button
            key={subject.id}
            onClick={() =>
              onNavigate('subject', {
                levelId,
                subjectId: subject.id,
                ...(seriesId ? { seriesId } : {}),
              })
            }
            className="bg-white rounded-xl p-4 shadow-sm border border-gray-100 hover:shadow-md transition-all text-left group min-h-[72px]"
          >
            <div className="flex items-center gap-3">
              <div
                className={`${theme(subject.color).bg100} w-12 h-12 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform`}
              >
                <Icon className={`${theme(subject.color).text600} w-6 h-6`} />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-bold text-gray-800 text-sm">{subject.name}</h3>
                <p className="text-xs text-gray-500 truncate">
                  {subject.chapters.length} chapitre{subject.chapters.length > 1 ? 's' : ''}
                </p>
              </div>
              <ChevronRight className="w-4 h-4 text-gray-300 group-hover:text-gray-400" />
            </div>
          </button>
        );
      })}
    </div>
  );
}

export function LevelPage({ levelId, seriesId: seriesIdProp, onNavigate }: Props) {
  const level = getLevelById(levelId) as Level | undefined;
  const [pickedSeries, setPickedSeries] = useState<string | null>(
    () => normalizeSeriesId(levelId, seriesIdProp) || seriesIdProp || null
  );

  const activeSeriesId = useMemo(() => {
    if (!level?.hasSeries) return null;
    return normalizeSeriesId(levelId, pickedSeries || seriesIdProp) || pickedSeries || seriesIdProp || null;
  }, [level, levelId, pickedSeries, seriesIdProp]);

  const seriesList: Series[] = level?.series ?? [];

  const visibleSeries = useMemo(() => {
    if (!level?.hasSeries) return [];
    const choices = seriesChoicesForLevel(levelId);
    if (choices.length === 0) return seriesList;
    // Afficher d'abord les séries canoniques présentes dans les données
    const ordered: Series[] = [];
    for (const c of choices) {
      const found = seriesList.find((s) => s.id === c.id);
      if (found) ordered.push(found);
    }
    // Conserver les autres (ex. ancien modèle) en bas, sans les cacher complètement
    for (const s of seriesList) {
      if (!ordered.some((o) => o.id === s.id)) ordered.push(s);
    }
    return ordered;
  }, [level, levelId, seriesList]);

  if (!level) {
    return (
      <div className="p-8 text-center text-gray-500">
        Niveau introuvable.
        <button onClick={() => onNavigate('home')} className="block mt-4 text-blue-600">
          Retour à l&apos;accueil
        </button>
      </div>
    );
  }

  const subjects = level.subjects ?? [];
  const selectedSeries = activeSeriesId
    ? seriesList.find((s) => s.id === activeSeriesId)
    : undefined;

  return (
    <div className="min-h-screen bg-gray-50">
      <div
        className={`bg-gradient-to-r ${theme(level.color).gradientFrom} ${theme(level.color).gradientTo} text-white px-4 py-6`}
      >
        <div className="max-w-4xl mx-auto">
          <button
            onClick={() => {
              if (level.hasSeries && activeSeriesId) {
                setPickedSeries(null);
                onNavigate('level', { levelId: level.id });
              } else {
                onNavigate('home');
              }
            }}
            className="flex items-center gap-1 text-white/80 hover:text-white text-sm mb-3"
          >
            <ArrowLeft className="w-4 h-4" />{' '}
            {level.hasSeries && activeSeriesId ? 'Séries' : 'Accueil'}
          </button>
          <h1 className="text-2xl font-bold">{level.name}</h1>
          <p className="text-white/80 text-sm mt-1">{level.description}</p>
          {selectedSeries && (
            <p className="text-white font-medium text-sm mt-2">{selectedSeries.name}</p>
          )}
          {(level.id === 'cm2' || level.id === '3e' || level.id === 'terminale') && (
            <button
              type="button"
              onClick={() =>
                onNavigate('annales', {
                  exam: level.id === 'cm2' ? 'CEP' : level.id === '3e' ? 'BEPC' : 'BAC',
                })
              }
              className="mt-3 inline-flex items-center gap-1.5 text-xs font-semibold bg-white/20 hover:bg-white/30 text-white rounded-lg px-3 py-2 min-h-[40px]"
            >
              Annales {level.id === 'cm2' ? 'CEP' : level.id === '3e' ? 'BEPC' : 'BAC'}
            </button>
          )}
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-6">
        {/* Lycée : choix de série d'abord */}
        {level.hasSeries && !activeSeriesId && (
          <div className="space-y-3">
            <h2 className="text-lg font-bold text-gray-800 mb-1">Choisir une série</h2>
            <p className="text-sm text-gray-500 mb-3">
              Les matières affichées dépendent de la série sélectionnée.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {visibleSeries.map((series) => (
                <button
                  key={series.id}
                  onClick={() => {
                    setPickedSeries(series.id);
                    onNavigate('level', { levelId: level.id, seriesId: series.id });
                  }}
                  className="bg-white rounded-xl p-4 shadow-sm border border-gray-100 hover:shadow-md text-left min-h-[64px]"
                >
                  <div className="flex items-center justify-between gap-2">
                    <div>
                      <h3 className="font-bold text-gray-800">{series.name}</h3>
                      <p className="text-xs text-gray-500 mt-0.5">
                        {subjectsWithContent(series.subjects).length} matière
                        {subjectsWithContent(series.subjects).length > 1 ? 's' : ''}
                      </p>
                    </div>
                    <ChevronRight className="w-5 h-5 text-gray-300" />
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Matières de la série choisie */}
        {level.hasSeries && activeSeriesId && selectedSeries && (
          <SubjectGrid
            subjects={selectedSeries.subjects}
            levelId={level.id}
            seriesId={selectedSeries.id}
            onNavigate={onNavigate}
          />
        )}

        {/* Université */}
        {level.hasFilieres && level.filieres && (
          <>
            {level.filieres.map((filiere) => (
              <div key={filiere.id} className="mb-6">
                <h2 className="text-lg font-bold text-gray-800 mb-1">{filiere.name}</h2>
                <p className="text-xs text-gray-500 mb-3">{filiere.domain}</p>
                <SubjectGrid subjects={filiere.subjects} levelId={level.id} onNavigate={onNavigate} />
              </div>
            ))}
          </>
        )}

        {/* Collège / CM2 sans séries */}
        {!level.hasSeries && !level.hasFilieres && subjects.length > 0 && (
          <SubjectGrid subjects={subjects} levelId={level.id} onNavigate={onNavigate} />
        )}
      </div>
    </div>
  );
}
