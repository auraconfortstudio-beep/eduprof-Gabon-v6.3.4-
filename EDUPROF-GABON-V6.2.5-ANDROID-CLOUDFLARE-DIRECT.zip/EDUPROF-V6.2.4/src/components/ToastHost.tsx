import { useEffect, useState } from 'react';
import { subscribeToasts, dismissToast, type ToastItem } from '@/lib/toast';

const colors: Record<string, string> = {
  success: 'bg-emerald-600',
  error: 'bg-red-600',
  info: 'bg-slate-800',
  loading: 'bg-blue-600',
};

export function ToastHost() {
  const [items, setItems] = useState<ToastItem[]>([]);
  useEffect(() => subscribeToasts(setItems), []);
  if (!items.length) return null;
  return (
    <div
      className="fixed z-[100] left-3 right-3 bottom-20 sm:left-auto sm:right-4 sm:bottom-4 sm:w-80 flex flex-col gap-2 pointer-events-none"
      role="region"
      aria-live="polite"
    >
      {items.map((t) => (
        <div
          key={t.id}
          className={`${colors[t.kind] || colors.info} text-white text-sm px-4 py-3 rounded-xl shadow-lg pointer-events-auto flex items-start gap-2 min-h-[44px]`}
        >
          <span className="flex-1">{t.message}</span>
          <button
            type="button"
            className="opacity-80 min-w-[32px] min-h-[32px]"
            aria-label="Fermer"
            onClick={() => dismissToast(t.id)}
          >
            ×
          </button>
        </div>
      ))}
    </div>
  );
}
