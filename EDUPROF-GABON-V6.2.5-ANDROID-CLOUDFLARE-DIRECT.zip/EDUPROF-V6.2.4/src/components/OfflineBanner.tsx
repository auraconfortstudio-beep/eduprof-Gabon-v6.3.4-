import { useEffect, useState } from 'react';

export function OfflineBanner() {
  const [online, setOnline] = useState(
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );
  useEffect(() => {
    const on = () => setOnline(true);
    const off = () => setOnline(false);
    window.addEventListener('online', on);
    window.addEventListener('offline', off);
    return () => {
      window.removeEventListener('online', on);
      window.removeEventListener('offline', off);
    };
  }, []);
  if (online) return null;
  return (
    <div
      className="bg-amber-500 text-amber-950 text-center text-sm font-medium px-3 py-2 min-h-[40px]"
      role="status"
    >
      Hors ligne — certaines actions (API, Maël) sont indisponibles. Le contenu déjà chargé reste visible.
    </div>
  );
}
