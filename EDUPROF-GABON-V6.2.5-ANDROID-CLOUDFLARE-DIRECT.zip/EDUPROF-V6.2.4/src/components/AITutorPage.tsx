import { useState, useRef, useEffect, useCallback } from 'react';
import { ArrowLeft, Send, Sparkles, Brain, ImagePlus, X, Loader2, History, Plus } from 'lucide-react';
import { getLevels } from '@/data/curriculum';
import { useAuth } from '@/lib/auth';
import { askTutor } from '@/lib/aiTutor';
import { api } from '@/lib/api';

interface Props {
  onNavigate: (page: string, params?: Record<string, string>) => void;
  /** Contexte scolaire optionnel (SubjectPage → Professeur IA / Annales) */
  tutorContext?: {
    level?: string;
    series?: string;
    filiere?: string;
    subjectId?: string;
    subjectName?: string;
    chapterId?: string;
    chapterName?: string;
    lessonId?: string;
    lessonTitle?: string;
  };
  /** Question préremplie (ex. depuis une annale) */
  prefillQuestion?: string;
}

export type ChatMessage = {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  image?: string;
  attachments?: {
    id?: string;
    fileName: string;
    mimeType: string;
    size: number;
    previewDataUrl?: string;
  }[];
  createdAt: number;
};

const ACCEPTED_MIME_TYPES = [
  'image/jpeg',
  'image/jpg',
  'image/png',
  'image/webp',
  'application/pdf',
];
const MAX_FILE_SIZE_MB = 4;
const MAX_ATTACHMENTS_PER_MESSAGE = 3;
/** Limite sessionStorage ~5 Mo : on tronque les data-URL trop grosses à la persistance */
const MAX_STORED_IMAGE_CHARS = 400_000;
const STORAGE_KEY = 'eduprof_ai_chat_v1';
const MAX_STORED_MESSAGES = 40;

export type PendingAttachment = {
  localId: string;
  fileName: string;
  mimeType: string;
  size: number;
  dataUrl: string;
  /** id serveur après upload */
  serverId?: string;
};

function uid(): string {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
}

const WELCOME: ChatMessage = {
  id: 'welcome',
  role: 'assistant',
  content:
    "Bonjour ! Je suis le Professeur IA d'EduProf Gabon. Pose-moi une question sur n'importe quelle matière, du CM2 à l'université. J'explique simplement, avec des exemples et des méthodes adaptées à ton niveau.",
  createdAt: Date.now(),
};

function isValidMessage(m: unknown): m is ChatMessage {
  if (!m || typeof m !== 'object') return false;
  const o = m as Record<string, unknown>;
  return (
    typeof o.id === 'string' &&
    (o.role === 'user' || o.role === 'assistant') &&
    typeof o.content === 'string' &&
    typeof o.createdAt === 'number'
  );
}

function loadHistory(): ChatMessage[] {
  try {
    const raw = sessionStorage.getItem(STORAGE_KEY);
    if (!raw) return [WELCOME];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed) || parsed.length === 0) return [WELCOME];
    const valid = parsed.filter(isValidMessage);
    if (valid.length === 0) return [WELCOME];
    // Ne pas re-ajouter welcome si l'historique a déjà des échanges
    return valid;
  } catch {
    return [WELCOME];
  }
}

function saveHistory(msgs: ChatMessage[]) {
  try {
    const trimmed = msgs.slice(-MAX_STORED_MESSAGES).map((m) => {
      if (m.image && m.image.length > MAX_STORED_IMAGE_CHARS) {
        // Garde le message texte, retire l'aperçu trop lourd
        const { image: _drop, ...rest } = m;
        return rest as ChatMessage;
      }
      return m;
    });
    sessionStorage.setItem(STORAGE_KEY, JSON.stringify(trimmed));
  } catch {
    // Quota / mode privé : on ignore silencieusement
    try {
      // Retry sans images
      const noImg = msgs.slice(-MAX_STORED_MESSAGES).map(({ image: _i, ...rest }) => rest);
      sessionStorage.setItem(STORAGE_KEY, JSON.stringify(noImg));
    } catch {
      /* ignore */
    }
  }
}

export function AITutorPage({ onNavigate, tutorContext, prefillQuestion }: Props) {
  const { user } = useAuth();
  const [messages, setMessages] = useState<ChatMessage[]>(() => loadHistory());
  const [input, setInput] = useState(() => prefillQuestion || '');
  const [selectedLevel, setSelectedLevel] = useState(
    tutorContext?.level || user?.educationLevel || 'cm2'
  );
  const [loading, setLoading] = useState(false);
  const [pendingAttachments, setPendingAttachments] = useState<PendingAttachment[]>([]);
  const [imageError, setImageError] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [conversationId, setConversationId] = useState<string | null>(null);
  const [showHistory, setShowHistory] = useState(false);
  const [conversationList, setConversationList] = useState<
    { id: string; title: string; updatedAt: string; messageCount: number; lessonTitle?: string | null }[]
  >([]);
  const [loadingHistory, setLoadingHistory] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const hydratedRef = useRef(false);
  const prefillAppliedRef = useRef(false);

  useEffect(() => {
    if (prefillQuestion && !prefillAppliedRef.current) {
      prefillAppliedRef.current = true;
      setInput(prefillQuestion);
    }
  }, [prefillQuestion]);

  const levels = getLevels();

  const contextLabel = [
    tutorContext?.level
      ? levels.find((l) => l.id === tutorContext.level)?.name || tutorContext.level
      : null,
    tutorContext?.series || null,
    tutorContext?.subjectName,
    tutorContext?.chapterName,
    tutorContext?.lessonTitle,
  ]
    .filter(Boolean)
    .join(' · ');

  const SUGGESTIONS = [
    { label: '👋 Bonjour Maël', text: 'Bonjour Maël' },
    { label: '🧠 Que peux-tu faire ?', text: 'Que peux-tu faire ?' },
    { label: '📚 Explique-moi cette leçon', text: 'Explique-moi cette leçon' },
    { label: '❓ Je ne comprends pas', text: 'Je ne comprends pas cette partie' },
    { label: '✏️ Donne-moi un exercice', text: 'Donne-moi un exercice' },
    { label: '🎯 Que dois-je réviser ?', text: 'Que dois-je réviser ?' },
  ];

  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages, loading, scrollToBottom]);

  // Persister l'historique (skip premier paint pour éviter d'écraser au montage)
  useEffect(() => {
    if (!hydratedRef.current) {
      hydratedRef.current = true;
      return;
    }
    saveHistory(messages);
  }, [messages]);

  // Auto-resize textarea
  useEffect(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = 'auto';
    el.style.height = `${Math.min(el.scrollHeight, 120)}px`;
  }, [input]);

  function handleFileSelect(e: React.ChangeEvent<HTMLInputElement>) {
    setImageError(null);
    const files = Array.from(e.target.files || []);
    e.target.value = '';
    if (!files.length) return;

    const remaining = MAX_ATTACHMENTS_PER_MESSAGE - pendingAttachments.length;
    if (remaining <= 0) {
      setImageError(`Maximum ${MAX_ATTACHMENTS_PER_MESSAGE} pièces jointes par message.`);
      return;
    }

    for (const file of files.slice(0, remaining)) {
      const mime = (file.type || '').toLowerCase();
      if (!ACCEPTED_MIME_TYPES.includes(mime)) {
        setImageError('Format non accepté. Utilise JPG, PNG, WEBP ou PDF.');
        continue;
      }
      if (file.size > MAX_FILE_SIZE_MB * 1024 * 1024) {
        setImageError(`Fichier trop lourd (max ${MAX_FILE_SIZE_MB} Mo).`);
        continue;
      }
      const reader = new FileReader();
      reader.onload = () => {
        const dataUrl = reader.result as string;
        setPendingAttachments((prev) => {
          if (prev.length >= MAX_ATTACHMENTS_PER_MESSAGE) return prev;
          return [
            ...prev,
            {
              localId: uid(),
              fileName: file.name || 'fichier',
              mimeType: mime === 'image/jpg' ? 'image/jpeg' : mime,
              size: file.size,
              dataUrl,
            },
          ];
        });
      };
      reader.onerror = () => {
        setImageError('Impossible de lire le fichier.');
      };
      reader.readAsDataURL(file);
    }
  }

  function removePendingAttachment(localId: string) {
    setPendingAttachments((prev) => prev.filter((a) => a.localId !== localId));
    setImageError(null);
  }

  function clearPendingAttachments() {
    setPendingAttachments([]);
    setImageError(null);
  }

  function startNewConversation() {
    setConversationId(null);
    setMessages([WELCOME]);
    setShowHistory(false);
  }

  async function openHistory() {
    setShowHistory(true);
    if (!user) return;
    setLoadingHistory(true);
    try {
      const { conversations } = await api.listConversations();
      setConversationList(conversations || []);
    } catch {
      setConversationList([]);
    } finally {
      setLoadingHistory(false);
    }
  }

  async function openConversation(id: string) {
    setLoadingHistory(true);
    try {
      const { conversation } = await api.getConversation(id);
      if (conversation) {
        const loaded: ChatMessage[] = (conversation.messages || [])
          .filter((m: { role: string }) => m.role !== 'system')
          .map((m: { id: string; role: string; content: string; createdAt: string }) => ({
            id: m.id,
            role: m.role === 'assistant' ? 'assistant' : 'user',
            content: m.content,
            createdAt: new Date(m.createdAt).getTime(),
          }));
        setMessages(loaded.length ? loaded : [WELCOME]);
        setConversationId(conversation.id);
      }
    } catch {
      /* si le chargement échoue, on reste sur la conversation en cours */
    } finally {
      setLoadingHistory(false);
      setShowHistory(false);
    }
  }

  async function handleSend() {
    const text = input.trim();
    if ((!text && pendingAttachments.length === 0) || loading || uploading) return;

    const snapshot = [...pendingAttachments];
    const historyForBackend = messages
      .filter((m) => m.id !== 'welcome')
      .map((m) => ({ role: m.role, content: m.content }));

    const userMessage: ChatMessage = {
      id: uid(),
      role: 'user',
      content: text || (snapshot.length ? '[Pièce(s) jointe(s)]' : ''),
      image: snapshot.find((a) => a.mimeType.startsWith('image/'))?.dataUrl,
      attachments: snapshot.map((a) => ({
        fileName: a.fileName,
        mimeType: a.mimeType,
        size: a.size,
        previewDataUrl: a.mimeType.startsWith('image/') ? a.dataUrl : undefined,
      })),
      createdAt: Date.now(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    clearPendingAttachments();
    setLoading(true);

    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }

    const levelName = levels.find((l) => l.id === selectedLevel)?.name ?? 'CM2';

    try {
      if (!user) {
        throw new Error('Connexion requise pour utiliser le Professeur IA.');
      }
      const tok = typeof localStorage !== 'undefined' ? localStorage.getItem('eduprof_token') : null;
      if (!tok) {
        throw new Error('Connexion requise pour utiliser le Professeur IA.');
      }

      // Upload sécurisé des pièces jointes vers le serveur (isolation userId)
      const uploadedIds: string[] = [];
      const uploadedMeta: { id: string; fileName: string; mimeType: string; size: number }[] = [];
      if (snapshot.length) {
        setUploading(true);
        for (const att of snapshot) {
          const res = await api.uploadAttachment({
            fileName: att.fileName,
            mimeType: att.mimeType,
            size: att.size,
            data: att.dataUrl,
            conversationId,
            lessonId: tutorContext?.lessonId ?? null,
          });
          uploadedIds.push(res.attachment.id);
          uploadedMeta.push({
            id: res.attachment.id,
            fileName: res.attachment.fileName,
            mimeType: res.attachment.mimeType,
            size: res.attachment.size,
          });
        }
        setUploading(false);
      }

      const questionForApi =
        text ||
        (uploadedMeta.length
          ? uploadedMeta.some((a) => a.mimeType.startsWith('image/'))
            ? "Voici une photo de mon exercice. Peux-tu la corriger et m'expliquer ?"
            : "J'ai joint un document. Peux-tu m'aider à le comprendre ?"
          : '');

      const result = await askTutor({
        level: selectedLevel,
        className: levelName,
        series: tutorContext?.series ?? null,
        filiere: tutorContext?.filiere ?? null,
        subject: tutorContext?.subjectName ?? null,
        subjectId: tutorContext?.subjectId ?? null,
        subjectName: tutorContext?.subjectName ?? null,
        chapterId: tutorContext?.chapterId ?? null,
        chapterName: tutorContext?.chapterName ?? null,
        lesson: tutorContext?.lessonTitle ?? null,
        lessonId: tutorContext?.lessonId ?? null,
        lessonTitle: tutorContext?.lessonTitle ?? null,
        question: questionForApi,
        history: historyForBackend,
        conversationId,
        attachmentIds: uploadedIds,
        attachments: uploadedMeta,
      });

      if (result.conversationId) setConversationId(result.conversationId);

      const assistantMessage: ChatMessage = {
        id: uid(),
        role: 'assistant',
        content: result.content,
        createdAt: Date.now(),
      };
      setMessages((prev) => [...prev, assistantMessage]);
    } catch (err) {
      console.error('AI Tutor error:', err);
      const msg =
        err instanceof Error && err.message
          ? err.message
          : "Désolé, je n'arrive pas à répondre pour le moment. Vérifie ta connexion et réessaie.";
      // Message utilisateur clair (pas de stack technique)
      const friendly =
        msg.includes('Connexion requise') ||
        msg.includes('Délai') ||
        msg.includes('introuvable') ||
        msg.includes('Limite')
          ? msg
          : "Désolé, je n'arrive pas à répondre pour le moment. Vérifie ta connexion et réessaie.";
      const errorMessage: ChatMessage = {
        id: uid(),
        role: 'assistant',
        content: friendly,
        createdAt: Date.now(),
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setLoading(false);
    }
  }

  function handleKeyDown(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  }

  const canSend = (input.trim().length > 0 || pendingAttachments.length > 0) && !loading && !uploading;

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <div className="bg-gradient-to-r from-violet-600 to-purple-700 text-white px-4 py-4 sticky top-0 z-20 shadow-sm">
        <div className="max-w-4xl mx-auto flex items-center gap-3">
          <button
            onClick={() => onNavigate('home')}
            className="text-white/80 hover:text-white p-1 -ml-1 rounded-lg"
            aria-label="Retour"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center shrink-0">
            <Sparkles className="w-5 h-5" />
          </div>
          <div className="min-w-0">
            <h1 className="text-lg font-bold leading-tight">Maël</h1>
            <p className="text-white/70 text-xs truncate">
              Professeur IA · EduProf Gabon
            </p>
          </div>
          <div className="ml-auto flex items-center gap-1">
            <button
              type="button"
              onClick={startNewConversation}
              className="text-white/80 hover:text-white p-2 rounded-lg hover:bg-white/10"
              aria-label="Nouvelle conversation"
              title="Nouvelle conversation"
            >
              <Plus className="w-5 h-5" />
            </button>
            <button
              type="button"
              onClick={openHistory}
              className="text-white/80 hover:text-white p-2 rounded-lg hover:bg-white/10"
              aria-label="Historique des conversations"
              title="Mes conversations"
            >
              <History className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {showHistory && (
        <div className="fixed inset-0 z-40 bg-black/40 flex items-start justify-center pt-20 px-4" onClick={() => setShowHistory(false)}>
          <div
            className="bg-white rounded-2xl shadow-lg w-full max-w-md max-h-[70vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-4 border-b border-gray-100 flex items-center justify-between">
              <p className="font-bold text-gray-900">Mes conversations</p>
              <button onClick={() => setShowHistory(false)} aria-label="Fermer" className="text-gray-400 hover:text-gray-600">
                <X className="w-5 h-5" />
              </button>
            </div>
            {!user ? (
              <p className="p-4 text-sm text-gray-400">Connecte-toi pour retrouver tes conversations.</p>
            ) : loadingHistory ? (
              <p className="p-4 text-sm text-gray-400">Chargement…</p>
            ) : conversationList.length === 0 ? (
              <p className="p-4 text-sm text-gray-400">Aucune conversation pour le moment.</p>
            ) : (
              <ul className="divide-y divide-gray-100">
                {conversationList.map((c) => (
                  <li key={c.id}>
                    <button
                      onClick={() => openConversation(c.id)}
                      className={`w-full text-left p-4 hover:bg-gray-50 ${c.id === conversationId ? 'bg-violet-50' : ''}`}
                    >
                      <p className="text-sm font-medium text-gray-900 truncate">{c.title}</p>
                      <p className="text-xs text-gray-400 mt-0.5">
                        {c.lessonTitle ? `${c.lessonTitle} · ` : ''}
                        {c.messageCount} message{c.messageCount > 1 ? 's' : ''} ·{' '}
                        {new Date(c.updatedAt).toLocaleDateString('fr-FR')}
                      </p>
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      )}

      {/* Level + context */}
      <div className="max-w-4xl mx-auto w-full px-4 py-3 space-y-2 shrink-0">
        <select
          value={selectedLevel}
          onChange={(e) => setSelectedLevel(e.target.value)}
          className="w-full p-2.5 border border-gray-200 rounded-lg text-sm text-gray-700 bg-white outline-none focus:border-violet-500"
          aria-label="Niveau scolaire"
        >
          {levels.map((l) => (
            <option key={l.id} value={l.id}>
              Niveau : {l.name}
            </option>
          ))}
        </select>
        {contextLabel && (
          <p className="text-xs text-violet-700 bg-violet-50 border border-violet-100 rounded-lg px-3 py-2">
            Contexte : {contextLabel}
          </p>
        )}
        {messages.length < 4 && (
          <div className="flex flex-wrap gap-2">
            {SUGGESTIONS.map((s) => (
              <button
                key={s.text}
                type="button"
                disabled={loading}
                onClick={() => {
                  setInput(s.text);
                  setTimeout(() => {
                    /* user can send; auto-send for fluidity */
                  }, 0);
                }}
                className="text-xs px-3 py-1.5 rounded-full bg-white border border-violet-200 text-violet-800 hover:bg-violet-50"
              >
                {s.label}
              </button>
            ))}
          </div>
        )}
        {!user && (
          <p className="text-xs text-amber-700 bg-amber-50 border border-amber-100 rounded-lg px-3 py-2">
            Connecte-toi pour utiliser pleinement le Professeur IA.
          </p>
        )}
      </div>

      {/* Messages */}
      <div
        className="flex-1 max-w-4xl mx-auto w-full px-4 space-y-3 overflow-y-auto pb-4"
        style={{ paddingBottom: '8rem' }}
      >
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm whitespace-pre-wrap break-words ${
                msg.role === 'user'
                  ? 'bg-violet-600 text-white rounded-br-md'
                  : 'bg-white text-gray-700 shadow-sm border border-gray-100 rounded-bl-md'
              }`}
            >
              {msg.role === 'assistant' && (
                <div className="flex items-center gap-1.5 mb-1.5">
                  <Brain className="w-4 h-4 text-violet-500" />
                  <span className="text-xs font-bold text-violet-600">Professeur IA</span>
                </div>
              )}
              {msg.image && (
                <div className="mb-2">
                  <img
                    src={msg.image}
                    alt="Image jointe"
                    className="max-h-48 max-w-full rounded-lg object-contain"
                  />
                </div>
              )}
              {msg.attachments && msg.attachments.length > 0 && (
                <div className="mb-2 flex flex-wrap gap-1">
                  {msg.attachments
                    .filter((a) => !a.mimeType.startsWith('image/'))
                    .map((a, i) => (
                      <span
                        key={i}
                        className={`text-[10px] px-2 py-0.5 rounded-full ${
                          msg.role === 'user'
                            ? 'bg-white/20 text-white'
                            : 'bg-violet-50 text-violet-700'
                        }`}
                      >
                        📄 {a.fileName}
                      </span>
                    ))}
                </div>
              )}
              {msg.content}
            </div>
          </div>
        ))}

        {loading && (
          <div className="flex justify-start">
            <div className="bg-white rounded-2xl rounded-bl-md px-4 py-3 shadow-sm border border-gray-100">
              <div className="flex items-center gap-2">
                <Loader2 className="w-4 h-4 text-violet-500 animate-spin" />
                <p className="text-xs text-violet-600 font-medium">
                  Le Professeur IA réfléchit…
                </p>
              </div>
              <div className="flex gap-1 mt-2">
                <span
                  className="w-2 h-2 bg-violet-400 rounded-full animate-bounce"
                  style={{ animationDelay: '0ms' }}
                />
                <span
                  className="w-2 h-2 bg-violet-400 rounded-full animate-bounce"
                  style={{ animationDelay: '150ms' }}
                />
                <span
                  className="w-2 h-2 bg-violet-400 rounded-full animate-bounce"
                  style={{ animationDelay: '300ms' }}
                />
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input zone — fixed above bottom nav */}
      <div className="fixed bottom-16 left-0 right-0 bg-white border-t border-gray-100 z-30">
        {pendingAttachments.length > 0 && (
          <div className="max-w-4xl mx-auto px-4 pt-3 flex flex-wrap gap-2">
            {pendingAttachments.map((att) => (
              <div
                key={att.localId}
                className="relative inline-flex items-center gap-2 rounded-lg border border-gray-200 bg-gray-50 p-2 pr-8"
              >
                {att.mimeType.startsWith('image/') ? (
                  <img
                    src={att.dataUrl}
                    alt={att.fileName}
                    className="h-14 w-14 rounded object-cover"
                  />
                ) : (
                  <div className="h-14 w-14 rounded bg-violet-100 text-violet-700 flex items-center justify-center text-xs font-bold">
                    PDF
                  </div>
                )}
                <div className="min-w-0 max-w-[120px]">
                  <p className="text-xs font-medium text-gray-800 truncate">{att.fileName}</p>
                  <p className="text-[10px] text-gray-400">{Math.max(1, Math.round(att.size / 1024))} Ko</p>
                </div>
                <button
                  type="button"
                  onClick={() => removePendingAttachment(att.localId)}
                  className="absolute top-1 right-1 w-5 h-5 bg-red-500 text-white rounded-full flex items-center justify-center shadow"
                  aria-label="Supprimer"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>
        )}
        {imageError && (
          <div className="max-w-4xl mx-auto px-4 pt-2">
            <p className="text-xs text-red-600">{imageError}</p>
          </div>
        )}

        <div className="max-w-4xl mx-auto p-3 flex items-end gap-2">
          <input
            ref={fileInputRef}
            type="file"
            accept="image/jpeg,image/jpg,image/png,image/webp,application/pdf"
            className="hidden"
            onChange={handleFileSelect}
            multiple
          />
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            disabled={loading}
            className="shrink-0 w-11 h-11 flex items-center justify-center rounded-xl border border-gray-200 text-gray-500 hover:bg-gray-50 hover:text-violet-600 transition-colors disabled:opacity-50"
            aria-label="Joindre un fichier"
          >
            <ImagePlus className="w-5 h-5" />
          </button>

          <textarea
            ref={textareaRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Pose ta question au Professeur IA…"
            rows={1}
            disabled={loading}
            className="flex-1 min-h-[44px] max-h-[120px] px-4 py-2.5 border border-gray-200 rounded-xl outline-none focus:border-violet-500 text-sm resize-none disabled:opacity-60 bg-white"
            aria-label="Message"
          />

          <button
            type="button"
            onClick={handleSend}
            disabled={!canSend}
            className="shrink-0 w-11 h-11 flex items-center justify-center bg-violet-600 text-white rounded-xl hover:bg-violet-700 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
            aria-label="Envoyer"
          >
            <Send className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
}
