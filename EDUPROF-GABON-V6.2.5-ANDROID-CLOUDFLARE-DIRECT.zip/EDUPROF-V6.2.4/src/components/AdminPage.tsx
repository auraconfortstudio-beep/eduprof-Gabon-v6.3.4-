import { useState, useEffect } from 'react';
import { useAuth } from '@/lib/auth';
import { ArrowLeft, Search, Crown, Loader2, ShieldCheck, Check, X } from 'lucide-react';
import { api } from '@/lib/api';
import { errorMessage } from '@/lib/errors';

interface Props {
  onNavigate: (page: string, params?: Record<string, string>) => void;
}

export function AdminPage({ onNavigate }: Props) {
  const { isAdmin, isOwner, setUserPremium } = useAuth();
  const [users, setUsers] = useState<any[]>([]);
  const [requests, setRequests] = useState<any[]>([]);
  const [logs, setLogs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [tab, setTab] = useState<'dashboard' | 'users' | 'institutions' | 'csv' | 'premium' | 'logs'>('dashboard');
  const [dash, setDash] = useState<{ establishments: number; active: number; expired: number; expiringSoon: number } | null>(null);
  const [institutions, setInstitutions] = useState<{ id: string; name: string; code: string; status: string }[]>([]);
  const [csvText, setCsvText] = useState('studentId,firstName,lastName,level,establishmentCode\n');
  const [csvPreview, setCsvPreview] = useState<string | null>(null);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!isAdmin) {
      setLoading(false);
      return;
    }
    load();
  }, [isAdmin]);

  async function load() {
    setLoading(true);
    setError(null);
    try {
      const [u, r] = await Promise.all([api.adminUsers(), api.getPremiumRequests()]);
      setUsers(u.users || []);
      setRequests(r.requests || []);
      try {
        const d = await api.institutionalDashboard();
        setDash({
          establishments: d.establishments,
          active: d.active,
          expired: d.expired,
          expiringSoon: d.expiringSoon,
        });
      } catch {
        setDash(null);
      }
      try {
        const inst = await api.listInstitutions();
        setInstitutions((inst.establishments || []) as { id: string; name: string; code: string; status: string }[]);
      } catch {
        setInstitutions([]);
      }
      if (isOwner) {
        const l = await api.adminLogs();
        setLogs(l.logs || []);
      }
    } catch (e: unknown) {
      setError(errorMessage(e));
    } finally {
      setLoading(false);
    }
  }

  async function handlePremium(targetId: string, grant: boolean, days = 30) {
    setActionLoading(targetId);
    try {
      await setUserPremium(targetId, grant, days);
      await load();
    } catch (e: unknown) {
      setError(errorMessage(e));
    } finally {
      setActionLoading(null);
    }
  }

  async function handleRole(targetId: string, role: 'ADMIN' | 'USER') {
    if (!isOwner) return;
    setActionLoading(targetId);
    try {
      await api.setRole(targetId, role);
      await load();
    } catch (e: unknown) {
      setError(errorMessage(e));
    } finally {
      setActionLoading(null);
    }
  }

  async function handleDelete(targetId: string) {
    if (!isOwner || !confirm('Supprimer cet utilisateur ?')) return;
    setActionLoading(targetId);
    try {
      await api.deleteUser(targetId);
      await load();
    } catch (e: unknown) {
      setError(errorMessage(e));
    } finally {
      setActionLoading(null);
    }
  }

  async function processReq(id: string, action: 'approve' | 'reject') {
    setActionLoading(id);
    try {
      await api.processPremium(id, action);
      await load();
    } catch (e: unknown) {
      setError(errorMessage(e));
    } finally {
      setActionLoading(null);
    }
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <p className="text-gray-500">Accès réservé aux administrateurs.</p>
      </div>
    );
  }

  const filtered = users.filter(
    (u) =>
      u.displayName?.toLowerCase().includes(search.toLowerCase()) ||
      u.email?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      <header className="bg-white border-b sticky top-0 z-10">
        <div className="max-w-2xl mx-auto px-4 py-3 flex items-center gap-3">
          <button onClick={() => onNavigate('home')} className="p-2 -ml-2 rounded-lg hover:bg-gray-100">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-lg font-bold flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-indigo-600" /> Administration
          </h1>
        </div>
        <div className="max-w-2xl mx-auto px-4 flex gap-2 pb-3">
          {(['users', 'premium', 'logs'] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`px-3 py-1.5 rounded-lg text-sm font-medium ${
                tab === t ? 'bg-indigo-600 text-white' : 'bg-gray-100 text-gray-600'
              }`}
            >
              {t === 'users' ? 'Utilisateurs' : t === 'premium' ? 'Demandes Premium' : 'Journaux'}
            </button>
          ))}
        </div>
      </header>

      <div className="max-w-2xl mx-auto px-4 py-4">
        
      <div className="flex flex-wrap gap-2 mb-4">
        {(['dashboard', 'users', 'institutions', 'csv', 'premium', 'logs'] as const).map((k) => (
          <button
            key={k}
            type="button"
            onClick={() => setTab(k)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium min-h-[36px] ${
              tab === k ? 'bg-blue-600 text-white' : 'bg-white border text-gray-600'
            }`}
          >
            {k === 'dashboard' ? 'Dashboard' : k === 'users' ? 'Élèves' : k === 'institutions' ? 'Établissements' : k === 'csv' ? 'Import CSV' : k === 'premium' ? 'Premium' : 'Audit'}
          </button>
        ))}
      </div>
      {tab === 'dashboard' && dash && (
        <div className="grid grid-cols-2 gap-3 mb-4">
          <div className="bg-white border rounded-xl p-3 text-sm"><div className="text-gray-500 text-xs">Établissements</div><div className="text-xl font-bold">{dash.establishments}</div></div>
          <div className="bg-white border rounded-xl p-3 text-sm"><div className="text-gray-500 text-xs">Actifs</div><div className="text-xl font-bold text-emerald-700">{dash.active}</div></div>
          <div className="bg-white border rounded-xl p-3 text-sm"><div className="text-gray-500 text-xs">Expirés</div><div className="text-xl font-bold text-amber-700">{dash.expired}</div></div>
          <div className="bg-white border rounded-xl p-3 text-sm"><div className="text-gray-500 text-xs">Bientôt expirés</div><div className="text-xl font-bold text-orange-700">{dash.expiringSoon}</div></div>
        </div>
      )}
      {tab === 'institutions' && (
        <div className="space-y-2 mb-4">
          {institutions.map((e) => (
            <div key={e.id} className="bg-white border rounded-xl p-3 text-sm">
              <div className="font-semibold">{e.name}</div>
              <div className="text-xs text-gray-500">{e.code} · {e.status}</div>
            </div>
          ))}
          {!institutions.length && <p className="text-sm text-gray-500">Aucun établissement.</p>}
          <button
            type="button"
            className="w-full py-2 rounded-xl bg-blue-600 text-white text-sm font-semibold"
            onClick={async () => {
              const name = prompt('Nom établissement ?');
              const code = prompt('Code unique ?');
              if (!name || !code) return;
              try {
                await api.createInstitution({ name, code });
                await load();
              } catch (e: unknown) {
                setError(errorMessage(e));
              }
            }}
          >
            Créer un établissement
          </button>
        </div>
      )}
      {tab === 'csv' && (
        <div className="space-y-2 mb-4">
          <textarea
            className="w-full border rounded-xl p-2 text-xs font-mono min-h-[120px]"
            value={csvText}
            onChange={(e) => setCsvText(e.target.value)}
          />
          <div className="flex gap-2">
            <button
              type="button"
              className="flex-1 py-2 rounded-xl border text-sm"
              onClick={async () => {
                try {
                  const p = await api.previewCsvImport(csvText);
                  setCsvPreview(JSON.stringify(p, null, 2));
                } catch (e: unknown) {
                  setError(errorMessage(e));
                }
              }}
            >
              Prévisualiser
            </button>
            <button
              type="button"
              className="flex-1 py-2 rounded-xl bg-emerald-600 text-white text-sm font-semibold"
              onClick={async () => {
                try {
                  const r = await api.confirmCsvImport(csvText);
                  setCsvPreview(JSON.stringify(r, null, 2));
                  await load();
                } catch (e: unknown) {
                  setError(errorMessage(e));
                }
              }}
            >
              Confirmer import
            </button>
          </div>
          {csvPreview && <pre className="text-[10px] bg-gray-50 border rounded-xl p-2 overflow-auto max-h-40">{csvPreview}</pre>}
        </div>
      )}

      {error && (
          <div className="mb-4 p-3 bg-red-50 text-red-700 text-sm rounded-lg">{error}</div>
        )}

        {loading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
          </div>
        ) : tab === 'users' ? (
          <>
            <div className="relative mb-4">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Rechercher…"
                className="w-full pl-9 pr-4 py-2 border rounded-lg text-sm"
              />
            </div>
            <p className="text-sm text-gray-500 mb-3">{users.length} utilisateurs</p>
            <ul className="space-y-3">
              {filtered.map((u) => (
                <li key={u.id} className="bg-white rounded-xl p-4 shadow-sm">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="font-semibold text-gray-900">
                        {u.displayName}{' '}
                        {u.role === 'OWNER' && <span className="text-xs text-purple-600">OWNER</span>}
                        {u.role === 'ADMIN' && <span className="text-xs text-indigo-600">ADMIN</span>}
                      </p>
                      <p className="text-xs text-gray-500">{u.email}</p>
                      <p className="text-xs text-gray-400 mt-1">
                        {u.educationLevel} · {u.xp} XP · série {u.streak}
                      </p>
                      {u.isPremium && (
                        <p className="text-xs text-amber-600 mt-1">
                          Premium jusqu'au {u.premiumUntil ? new Date(u.premiumUntil).toLocaleDateString('fr-FR') : '—'}
                        </p>
                      )}
                    </div>
                    <div className="flex flex-col gap-1">
                      {u.isPremium ? (
                        <button
                          disabled={!!actionLoading}
                          onClick={() => handlePremium(u.id, false)}
                          className="text-xs px-2 py-1 bg-gray-100 rounded text-gray-600"
                        >
                          Retirer Premium
                        </button>
                      ) : (
                        <button
                          disabled={!!actionLoading}
                          onClick={() => handlePremium(u.id, true, 30)}
                          className="text-xs px-2 py-1 bg-amber-100 text-amber-700 rounded flex items-center gap-1"
                        >
                          <Crown className="w-3 h-3" /> +30j
                        </button>
                      )}
                      {isOwner && u.role !== 'OWNER' && (
                        <>
                          <button
                            onClick={() => handleRole(u.id, u.role === 'ADMIN' ? 'USER' : 'ADMIN')}
                            className="text-xs px-2 py-1 bg-indigo-50 text-indigo-700 rounded"
                          >
                            {u.role === 'ADMIN' ? 'Retirer ADMIN' : 'Nommer ADMIN'}
                          </button>
                          <button
                            onClick={() => handleDelete(u.id)}
                            className="text-xs px-2 py-1 bg-red-50 text-red-600 rounded"
                          >
                            Supprimer
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          </>
        ) : tab === 'premium' ? (
          <ul className="space-y-3">
            {requests.length === 0 && <p className="text-gray-400 text-sm">Aucune demande.</p>}
            {requests.map((r) => (
              <li key={r.id} className="bg-white rounded-xl p-4 shadow-sm">
                <div className="flex justify-between">
                  <div>
                    <p className="font-semibold">{r.userDisplayName}</p>
                    <p className="text-xs text-gray-500">{r.userEmail}</p>
                    <p className="text-sm mt-1">
                      {r.plan === 'daily' ? '1 jour' : '1 mois'} — {r.amount} FCFA
                    </p>
                    <p className="text-xs text-gray-600 mt-1">Preuve : {r.proof}</p>
                    <p className="text-xs text-gray-400">{new Date(r.createdAt).toLocaleString('fr-FR')}</p>
                  </div>
                  <div className="flex flex-col gap-1 items-end">
                    <span
                      className={`text-xs px-2 py-0.5 rounded ${
                        r.status === 'pending'
                          ? 'bg-yellow-100 text-yellow-800'
                          : r.status === 'approved'
                          ? 'bg-green-100 text-green-800'
                          : 'bg-red-100 text-red-800'
                      }`}
                    >
                      {r.status}
                    </span>
                    {r.status === 'pending' && (
                      <div className="flex gap-1 mt-1">
                        <button
                          onClick={() => processReq(r.id, 'approve')}
                          className="p-1.5 bg-green-100 text-green-700 rounded"
                        >
                          <Check className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => processReq(r.id, 'reject')}
                          className="p-1.5 bg-red-100 text-red-700 rounded"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </li>
            ))}
          </ul>
        ) : (
          <ul className="space-y-2">
            {!isOwner && <p className="text-sm text-gray-400">Réservé à l'OWNER.</p>}
            {logs.map((l) => (
              <li key={l.id} className="bg-white rounded-lg p-3 text-sm shadow-sm">
                <p className="font-medium">{l.action}</p>
                <p className="text-xs text-gray-500">
                  {l.actorEmail} → {l.targetUserId || '—'} · {l.details}
                </p>
                <p className="text-xs text-gray-400">{new Date(l.createdAt).toLocaleString('fr-FR')}</p>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
