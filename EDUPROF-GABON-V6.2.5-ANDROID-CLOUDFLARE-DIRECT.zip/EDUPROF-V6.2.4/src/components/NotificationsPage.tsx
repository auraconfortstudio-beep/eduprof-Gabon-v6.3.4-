import { useEffect, useState } from 'react';
import { api } from '@/lib/api';
import { errorMessage } from '@/lib/errors';
import { showToast } from '@/lib/toast';

interface Props {
  onNavigate: (page: string) => void;
}

interface NItem {
  id: string;
  title: string;
  message: string;
  type: string;
  createdAt: string;
  readAt?: string | null;
}

export function NotificationsPage({ onNavigate }: Props) {
  const [items, setItems] = useState<NItem[]>([]);
  const [unread, setUnread] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  async function load() {
    setLoading(true);
    setError(null);
    try {
      const r = await api.listNotifications();
      setItems((r.items || []) as NItem[]);
      setUnread(r.unread || 0);
    } catch (e: unknown) {
      setError(errorMessage(e));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      <div className="bg-blue-700 text-white px-4 pt-10 pb-4">
        <button type="button" className="text-sm min-h-[44px]" onClick={() => onNavigate('home')}>
          ← Retour
        </button>
        <h1 className="text-xl font-bold">Notifications</h1>
        <p className="text-blue-100 text-sm">{unread} non lue(s)</p>
      </div>
      <div className="p-4 space-y-3">
        {loading && <p className="text-sm text-gray-500">Chargement…</p>}
        {error && <p className="text-sm text-red-600">{error}</p>}
        {!loading && !items.length && (
          <p className="text-sm text-gray-500 text-center py-12">Aucune notification.</p>
        )}
        {items.map((n) => (
          <button
            key={n.id}
            type="button"
            className={`w-full text-left bg-white border rounded-xl p-4 min-h-[64px] ${
              n.readAt ? 'border-gray-100 opacity-80' : 'border-blue-200'
            }`}
            onClick={async () => {
              try {
                await api.markNotificationRead(n.id);
                await load();
              } catch (e: unknown) {
                showToast(errorMessage(e), 'error');
              }
            }}
          >
            <div className="text-xs text-gray-400">{n.type}</div>
            <div className="font-semibold text-sm">{n.title}</div>
            <div className="text-sm text-gray-600">{n.message}</div>
          </button>
        ))}
        {!!items.length && (
          <button
            type="button"
            className="w-full min-h-[48px] rounded-xl border text-sm font-semibold"
            onClick={async () => {
              await api.markAllNotificationsRead();
              showToast('Tout marqué comme lu', 'success');
              await load();
            }}
          >
            Tout marquer comme lu
          </button>
        )}
      </div>
    </div>
  );
}
