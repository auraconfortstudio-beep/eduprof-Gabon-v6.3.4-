import { getLevels } from '@/data/curriculum';
import { getIcon } from '@/lib/icons';
import { useAuth } from '@/lib/auth';
import { PREMIUM_DAILY, PREMIUM_MONTHLY } from '@/lib/constants';
import { Award, Flame, Search, Sparkles, BookOpen, HelpCircle, Archive, Info } from 'lucide-react';

interface Props {
  onNavigate: (page: string, params?: Record<string, string>) => void;
}

/** Niveaux avec pack pédagogique documenté Gabon 2024-2025 (V2.6) */
const LEVELS_WITH_DOCUMENTED_PACK = new Set(['cm2', '6e', '5e', '4e', '3e', 'seconde', 'premiere', 'terminale']);

export function HomePage({ onNavigate }: Props) {
  // Université masquée de la vitrine commerciale (hors périmètre pack documenté)
  const levels = getLevels().filter((l) => l.category !== 'universite');
  const { profile } = useAuth();

  const categories = [
    { id: 'primaire', label: 'Primaire', color: 'emerald' },
    { id: 'college', label: 'Collège', color: 'blue' },
    { id: 'lycee', label: 'Lycée', color: 'violet' },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero */}
      <div className="bg-gradient-to-br from-blue-600 to-indigo-700 text-white">
        <div className="max-w-4xl mx-auto px-4 pt-12 pb-8">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold">EduProf Gabon</h1>
              <p className="text-blue-100 text-sm mt-1">
                Parcours scolaire CM2 → Terminale — cours, exercices, quiz, Maël
              </p>
            </div>
            <button
              onClick={() => onNavigate('search')}
              className="p-2.5 bg-white/20 rounded-xl hover:bg-white/30 transition-colors min-h-[44px] min-w-[44px] flex items-center justify-center"
              aria-label="Rechercher"
            >
              <Search className="w-5 h-5" />
            </button>
          </div>

          {profile && (
            <div className="flex flex-wrap gap-3 mt-4">
              <div className="bg-white/15 rounded-xl px-4 py-2 flex items-center gap-2">
                <Flame className="w-4 h-4 text-orange-300" />
                <span className="text-sm font-medium">{profile.streak} jours</span>
              </div>
              <div className="bg-white/15 rounded-xl px-4 py-2 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-yellow-300" />
                <span className="text-sm font-medium">{profile.xp} XP</span>
              </div>
              {profile.isPremium && (
                <div className="bg-yellow-400/30 rounded-xl px-4 py-2 flex items-center gap-2">
                  <Award className="w-4 h-4 text-yellow-200" />
                  <span className="text-sm font-medium">Premium</span>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Quick actions — z-10 pour rester cliquables au-dessus du hero */}
      <div className="max-w-4xl mx-auto px-4 -mt-4 relative z-10">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <QuickAction
            icon={BookOpen}
            label="Cours"
            color="blue"
            onClick={() => document.getElementById('niveaux')?.scrollIntoView({ behavior: 'smooth' })}
          />
          <QuickAction
            icon={HelpCircle}
            label="Quiz"
            color="emerald"
            onClick={() => document.getElementById('niveaux')?.scrollIntoView({ behavior: 'smooth' })}
          />
          <QuickAction
            icon={Archive}
            label="Annales"
            color="orange"
            onClick={() => onNavigate('annales')}
          />
          <QuickAction
            icon={Sparkles}
            label="Professeur IA"
            color="violet"
            onClick={() => onNavigate('ai-tutor')}
          />
        </div>
      </div>

      {/* Couverture honnête */}
      <div className="max-w-4xl mx-auto px-4 pt-6">
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-sm text-amber-950">
          <p className="leading-relaxed">
            <strong>Couverture progressive.</strong> EduProf s&apos;appuie sur des références pédagogiques
            gabonaises documentées. Le pack actuel propose des parcours complets (cours → exercices → quiz)
            sur certaines matières — pas encore l&apos;ensemble du programme national.
          </p>
          <button
            type="button"
            onClick={() => onNavigate('info')}
            className="mt-2 inline-flex items-center gap-1.5 text-amber-900 font-semibold underline min-h-[44px]"
          >
            <Info className="w-4 h-4" />
            Voir la couverture, les sources et à propos
          </button>
        </div>
      </div>

      {/* Levels */}
      <div id="niveaux" className="max-w-4xl mx-auto px-4 py-8">
        {categories.map((cat) => {
          const catLevels = levels.filter((l) => l.category === cat.id);
          if (catLevels.length === 0) return null;
          return (
            <div key={cat.id} className="mb-8">
              <h2 className={`text-lg font-bold text-${cat.color}-600 mb-3`}>{cat.label}</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {catLevels.map((level) => {
                  const Icon = getIcon(level.icon);
                  const documented = LEVELS_WITH_DOCUMENTED_PACK.has(level.id);
                  return (
                    <button
                      key={level.id}
                      onClick={() => onNavigate('level', { levelId: level.id })}
                      className="bg-white rounded-xl p-4 shadow-sm border border-gray-100 hover:shadow-md transition-all text-left group min-h-[72px]"
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-12 h-12 shrink-0 rounded-xl bg-${level.color}-100 flex items-center justify-center group-hover:scale-110 transition-transform`}
                        >
                          <Icon className={`w-6 h-6 text-${level.color}-600`} />
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="flex flex-wrap items-center gap-2">
                            <h3 className="font-bold text-gray-800">{level.name}</h3>
                            <span
                              className={`text-[10px] font-semibold px-1.5 py-0.5 rounded-full ${
                                documented
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : 'bg-amber-100 text-amber-800'
                              }`}
                            >
                              {documented ? 'Pack dispo.' : 'Enrichissement'}
                            </span>
                          </div>
                          <p className="text-xs text-gray-500 line-clamp-2">{level.description}</p>
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}

        {/* Premium banner — tarifs officiels inchangés */}
        {(!profile || !profile.isPremium) && (
          <button
            onClick={() => onNavigate('premium')}
            className="w-full bg-gradient-to-r from-amber-400 to-orange-500 rounded-2xl p-5 text-white text-left shadow-lg hover:shadow-xl transition-shadow min-h-[72px]"
          >
            <div className="flex items-center justify-between gap-3">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <Award className="w-5 h-5" />
                  <h3 className="font-bold text-lg">Passez Premium</h3>
                </div>
                <p className="text-sm text-amber-50">
                  {PREMIUM_DAILY} FCFA/jour ou {PREMIUM_MONTHLY} FCFA/mois
                </p>
              </div>
              <div className="text-2xl font-bold shrink-0">→</div>
            </div>
          </button>
        )}
      </div>
    </div>
  );
}

function QuickAction({
  icon: Icon,
  label,
  color,
  onClick,
}: {
  icon: typeof BookOpen;
  label: string;
  color: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={(e) => {
        e.preventDefault();
        e.stopPropagation();
        onClick();
      }}
      className="bg-white rounded-xl p-3 shadow-sm border border-gray-100 hover:shadow-md transition-all flex flex-col items-center gap-1.5 min-h-[72px] w-full cursor-pointer"
      aria-label={label}
    >
      <div className={`w-10 h-10 rounded-lg bg-${color}-100 flex items-center justify-center`}>
        <Icon className={`w-5 h-5 text-${color}-600`} />
      </div>
      <span className="text-xs font-medium text-gray-700">{label}</span>
    </button>
  );
}
