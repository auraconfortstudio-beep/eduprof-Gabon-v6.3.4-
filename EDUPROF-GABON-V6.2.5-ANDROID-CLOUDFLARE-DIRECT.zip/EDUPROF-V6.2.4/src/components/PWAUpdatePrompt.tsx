import { useEffect, useState } from 'react';

/**
 * Détection basique SW update (sans vite-plugin-pwa).
 * Affiche un bandeau si un worker en attente est détecté.
 */
export function PWAUpdatePrompt() {
  const [waiting, setWaiting] = useState<ServiceWorker | null>(null);
  const [offlineReady, setOfflineReady] = useState(false);

  useEffect(() => {
    if (!('serviceWorker' in navigator)) return;
    let reg: ServiceWorkerRegistration | undefined;
    navigator.serviceWorker.ready.then((r) => {
      reg = r;
      if (r.active) setOfflineReady(true);
      if (r.waiting) setWaiting(r.waiting);
      r.addEventListener('updatefound', () => {
        const sw = r.installing;
        if (!sw) return;
        sw.addEventListener('statechange', () => {
          if (sw.state === 'installed' && navigator.serviceWorker.controller) {
            setWaiting(r.waiting);
          }
        });
      });
    });
    const onController = () => {
      // nouvelle version activée
    };
    navigator.serviceWorker.addEventListener('controllerchange', onController);
    return () => navigator.serviceWorker.removeEventListener('controllerchange', onController);
  }, []);

  if (!waiting && !offlineReady) return null;

  return (
    <div className="fixed z-[90] left-3 right-3 top-3 sm:left-auto sm:right-4 sm:w-96 space-y-2">
      {waiting && (
        <div className="bg-blue-700 text-white rounded-xl px-4 py-3 shadow-lg text-sm flex flex-col gap-2">
          <p>Une nouvelle version d’EduProf est disponible.</p>
          <div className="flex gap-2">
            <button
              type="button"
              className="flex-1 min-h-[44px] rounded-lg bg-white text-blue-800 font-semibold"
              onClick={() => {
                waiting.postMessage({ type: 'SKIP_WAITING' });
                window.location.reload();
              }}
            >
              Mettre à jour
            </button>
            <button
              type="button"
              className="min-h-[44px] px-3 rounded-lg border border-white/40"
              onClick={() => setWaiting(null)}
            >
              Plus tard
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
