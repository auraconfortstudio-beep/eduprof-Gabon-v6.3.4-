import { useState, useEffect } from 'react';
import { useAuth } from '@/lib/auth';
import { ArrowLeft, Flame, Sparkles, Award, TrendingUp, BarChart3 } from 'lucide-react';
import { getProgress } from '@/lib/progress';
import { api } from '@/lib/api';
import { getLevels } from '@/data/curriculum';
import { seriesChoicesForLevel, levelRequiresSeries, normalizeSeriesId } from '@/data/seriesRegistry';
import { errorMessage } from '@/lib/errors';

interface Props {
  onNavigate: (page: string, params?: Record<string, string>) => void;
}

/**
 * Stats affichées : issues de GET /progress (profile serveur) + GET /leaderboard (myRank).
 * Pas de valeurs fictives — pendant le chargement on affiche « … »,
 * si l’API échoue on affiche « — » et un message d’erreur.
 */
export function ProgressPage({ onNavigate }: Props) {
  const { user, updateProfile } = useAuth();
  const [editLevel, setEditLevel] = useState(user?.educationLevel || 'cm2');
  const [editSeries, setEditSeries] = useState(user?.educationSeries || '');
  const [savingProfile, setSavingProfile] = useState(false);
  const [profileMsg, setProfileMsg] = useState<string | null>(null);

  useEffect(() => {
    if (user?.educationLevel) setEditLevel(user.educationLevel);
    if (user?.educationSeries != null) setEditSeries(user.educationSeries || '');
  }, [user?.educationLevel, user?.educationSeries]);

  const seriesOptions = seriesChoicesForLevel(editLevel);

  async function saveSchoolProfile() {
    if (!user) return;
    setSavingProfile(true);
    setProfileMsg(null);
    try {
      const payload: Record<string, unknown> = { educationLevel: editLevel };
      if (levelRequiresSeries(editLevel)) {
        const norm = normalizeSeriesId(editLevel, editSeries) || editSeries || null;
        payload.educationSeries = norm;
      } else {
        payload.educationSeries = null;
      }
      const res = await updateProfile(payload);
      if (res?.error) setProfileMsg(res.error);
      else setProfileMsg('Profil scolaire enregistré.');
    } catch (e: unknown) {
      setProfileMsg(errorMessage(e) || 'Enregistrement impossible.');
    } finally {
      setSavingProfile(false);
    }
  }

  const [quizResults, setQuizResults] = useState<any[]>([]);
  const [xpHistory, setXpHistory] = useState<any[]>([]);
  const [completedLessons, setCompletedLessons] = useState<string[]>([]);
  const [leaderboard, setLeaderboard] = useState<any[]>([]);
  /** XP / streak / rang issus de l’API (null = pas encore chargé ou échec) */
  const [serverXp, setServerXp] = useState<number | null>(null);
  const [serverStreak, setServerStreak] = useState<number | null>(null);
  const [myRank, setMyRank] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);

  useEffect(() => {
    if (!user?.id) {
      setLoading(false);
      return;
    }

    let cancelled = false;

    (async () => {
      setLoading(true);
      setLoadError(null);
      try {
        // 1) Progression + profil serveur (source de vérité XP)
        const data = await getProgress();
        if (cancelled) return;

        if (data?.profile) {
          if (typeof data.profile.xp === 'number') setServerXp(data.profile.xp);
          if (typeof data.profile.streak === 'number') setServerStreak(data.profile.streak);
        } else if (data === null) {
          // getProgress a échoué silencieusement — tenter le profil auth comme secours
          if (typeof user.xp === 'number') setServerXp(user.xp);
          if (typeof user.streak === 'number') setServerStreak(user.streak);
          setLoadError('Impossible de charger la progression complète. Vérifie ta connexion.');
        }

        if (data?.progress) {
          setQuizResults(data.progress.quizzes || []);
          setXpHistory(data.progress.xpHistory || []);
          setCompletedLessons(
            (data.progress.lessons || []).map((l: { lessonId: string }) => l.lessonId)
          );
        }

        // 2) Classement + rang
        const lb = await api.leaderboard();
        if (cancelled) return;
        const list = lb.leaderboard || [];
        setLeaderboard(list);

        if (lb.myRank && typeof lb.myRank.rank === 'number') {
          setMyRank(lb.myRank.rank);
        } else {
          const idx = list.findIndex((p: { id: string }) => p.id === user.id);
          setMyRank(idx >= 0 ? idx + 1 : null);
        }

        // Si le leaderboard a mon XP plus récent, l’utiliser
        if (lb.myRank && typeof lb.myRank.xp === 'number') {
          setServerXp(lb.myRank.xp);
        }
      } catch (e) {
        console.error('ProgressPage load error:', e);
        if (!cancelled) {
          setLoadError(
            errorMessage(e, 'Erreur de chargement de la progression.')
          );
          // Secours : valeurs déjà connues côté auth (session)
          if (typeof user.xp === 'number') setServerXp(user.xp);
          if (typeof user.streak === 'number') setServerStreak(user.streak);
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [user?.id]); // eslint-disable-line react-hooks/exhaustive-deps -- volontaire : un fetch par id

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <p className="text-gray-500">Connectez-vous pour voir votre progression.</p>
      </div>
    );
  }

  const xpDisplay = loading && serverXp === null ? '…' : serverXp !== null ? serverXp : '—';
  const streakDisplay =
    loading && serverStreak === null ? '…' : serverStreak !== null ? serverStreak : '—';
  const rankDisplay = loading && myRank === null ? '…' : myRank !== null ? myRank : '—';

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      <header className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-lg mx-auto px-4 py-3 flex items-center gap-3">
          <button
            onClick={() => onNavigate('home')}
            className="p-2 -ml-2 rounded-lg hover:bg-gray-100"
          >
            <ArrowLeft className="w-5 h-5 text-gray-600" />
          </button>
          <h1 className="text-lg font-bold text-gray-900">Ma progression</h1>
        </div>
      </header>

      <div className="max-w-lg mx-auto px-4 py-6 space-y-6">
        {loadError && (
          <p className="text-xs text-amber-700 bg-amber-50 border border-amber-100 rounded-lg px-3 py-2">
            {loadError}
          </p>
        )}

        {/* Stats depuis l’API */}
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-white rounded-xl p-4 shadow-sm text-center">
            <Sparkles className="w-6 h-6 text-amber-500 mx-auto mb-1" />
            <p className="text-2xl font-bold text-gray-900">{xpDisplay}</p>
            <p className="text-xs text-gray-500">XP</p>
          </div>
          <div className="bg-white rounded-xl p-4 shadow-sm text-center">
            <Flame className="w-6 h-6 text-orange-500 mx-auto mb-1" />
            <p className="text-2xl font-bold text-gray-900">{streakDisplay}</p>
            <p className="text-xs text-gray-500">Série</p>
          </div>
          <div className="bg-white rounded-xl p-4 shadow-sm text-center">
            <Award className="w-6 h-6 text-blue-500 mx-auto mb-1" />
            <p className="text-2xl font-bold text-gray-900">{rankDisplay}</p>
            <p className="text-xs text-gray-500">Rang</p>
          </div>
        </div>

        {/* Leaderboard */}
        <div className="bg-white rounded-xl shadow-sm p-4">
          <h2 className="font-bold text-gray-800 mb-3 flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-green-600" /> Classement
          </h2>
          {loading ? (
            <p className="text-sm text-gray-400">Chargement…</p>
          ) : (
            <ul className="space-y-2">
              {leaderboard.slice(0, 15).map((p) => (
                <li
                  key={p.id}
                  className={`flex items-center justify-between py-2 px-2 rounded-lg ${
                    p.id === user.id ? 'bg-blue-50' : ''
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className="w-6 text-sm font-bold text-gray-400">#{p.rank}</span>
                    <span className="font-medium text-gray-800">{p.displayName}</span>
                    {p.isPremium && <span className="text-xs text-amber-600">★</span>}
                  </div>
                  <span className="text-sm font-semibold text-blue-600">{p.xp} XP</span>
                </li>
              ))}
              {leaderboard.length === 0 && (
                <li className="text-sm text-gray-400">Aucun classement pour le moment.</li>
              )}
            </ul>
          )}
        </div>

        
        {/* Profil scolaire : niveau → série */}
        <div className="bg-white rounded-xl shadow-sm p-4">
          <h2 className="font-bold text-gray-800 mb-3">Profil scolaire</h2>
          <div className="space-y-3">
            <div>
              <label className="text-xs text-gray-500">Niveau</label>
              <select
                value={editLevel}
                onChange={(e) => {
                  setEditLevel(e.target.value);
                  setEditSeries('');
                }}
                className="w-full mt-1 border border-gray-200 rounded-lg px-3 py-2 text-sm"
              >
                {getLevels().map((l) => (
                  <option key={l.id} value={l.id}>
                    {l.name}
                  </option>
                ))}
              </select>
            </div>
            {seriesOptions.length > 0 && (
              <div>
                <label className="text-xs text-gray-500">Série</label>
                <select
                  value={editSeries}
                  onChange={(e) => setEditSeries(e.target.value)}
                  className="w-full mt-1 border border-gray-200 rounded-lg px-3 py-2 text-sm"
                >
                  <option value="">— Choisir —</option>
                  {seriesOptions.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.label}
                      {s.classificationPending ? ' (contenu littéraire commun)' : ''}
                    </option>
                  ))}
                </select>
                <p className="text-xs text-gray-400 mt-1">
                  Anciennes valeurs A / C / D restent reconnues.
                </p>
              </div>
            )}
            <button
              type="button"
              disabled={savingProfile}
              onClick={saveSchoolProfile}
              className="w-full py-2.5 bg-blue-600 text-white text-sm font-semibold rounded-lg disabled:opacity-50"
            >
              {savingProfile ? 'Enregistrement…' : 'Enregistrer le parcours'}
            </button>
            {profileMsg && <p className="text-xs text-gray-600">{profileMsg}</p>}
          </div>
        </div>

{/* Recent XP */}
        <div className="bg-white rounded-xl shadow-sm p-4">
          <h2 className="font-bold text-gray-800 mb-3 flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-purple-600" /> Historique XP
          </h2>
          {loading ? (
            <p className="text-sm text-gray-400">Chargement…</p>
          ) : xpHistory.length === 0 ? (
            <p className="text-sm text-gray-400">Aucune activité encore.</p>
          ) : (
            <ul className="space-y-2 max-h-48 overflow-y-auto">
              {xpHistory.slice(0, 20).map((e, i) => (
                <li key={i} className="flex justify-between text-sm">
                  <span className="text-gray-600 truncate">{e.reason}</span>
                  <span className="text-green-600 font-medium">+{e.amount}</span>
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* Quizzes */}
        <div className="bg-white rounded-xl shadow-sm p-4">
          <h2 className="font-bold text-gray-800 mb-3">Quiz récents</h2>
          {loading ? (
            <p className="text-sm text-gray-400">Chargement…</p>
          ) : quizResults.length === 0 ? (
            <p className="text-sm text-gray-400">Aucun quiz complété.</p>
          ) : (
            <ul className="space-y-2">
              {quizResults.slice(0, 10).map((q, i) => (
                <li key={i} className="flex justify-between text-sm">
                  <span className="text-gray-600">{q.quizId}</span>
                  <span className="font-medium">
                    {q.score}/{q.totalQuestions}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </div>

        <p className="text-center text-xs text-gray-400">
          {completedLessons.length} leçon(s) terminée(s)
        </p>
      </div>
    </div>
  );
}
