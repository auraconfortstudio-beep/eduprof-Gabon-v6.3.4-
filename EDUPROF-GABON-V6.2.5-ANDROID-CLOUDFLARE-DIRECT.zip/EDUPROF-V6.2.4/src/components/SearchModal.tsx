import { useState } from 'react';
import { Search, X } from 'lucide-react';
import { getLevels } from '@/data/curriculum';
import { getIcon } from '@/lib/icons';
import type { Level, Subject } from '@/data/types';

interface Props {
  onNavigate: (page: string, params?: Record<string, string>) => void;
}

export function SearchModal({ onNavigate }: Props) {
  const [query, setQuery] = useState('');
  const levels = getLevels();

  const results: { level: Level; subject: Subject; levelName: string }[] = [];
  const q = query.toLowerCase().trim();

  if (q) {
    for (const level of levels) {
      if (level.subjects) {
        for (const subject of level.subjects) {
          if (subject.name.toLowerCase().includes(q) || level.name.toLowerCase().includes(q)) {
            results.push({ level, subject, levelName: level.name });
          }
        }
      }
      if (level.series) {
        for (const series of level.series) {
          for (const subject of series.subjects) {
            if (subject.name.toLowerCase().includes(q) || series.name.toLowerCase().includes(q)) {
              results.push({ level, subject, levelName: `${level.name} - ${series.name}` });
            }
          }
        }
      }
      if (level.filieres) {
        for (const filiere of level.filieres) {
          for (const subject of filiere.subjects) {
            if (subject.name.toLowerCase().includes(q) || filiere.name.toLowerCase().includes(q)) {
              results.push({ level, subject, levelName: `${level.name} - ${filiere.name}` });
            }
          }
        }
      }
    }
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex items-start justify-center pt-20 px-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg max-h-[70vh] overflow-hidden flex flex-col">
        <div className="flex items-center gap-3 p-4 border-b">
          <Search className="w-5 h-5 text-gray-400" />
          <input
            autoFocus
            type="text"
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Rechercher un cours, une matière, un niveau..."
            className="flex-1 outline-none text-gray-800 placeholder-gray-400"
          />
          <button onClick={() => onNavigate('home')} className="text-gray-400 hover:text-gray-600">
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="overflow-y-auto flex-1">
          {results.length === 0 && q && (
            <p className="p-4 text-gray-500 text-center text-sm">Aucun résultat pour « {query} »</p>
          )}
          {results.length === 0 && !q && (
            <p className="p-4 text-gray-400 text-center text-sm">Commencez à taper pour rechercher</p>
          )}
          {results.slice(0, 20).map(({ level, subject, levelName }) => {
            const Icon = getIcon(subject.icon);
            return (
              <button
                key={subject.id}
                onClick={() => onNavigate('subject', { levelId: level.id, subjectId: subject.id })}
                className="w-full flex items-center gap-3 p-3 hover:bg-gray-50 text-left border-b border-gray-100"
              >
                <div className={`w-10 h-10 rounded-lg bg-${subject.color}-100 flex items-center justify-center flex-shrink-0`}>
                  <Icon className={`w-5 h-5 text-${subject.color}-600`} />
                </div>
                <div className="min-w-0">
                  <p className="font-medium text-gray-800 text-sm truncate">{subject.name}</p>
                  <p className="text-xs text-gray-500 truncate">{levelName}</p>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
