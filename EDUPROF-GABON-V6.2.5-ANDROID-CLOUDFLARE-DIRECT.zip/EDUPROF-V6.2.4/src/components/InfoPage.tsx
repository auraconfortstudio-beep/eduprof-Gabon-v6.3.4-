import { ArrowLeft, BookOpen, Shield, Map, Info } from 'lucide-react';

interface Props {
  onNavigate: (page: string, params?: Record<string, string>) => void;
  section?: string;
}

/**
 * Couverture pédagogique principale CM2 → Terminale (catalogue Maël + packs 2024-2025).
 * Chiffres = leçons indexées côté serveur (lesson-catalog) — pas un inventaire exhaustif du programme national.
 */
const COVERAGE = [
  { niveau: 'CM2', matieres: 'Maths, Français, HG, Anglais, EPS, Découverte…', statut: 'DISPONIBLE', unites: 16 },
  { niveau: '6ème', matieres: 'Maths, SVT, PC, Français, HG, Anglais…', statut: 'DISPONIBLE', unites: 43 },
  { niveau: '5ème', matieres: 'Maths, SVT, PC, Français, HG, Langues…', statut: 'DISPONIBLE', unites: 42 },
  { niveau: '4ème', matieres: 'Maths, SVT, PC, Français, HG, Techno…', statut: 'DISPONIBLE', unites: 47 },
  { niveau: '3ème (BEPC)', matieres: 'Maths, SVT, PC, Français, HG, Anglais…', statut: 'DISPONIBLE', unites: 45 },
  { niveau: 'Seconde (LE / S)', matieres: 'Tronc commun + packs série', statut: 'DISPONIBLE', unites: 30 },
  { niveau: 'Première (A1 · A2 · B · S)', matieres: 'Packs série + philo / sciences', statut: 'DISPONIBLE', unites: 43 },
  { niveau: 'Terminale (A1 · A2 · B · C · D)', matieres: 'Maths, PC, SVT, Philo, Méthodo BAC…', statut: 'DISPONIBLE', unites: 35 },
  { niveau: 'Enrichissement progressif', matieres: 'Certaines matières restent à densifier', statut: 'EN COURS', unites: 0 },
];

export function InfoPage({ onNavigate, section }: Props) {
  const show = section || 'all';

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-gradient-to-r from-slate-700 to-slate-900 text-white px-4 py-6">
        <div className="max-w-4xl mx-auto">
          <button
            onClick={() => onNavigate('home')}
            className="flex items-center gap-1 text-white/80 hover:text-white text-sm mb-3 min-h-[44px]"
          >
            <ArrowLeft className="w-4 h-4" /> Accueil
          </button>
          <h1 className="text-2xl font-bold">À propos & transparence</h1>
          <p className="text-white/80 text-sm mt-1">EduProf Gabon — plateforme éducative indépendante</p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
        {(show === 'all' || show === 'about') && (
          <section className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
            <div className="flex items-center gap-2 mb-3">
              <Info className="w-5 h-5 text-blue-600" />
              <h2 className="font-bold text-gray-900 text-lg">À propos</h2>
            </div>
            <p className="text-sm text-gray-700 leading-relaxed">
              <strong>EduProf Gabon</strong> est une plateforme éducative <strong>indépendante</strong> destinée
              aux apprenants au Gabon. Elle propose des parcours (cours, exercices, quiz) pour accompagner
              l&apos;apprentissage du primaire au lycée.
            </p>
            <p className="text-sm text-gray-700 leading-relaxed mt-3">
              EduProf <strong>n&apos;est pas</strong> le Ministère de l&apos;Éducation nationale, ni l&apos;IPN,
              ni une institution officielle. Les programmes et progressions gabonais servent de{' '}
              <strong>références pédagogiques</strong> ; les cours et exercices sont rédigés pour la plateforme.
            </p>
          </section>
        )}

        {(show === 'all' || show === 'coverage') && (
          <section className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
            <div className="flex items-center gap-2 mb-3">
              <Map className="w-5 h-5 text-emerald-600" />
              <h2 className="font-bold text-gray-900 text-lg">Programmes & couverture</h2>
            </div>
            <p className="text-sm text-gray-700 leading-relaxed mb-4">
              EduProf construit ses parcours à partir de références pédagogiques gabonaises documentées
              (année scolaire 2024-2025). <strong>La couverture est progressive</strong> : elle n&apos;inclut
              pas encore l&apos;ensemble des matières et niveaux du système éducatif gabonais.
            </p>
            <div className="overflow-x-auto -mx-1">
              <table className="w-full text-sm min-w-[280px]">
                <thead>
                  <tr className="text-left text-gray-500 border-b">
                    <th className="py-2 pr-2 font-medium">Niveau</th>
                    <th className="py-2 pr-2 font-medium">Matières pack</th>
                    <th className="py-2 font-medium">Statut</th>
                  </tr>
                </thead>
                <tbody>
                  {COVERAGE.map((row) => (
                    <tr key={row.niveau} className="border-b border-gray-50">
                      <td className="py-2.5 pr-2 text-gray-800">{row.niveau}</td>
                      <td className="py-2.5 pr-2 text-gray-600">{row.matieres}</td>
                      <td className="py-2.5">
                        <span
                          className={`inline-block text-xs font-semibold px-2 py-1 rounded-full ${
                            row.statut === 'DISPONIBLE'
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {row.statut}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p className="text-xs text-gray-500 mt-3">
              Pack documenté actuel : 380+ leçons · 1100+ exercices · 750+ questions de quiz (index serveur 100 % synchronisé).
            </p>
          </section>
        )}

        {(show === 'all' || show === 'sources') && (
          <section className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
            <div className="flex items-center gap-2 mb-3">
              <Shield className="w-5 h-5 text-indigo-600" />
              <h2 className="font-bold text-gray-900 text-lg">Sources & transparence</h2>
            </div>
            <ul className="text-sm text-gray-700 space-y-2 list-disc pl-5">
              <li>
                Les <strong>programmes et progressions gabonais</strong> (MEN / IPN / IGS) servent de référence
                pour choisir les notions à traiter.
              </li>
              <li>
                Les <strong>cours, exercices et quiz</strong> du pack 2024-2025 sont des rédactions{' '}
                <strong>originales EduProf</strong> (audit provenance V2.6.1) — pas une copie de manuels.
              </li>
              <li>
                Les documents tiers (manuels, annales intégrales) <strong>ne sont pas présentés</strong> comme
                appartenant à EduProf et ne sont pas reproduits intégralement dans ce pack.
              </li>
              <li>
                Aucun programme étranger (France, Côte d&apos;Ivoire, Cameroun, etc.) n&apos;est utilisé pour
                compléter artificiellement le catalogue.
              </li>
              <li>Les contenus sont enrichis progressivement, avec traçabilité des unités pédagogiques.</li>
            </ul>
            <p className="text-xs text-gray-500 mt-4">
              Cet affichage ne remplace pas un avis juridique. EduProf s&apos;engage à corriger tout contenu
              qui s&apos;avérerait non conforme.
            </p>
          </section>
        )}

        <section className="bg-blue-50 rounded-2xl p-5 border border-blue-100">
          <div className="flex items-start gap-3">
            <BookOpen className="w-5 h-5 text-blue-600 mt-0.5 shrink-0" />
            <div>
              <h3 className="font-bold text-blue-900 text-sm">Comment apprendre avec EduProf</h3>
              <p className="text-sm text-blue-800 mt-1 leading-relaxed">
                Choisissez un <strong>niveau</strong> → une <strong>matière</strong> → un{' '}
                <strong>chapitre</strong> → lisez le <strong>cours</strong> → pratiquez les{' '}
                <strong>exercices</strong> → testez-vous avec le <strong>quiz</strong>.
              </p>
              <button
                onClick={() => onNavigate('home')}
                className="mt-3 text-sm font-semibold text-blue-700 underline min-h-[44px]"
              >
                Retour aux niveaux
              </button>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
