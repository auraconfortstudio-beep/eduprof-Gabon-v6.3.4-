import { useState } from 'react';
import { ArrowLeft, Award, Check, Phone, MessageCircle, Info, Star, Send } from 'lucide-react';
import { useAuth } from '@/lib/auth';
import { WHATSAPP_DISPLAY, PREMIUM_DAILY, PREMIUM_MONTHLY, whatsappLink, PREMIUM_PAYMENT_MESSAGE } from '@/lib/constants';
import { api } from '@/lib/api';
import { errorMessage } from '@/lib/errors';

interface Props {
  onNavigate: (page: string, params?: Record<string, string>) => void;
}

export function PremiumPage({ onNavigate }: Props) {
  const { profile, user } = useAuth();
  const [selectedPlan, setSelectedPlan] = useState<'daily' | 'monthly'>('monthly');
  const [proof, setProof] = useState('');
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submitRequest() {
    if (!user) {
      onNavigate('auth');
      return;
    }
    if (!proof.trim()) {
      setError('Indiquez la référence ou description de votre paiement');
      return;
    }
    setSending(true);
    setError(null);
    try {
      await api.requestPremium(selectedPlan, proof.trim());
      setSent(true);
    } catch (e: unknown) {
      setError(errorMessage(e));
    } finally {
      setSending(false);
    }
  }

  const isPremium = profile?.isPremium;

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      <div className="bg-gradient-to-br from-amber-500 via-orange-500 to-orange-600 text-white px-4 py-6">
        <div className="max-w-4xl mx-auto">
          <button onClick={() => onNavigate('home')} className="flex items-center gap-1 text-white/80 hover:text-white text-sm mb-3">
            <ArrowLeft className="w-4 h-4" /> Accueil
          </button>
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center">
              <Award className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">Premium EduProf</h1>
              <p className="text-white/80 text-sm">Accédez à tout le contenu, sans limites</p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-6">
        {isPremium && (
          <div className="bg-gradient-to-r from-amber-400 to-orange-500 rounded-xl p-4 mb-6 text-white">
            <div className="flex items-center gap-2">
              <Star className="w-5 h-5" />
              <p className="font-bold">Vous êtes Premium !</p>
            </div>
            {profile?.premiumUntil && (
              <p className="text-sm text-amber-50 mt-1">
                Actif jusqu'au {new Date(profile.premiumUntil).toLocaleDateString('fr-FR')}.
              </p>
            )}
          </div>
        )}

        <h2 className="font-bold text-gray-800 mb-3">Choisissez votre formule</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6">
          <button
            onClick={() => setSelectedPlan('daily')}
            className={`p-5 rounded-xl border-2 text-left transition-all ${selectedPlan === 'daily' ? 'border-amber-500 bg-amber-50' : 'border-gray-200 bg-white'}`}
          >
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-bold text-gray-800">Formule Jour</h3>
              {selectedPlan === 'daily' && <Check className="w-5 h-5 text-amber-600" />}
            </div>
            <p className="text-2xl font-bold text-amber-600">{PREMIUM_DAILY} FCFA</p>
            <p className="text-xs text-gray-500 mt-1">par jour</p>
          </button>
          <button
            onClick={() => setSelectedPlan('monthly')}
            className={`p-5 rounded-xl border-2 text-left transition-all ${selectedPlan === 'monthly' ? 'border-amber-500 bg-amber-50' : 'border-gray-200 bg-white'}`}
          >
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-bold text-gray-800">Formule Mois</h3>
              {selectedPlan === 'monthly' && <Check className="w-5 h-5 text-amber-600" />}
            </div>
            <p className="text-2xl font-bold text-amber-600">{PREMIUM_MONTHLY} FCFA</p>
            <p className="text-xs text-gray-500 mt-1">par mois</p>
          </button>
        </div>

        <div className="bg-white rounded-xl shadow-sm border p-5 mb-6">
          <h3 className="font-bold text-gray-800 mb-4">Procédure de paiement</h3>
          <div className="space-y-4">
            <div className="flex gap-3">
              <div className="w-7 h-7 rounded-full bg-amber-500 text-white flex items-center justify-center text-sm font-bold">1</div>
              <div>
                <p className="text-sm font-medium">Choisir la formule</p>
                <p className="text-xs text-gray-500">
                  {selectedPlan === 'daily' ? `${PREMIUM_DAILY} FCFA / jour` : `${PREMIUM_MONTHLY} FCFA / mois`}
                </p>
              </div>
            </div>
            <div className="flex gap-3">
              <div className="w-7 h-7 rounded-full bg-amber-500 text-white flex items-center justify-center text-sm font-bold">2</div>
              <div>
                <p className="text-sm font-medium">Effectuer le dépôt</p>
                <div className="flex items-center gap-2 mt-1">
                  <Phone className="w-4 h-4 text-amber-600" />
                  <span className="text-lg font-bold">{WHATSAPP_DISPLAY}</span>
                </div>
              </div>
            </div>
            <div className="flex gap-3">
              <div className="w-7 h-7 rounded-full bg-amber-500 text-white flex items-center justify-center text-sm font-bold">3</div>
              <div className="flex-1">
                <p className="text-sm font-medium">Transmettre la preuve</p>
                {sent ? (
                  <p className="text-sm text-green-600 mt-2">Demande envoyée ! Un admin validera bientôt.</p>
                ) : (
                  <>
                    <textarea
                      value={proof}
                      onChange={(e) => setProof(e.target.value)}
                      placeholder="Référence de transaction, nom, montant…"
                      className="w-full mt-2 p-2 border rounded-lg text-sm"
                      rows={2}
                    />
                    {error && <p className="text-xs text-red-600 mt-1">{error}</p>}
                    <button
                      onClick={submitRequest}
                      disabled={sending}
                      className="mt-2 inline-flex items-center gap-2 px-4 py-2 bg-amber-500 text-white text-sm font-semibold rounded-lg hover:bg-amber-600 disabled:opacity-50"
                    >
                      <Send className="w-4 h-4" />
                      {sending ? 'Envoi…' : 'Envoyer la demande de validation'}
                    </button>
                  </>
                )}
                <a
                  href={whatsappLink(PREMIUM_PAYMENT_MESSAGE)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-2 inline-flex items-center gap-2 px-4 py-2 bg-green-500 text-white text-sm font-semibold rounded-lg hover:bg-green-600"
                >
                  <MessageCircle className="w-4 h-4" />
                  Ou via WhatsApp
                </a>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
          <div className="flex items-start gap-2">
            <Info className="w-5 h-5 text-blue-600 flex-shrink-0" />
            <p className="text-sm text-blue-800">
              Après paiement sur {WHATSAPP_DISPLAY}, envoyez votre preuve ici ou sur WhatsApp. L'activation est manuelle après vérification. Aucun paiement automatique.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
