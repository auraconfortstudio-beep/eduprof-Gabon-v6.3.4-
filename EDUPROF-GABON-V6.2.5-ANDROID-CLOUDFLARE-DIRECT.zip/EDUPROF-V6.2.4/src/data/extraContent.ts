/**
 * Complément pédagogique EduProf — 6e, langues 4e/5e, université
 * Contenus originaux + exercices progressifs (non officiels).
 */
import { makeSubject, type Subject, type TopicData, type TopicExercise, type Filiere } from './types';

function ex(
  q: string,
  opts: string[],
  ans: number,
  exp: string,
  method: string,
  difficulty: 'facile' | 'intermediaire' | 'difficile' = 'intermediaire'
): TopicExercise {
  return { q, opts, ans, exp, method, difficulty };
}
function qz(q: string, opts: string[], ans: number, exp: string) {
  return { q, opts, ans, exp };
}

const maths6e: TopicData[] = [
  {
    title: 'Nombres décimaux et opérations',
    content:
      "Un nombre décimal s’écrit avec une virgule : partie entière et partie décimale.\n\nAddition/soustraction : aligner les virgules.\nMultiplication : multiplier comme des entiers puis placer la virgule (somme des chiffres après virgule).\nDivision : techniques de pose et estimation.",
    example: '12,5 + 3,75 = 16,25 ; 1,2 × 0,3 = 0,36.',
    keyPoints: ['Virgule', 'Alignement', 'Multiplication décimale', 'Estimation'],
    exercise: ex('12,5 + 3,75 = ?', ['15,25', '16,25', '16,125', '15,125'], 1, 'Aligner les virgules.', 'Addition.', 'facile'),
    exercises: [
      ex('12,5 + 3,75 = ?', ['15,25', '16,25', '16,125', '15,125'], 1, '16,25.', 'Alignement.', 'facile'),
      ex('10 − 2,45 = ?', ['8,55', '7,55', '8,45', '7,65'], 0, '10,00−2,45=8,55.', 'Soustraction.', 'facile'),
      ex('1,2 × 0,5 = ?', ['0,6', '6', '0,06', '1,7'], 0, '12×5=60 → 0,60.', 'Multiplication.', 'intermediaire'),
      ex('7,2 ÷ 0,8 = ?', ['9', '0,9', '90', '8'], 0, '72÷8=9.', 'Division décimale.', 'intermediaire'),
      ex('0,25 × 0,4 = ?', ['0,1', '1', '0,01', '0,001'], 0, '25×4=100 → 0,1.', 'Décimales.', 'difficile'),
    ],
    quiz: [
      qz('Pour additionner des décimaux on :', ['aligne les virgules', 'aligne à droite sans virgule', 'multiplie', 'ignore la virgule'], 0, 'Alignement.'),
      qz('1,5 × 10 = ?', ['1,50', '15', '0,15', '150'], 1, '×10 décale la virgule.'),
    ],
  },
  {
    title: 'Fractions : simplifier et comparer',
    content:
      "Fraction a/b : a numérateur, b dénominateur (b≠0).\nSimplifier : diviser numérateur et dénominateur par un diviseur commun.\nComparer : même dénominateur, produit en croix, ou passage en décimal.",
    example: '18/24 = 3/4 ; 1/2 > 1/3.',
    keyPoints: ['Simplification', 'Fraction irréductible', 'Comparaison', 'Égalité'],
    exercise: ex('Simplifier 18/24', ['3/4', '9/12', '6/8', '2/3'], 0, 'Diviser par 6.', 'PGCD.', 'facile'),
    exercises: [
      ex('Simplifier 18/24', ['3/4', '9/12', '6/8', '2/3'], 0, '÷6 → 3/4.', 'Simplification.', 'facile'),
      ex('1/2 et 2/4 sont :', ['différentes', 'égales', 'incomparables', 'négatives'], 1, '2/4=1/2.', 'Égalité.', 'facile'),
      ex('Quelle fraction est la plus grande : 2/5 ou 3/7 ?', ['2/5', '3/7', 'égales', 'impossible'], 1, '2×7=14 < 3×5=15 donc 3/7 > 2/5.', 'Produit en croix.', 'intermediaire'),
      ex('3/4 de 20 = ?', ['15', '12', '16', '5'], 0, '(3×20)/4=15.', 'Fraction d’une quantité.', 'intermediaire'),
      ex('Fraction irréductible de 45/60', ['9/12', '3/4', '15/20', '5/6'], 1, '÷15 → 3/4.', 'PGCD 15.', 'difficile'),
    ],
    quiz: [
      qz('Le dénominateur d’une fraction ne peut pas être :', ['1', '2', '0', '10'], 2, 'Division par 0.'),
      qz('Pour comparer a/b et c/d (positifs) :', ['a×d ? b×c', 'a+c', 'b−d', 'a×b'], 0, 'Produit en croix.'),
    ],
  },
];

const francais6e: TopicData[] = [
  {
    title: 'Nature et fonction des mots',
    content:
      "Nature (classe) : nom, verbe, adjectif, déterminant, pronom, adverbe…\nFonction : rôle dans la phrase (sujet, COD, COI, attribut, complément circonstanciel…).\n\nUn même mot peut changer de fonction selon la phrase.",
    example: '« Le chat » : déterminant + nom ; fonction sujet dans « Le chat dort ».',
    keyPoints: ['Nature', 'Fonction', 'Sujet', 'COD', 'Adjectif'],
    exercise: ex('Dans « Les élèves travaillent », « Les élèves » est :', ['COD', 'sujet', 'attribut', 'COI'], 1, 'Qui travaille ?', 'Sujet.', 'facile'),
    exercises: [
      ex('« Les élèves travaillent » : « Les élèves » est', ['COD', 'sujet', 'attribut', 'COI'], 1, 'Sujet du verbe.', 'Fonction.', 'facile'),
      ex('Nature de « rapidement » dans « Il court rapidement »', ['nom', 'adverbe', 'adjectif', 'verbe'], 1, 'Modifie le verbe.', 'Nature.', 'facile'),
      ex('COD dans « Elle lit un roman »', ['Elle', 'lit', 'un roman', 'aucun'], 2, 'Lit quoi ?', 'COD.', 'intermediaire'),
      ex('« beau » dans « un beau paysage » est :', ['adverbe', 'adjectif épithète', 'verbe', 'pronom'], 1, 'Qualifie le nom.', 'Adjectif.', 'intermediaire'),
      ex('Attribut du sujet : « Paul est médecin ». Attribut = ?', ['Paul', 'est', 'médecin', 'aucun'], 2, 'Après verbe d’état.', 'Attribut.', 'difficile'),
    ],
    quiz: [
      qz('La nature d’un mot c’est :', ['son rôle dans la phrase', 'sa classe grammaticale', 'sa longueur', 'sa rime'], 1, 'Classe.'),
      qz('Le sujet répond à la question :', ['quoi ?', 'qui / qu’est-ce qui + verbe', 'où ?', 'quand ?'], 1, 'Sujet.'),
    ],
  },
];

const anglais6e: TopicData[] = [
  {
    title: 'To be and to have — present',
    content:
      "To be : I am, you are, he/she/it is, we/you/they are.\nTo have : I/you/we/they have ; he/she/it has.\nNegatives : isn’t / aren’t ; haven’t / hasn’t.\nQuestions : Are you…? Has she…?",
    example: 'She is a student. He has a book.',
    keyPoints: ['am/is/are', 'have/has', 'Negation', 'Questions'],
    exercise: ex('She ___ a teacher.', ['am', 'is', 'are', 'be'], 1, 'he/she/it → is.', 'To be.', 'facile'),
    exercises: [
      ex('She ___ a teacher.', ['am', 'is', 'are', 'be'], 1, 'is.', 'To be.', 'facile'),
      ex('They ___ two brothers.', ['has', 'have', 'is', 'am'], 1, 'they → have.', 'To have.', 'facile'),
      ex('___ you from Gabon?', ['Is', 'Are', 'Am', 'Have'], 1, 'you → Are.', 'Question.', 'intermediaire'),
      ex('He ___ not at school today.', ['am', 'is', 'are', 'have'], 1, 'is not.', 'Negation.', 'intermediaire'),
      ex('My sister ___ a new bag.', ['have', 'has', 'is', 'are'], 1, 'she → has.', 'Have.', 'facile'),
    ],
    quiz: [
      qz('I ___ happy.', ['is', 'am', 'are', 'has'], 1, 'I am.'),
      qz('Negative of “they are”:', ['they isn’t', 'they aren’t', 'they am not', 'they hasn’t'], 1, 'aren’t.'),
    ],
  },
];

const anglais5e: TopicData[] = [
  {
    title: 'Present continuous and daily routines',
    content:
      "Present continuous : am/is/are + V-ing — action in progress now.\nDaily routines : present simple + frequency adverbs (always, often, sometimes, never).\n\nI am reading now. / I usually wake up at 6.",
    example: 'She is doing her homework. He always takes the bus.',
    keyPoints: ['be + V-ing', 'Present simple habits', 'Frequency adverbs'],
    exercise: ex('Look! The children ___ in the yard.', ['play', 'are playing', 'plays', 'played'], 1, 'now → continuous.', 'Continuous.', 'facile'),
    exercises: [
      ex('Look! The children ___ in the yard.', ['play', 'are playing', 'plays', 'played'], 1, 'are playing.', 'Continuous.', 'facile'),
      ex('She ___ to school every day.', ['go', 'goes', 'is going', 'gone'], 1, 'habit → present simple.', 'Routines.', 'facile'),
      ex('I am ___ a letter now.', ['write', 'writing', 'writes', 'wrote'], 1, 'V-ing.', 'Form.', 'intermediaire'),
      ex('He ___ eats fish. (frequency)', ['never', 'is never', 'are never', 'be never'], 0, 'He never eats…', 'Adverbs.', 'difficile'),
      ex('___ you doing your homework?', ['Is', 'Are', 'Do', 'Does'], 1, 'Are + you + V-ing.', 'Question.', 'intermediaire'),
    ],
    quiz: [
      qz('Present continuous needs:', ['have + V-ed', 'be + V-ing', 'will + V', 'to + V'], 1, 'be+V-ing.'),
      qz('“always” often goes with:', ['present continuous only', 'present simple for habits', 'past only', 'imperative only'], 1, 'Habits.'),
    ],
  },
];

const anglais4e: TopicData[] = [
  {
    title: 'Past simple — regular and irregular',
    content:
      "Past simple : finished actions in the past.\nRegular : V-ed (played, visited).\nIrregular : go→went, have→had, be→was/were, do→did, see→saw…\nNegation : did not (didn’t) + base verb. Question : Did + subject + base?",
    example: 'Yesterday I went to the market. I did not stay long.',
    keyPoints: ['V-ed', 'Irregular list', 'did/didn’t', 'Time markers'],
    exercise: ex('Yesterday she ___ to Port-Gentil.', ['go', 'goes', 'went', 'gone'], 2, 'past of go = went.', 'Irregular.', 'facile'),
    exercises: [
      ex('Yesterday she ___ to Port-Gentil.', ['go', 'goes', 'went', 'gone'], 2, 'went.', 'Past.', 'facile'),
      ex('They ___ football last Sunday.', ['play', 'played', 'playing', 'plays'], 1, 'regular +ed.', 'Regular.', 'facile'),
      ex('He ___ not finish his work.', ['do', 'did', 'does', 'done'], 1, 'didn’t + base.', 'Negation.', 'intermediaire'),
      ex('___ you see the film?', ['Do', 'Did', 'Are', 'Have'], 1, 'Did + subject + base.', 'Question.', 'intermediaire'),
      ex('We ___ at home at 8 p.m. (be)', ['was', 'were', 'are', 'been'], 1, 'we → were.', 'Be past.', 'difficile'),
    ],
    quiz: [
      qz('Past of “have”:', ['haved', 'had', 'has', 'having'], 1, 'had.'),
      qz('Time marker for past simple:', ['now', 'yesterday', 'tomorrow', 'often (habit only)'], 1, 'yesterday/last…'),
    ],
  },
];

const histoire6e: TopicData[] = [
  {
    title: 'La Préhistoire et les premiers humains',
    content:
      "Préhistoire : période avant l’écriture.\nPaléolithique : chasse, cueillette, outils de pierre, maîtrise du feu.\nNéolithique : agriculture, élevage, sédentarisation, villages.\nL’apparition de l’écriture marque l’entrée dans l’Histoire.",
    example: 'Peintures rupestres ; premiers villages agricoles.',
    keyPoints: ['Paléolithique', 'Néolithique', 'Feu', 'Agriculture', 'Écriture'],
    exercise: ex('La Préhistoire se termine avec :', ['le feu', 'l’écriture', 'l’agriculture seulement', 'l’empire romain'], 1, 'Écriture = Histoire.', 'Repère.', 'facile'),
    exercises: [
      ex('Fin de la Préhistoire :', ['feu', 'écriture', 'agriculture seule', 'Rome'], 1, 'Écriture.', 'Chronologie.', 'facile'),
      ex('Au Paléolithique, les humains :', ['cultivent surtout', 'chassent et cueillent', 'écrivent', 'bâtissent des usines'], 1, 'Chasse-cueillette.', 'Paléo.', 'facile'),
      ex('Le Néolithique est marqué par :', ['uniquement la guerre', 'agriculture et sédentarisation', 'l’ordinateur', 'l’abolition du feu'], 1, 'Révolution néolithique.', 'Néolithique.', 'intermediaire'),
      ex('Le feu a permis surtout :', ['d’écrire', 'de cuire, se chauffer, se protéger', 'de naviguer au GPS', 'd’imprimer'], 1, 'Maîtrise du feu.', 'Techniques.', 'intermediaire'),
      ex('Les peintures rupestres datent surtout :', ['du Moyen Âge', 'de la Préhistoire', 'du XXe siècle', 'de l’époque coloniale'], 1, 'Art pariétal.', 'Culture.', 'facile'),
    ],
    quiz: [
      qz('Sédentarisation = ', ['nomadisme', 's’installer durablement', 'voyager sans cesse', 'écrire'], 1, 'Villages.'),
      qz('Outil typique du Paléolithique :', ['tracteur', 'pierre taillée', 'smartphone', 'imprimante'], 1, 'Pierre.'),
    ],
  },
];

const univInfoAlgo: TopicData[] = [
  {
    title: 'Algorithmique : variables, conditions, boucles',
    content:
      "Un algorithme décrit une suite d’étapes pour résoudre un problème.\nVariable : zone mémoire nommée.\nCondition (si … alors … sinon) : branchement.\nBoucles : pour / tant que — répéter des instructions.\nComplexité : ordre de grandeur du nombre d’opérations.",
    example: 'Pour i de 1 à n : somme ← somme + i.',
    keyPoints: ['Variable', 'Si/alors', 'Boucle', 'Entrée-sortie'],
    exercise: ex('Une boucle « pour i de 1 à 5 » s’exécute combien de fois ?', ['4', '5', '6', '1'], 1, 'i=1..5.', 'Pour.', 'facile'),
    exercises: [
      ex('Boucle pour i de 1 à 5 : itérations ?', ['4', '5', '6', '1'], 1, '5 fois.', 'Boucle.', 'facile'),
      ex('Une variable sert à :', ['décorer le code', 'stocker une valeur', 'remplacer le CPU', 'afficher uniquement'], 1, 'Mémoire nommée.', 'Variable.', 'facile'),
      ex('« Si x>0 alors … » est :', ['une boucle', 'une condition', 'une variable', 'un tableau'], 1, 'Branchement.', 'Condition.', 'intermediaire'),
      ex('Tant que n>0 : n ← n−1. Si n part de 3, la boucle s’arrête quand n vaut :', ['3', '0', '−1', '1'], 1, 'Condition devenue fausse.', 'While.', 'intermediaire'),
      ex('Complexité linéaire signifie surtout :', ['temps proportionnel à n', 'temps constant', 'temps exponentiel', 'impossible'], 0, 'O(n).', 'Complexité.', 'difficile'),
    ],
    quiz: [
      qz('Pseudocode :', ['langage machine uniquement', 'description d’algo indépendante du langage', 'erreur de syntaxe', 'virus'], 1, 'Description.'),
      qz('Affectation x ← 3 signifie :', ['comparer x et 3', 'mettre 3 dans x', 'effacer x', 'afficher 3'], 1, 'Affectation.'),
    ],
  },
];

const univInfoBD: TopicData[] = [
  {
    title: 'Bases de données : tables et requêtes simples',
    content:
      "Base relationnelle : tables (lignes = enregistrements, colonnes = attributs).\nClé primaire : identifiant unique.\nSQL de base : SELECT … FROM … WHERE … ;\nJointures : relier des tables via des clés.",
    example: "SELECT nom FROM Eleves WHERE classe = '3e';",
    keyPoints: ['Table', 'Clé primaire', 'SELECT', 'WHERE', 'Jointure'],
    exercise: ex('Une clé primaire doit être :', ['toujours nulle', 'unique par ligne', 'un doublon', 'un fichier image'], 1, 'Identifiant unique.', 'Modèle relationnel.', 'facile'),
    exercises: [
      ex('Clé primaire :', ['nulle', 'unique', 'doublon obligatoire', 'image'], 1, 'Unique.', 'Clé.', 'facile'),
      ex('SELECT sert à :', ['supprimer la base', 'lire des données', 'éteindre le serveur', 'compiler C++'], 1, 'Lecture.', 'SQL.', 'facile'),
      ex('WHERE filtre :', ['les colonnes affichées seulement', 'les lignes selon une condition', 'le disque dur', 'les utilisateurs OS'], 1, 'Condition sur lignes.', 'WHERE.', 'intermediaire'),
      ex('Une jointure relie :', ['deux fichiers Word', 'des tables via des clés', 'deux langages', 'CPU et RAM'], 1, 'Relations.', 'JOIN.', 'intermediaire'),
      ex('FROM Eleves signifie :', ['créer la table Eleves', 'source des données = table Eleves', 'supprimer Eleves', 'renommer'], 1, 'Source.', 'SQL.', 'facile'),
    ],
    quiz: [
      qz('Ligne d’une table = ', ['attribut', 'enregistrement / tuple', 'SGBD', 'index uniquement'], 1, 'Record.'),
      qz('SQL est :', ['un langage de requête', 'un système d’exploitation', 'un navigateur', 'un protocole réseau uniquement'], 0, 'Structured Query Language.'),
    ],
  },
];

const univDroitCivil: TopicData[] = [
  {
    title: 'Introduction au droit civil',
    content:
      "Le droit civil régit les rapports entre personnes privées (famille, contrats, biens, responsabilité).\nPersonnalité juridique : aptitude à être titulaire de droits et d’obligations.\nActe juridique vs fait juridique.\nPreuve et bonne foi sont des notions transversales.",
    example: 'Contrat de vente ; responsabilité en cas de dommage.',
    keyPoints: ['Personnes', 'Biens', 'Contrats', 'Responsabilité'],
    exercise: ex('Le droit civil concerne surtout :', ['uniquement le pénal', 'rapports entre personnes privées', 'la seule Constitution', 'le sport'], 1, 'Branche du droit privé.', 'Définition.', 'facile'),
    exercises: [
      ex('Droit civil :', ['pénal seul', 'rapports privés', 'Constitution seule', 'sport'], 1, 'Droit privé.', 'Intro.', 'facile'),
      ex('Une personne morale est par ex. :', ['un rocher', 'une société / association', 'un animal sauvage sans statut', 'un chiffre'], 1, 'Groupement personnifié.', 'Personnes.', 'intermediaire'),
      ex('Un contrat est en principe :', ['un fait purement accidentel', 'un accord de volontés', 'une loi pénale', 'un jugement'], 1, 'Autonomie de la volonté.', 'Contrats.', 'facile'),
      ex('Responsabilité civile vise surtout à :', ['punir comme le pénal', 'réparer un dommage', 'écrire la Constitution', 'élire'], 1, 'Réparation.', 'Responsabilité.', 'intermediaire'),
      ex('Capacité juridique désigne :', ['la taille', 'l’aptitude à exercer des droits', 'la nationalité seule', 'le salaire'], 1, 'Capacité.', 'Personnes.', 'difficile'),
    ],
    quiz: [
      qz('Fait juridique :', ['événement produisant des effets de droit hors volonté pure d’acte', 'toujours un contrat', 'une élection', 'un roman'], 0, 'Fait vs acte.'),
      qz('Bonne foi en droit civil :', ['inutile', 'principe de loyauté dans les relations', 'un délit', 'une peine'], 1, 'Principe.'),
    ],
  },
];

const univDroitConst: TopicData[] = [
  {
    title: 'Droit constitutionnel : principes',
    content:
      "La Constitution est la norme suprême de l’État.\nSéparation des pouvoirs : législatif, exécutif, judiciaire.\nÉtat de droit : soumission des autorités au droit.\nDroits fondamentaux et contrôle de constitutionnalité.",
    example: 'Hiérarchie des normes ; rôle du Parlement et du gouvernement.',
    keyPoints: ['Constitution', 'Séparation des pouvoirs', 'État de droit', 'Droits fondamentaux'],
    exercise: ex('Norme suprême de l’État :', ['un arrêté municipal', 'la Constitution', 'un contrat', 'un usage commercial'], 1, 'Suprématie constitutionnelle.', 'Normes.', 'facile'),
    exercises: [
      ex('Norme suprême :', ['arrêté', 'Constitution', 'contrat', 'usage'], 1, 'Constitution.', 'Hiérarchie.', 'facile'),
      ex('Pouvoir qui vote la loi (schéma classique) :', ['exécutif seul', 'législatif', 'médias', 'armée seule'], 1, 'Parlement.', 'Séparation.', 'facile'),
      ex('État de droit signifie surtout :', ['absence de règles', 'pouvoirs soumis au droit', 'loi du plus fort', 'anarchie'], 1, 'Rule of law.', 'Concept.', 'intermediaire'),
      ex('Le judiciaire a pour rôle principal :', ['faire la loi', 'trancher les litiges selon le droit', 'diriger l’armée', 'battre monnaie'], 1, 'Justice.', 'Pouvoirs.', 'intermediaire'),
      ex('Contrôle de constitutionnalité vérifie :', ['le prix des denrées', 'la conformité des lois à la Constitution', 'la météo', 'les notes scolaires'], 1, 'Hiérarchie.', 'Contrôle.', 'difficile'),
    ],
    quiz: [
      qz('Exécutif :', ['applique / exécute les lois', 'écrit les romans', 'remplace les juges toujours', 'interdit toute norme'], 0, 'Gouvernement/administration.'),
      qz('Droits fondamentaux :', ['droits essentiels reconnus aux personnes', 'uniquement fiscaux', 'secrets d’État seulement', 'règles de football'], 0, 'Libertés publiques.'),
    ],
  },
];

const univEco: TopicData[] = [
  {
    title: 'Microéconomie : offre, demande, marché',
    content:
      "Demande : quantité voulue selon le prix (souvent décroissante avec le prix).\nOffre : quantité proposée (souvent croissante avec le prix).\nÉquilibre : prix où offre = demande.\nÉlasticité : sensibilité de la quantité au prix.",
    example: 'Hausse du prix du carburant → baisse de la quantité demandée (ceteris paribus).',
    keyPoints: ['Offre', 'Demande', 'Équilibre', 'Élasticité', 'Prix'],
    exercise: ex('Si le prix augmente (demande normale), la quantité demandée :', ['augmente', 'diminue', 'reste fixe toujours', 'devient infinie'], 1, 'Loi de la demande.', 'Demande.', 'facile'),
    exercises: [
      ex('Prix ↑ (demande normale) ⇒ quantité demandée :', ['↑', '↓', 'fixe', 'infinie'], 1, 'Loi de la demande.', 'Demande.', 'facile'),
      ex('Équilibre de marché :', ['offre > demande toujours', 'offre = demande', 'prix = 0', 'pas de vendeurs'], 1, 'Intersection.', 'Équilibre.', 'facile'),
      ex('Courbe d’offre (cas standard) :', ['décroissante', 'croissante avec le prix', 'horizontale toujours', 'inexistante'], 1, 'Prix↑ ⇒ offre↑.', 'Offre.', 'intermediaire'),
      ex('Élasticité-prix de la demande mesure :', ['la couleur du produit', 'la sensibilité de la demande au prix', 'le PIB', 'le chômage'], 1, 'Réactivité.', 'Élasticité.', 'intermediaire'),
      ex('Bien inférieur : quand le revenu augmente, la demande :', ['augmente toujours', 'peut diminuer', 'devient offre', 'disparaît forcément'], 1, 'Définition.', 'Revenu.', 'difficile'),
    ],
    quiz: [
      qz('Ceteris paribus signifie :', ['toutes choses égales par ailleurs', 'prix nul', 'marché fermé', 'inflation'], 0, 'Hypothèse.'),
      qz('Surplus du consommateur lié à :', ['différence entre consentement à payer et prix', 'uniquement le salaire', 'la dette publique', 'le taux directeur seul'], 0, 'Bien-être.'),
    ],
  },
];

const univMed: TopicData[] = [
  {
    title: 'Anatomie : organisation du corps humain',
    content:
      "Niveaux : cellule → tissu → organe → système → organisme.\nSystèmes majeurs : locomoteur, nerveux, cardiovasculaire, respiratoire, digestif, urinaire, endocrinien, immunitaire, reproducteur.\nAnatomie = structure ; physiologie = fonctionnement.",
    example: 'Le cœur (organe) appartient au système cardiovasculaire.',
    keyPoints: ['Cellule', 'Organe', 'Système', 'Anatomie vs physiologie'],
    exercise: ex('Le cœur appartient au système :', ['digestif', 'cardiovasculaire', 'urinaire', 'squelettique seul'], 1, 'Pompe sanguine.', 'Systèmes.', 'facile'),
    exercises: [
      ex('Cœur → système :', ['digestif', 'cardiovasculaire', 'urinaire', 'squelettique seul'], 1, 'CV.', 'Organes.', 'facile'),
      ex('Unité de base du vivant :', ['organe', 'cellule', 'système', 'population'], 1, 'Cellule.', 'Niveaux.', 'facile'),
      ex('Physiologie étudie :', ['uniquement les noms latins', 'le fonctionnement', 'seulement les os secs', 'la géographie'], 1, 'Fonction.', 'Définition.', 'intermediaire'),
      ex('Les poumons relèvent surtout du système :', ['nerveux', 'respiratoire', 'digestif', 'endocrinien'], 1, 'Échanges gazeux.', 'Systèmes.', 'facile'),
      ex('Tissu = ', ['ensemble de cellules de même type / fonction', 'un organe entier', 'un individu', 'une espèce'], 0, 'Niveau tissulaire.', 'Histo.', 'difficile'),
    ],
    quiz: [
      qz('Système nerveux central comprend :', ['cœur et vaisseaux', 'encéphale et moelle spinale', 'estomac seul', 'reins seuls'], 1, 'SNC.'),
      qz('Anatomie = ', ['structure', 'uniquement les maladies', 'chimie organique seule', 'psychologie'], 0, 'Structure.'),
    ],
  },
];

export function getExtra_6e_mathematiques(): Subject {
  return makeSubject('mathematiques', 'Mathématiques', 'Calculator', 'blue', '6e', '6ème', maths6e);
}
export function getExtra_6e_francais(): Subject {
  return makeSubject('francais', 'Français', 'BookOpen', 'amber', '6e', '6ème', francais6e);
}
export function getExtra_6e_anglais(): Subject {
  return makeSubject('anglais', 'Anglais', 'Languages', 'red', '6e', '6ème', anglais6e);
}
export function getExtra_6e_histoire(): Subject {
  return makeSubject('histoire', 'Histoire', 'Landmark', 'orange', '6e', '6ème', histoire6e);
}
export function getExtra_5e_anglais(): Subject {
  return makeSubject('anglais', 'Anglais', 'Languages', 'red', '5e', '5ème', anglais5e);
}
export function getExtra_4e_anglais(): Subject {
  return makeSubject('anglais', 'Anglais', 'Languages', 'red', '4e', '4ème', anglais4e);
}

export function getExtraSubjectsForLevel(levelId: string): Subject[] {
  const out: Subject[] = [];
  if (levelId === '6e') {
    out.push(getExtra_6e_mathematiques(), getExtra_6e_francais(), getExtra_6e_anglais(), getExtra_6e_histoire());
  }
  if (levelId === '5e') {
    out.push(getExtra_5e_anglais(), getExtra_5e_svt(), getExtra_5e_pc(), getExtra_5e_hg());
  }
  if (levelId === '4e') {
    out.push(getExtra_4e_anglais(), getExtra_4e_svt(), getExtra_4e_pc(), getExtra_4e_hg());
  }
  return out;
}

// ——— 5e SVT / PC / HG ———
const svt5e: TopicData[] = [
  {
    title: 'Respiration et échanges gazeux',
    content:
      "La respiration cellulaire utilise le dioxygène pour produire de l’énergie à partir des nutriments.\nÀ l’échelle de l’organisme : inspiration / expiration, trajet de l’air (fosses nasales → trachée → bronches → alvéoles).\nÉchanges gazeux alvéolaires : O₂ vers le sang, CO₂ vers l’air.",
    example: 'Après un effort, la fréquence respiratoire augmente pour apporter plus d’O₂ aux muscles.',
    keyPoints: ['Inspiration', 'Alvéoles', 'O₂ / CO₂', 'Sang'],
    exercise: ex('Les échanges gazeux se font surtout au niveau :', ['de la bouche', 'des alvéoles pulmonaires', 'de l’estomac', 'des reins'], 1, 'Surface d’échange alvéolaire.', 'Anatomie.', 'facile'),
    exercises: [
      ex('Échanges gazeux surtout au niveau :', ['bouche', 'alvéoles', 'estomac', 'reins'], 1, 'Alvéoles.', 'Respiration.', 'facile'),
      ex('Le dioxygène dans le sang est surtout transporté par :', ['le plasma seul', 'les globules rouges (hémoglobine)', 'les plaquettes', 'les neurones'], 1, 'Hémoglobine.', 'Transport.', 'intermediaire'),
      ex('Pendant l’expiration, le diaphragme :', ['se contracte toujours', 'se relâche (remonte)', 'disparaît', 'produit de l’O₂'], 1, 'Mécanique ventilatoire.', 'Physiologie.', 'intermediaire'),
      ex('Le CO₂ est un déchet de :', ['la photosynthèse humaine', 'la respiration cellulaire', 'la digestion mécanique seule', 'la vision'], 1, 'Métabolisme.', 'Bio.', 'facile'),
      ex('Fréquence respiratoire qui augmente à l’effort : rôle principal ?', ['refroidir l’air seulement', 'augmenter les apports en O₂', 'arrêter le cœur', 'digérer plus vite'], 1, 'Adaptation à l’effort.', 'Effort.', 'difficile'),
    ],
    quiz: [
      qz('Trajet de l’air (ordre) :', ['alvéoles → trachée → nez', 'nez/bouche → trachée → bronches → alvéoles', 'estomac → poumons', 'cœur → poumons seulement'], 1, 'Voies respiratoires.'),
      qz('Inspiration : volume thoracique', ['diminue', 'augmente', 'reste fixe', 'devient nul'], 1, 'Augmente.'),
    ],
  },
];

const pc5e: TopicData[] = [
  {
    title: 'États de la matière et changements d’état',
    content:
      "Trois états courants : solide, liquide, gaz.\nChangements : fusion, solidification, vaporisation, liquéfaction, sublimation.\nÀ pression donnée, changement d’état à température (approximativement) constante pour un corps pur.",
    example: 'Glace → eau (fusion à 0 °C sous 1 atm) ; eau → vapeur (ébullition à 100 °C).',
    keyPoints: ['Solide / liquide / gaz', 'Fusion', 'Vaporisation', 'Température'],
    exercise: ex('Passage de solide à liquide :', ['solidification', 'fusion', 'sublimation', 'condensation'], 1, 'Fusion.', 'Vocabulaire.', 'facile'),
    exercises: [
      ex('Solide → liquide :', ['solidification', 'fusion', 'sublimation', 'condensation'], 1, 'Fusion.', 'États.', 'facile'),
      ex('Liquide → gaz :', ['fusion', 'vaporisation', 'solidification', 'ionisation'], 1, 'Vaporisation.', 'États.', 'facile'),
      ex('À 0 °C sous 1 atm, l’eau pure peut :', ['seulement bouillir', 'fondre / solidifier selon apport de chaleur', 'devenir du fer', 'disparaître'], 1, 'Équilibre glace-eau.', 'Corps pur.', 'intermediaire'),
      ex('La sublimation est :', ['liquide → solide', 'solide → gaz (sans passer par liquide)', 'gaz → liquide', 'fusion'], 1, 'Ex. neige carbonique.', 'Vocabulaire.', 'intermediaire'),
      ex('Pendant la fusion d’un corps pur, la température (idéal) :', ['augmente toujours vite', 'reste (quasi) constante', 'devient négative', 'n’existe pas'], 1, 'Plateau de changement d’état.', 'Thermique.', 'difficile'),
    ],
    quiz: [
      qz('Gaz : les particules', ['sont fixes en réseau', 'sont très agitées et éloignées', 'ne bougent jamais', 'sont toujours liquides'], 1, 'Modèle cinétique.'),
      qz('Liquéfaction = ', ['gaz → liquide', 'liquide → gaz', 'solide → liquide', 'solide → gaz'], 0, 'Condensation.'),
    ],
  },
];

const hg5e: TopicData[] = [
  {
    title: 'Les climats et la végétation',
    content:
      "Climat : moyenne des conditions météo sur une longue période (températures, précipitations).\nGrands types : équatorial, tropical, désertique, tempéré, polaire…\nLa végétation dépend fortement du climat (forêt dense, savane, désert, toundra…).",
    example: 'Le Gabon : climat équatorial / tropical humide, forêt dense sur une grande partie du territoire.',
    keyPoints: ['Températures', 'Précipitations', 'Climats', 'Biomes'],
    exercise: ex('Un climat avec chaleur et pluies abondantes toute l’année est plutôt :', ['polaire', 'équatorial', 'désertique', 'méditerranéen sec'], 1, 'Équatorial.', 'Types.', 'facile'),
    exercises: [
      ex('Chaleur + pluies abondantes toute l’année :', ['polaire', 'équatorial', 'désertique', 'méditerranéen'], 1, 'Équatorial.', 'Climats.', 'facile'),
      ex('Végétation typique du climat désertique :', ['forêt dense', 'végétation très rare / adaptée à la sécheresse', 'toundra humide', 'mangrove froide'], 1, 'Adaptation.', 'Biomes.', 'facile'),
      ex('Le Gabon est surtout marqué par :', ['climat polaire', 'forêt dense / climat chaud et humide', 'désert absolu', 'steppe uniquement'], 1, 'Afrique centrale humide.', 'Gabon.', 'intermediaire'),
      ex('La savane est associée surtout à un climat :', ['polaire', 'tropical (saison sèche / saison des pluies)', 'équatorial sans saison', 'alpin seul'], 1, 'Tropical à saisons.', 'Savane.', 'intermediaire'),
      ex('Un climagramme représente :', ['uniquement la population', 'températures et précipitations mensuelles', 'les frontières politiques', 'le PIB'], 1, 'Outil de géographie.', 'Graphiques.', 'difficile'),
    ],
    quiz: [
      qz('Climat ≠ météo : le climat', ['est le temps d’un jour', 'est une moyenne sur le long terme', 'n’existe pas', 'est un nuage'], 1, 'Longue période.'),
      qz('Forêt dense équatoriale :', ['feuilles en aiguilles seulement', 'grande biodiversité, humidité', 'absence totale d’arbres', 'glace permanente'], 1, 'Biodiversité.'),
    ],
  },
];

// ——— 4e SVT / PC / HG ———
const svt4e: TopicData[] = [
  {
    title: 'Nutrition et digestion',
    content:
      "Les aliments apportent nutriments et énergie.\nDigestion : transformation mécanique et chimique (enzymes) jusqu’aux nutriments absorbables.\nAbsorption surtout au niveau de l’intestin grêle ; le sang transporte les nutriments.",
    example: 'L’amidon est digéré en sucres simples grâce à des enzymes (salive, pancréas…).',
    keyPoints: ['Nutriments', 'Enzymes', 'Tube digestif', 'Absorption'],
    exercise: ex('L’absorption des nutriments se fait surtout dans :', ['la bouche', 'l’intestin grêle', 'l’œsophage', 'les poumons'], 1, 'Muqueuse intestinale.', 'Digestion.', 'facile'),
    exercises: [
      ex('Absorption surtout dans :', ['bouche', 'intestin grêle', 'œsophage', 'poumons'], 1, 'Intestin grêle.', 'Digestion.', 'facile'),
      ex('Une enzyme digestive :', ['construit l’os', 'catalyse la transformation de substrats alimentaires', 'est un os', 'est un virus'], 1, 'Catalyseur bio.', 'Enzymes.', 'intermediaire'),
      ex('Le bol alimentaire traverse après l’estomac :', ['les poumons', 'l’intestin grêle puis le gros intestin', 'le cœur', 'le cerveau'], 1, 'Tube digestif.', 'Anatomie.', 'facile'),
      ex('Les protéines sont surtout sources de :', ['uniquement de sucre', 'acides aminés', 'O₂', 'fer métallique pur'], 1, 'Briques protéiques.', 'Nutriments.', 'intermediaire'),
      ex('Pourquoi mâcher les aliments aide la digestion ?', ['ça les refroidit seulement', 'augmente la surface pour les enzymes', 'produit de la photosynthèse', 'crée des anticorps'], 1, 'Surface d’échange.', 'Mécanique.', 'difficile'),
    ],
    quiz: [
      qz('Foie / pancréas : rôle digestif', ['uniquement stocker l’air', 'produire des substances (bile, enzymes) utiles à la digestion', 'battre comme le cœur', 'filtrer uniquement l’urine'], 1, 'Glandes annexes.'),
      qz('Nutriment énergétique majeur souvent cité :', ['cellulose pure non digérée', 'glucides / lipides', 'O₂ solide', 'azote atmosphérique'], 1, 'Énergie.'),
    ],
  },
];

const pc4e: TopicData[] = [
  {
    title: 'Électricité : circuit simple et sécurité',
    content:
      "Circuit en série : une seule boucle ; l’intensité est la même en tout point.\nDipôles : générateur, lampes, interrupteur, résistor…\nLoi d’Ohm (niveau collège) : U = R × I (conventions du programme).\nSécurité : ne jamais toucher une installation sous tension ; rôle du disjoncteur / fusible.",
    example: 'Pile + interrupteur + lampe en série : la lampe s’allume si le circuit est fermé.',
    keyPoints: ['Série', 'Intensité', 'Tension', 'Loi d’Ohm', 'Sécurité'],
    exercise: ex('Dans un circuit série, l’intensité :', ['change à chaque lampe obligatoirement', 'est la même en tout point', 'est toujours nulle', 'n’existe pas'], 1, 'Même I en série.', 'Série.', 'facile'),
    exercises: [
      ex('Circuit série : intensité', ['varie forcément partout', 'identique en tout point', 'toujours nulle', 'infinie'], 1, 'Série.', 'Électricité.', 'facile'),
      ex('Un interrupteur ouvert :', ['laisse passer le courant', 'interrompt le circuit', 'augmente la tension à l’infini', 'crée de l’eau'], 1, 'Circuit ouvert.', 'Composants.', 'facile'),
      ex('U = R × I : si R double et I constant, U :', ['diminue de moitié', 'double', 'reste égal', 'devient nul'], 1, 'Proportionnalité.', 'Ohm.', 'intermediaire'),
      ex('Un fusible qui fond :', ['augmente le courant', 'coupe le circuit en cas de surintensité', 'produit de la lumière utile', 'mesure la masse'], 1, 'Protection.', 'Sécurité.', 'intermediaire'),
      ex('Deux lampes identiques en série sous une pile : chacune reçoit (idéalement) :', ['toute la tension de la pile', 'une part de la tension', 'zéro tension', 'une tension infinie'], 1, 'Répartition.', 'Série.', 'difficile'),
    ],
    quiz: [
      qz('Générateur dans un schéma :', ['fournit de l’énergie électrique', 'est toujours une lampe', 'coupe le courant', 'est un isolant'], 0, 'Source.'),
      qz('Ne jamais :', ['utiliser un interrupteur', 'toucher une installation électrique sous tension', 'fermer un circuit sur pile 4,5 V de TP', 'observer une lampe'], 1, 'Sécurité.'),
    ],
  },
];

const hg4e: TopicData[] = [
  {
    title: 'L’Afrique : relief, climats, enjeux',
    content:
      "Afrique : vaste continent, déserts (Sahara), forêts (bassin du Congo), savanes, hauts plateaux, rift.\nClimats variés du nord au sud.\nEnjeux : ressources, développement, urbanisation, environnement, intégration régionale.",
    example: 'Le Gabon dans le bassin du Congo forestier ; le Sahara au nord du continent.',
    keyPoints: ['Relief', 'Climats', 'Ressources', 'Développement'],
    exercise: ex('Le Sahara est :', ['une forêt équatoriale', 'un grand désert africain', 'une mer intérieure', 'une chaîne alpine européenne'], 1, 'Désert.', 'Relief/climats.', 'facile'),
    exercises: [
      ex('Sahara :', ['forêt', 'désert africain', 'mer', 'Alpes'], 1, 'Désert.', 'Afrique.', 'facile'),
      ex('Bassin du Congo associé surtout à :', ['désert absolu', 'forêt dense', 'banquise', 'steppe sibérienne'], 1, 'Forêt.', 'Afrique centrale.', 'facile'),
      ex('Enjeu majeur pour beaucoup de pays africains :', ['absence totale de population', 'développement et gestion des ressources', 'manque d’océans sur Terre', 'absence de langues'], 1, 'Développement.', 'Enjeux.', 'intermediaire'),
      ex('Le rift est-africain est lié à :', ['une faille / tectonique', 'un seul volcan éteint sans intérêt', 'une frontière purement politique sans géologie', 'un fleuve artificiel'], 0, 'Tectonique.', 'Relief.', 'difficile'),
      ex('Urbanisation en Afrique signifie surtout :', ['retour exclusif aux villages', 'croissance des villes', 'disparition des capitales', 'fin de l’agriculture mondiale'], 1, 'Villes.', 'Société.', 'intermediaire'),
    ],
    quiz: [
      qz('Le Gabon se situe en :', ['Afrique du Nord désertique exclusive', 'Afrique centrale', 'Afrique australe polaire', 'Europe'], 1, 'Centrale.'),
      qz('Ressource forestière du bassin du Congo :', ['pétrole uniquement', 'bois / biodiversité entre autres', 'banquise', 'blé nordique seul'], 1, 'Forêt.'),
    ],
  },
];

// ——— Première ———
const pcPremiere: TopicData[] = [
  {
    title: 'Quantité de matière et concentrations',
    content:
      "Mole : unité de quantité de matière ; nombre d’Avogadro N_A ≈ 6,02×10²³ mol⁻¹.\nn = m/M ; n = C × V (C en mol·L⁻¹, V en L).\nConcentration massique ρ = m/V.\nDilution : conservation de la quantité de matière n_i = n_f.",
    example: 'n = 0,1 mol dans V = 0,5 L ⇒ C = 0,2 mol·L⁻¹.',
    keyPoints: ['Mole', 'Masse molaire', 'Concentration', 'Dilution'],
    exercise: ex('n = m/M. Si m=18 g et M=18 g·mol⁻¹, n = ?', ['1 mol', '18 mol', '0,1 mol', '2 mol'], 0, '18/18=1.', 'Mole.', 'facile'),
    exercises: [
      ex('m=18 g, M=18 g·mol⁻¹ → n ?', ['1 mol', '18 mol', '0,1 mol', '2 mol'], 0, '1 mol.', 'n=m/M.', 'facile'),
      ex('C = n/V. n=0,1 mol, V=0,5 L → C ?', ['0,05', '0,2', '0,5', '2'], 1, '0,1/0,5=0,2 mol·L⁻¹.', 'Concentration.', 'facile'),
      ex('Dilution : n avant = n après. Si C_i V_i = C_f V_f, et C_i=1, V_i=0,1, C_f=0,1 → V_f ?', ['0,1 L', '1 L', '0,01 L', '10 L'], 1, 'V_f = C_i V_i / C_f = 1 L.', 'Dilution.', 'intermediaire'),
      ex('Masse molaire de H₂O (H=1, O=16) :', ['17', '18', '16', '2'], 1, '2+16=18 g·mol⁻¹.', 'M.', 'intermediaire'),
      ex('Nombre d’entités dans 2 mol :', ['N_A', '2 N_A', 'N_A/2', '2'], 1, 'n×N_A.', 'Avogadro.', 'difficile'),
    ],
    quiz: [
      qz('Unité de C (molaire) :', ['g·L⁻¹ seulement', 'mol·L⁻¹', 'mol', 'L'], 1, 'Concentration molaire.'),
      qz('Diluer une solution :', ['augmente C', 'diminue C en augmentant V (n constant)', 'change n obligatoirement', 'détruit les moles'], 1, 'n constant.'),
    ],
  },
];

const svtPremiere: TopicData[] = [
  {
    title: 'ADN, gènes et information génétique',
    content:
      "L’ADN porte l’information génétique. Gène : segment d’ADN codant (souvent) une chaîne polypeptidique.\nRéplication semi-conservative avant division cellulaire.\nMutation : modification de la séquence ; peut être silencieuse, ou modifier la protéine.",
    example: 'Allèles : versions d’un même gène.',
    keyPoints: ['ADN', 'Gène', 'Réplication', 'Mutation', 'Allèle'],
    exercise: ex('Un gène est :', ['une cellule', 'un segment d’ADN porteur d’information', 'un organe', 'un lipide'], 1, 'Information génétique.', 'Gène.', 'facile'),
    exercises: [
      ex('Un gène est :', ['une cellule', 'un segment d’ADN informatif', 'un organe', 'un lipide'], 1, 'ADN.', 'Gène.', 'facile'),
      ex('La réplication de l’ADN sert surtout à :', ['digérer', 'dupliquer l’info avant division', 'produire de l’ATP seulement', 'former les os'], 1, 'Transmission.', 'Réplication.', 'intermediaire'),
      ex('Une mutation est :', ['toujours mortelle', 'une modification de séquence d’ADN', 'une digestion', 'une respiration'], 1, 'Changement de séquence.', 'Mutation.', 'facile'),
      ex('Allèles :', ['chromosomes différents d’espèces', 'versions d’un même gène', 'types de cellules sanguines seulement', 'organes'], 1, 'Variantes.', 'Génétique.', 'intermediaire'),
      ex('Semi-conservative signifie :', ['brin parental + brin néoformé dans chaque double hélice fille', 'destruction totale de l’ADN', 'copie ARN seule', 'pas de copie'], 0, 'Mécanisme.', 'Réplication.', 'difficile'),
    ],
    quiz: [
      qz('Support principal de l’hérédité cellulaire :', ['glucose', 'ADN', 'eau seule', 'O₂'], 1, 'ADN.'),
      qz('Protéine codée via :', ['transcription/traduction à partir de l’info génique', 'uniquement la digestion', 'la photosynthèse humaine', 'la filtration rénale'], 0, 'Expression des gènes.'),
    ],
  },
];

const philoPremiere: TopicData[] = [
  {
    title: 'La vérité et la connaissance',
    content:
      "Vérité : adéquation de la pensée au réel (correspondance), cohérence, ou consensus — selon les théories.\nConnaissance : croyance vraie justifiée (approche classique), avec débats sur la justification.\nScience : méthodes, épreuves empiriques, réfutabilité (Popper) ; opinion ≠ savoir démontré.",
    example: 'Une hypothèse scientifique doit pouvoir être testée / confrontée à l’expérience.',
    keyPoints: ['Vérité', 'Justification', 'Science', 'Opinion', 'Méthode'],
    exercise: ex('Selon une approche classique, connaître c’est souvent :', ['croire sans raison', 'avoir une croyance vraie justifiée', 'rêver', 'ignorer'], 1, 'Croyance vraie justifiée.', 'Épistémologie.', 'facile'),
    exercises: [
      ex('Connaissance (approche classique) :', ['croyance sans raison', 'croyance vraie justifiée', 'rêve', 'ignorance'], 1, 'Justifiée.', 'Épistémologie.', 'facile'),
      ex('Popper insiste sur :', ['l’irréfutabilité totale', 'la réfutabilité des hypothèses scientifiques', 'l’absence d’expérience', 'la foi seule'], 1, 'Falsifiabilité.', 'Science.', 'intermediaire'),
      ex('Opinion et savoir se distinguent surtout par :', ['la longueur du texte', 'le degré de justification / preuve', 'la couleur de l’encre', 'le volume de la voix'], 1, 'Justification.', 'Distinction.', 'facile'),
      ex('Vérité-correspondance :', ['cohérence interne seule', 'adéquation aux faits / au réel', 'majorité absolue', 'beauté'], 1, 'Correspondance.', 'Théories.', 'intermediaire'),
      ex('Une hypothèse non testable est :', ['automatiquement vraie', 'difficilement scientifique au sens poppérien', 'une loi', 'une expérience'], 1, 'Critère de démarcation.', 'Popper.', 'difficile'),
    ],
    quiz: [
      qz('Épistémologie :', ['étude de la connaissance', 'étude des insectes', 'étude des roches seulement', 'comptabilité'], 0, 'Philosophie de la connaissance.'),
      qz('Science moderne s’appuie souvent sur :', ['l’autorité seule', 'méthode et épreuves empiriques', 'la rumeur', 'l’astrologie'], 1, 'Méthode.'),
    ],
  },
];

export function getExtra_5e_svt(): Subject {
  return makeSubject('svt', 'SVT', 'Leaf', 'green', '5e', '5ème', svt5e);
}
export function getExtra_5e_pc(): Subject {
  return makeSubject('physique-chimie', 'Physique-Chimie', 'Atom', 'indigo', '5e', '5ème', pc5e);
}
export function getExtra_5e_hg(): Subject {
  return makeSubject('geographie', 'Géographie', 'Map', 'teal', '5e', '5ème', hg5e);
}
export function getExtra_4e_svt(): Subject {
  return makeSubject('svt', 'SVT', 'Leaf', 'green', '4e', '4ème', svt4e);
}
export function getExtra_4e_pc(): Subject {
  return makeSubject('physique-chimie', 'Physique-Chimie', 'Atom', 'indigo', '4e', '4ème', pc4e);
}
export function getExtra_4e_hg(): Subject {
  return makeSubject('geographie', 'Géographie', 'Map', 'teal', '4e', '4ème', hg4e);
}
export function getExtra_premiere_pc(): Subject {
  return makeSubject('physique-chimie', 'Physique-Chimie', 'Atom', 'indigo', 'premiere', 'Première', pcPremiere);
}
export function getExtra_premiere_svt(): Subject {
  return makeSubject('svt', 'SVT', 'Leaf', 'green', 'premiere', 'Première', svtPremiere);
}
export function getExtra_premiere_philo(): Subject {
  return makeSubject('philosophie', 'Philosophie', 'Brain', 'purple', 'premiere', 'Première', philoPremiere);
}


// ——— Vague v5 : Histoire/Français 4e-5e, Terminale SVT/PC, Univ macro/physio ———

const histoire5e: TopicData[] = [
  {
    title: 'Sociétés et échanges en Afrique centrale avant la colonisation',
    content:
      "Bien avant la colonisation, des sociétés organisées existent sur le territoire de l’actuel Gabon : villages, chefferies, échanges (sel, fer, forêt, côte).\nLes peuples du Gabon ont façonné langues et cultures sur le temps long.\nL’histoire du pays ne se limite pas à la colonisation ni à 1960.",
    example: 'Échanges régionaux ; organisation villageoise ; mémoire orale des peuples du Gabon.',
    keyPoints: ['Afrique centrale', 'Chefferies', 'Échanges', 'Peuples', 'Avant la colonisation'],
    exercise: ex('Avant la colonisation, le territoire gabonais connaissait :', ['aucune société organisée', 'des sociétés et des échanges', 'uniquement des usines modernes', 'uniquement des aéroports'], 1, 'Sociétés précoloniales.', 'Histoire du Gabon.', 'facile'),
    exercises: [
      ex('Avant la colonisation, le territoire gabonais connaissait :', ['aucune société', 'des sociétés et échanges', 'uniquement des usines', 'uniquement des aéroports'], 1, 'Sociétés organisées.', 'Histoire.', 'facile'),
      ex('Les réseaux d’échanges pouvaient porter sur :', ['uniquement le pétrole moderne', 'sel, fer, produits de la forêt, contacts côtiers', 'des smartphones', 'des trains TGV'], 1, 'Commerce ancien.', 'Échanges.', 'facile'),
      ex('Réduire l’histoire du Gabon à la seule colonisation :', ['est complet', 'oublie les périodes antérieures', 'est obligatoire', 'est la seule méthode'], 1, 'Longue durée.', 'Méthode.', 'intermediaire'),
      ex('L’Afrique centrale est la région où se trouve :', ['le Gabon', 'uniquement le Canada', 'l’Antarctique', 'l’Australie seule'], 0, 'Situation.', 'Géo-histoire.', 'facile'),
      ex('La mémoire orale (contes, généalogies) sert à :', ['rien', 'transmettre histoire et valeurs', 'remplacer l’école de maths', 'interdire la lecture'], 1, 'Oralité.', 'Culture.', 'difficile'),
    ],
    quiz: [
      qz('Chefferie :', ['forme d’organisation politique locale', 'un type de poisson', 'une province d’Europe', 'un engrais'], 0, 'Organisation.'),
      qz('Peuples du Gabon ont des histoires :', ['uniquement depuis 2000', 'plus anciennes que la colonisation', 'inexistantes', 'uniquement françaises'], 1, 'Antériorité.'),
    ],
  },
];

const histoire4e: TopicData[] = [
  {
    title: 'De la côte atlantique à la colonisation : le Gabon dans les échanges mondiaux',
    content:
      "À partir du XVe siècle : expansion maritime européenne (routes vers l’Asie, Amériques), échanges mondiaux, empires coloniaux.\nRenforcement de l’État monarchique dans plusieurs royaumes européens.\nRenaissance culturelle et Réforme religieuse transforment l’Europe.",
    example: 'Comptoirs côtiers ; traite ; colonisation française ; chemin vers 1960.',
    keyPoints: ['Atlantique', 'Échanges', 'Colonisation', 'Libreville', 'Indépendance'],
    exercise: ex('Libreville est fondée dans un contexte lié à :', ['la Préhistoire seule', 'le XIXe siècle et la période coloniale', 'l’an 2000 seulement', 'l’Empire romain'], 1, 'Fondation au XIXe s.', 'Gabon.', 'facile'),
    exercises: [
      ex('Libreville : contexte de fondation :', ['Préhistoire seule', 'XIXe s. / période coloniale', 'an 2000', 'Empire romain'], 1, 'XIXe s.', 'Gabon.', 'facile'),
      ex('La traite atlantique a touché l’Afrique en :', ['déportant des captifs vers les Amériques', 'construisant le TGV', 'créant le pétrole', 'fondant Oyem en 2010'], 0, 'Traite.', 'Mémoire.', 'intermediaire'),
      ex('La colonisation française au Gabon :', ['n’a jamais existé', 'a précédé l’indépendance de 1960', 'commence en 2020', 'concerne uniquement l’Asie'], 1, 'Cadre colonial.', 'Histoire.', 'facile'),
      ex('17 août 1960 :', ['fête de la musique en Europe', 'indépendance du Gabon', 'fin de la Préhistoire', 'fondation de Rome'], 1, 'Fête nationale.', 'Repère.', 'facile'),
      ex('Étudier la période coloniale au Gabon sert à :', ['oublier 1960', 'comprendre le passage à l’État indépendant', 'remplacer la géographie des provinces', 'interdire l’EMC'], 1, 'Sens historique.', 'Finalités.', 'difficile'),
    ],
    quiz: [
      qz('Imprimerie (Gutenberg) favorise :', ['la baisse de l’écrit', 'la diffusion des textes', 'l’interdiction des livres', 'la fin des langues'], 1, 'Diffusion.'),
      qz('Monarchie d’Ancien Régime :', ['pouvoir souvent concentré autour du roi', 'suffrage universel', 'république systématique', 'absence d’État'], 0, 'État moderne.'),
    ],
  },
];

const francais5e: TopicData[] = [
  {
    title: 'Le récit : schéma narratif et points de vue',
    content:
      "Schéma narratif : situation initiale, élément perturbateur, péripéties, dénouement, situation finale.\nPoint de vue / focalisation : narrateur omniscient, interne, externe.\nTemps du récit : passé simple / imparfait (narration classique), présent de narration.",
    example: 'Un conte : « Il était une fois… » puis une épreuve, puis une résolution.',
    keyPoints: ['Schéma narratif', 'Narrateur', 'Focalisation', 'Temps verbaux'],
    exercise: ex('L’élément perturbateur :', ['termine toujours l’histoire', 'rompt l’équilibre initial', 'est le titre', 'est la conclusion seule'], 1, 'Déclenche l’action.', 'Schéma.', 'facile'),
    exercises: [
      ex('Élément perturbateur :', ['termine l’histoire', 'rompt l’équilibre initial', 'est le titre', 'est la conclusion'], 1, 'Déclencheur.', 'Narratif.', 'facile'),
      ex('Narrateur omniscient :', ['ne sait rien', 'sait tout des personnages', 'est forcément un animal', 'écrit seulement au futur'], 1, 'Savoir total.', 'Point de vue.', 'facile'),
      ex('Focalisation interne :', ['on voit à travers un personnage', 'on ignore tout sentiment', 'il n’y a pas de narrateur', 'c’est un dialogue seul'], 0, 'Filtrage par un personnage.', 'Focalisation.', 'intermediaire'),
      ex('Passé simple + imparfait servent souvent à :', ['uniquement la poésie lyrique', 'raconter et décrire dans un récit au passé', 'donner des ordres', 'conjuguer l’anglais'], 1, 'Narration classique.', 'Temps.', 'intermediaire'),
      ex('La situation finale :', ['ouvre toujours un nouveau roman obligatoire', 'rétablit un nouvel équilibre', 'est l’élément perturbateur', 'n’existe jamais'], 1, 'Clôture.', 'Schéma.', 'difficile'),
    ],
    quiz: [
      qz('Péripéties :', ['événements qui compliquent l’action', 'la couverture du livre', 'le nom de l’auteur', 'la pagination'], 0, 'Actions.'),
      qz('Narrateur ≠ personnage toujours :', ['vrai : le narrateur raconte, le personnage agit', 'faux toujours identiques', 'ils sont des verbes', 'ils sont des lieux'], 0, 'Distinction.'),
    ],
  },
];

const francais4e: TopicData[] = [
  {
    title: 'Argumenter : thèse, arguments, exemples',
    content:
      "Texte argumentatif : défendre une thèse avec des arguments et des exemples.\nConnecteurs logiques : cause, conséquence, opposition, addition, conclusion.\nRepérer la thèse adverse (concession / réfutation) renforce le discours.",
    example: 'Thèse : « Il faut protéger la forêt gabonaise. » Argument écologique + exemple de biodiversité.',
    keyPoints: ['Thèse', 'Argument', 'Exemple', 'Connecteurs', 'Réfutation'],
    exercise: ex('La thèse est :', ['un exemple isolé', 'l’idée principale défendue', 'un connecteur', 'un titre de chapitre seulement'], 1, 'Position défendue.', 'Argumentation.', 'facile'),
    exercises: [
      ex('La thèse est :', ['un exemple', 'l’idée défendue', 'un connecteur', 'un titre seul'], 1, 'Position.', 'Argumenter.', 'facile'),
      ex('Un argument sert à :', ['décorer sans lien', 'justifier la thèse', 'remplacer la ponctuation', 'citer au hasard'], 1, 'Justification.', 'Argument.', 'facile'),
      ex('« Cependant » introduit souvent :', ['une cause', 'une opposition / restriction', 'une conclusion obligatoire', 'une énumération neutre'], 1, 'Opposition.', 'Connecteurs.', 'intermediaire'),
      ex('Réfuter :', ['ignorer l’adversaire', 'discuter et contrer un argument adverse', 'copier la thèse', 'finir sans conclusion'], 1, 'Contre-argumentation.', 'Réfutation.', 'intermediaire'),
      ex('Un exemple efficace est :', ['hors sujet', 'précis et relié à l’argument', 'très long sans lien', 'en chiffres seulement sans sens'], 1, 'Pertinence.', 'Exemple.', 'difficile'),
    ],
    quiz: [
      qz('« Donc », « ainsi », « c’est pourquoi » :', ['opposition', 'conséquence', 'cause seule', 'temps'], 1, 'Conséquence.'),
      qz('Concession :', ['admettre partiellement avant de maintenir sa thèse', 'abandonner toute thèse', 'raconter une fable seule', 'décrire un paysage'], 0, 'Stratégie.'),
    ],
  },
];

const svtTerminale: TopicData[] = [
  {
    title: 'Immunité adaptative et vaccination (rappels BAC)',
    content:
      "Immunité innée : réponse rapide, peu spécifique (barrières, phagocytes, inflammation).\nImmunité adaptative : lymphocytes, spécificité, mémoire (anticorps, LTc).\nVaccination : stimuler la mémoire sans pathogénicité de la maladie ; sérum = apport passif d’anticorps.",
    example: 'Rappel vaccinal entretient la mémoire immunitaire.',
    keyPoints: ['Innée', 'Adaptative', 'Mémoire', 'Vaccin', 'Sérum'],
    exercise: ex('La mémoire immunitaire permet :', ['d’oublier l’antigène', 'une réponse secondaire plus rapide et intense', 'd’arrêter la circulation', 'de digérer l’ADN'], 1, 'Réponse secondaire.', 'Immunité.', 'facile'),
    exercises: [
      ex('Mémoire immunitaire :', ['oubli', 'réponse secondaire plus efficace', 'arrêt cardiaque', 'digestion ADN'], 1, 'Secondaire.', 'BAC SVT.', 'facile'),
      ex('Vaccination vise surtout :', ['guérir une infection déclarée comme un antibiotique antiviral universel', 'préparer le système avant infection', 'remplacer l’eau', 'supprimer les globules rouges'], 1, 'Prévention.', 'Vaccin.', 'facile'),
      ex('Les anticorps sont produits par :', ['hépatocytes uniquement', 'plasmocytes (issus de LB)', 'ostéocytes', 'kératinocytes seuls'], 1, 'LB différenciés.', 'Humorale.', 'intermediaire'),
      ex('Sérum thérapeutique apporte :', ['des lymphocytes T naïfs seulement', 'des anticorps tout prêts (immunité passive)', 'des vaccins atténués toujours', 'de l’hémoglobine pure'], 1, 'Passif.', 'Sérum.', 'intermediaire'),
      ex('Sida (VIH) touche surtout :', ['les os uniquement', 'les lymphocytes T CD4, fragilisant l’immunité', 'la vision seule', 'les cheveux'], 1, 'Immunodépression.', 'Pathologie.', 'difficile'),
    ],
    quiz: [
      qz('Antigène :', ['molécule reconnue par le système immunitaire', 'toujours un antibiotique', 'un os', 'une vitamine C'], 0, 'Reconnaissance.'),
      qz('Immunité innée est :', ['lente et très spécifique dès le premier contact', 'rapide et peu spécifique', 'absente chez l’humain', 'uniquement vaccinale'], 1, 'Innée.'),
    ],
  },
  {
    title: 'Génétique humaine et patrimoniale (BAC)',
    content:
      "Chromosomes, caryotype, mitose / méiose (rappels).\nTransmission mendélienne simple ; arbres généalogiques.\nParticularités : linkage, codominance, maladies monogéniques.\nEnjeux éthiques des tests génétiques.",
    example: 'Arbre : carré = homme, cercle = femme ; noirci = atteint.',
    keyPoints: ['Caryotype', 'Méiose', 'Hérédité', 'Arbre', 'Éthique'],
    exercise: ex('La méiose produit des cellules :', ['2n identiques à la mère', 'haploïdes (n)', 'toujours cancéreuses', 'sans ADN'], 1, 'Réduction chromatique.', 'Méiose.', 'facile'),
    exercises: [
      ex('Méiose → cellules :', ['2n identiques', 'haploïdes', 'cancéreuses', 'sans ADN'], 1, 'n.', 'Méiose.', 'facile'),
      ex('Caryotype humain normal :', ['23 chromosomes', '46 chromosomes (23 paires)', '92 chromosomes', '2 chromosomes'], 1, '2n=46.', 'Caryotype.', 'facile'),
      ex('Dans un arbre, un symbole noirci indique souvent :', ['un non-né', 'un individu atteint du trait étudié', 'un jumeau obligatoire', 'un médecin'], 1, 'Phénotype étudié.', 'Arbre.', 'intermediaire'),
      ex('Un gène dominant s’exprime :', ['seulement à l’état homozygote', 'déjà à l’état hétérozygote', 'jamais', 'uniquement chez les plantes'], 1, 'Dominance.', 'Mendel.', 'intermediaire'),
      ex('Trisomie 21 liée à :', ['absence totale d’ADN', 'chromosome 21 en trois exemplaires', 'virus grippe', 'carence en fer seule'], 1, 'Aneuploïdie.', 'Chromosomes.', 'difficile'),
    ],
    quiz: [
      qz('Allèle :', ['version d’un gène', 'un organe', 'une espèce', 'un climat'], 0, 'Variante.'),
      qz('Test génétique soulève des questions :', ['uniquement de grammaire', 'éthiques (confidentialité, discrimination…)', 'de cuisine', 'de météo'], 1, 'Éthique.'),
    ],
  },
];

const pcTerminale: TopicData[] = [
  {
    title: 'Acides, bases et pH (BAC)',
    content:
      "Acide (Brönsted) : donneur de proton H⁺ ; base : accepteur.\nCouple acide/base ; pH = −log[H₃O⁺] (solution aqueuse diluée).\nAcide fort : quasi totalement dissocié ; faible : équilibre.\nRéaction acide-base, dosage approximatif au collège/lycée.",
    example: 'pH=2 → [H₃O⁺]=10⁻² mol·L⁻¹ ; acide fort monoprotoné de C=10⁻² a pH≈2.',
    keyPoints: ['H₃O⁺', 'pH', 'Fort / faible', 'Couple', 'Dosage'],
    exercise: ex('pH = −log[H₃O⁺]. Si [H₃O⁺]=10⁻³, pH = ?', ['3', '−3', '1', '11'], 0, '−log(10⁻³)=3.', 'pH.', 'facile'),
    exercises: [
      ex('[H₃O⁺]=10⁻³ → pH ?', ['3', '−3', '1', '11'], 0, 'pH=3.', 'Définition.', 'facile'),
      ex('pH < 7 (25 °C, dilué) indique :', ['basique', 'acide', 'neutre strict', 'gazeux'], 1, 'Acide.', 'Échelle.', 'facile'),
      ex('Acide fort monoprotoné C=0,01 mol·L⁻¹ : pH ≈', ['0,01', '2', '12', '7'], 1, '−log(0,01)=2.', 'Fort.', 'intermediaire'),
      ex('Une base de Brönsted :', ['donne H⁺', 'accepte H⁺', 'est toujours un métal', 'est un gaz rare'], 1, 'Accepteur.', 'Définition.', 'intermediaire'),
      ex('À l’équivalence d’un dosage acide fort / base forte :', ['pH toujours 1', 'quantités de matière acide et base apportées en rapport stœchiométrique', 'volume nul', 'température 0 K'], 1, 'Stœchiométrie.', 'Dosage.', 'difficile'),
    ],
    quiz: [
      qz('Eau pure à 25 °C : pH ≈', ['0', '7', '14', '1'], 1, 'Neutre.'),
      qz('log(10⁻ᵃ) =', ['a', '−a', '10ᵃ', '1/a'], 1, 'Propriété log.'),
    ],
  },
  {
    title: 'Énergie mécanique et travail (rappels)',
    content:
      "Énergie cinétique Ec = ½ mv² ; énergie potentielle de pesanteur Ep = mgh (référentiel local).\nÉnergie mécanique Em = Ec + Ep.\nTravail d’une force ; théorème de l’énergie cinétique ; conservation si forces conservatives uniquement (cas idéal sans frottements).",
    example: 'Chute libre sans frottement : Em constante ; Ec augmente, Ep diminue.',
    keyPoints: ['Ec', 'Ep', 'Em', 'Travail', 'Conservation'],
    exercise: ex('Ec de m=2 kg, v=3 m/s :', ['9 J', '18 J', '6 J', '3 J'], 0, '½×2×9=9 J.', 'Ec.', 'facile'),
    exercises: [
      ex('Ec m=2 kg v=3 m/s', ['9 J', '18 J', '6 J', '3 J'], 0, '½mv²=9.', 'Cinétique.', 'facile'),
      ex('Ep = mgh. m=2, g=10, h=5 → Ep', ['10 J', '100 J', '50 J', '25 J'], 1, '2×10×5=100 J.', 'Pesanteur.', 'facile'),
      ex('Sans frottement, chute libre : Em', ['augmente toujours', 'se conserve', 'est nulle', 'devient chimique'], 1, 'Conservatif.', 'Mécanique.', 'intermediaire'),
      ex('Unité d’énergie / travail dans le SI :', ['newton', 'joule', 'watt', 'pascal'], 1, 'Joule.', 'Unités.', 'facile'),
      ex('Théorème de l’énergie cinétique : variation de Ec =', ['travail total des forces', 'seulement Ep', 'la masse', 'la température'], 0, 'ΣW = ΔEc.', 'TEC.', 'difficile'),
    ],
    quiz: [
      qz('Force conservative :', ['travail indépendant du chemin (lié à une Ep)', 'toujours frottement', 'n’existe pas', 'uniquement magnétique'], 0, 'Potentiel.'),
      qz('Frottements :', ['conservent toujours Em', 'dissipent souvent de l’énergie mécanique', 'augmentent Em sans limite', 'annulent la masse'], 1, 'Dissipation.'),
    ],
  },
];

const univMacro: TopicData[] = [
  {
    title: 'Macroéconomie : PIB, inflation, chômage',
    content:
      "PIB : mesure de la production de richesses sur un territoire et une période.\nInflation : hausse générale et durable des prix ; mesurée souvent par un indice.\nChômage : actifs sans emploi à la recherche d’un emploi (définitions BIT / nationales).\nPolitiques budgétaire et monétaire cherchent à stabiliser l’activité.",
    example: 'Croissance = hausse du PIB réel ; stagflation = stagnation + inflation.',
    keyPoints: ['PIB', 'Croissance', 'Inflation', 'Chômage', 'Politiques'],
    exercise: ex('Le PIB mesure surtout :', ['la population', 'la production de richesses', 'la surface du pays', 'le nombre d’écoles seulement'], 1, 'Production.', 'PIB.', 'facile'),
    exercises: [
      ex('PIB mesure :', ['population', 'production de richesses', 'surface', 'écoles seules'], 1, 'Richesses.', 'Macro.', 'facile'),
      ex('Inflation :', ['baisse durable des prix', 'hausse générale et durable des prix', 'stabilité absolue', 'chômage seul'], 1, 'Prix.', 'Inflation.', 'facile'),
      ex('Croissance économique :', ['hausse du PIB réel', 'baisse démographique obligatoire', 'fin du commerce', 'inflation nulle toujours'], 0, 'PIB réel.', 'Croissance.', 'intermediaire'),
      ex('Chômeur (sens courant BIT) :', ['inactif volontaire sans recherche', 'sans emploi et en recherche active', 'étudiant sans contrainte', 'retraité'], 1, 'Actif non occupé.', 'Chômage.', 'intermediaire'),
      ex('Politique monétaire agit surtout via :', ['les programmes scolaires', 'taux d’intérêt / liquidités (banque centrale)', 'la météo', 'les notes du BAC'], 1, 'Banque centrale.', 'Politiques.', 'difficile'),
    ],
    quiz: [
      qz('PIB nominal vs réel :', ['réel corrige (souvent) des effets de prix', 'identique toujours', 'réel ignore la production', 'nominal est une surface'], 0, 'Déflation des prix.'),
      qz('Demande globale inclut :', ['seulement les exportations', 'consommation, investissement, dépenses publiques, solde extérieur…', 'uniquement les salaires des enseignants', 'la masse des roches'], 1, 'Composantes.'),
    ],
  },
];

const univPhysio: TopicData[] = [
  {
    title: 'Physiologie : homéostasie et systèmes',
    content:
      "Homéostasie : maintien d’un milieu intérieur relativement stable (température, glycémie, pH, pression…).\nRétrocontrôle négatif : le plus fréquent (corrige un écart).\nExemples : régulation de la glycémie (insuline / glucagon) ; thermorégulation.",
    example: 'Après un repas, insuline favorise le stockage ; à jeun, glucagon mobilise le glucose.',
    keyPoints: ['Homéostasie', 'Rétrocontrôle', 'Glycémie', 'Thermorégulation'],
    exercise: ex('Homéostasie signifie surtout :', ['maladie chronique', 'maintien d’un équilibre interne', 'croissance tumorale', 'arrêt cardiaque'], 1, 'Stabilité relative.', 'Physio.', 'facile'),
    exercises: [
      ex('Homéostasie :', ['maladie', 'équilibre interne', 'tumeur', 'arrêt cardiaque'], 1, 'Stabilité.', 'Concept.', 'facile'),
      ex('Insuline a pour effet net typique :', ['augmenter la glycémie', 'diminuer la glycémie', 'créer des os', 'produire de la bile seule'], 1, 'Hypoglycémiante.', 'Glycémie.', 'facile'),
      ex('Rétrocontrôle négatif :', ['amplifie toujours l’écart', 'réduit l’écart à la valeur de référence', 'ignore les capteurs', 'est un os'], 1, 'Correction.', 'Feedback.', 'intermediaire'),
      ex('Glucagon :', ['hypoglycémiant', 'hyperglycémiant (mobilise le glucose)', 'un anticorps', 'un neurotransmetteur de la vision seule'], 1, 'Opposé à l’insuline.', 'Hormones.', 'intermediaire'),
      ex('Fièvre :', ['n’a aucun lien avec la régulation', 'modification du point de consigne thermique souvent liée à une infection', 'baisse obligatoire de métabolisme à zéro', 'arrêt de l’homéostasie définitif'], 1, 'Thermorégulation.', 'Fièvre.', 'difficile'),
    ],
    quiz: [
      qz('Milieu intérieur :', ['liquides du corps (plasma, etc.)', 'forêt amazonienne', 'atmosphère seule', 'noyau terrestre'], 0, 'Claude Bernard.'),
      qz('Système endocrinien agit par :', ['hormones dans le sang', 'uniquement des os', 'ondes radio', 'enzymes digestives seulement'], 0, 'Hormones.'),
    ],
  },
];

export function getExtra_5e_histoire(): Subject {
  return makeSubject('histoire', 'Histoire', 'Landmark', 'orange', '5e', '5ème', histoire5e);
}
export function getExtra_4e_histoire(): Subject {
  return makeSubject('histoire', 'Histoire', 'Landmark', 'orange', '4e', '4ème', histoire4e);
}
export function getExtra_5e_francais(): Subject {
  return makeSubject('francais', 'Français', 'BookOpen', 'amber', '5e', '5ème', francais5e);
}
export function getExtra_4e_francais(): Subject {
  return makeSubject('francais', 'Français', 'BookOpen', 'amber', '4e', '4ème', francais4e);
}
export function getExtra_terminale_svt(): Subject {
  return makeSubject('svt', 'SVT', 'Leaf', 'green', 'terminale-d', 'Terminale D', svtTerminale);
}
export function getExtra_terminale_pc(): Subject {
  return makeSubject('physique-chimie', 'Physique-Chimie', 'Atom', 'indigo', 'terminale-c', 'Terminale C', pcTerminale);
}

/** Overrides / extends level extras — call this as the single entry for levels */
export function getExtraSubjectsForLevelV5(levelId: string): Subject[] {
  const out: Subject[] = [];
  if (levelId === '6e') {
    out.push(getExtra_6e_mathematiques(), getExtra_6e_francais(), getExtra_6e_anglais(), getExtra_6e_histoire());
  }
  if (levelId === '5e') {
    out.push(
      getExtra_5e_anglais(),
      getExtra_5e_svt(),
      getExtra_5e_pc(),
      getExtra_5e_hg(),
      getExtra_5e_histoire(),
      getExtra_5e_francais(),
    );
  }
  if (levelId === '4e') {
    out.push(
      getExtra_4e_anglais(),
      getExtra_4e_svt(),
      getExtra_4e_pc(),
      getExtra_4e_hg(),
      getExtra_4e_histoire(),
      getExtra_4e_francais(),
    );
  }
  return out;
}


/** Version enrichie université : micro + macro, anatomie + physiologie */
export function mergeUniversityFilieres(filieres: Filiere[]): Filiere[] {
  return filieres.map((f) => {
    const n = f.name.toLowerCase();
    let extra: Subject[] = [];
    if (n.includes('info')) {
      extra = [
        makeSubject('algorithmique', 'Algorithmique', 'Code', 'blue', 'univ-info', 'Informatique', univInfoAlgo),
        makeSubject('bases-de-donnees', 'Bases de données', 'Database', 'indigo', 'univ-info', 'Informatique', univInfoBD),
      ];
    } else if (n.includes('droit')) {
      extra = [
        makeSubject('droit-civil', 'Droit Civil', 'Scale', 'amber', 'univ-droit', 'Droit', univDroitCivil),
        makeSubject('droit-constitutionnel', 'Droit Constitutionnel', 'Landmark', 'orange', 'univ-droit', 'Droit', univDroitConst),
      ];
    } else if (n.includes('éco') || n.includes('eco')) {
      extra = [
        makeSubject('microeconomie', 'Microéconomie', 'TrendingUp', 'emerald', 'univ-eco', 'Sciences Économiques', univEco),
        makeSubject('macroeconomie', 'Macroéconomie', 'BarChart3', 'teal', 'univ-eco', 'Sciences Économiques', univMacro),
      ];
    } else if (n.includes('méd') || n.includes('med')) {
      extra = [
        makeSubject('anatomie', 'Anatomie', 'Activity', 'red', 'univ-med', 'Médecine', univMed),
        makeSubject('physiologie', 'Physiologie', 'HeartPulse', 'rose', 'univ-med', 'Médecine', univPhysio),
      ];
    }
    if (!extra.length) return f;
    const byName = new Map(f.subjects.map((s) => [s.name, s]));
    for (const s of extra) {
      const prev = byName.get(s.name);
      if (prev) {
        byName.set(s.name, { ...prev, chapters: [...s.chapters, ...prev.chapters] });
      } else {
        byName.set(s.name, s);
      }
    }
    return { ...f, subjects: Array.from(byName.values()) };
  });
}


// ——— Vague v6 : HG 3e, Anglais lycée, Série A littérature ———

const hg3e: TopicData[] = [
  {
    title: 'Géographie : mondialisation et territoires',
    content:
      "La mondialisation : intensification des échanges (biens, services, informations, personnes) à l’échelle planétaire.\nActeurs : firmes multinationales, États, organisations internationales, sociétés civiles.\nTerritoires inégalement intégrés : métropoles connectées vs marges.\nLe Gabon dans la mondialisation : ressources, ports, enjeux de diversification.",
    example: 'Un conteneur part de l’Asie, transite par un hub, arrive dans un port africain.',
    keyPoints: ['Échanges mondiaux', 'Acteurs', 'Métropoles', 'Inégalités', 'Gabon'],
    exercise: ex('La mondialisation désigne surtout :', ['la fin des échanges', 'l’intensification des échanges à l’échelle mondiale', 'un climat local', 'une seule ville'], 1, 'Échanges planétaires.', 'Géo.', 'facile'),
    exercises: [
      ex('Mondialisation :', ['fin des échanges', 'intensification des échanges mondiaux', 'climat local', 'une ville'], 1, 'Échanges.', 'Définition.', 'facile'),
      ex('Une firme multinationale :', ['n’existe que dans un village', 'implante des activités dans plusieurs pays', 'est un fleuve', 'est un climat'], 1, 'Acteur économique.', 'Acteurs.', 'facile'),
      ex('Les métropoles dans la mondialisation sont souvent :', ['isolées sans flux', 'des nœuds de connexions (finance, transport, info)', 'des déserts', 'des glaciers'], 1, 'Hubs.', 'Territoires.', 'intermediaire'),
      ex('Enjeu pour le Gabon dans la mondialisation :', ['ignorer les ports', 'valoriser les ressources et diversifier l’économie', 'interdire toute exportation définitivement', 'quitter le continent'], 1, 'Diversification.', 'Gabon.', 'intermediaire'),
      ex('Une « marge » territoriale est plutôt :', ['un centre très connecté', 'un espace peu intégré aux réseaux dominants', 'une capitale mondiale', 'un aéroport hub'], 1, 'Inégalités spatiales.', 'Marges.', 'difficile'),
    ],
    quiz: [
      qz('Flux de la mondialisation incluent :', ['uniquement les rêves', 'marchandises, capitaux, informations, personnes…', 'seulement la pluie', 'uniquement les frontières fermées'], 1, 'Flux.'),
      qz('Organisation internationale exemple :', ['ONU, OMC…', 'un commerce de quartier seul', 'une équipe de foot locale uniquement', 'un arbre'], 0, 'OI.'),
    ],
  },
  {
    title: 'Histoire : le Gabon et l’Afrique depuis 1960',
    content:
      "Le Gabon devient indépendant le 17 août 1960, comme de nombreux États africains à la même période.\nL’ONU accueille les nouveaux États ; l’Afrique construit ses organisations régionales.\nDéfis : développement, éducation, santé, gestion des ressources, unité nationale.\nLe Gabon s’inscrit dans l’Afrique centrale (voisinage Cameroun, Guinée équatoriale, Congo).",
    example: 'Fête nationale gabonaise le 17 août ; Libreville capitale de l’État indépendant.',
    keyPoints: ['17 août 1960', 'Décolonisation', 'État gabonais', 'Afrique centrale', 'Développement'],
    exercise: ex('Le Gabon devient indépendant en :', ['1789', '1960', '1492', '2000'], 1, '17 août 1960.', 'Gabon.', 'facile'),
    exercises: [
      ex('Indépendance du Gabon :', ['1789', '1960', '1492', '2000'], 1, '1960.', 'Histoire.', 'facile'),
      ex('L’ONU sert notamment à :', ['coloniser', 'la paix et la coopération entre États', 'remplacer les écoles gabonaises', 'interdire le français'], 1, 'Paix.', 'ONU.', 'facile'),
      ex('Vague d’indépendances en Afrique :', ['années 1960 surtout', 'années 1920 seulement', '2020 uniquement', 'Antiquité'], 0, 'Décolonisation.', 'Afrique.', 'intermediaire'),
      ex('La capitale du Gabon indépendant est :', ['Berlin', 'Libreville', 'Paris', 'Rome'], 1, 'Libreville.', 'Repère.', 'facile'),
      ex('Après 1960, un enjeu majeur pour le Gabon :', ['absence de population', 'développement et gestion des ressources', 'retour à la colonisation', 'fin de l’école'], 1, 'Défis nationaux.', 'Gabon.', 'difficile'),
    ],
    quiz: [
      qz('17 août au Gabon :', ['fête nationale / indépendance', 'Noël européen', 'un match de foot seulement', 'une date sans sens'], 0, 'Mémoire.'),
      qz('Décolonisation :', ['accès à la souveraineté', 'création de nouvelles colonies', 'fin de l’agriculture', 'invention du pétrole'], 0, 'Souveraineté.'),
    ],
  },
];

const anglaisSeconde: TopicData[] = [
  {
    title: 'Expressing opinion and connecting ideas',
    content:
      "Useful phrases: I think that… / In my opinion… / On the one hand… on the other hand…\nLinking words: because, so, however, although, therefore, furthermore.\nAgree / disagree politely: I agree with you / I’m not sure I agree.",
    example: 'I think that protecting forests is essential because biodiversity matters.',
    keyPoints: ['Opinion', 'Linkers', 'Agree/disagree', 'Paragraph structure'],
    exercise: ex('« However » expresses :', ['addition only', 'contrast', 'time only', 'place'], 1, 'Contrast.', 'Linkers.', 'facile'),
    exercises: [
      ex('« However » means mainly :', ['and', 'contrast', 'because', 'under'], 1, 'Contrast.', 'Linkers.', 'facile'),
      ex('To give an opinion :', ['I think that…', 'I am yesterday…', 'Go school…', 'Very table…'], 0, 'Opinion phrase.', 'Speaking/Writing.', 'facile'),
      ex('« Although it rained, we went out » shows :', ['pure addition', 'concession/contrast', 'only future', 'a question'], 1, 'Although.', 'Grammar.', 'intermediaire'),
      ex('Polite disagreement :', ['You are stupid', 'I’m not sure I agree', 'Shut up', 'Never speak'], 1, 'Register.', 'Interaction.', 'intermediaire'),
      ex('« Therefore » introduces :', ['a contrast only', 'a consequence/result', 'a location', 'a name'], 1, 'Result.', 'Linkers.', 'difficile'),
    ],
    quiz: [
      qz('« Furthermore » adds :', ['an extra point', 'a full stop only', 'a negation always', 'a past tense'], 0, 'Addition.'),
      qz('On the one hand… on the other hand… structures :', ['two sides of an issue', 'only one idea', 'a shopping list', 'a phone number'], 0, 'Balance.'),
    ],
  },
];

const anglaisPremiere: TopicData[] = [
  {
    title: 'Past perfect and narrative tenses',
    content:
      "Past perfect: had + past participle — action before another past action.\nNarrative: past simple (sequence), past continuous (background), past perfect (earlier past).\nExample: When I arrived, the lesson had already started.",
    example: 'She had studied English before she moved to Libreville.',
    keyPoints: ['had + V-ed', 'Sequence of past events', 'Background vs event'],
    exercise: ex('When I arrived, the film ___ already ___.', ['has / start', 'had / started', 'was / start', 'will / start'], 1, 'Past perfect for earlier past.', 'Tenses.', 'facile'),
    exercises: [
      ex('When I arrived, the film ___ already started.', ['has', 'had', 'was', 'will'], 1, 'had started.', 'Past perfect.', 'facile'),
      ex('Past continuous often describes :', ['a completed list of dates only', 'background action in progress', 'future plans only', 'imperatives'], 1, 'was/were + V-ing.', 'Narrative.', 'intermediaire'),
      ex('She ___ English before she moved.', ['studies', 'had studied', 'is studying', 'study'], 1, 'Earlier past.', 'Past perfect.', 'facile'),
      ex('I was reading when the phone ___.', ['ringing', 'rang', 'had ring', 'rings'], 1, 'Interrupted action → past simple.', 'Mixed tenses.', 'intermediaire'),
      ex('By 2019 they ___ the bridge.', ['build', 'had built', 'are building', 'builds'], 1, 'Completed before a past time.', 'By + past.', 'difficile'),
    ],
    quiz: [
      qz('Form of past perfect :', ['have + V-ing', 'had + past participle', 'will + V', 'do + V'], 1, 'had + V-ed.'),
      qz('« already » with past perfect means :', ['later than expected future', 'earlier than another past moment', 'never', 'only tomorrow'], 1, 'Anteriority.'),
    ],
  },
];

const anglaisTerminale: TopicData[] = [
  {
    title: 'Essay writing: discuss both views',
    content:
      "Structure: introduction (paraphrase + outline) → paragraph 1 (view A + example) → paragraph 2 (view B + example) → conclusion (balanced opinion).\nUseful language: It is often argued that… / Critics point out that… / On balance, I believe…\nStay formal; avoid slang; check agreement and tense consistency.",
    example: 'Topic: Should social media be limited for teenagers? Discuss both views and give your opinion.',
    keyPoints: ['Structure', 'Both views', 'Examples', 'Formal register', 'Conclusion'],
    exercise: ex('A balanced essay should :', ['ignore the other side', 'present more than one viewpoint before concluding', 'only list vocabulary', 'copy the topic without ideas'], 1, 'Both views.', 'Writing.', 'facile'),
    exercises: [
      ex('Balanced essay :', ['one side only always', 'several viewpoints then opinion', 'vocab list only', 'copy topic'], 1, 'Discuss both views.', 'Essay.', 'facile'),
      ex('Formal style avoids :', ['clear arguments', 'slang and chat abbreviations', 'examples', 'linkers'], 1, 'Register.', 'Style.', 'facile'),
      ex('Introduction should mainly :', ['give the full conclusion only', 'rephrase the topic and announce the plan', 'tell a joke only', 'list irregular verbs'], 1, 'Lead-in.', 'Structure.', 'intermediaire'),
      ex('« On balance, I believe… » fits best in :', ['the title only', 'the conclusion / personal stance', 'a shopping list', 'a conjugation table'], 1, 'Opinion close.', 'Phrases.', 'intermediaire'),
      ex('Each body paragraph ideally has :', ['no topic sentence', 'a clear idea + explanation/example', 'only one word', 'random quotes without link'], 1, 'Unity.', 'Paragraph.', 'difficile'),
    ],
    quiz: [
      qz('Paraphrase the topic means :', ['copy word for word', 'say the same idea with other words', 'delete the topic', 'translate to Latin only'], 1, 'Rephrase.'),
      qz('Critics point out that… introduces :', ['your shopping', 'an opposing or critical view', 'a phone number', 'a conjugation'], 1, 'Counterpoint.'),
    ],
  },
];

const francaisTermA: TopicData[] = [
  {
    title: 'Littérature : genres, registres et francophonie africaine',
    content:
      "Genres : roman, théâtre, poésie, essai…\nRegistres : tragique, comique, lyrique, satirique, pathétique, épique…\nFrancophonie africaine : oralité, roman, poésie, théâtre (mémoire, identité, forêt, indépendance)\nAu BAC : relier procédé → effet → sens, et situer dans une histoire littéraire.",
    example: 'Un conte gabonais / un roman africain francophone : thème, narrateur, figures de style.',
    keyPoints: ['Genres', 'Registres', 'Oralité', 'Francophonie africaine', 'Procédés'],
    exercise: ex('Le registre lyrique exprime surtout :', ['la seule logique mathématique', 'les sentiments personnels', 'un compte rendu scientifique', 'une recette'], 1, 'Épanchement du moi.', 'Registres.', 'facile'),
    exercises: [
      ex('Registre lyrique :', ['maths pures', 'sentiments personnels', 'compte rendu labo', 'recette'], 1, 'Moi / émotions.', 'Registre.', 'facile'),
      ex('L’oralité africaine inclut surtout :', ['uniquement les équations', 'contes, proverbes, chants', 'le code de la route', 'la comptabilité'], 1, 'Tradition orale.', 'Culture.', 'facile'),
      ex('La francophonie africaine désigne :', ['uniquement Paris', 'l’espace des cultures de langue française en Afrique', 'une province du Canada seule', 'un sport'], 1, 'Francophonie.', 'Culture.', 'intermediaire'),
      ex('Un monologue au théâtre :', ['dialogue à deux obligatoires', 'parole d’un personnage seul sur scène', 'didascalie uniquement', 'titre d’acte'], 1, 'Forme théâtrale.', 'Théâtre.', 'intermediaire'),
      ex('Relier une métaphore à un texte sur la forêt gabonaise :', ['description purement administrative', 'image qui enrichit le sens (beauté, danger, mémoire…)', 'règle de football', 'compte bancaire'], 1, 'Procédé → sens.', 'Analyse.', 'difficile'),
    ],
    quiz: [
      qz('Didascalie :', ['indication scénique non dite par les personnages', 'réplique principale', 'rime riche', 'chapitre de roman'], 0, 'Théâtre.'),
      qz('Un texte argumentatif sur le Gabon peut porter sur :', ['uniquement la conjugaison latine', 'forêt, éducation, vivre ensemble, développement', 'la météo de l’Antarctique seule', 'interdire la description'], 1, 'Enjeux locaux.'),
    ],
  },
  {
    title: 'Dissertation littéraire : méthode BAC A',
    content:
      "Sujet de dissertation : problématiser à partir d’une citation ou d’un libellé sur la littérature.\nPlan possible : dialectique, thématique, ou par œuvres/genres.\nChaque partie : argument de lecture + exemples d’œuvres précis (titres, auteurs, procédés).\nConclusion : bilan + ouverture (autre œuvre, question esthétique, actualité de la littérature).",
    example: '« La littérature doit-elle plaire ou instruire ? » → divertissement / formation / articulations.',
    keyPoints: ['Problématique', 'Plan', 'Exemples d’œuvres', 'Procédés', 'Ouverture'],
    exercise: ex('Dans une dissertation littéraire, les exemples doivent être :', ['vagues (« un livre »)', 'précis (œuvre, auteur, passage/procédé)', 'uniquement des films sans lien', 'des dates isolées'], 1, 'Ancrage textuel.', 'Méthode.', 'facile'),
    exercises: [
      ex('Exemples en dissertation A :', ['vagues', 'précis (œuvre, auteur, procédé)', 'films hors sujet', 'dates seules'], 1, 'Précision.', 'Méthode.', 'facile'),
      ex('Problématiser c’est :', ['recopier le sujet', 'transformer le libellé en question de lecture fertile', 'lister l’alphabet', 'compter les pages'], 1, 'Question directrice.', 'Intro.', 'intermediaire'),
      ex('Un plan thématique organise :', ['uniquement la biographie de l’auteur', 'des angles (thèmes) successifs', 'la météo', 'les notes de musique seules'], 1, 'Thèmes.', 'Plan.', 'intermediaire'),
      ex('L’ouverture de conclusion peut :', ['poser une nouvelle question liée', 'copier l’intro mot à mot', 'insulter le correcteur', 'changer de matière'], 0, 'Élargissement.', 'Conclusion.', 'facile'),
      ex('Un sujet « Pourquoi lire les contes gabonais ? » attend :', ['aucun exemple', 'thèse, arguments, exemples culturels précis', 'une règle de football', 'un théorème'], 1, 'Argumentation ancrée.', 'Méthode.', 'difficile'),
    ],
    quiz: [
      qz('Citation dans le développement :', ['hors sol', 'analysée (procédé → effet → sens)', 'sans guillemets toujours', 'en latin obligatoire'], 1, 'Analyse.'),
      qz('Hors-sujet :', ['répondre à une autre question que celle posée', 'problématiser le libellé', 'citer une œuvre pertinente', 'annoncer un plan'], 0, 'Piège.'),
    ],
  },
];

const philoTermAExtra: TopicData[] = [
  {
    title: 'Le langage et la communication',
    content:
      "Le langage n’est pas un simple outil : il structure la pensée (débats : Sapir-Whorf, critiques).\nSigne : signifiant / signifié (Saussure).\nParole, langue, discours ; performatif (Austin) : dire c’est parfois faire.\nCommunication : bruit, intention, interprétation — malentendus et pouvoir du discours.",
    example: 'Promettre : acte de langage qui engage.',
    keyPoints: ['Signe', 'Langue / parole', 'Performatif', 'Pouvoir du discours'],
    exercise: ex('Un énoncé performatif :', ['décrit seulement le temps', 'accomplit un acte en étant dit (ex. promettre)', 'est toujours faux', 'est un nombre'], 1, 'Austin.', 'Langage.', 'facile'),
    exercises: [
      ex('Performatif :', ['météo seule', 'acte accompli par le dire', 'toujours faux', 'un nombre'], 1, 'Acte de langage.', 'Austin.', 'facile'),
      ex('Chez Saussure, le signe unit :', ['un arbre et une pierre', 'signifiant et signifié', 'deux États', 'deux dates'], 1, 'Signe linguistique.', 'Saussure.', 'intermediaire'),
      ex('Le langage permet surtout :', ['uniquement de manger', 'de signifier, communiquer, penser en société', 'de remplacer l’oxygène', 'd’annuler le temps'], 1, 'Fonctions.', 'Philo.', 'facile'),
      ex('Un malentendu montre que :', ['la communication est toujours transparente', 'l’interprétation joue un rôle', 'les mots n’existent pas', 'la logique est inutile'], 1, 'Interprétation.', 'Communication.', 'intermediaire'),
      ex('Dire « je vous déclare unis » (contexte institutionnel) est :', ['un simple bruit', 'souvent un acte institutionnel / performatif', 'une équation', 'une description botanique'], 1, 'Institution.', 'Performatif.', 'difficile'),
    ],
    quiz: [
      qz('Langue (Saussure) :', ['système social de signes', 'un idiolecte unique sans règles', 'un muscle', 'un climat'], 0, 'Système.'),
      qz('Pouvoir du discours :', ['les mots peuvent classer, exclure, convaincre', 'les mots sont neutres toujours', 'parler est impossible', 'le silence seul existe'], 0, 'Pouvoir.'),
    ],
  },
];

export function getExtra_3e_hg(): Subject {
  return makeSubject('geographie', 'Géographie', 'Map', 'teal', '3e', '3ème', [hg3e[0]]);
}
export function getExtra_3e_histoire_monde(): Subject {
  return makeSubject('histoire', 'Histoire', 'Landmark', 'orange', '3e', '3ème', [hg3e[1]]);
}
export function getExtra_seconde_anglais(): Subject {
  return makeSubject('anglais', 'Anglais', 'Languages', 'red', 'seconde', 'Seconde', anglaisSeconde);
}
export function getExtra_premiere_anglais(): Subject {
  return makeSubject('anglais', 'Anglais', 'Languages', 'red', 'premiere', 'Première', anglaisPremiere);
}
export function getExtra_terminale_anglais(): Subject {
  return makeSubject('anglais', 'Anglais', 'Languages', 'red', 'terminale', 'Terminale', anglaisTerminale);
}
export function getExtra_terminale_francais_A(): Subject {
  return makeSubject('francais', 'Français', 'BookOpen', 'amber', 'terminale-a', 'Terminale A', francaisTermA);
}
export function getExtra_terminale_philo_langage(): Subject {
  return makeSubject('philosophie', 'Philosophie', 'Brain', 'purple', 'terminale-a', 'Terminale A', philoTermAExtra);
}

/** Entry point niveaux collège enrichi v6 */
export function getExtraSubjectsForLevelV6(levelId: string): Subject[] {
  const base = typeof getExtraSubjectsForLevelV5 === 'function' ? getExtraSubjectsForLevelV5(levelId) : [];
  const out = [...base];
  if (levelId === '3e') {
    out.push(getExtra_3e_hg(), getExtra_3e_histoire_monde());
  }
  if (levelId === 'seconde') {
    out.push(getExtra_seconde_anglais());
  }
  return out;
}


export function getExtraForPremiereSeries(seriesName: string): Subject[] {
  const n = seriesName.toLowerCase();
  const out: Subject[] = [getExtra_premiere_philo(), getExtra_premiere_anglais()];
  if (n.includes('c') || n.includes('d') || n.includes('scient')) {
    out.push(getExtra_premiere_pc(), getExtra_premiere_svt());
  }
  return out;
}


// ——— Vague v7 : EPS, EMC, Espagnol, Méthodo BAC ———

const eps3e: TopicData[] = [
  {
    title: 'Condition physique et échauffement',
    content:
      "L’échauffement prépare le corps à l’effort : augmente la température musculaire, lubrifie les articulations, active le système cardio-respiratoire, réduit le risque de blessure.\nPhases typiques : mobilisation articulaire, activation progressive, étirements dynamiques.\nRetour au calme : baisse progressive de l’intensité, hydratation, étirements doux.",
    example: 'Avant un match : 10–15 min d’échauffement (jogging léger, rotations, passes).',
    keyPoints: ['Échauffement', 'Blessures', 'Cardio', 'Retour au calme', 'Hydratation'],
    exercise: ex('Le but principal de l’échauffement est :', ['se fatiguer au maximum', 'préparer le corps et limiter les blessures', 'remplacer le match', 's’asseoir'], 1, 'Préparation + prévention.', 'EPS.', 'facile'),
    exercises: [
      ex('But de l’échauffement :', ['fatigue max', 'préparer / prévenir les blessures', 'remplacer le match', 's’asseoir'], 1, 'Prévention.', 'EPS.', 'facile'),
      ex('Un échauffement efficace dure souvent :', ['2 secondes', 'environ 10–15 minutes', '3 heures sans pause', 'aucun temps'], 1, 'Durée indicative.', 'Méthode.', 'facile'),
      ex('Étirement dynamique plutôt :', ['avant l’effort, en mouvement contrôlé', 'uniquement en dormant', 'après une fracture immédiate sans avis', 'en apnée forcée'], 0, 'Dynamique pré-effort.', 'Étirements.', 'intermediaire'),
      ex('Retour au calme sert à :', ['augmenter brutalement l’intensité', 'redescendre progressivement et récupérer', 'sauter le repas', 'déséchauffer le cerveau seul'], 1, 'Récupération.', 'Fin de séance.', 'intermediaire'),
      ex('Signal d’alerte pendant l’effort :', ['légère transpiration', 'douleur vive / malaise → arrêter et signaler', 'envie de gagner', 'rythme cardiaque un peu plus haut'], 1, 'Sécurité.', 'Santé.', 'difficile'),
    ],
    quiz: [
      qz('Hydratation :', ['inutile sous l’équateur', 'importante avant/pendant/après l’effort', 'réservée aux pro seulement', 'remplace le sommeil'], 1, 'Hydratation.'),
      qz('Fréquence cardiaque à l’effort :', ['diminue toujours', 'augmente pour apporter plus d’O₂', 'reste à 0', 'mesure la taille'], 1, 'Adaptation.'),
    ],
  },
];

const eps4e: TopicData[] = [
  {
    title: 'Règles, fair-play et rôles dans un sport collectif',
    content:
      "Sport collectif : attaque / défense, occupation de l’espace, communication.\nRègles : cadre de sécurité et d’équité ; l’arbitre fait respecter le règlement.\nFair-play : respect adversaires, partenaires, officiel, matériel.\nRôles : joueur, arbitre, observateur, coach — chacun apprend des compétences différentes.",
    example: 'En foot ou basket scolaire : respecter hors-jeu / marches, accepter la décision arbitrale.',
    keyPoints: ['Règles', 'Fair-play', 'Espace', 'Rôles', 'Communication'],
    exercise: ex('Le fair-play c’est surtout :', ['tricher sans se faire prendre', 'respecter règles et personnes', 'insulter l’arbitre', 'refuser de jouer'], 1, 'Respect.', 'EPS.', 'facile'),
    exercises: [
      ex('Fair-play :', ['tricher', 'respect règles et personnes', 'insulter', 'refuser'], 1, 'Respect.', 'Valeurs.', 'facile'),
      ex('L’arbitre :', ['joue attaquant seulement', 'fait respecter le règlement', 'remplace le coach toujours', 'choisit le score final arbitrairement sans règle'], 1, 'Officiel.', 'Règles.', 'facile'),
      ex('En défense on cherche souvent à :', ['ouvrir tous les espaces à l’adversaire', 'réduire les espaces et récupérer le ballon', 'quitter le terrain', 'ignorer le ballon'], 1, 'Principes tactiques.', 'Collectif.', 'intermediaire'),
      ex('Communiquer en sport collectif :', ['inutile', 'appeler, indiquer, encourager, signaler un danger', 'seulement après le match', 'par écrit au tableau'], 1, 'Coopération.', 'Rôles.', 'intermediaire'),
      ex('Accepter une décision arbitrale contestable enseigne :', ['la triche', 'la maîtrise de soi et le respect du cadre', 'l’abandon de tout sport', 'l’absence de règles'], 1, 'Citoyenneté sportive.', 'Fair-play.', 'difficile'),
    ],
    quiz: [
      qz('Rôle d’observateur en EPS :', ['noter des faits de jeu / critères', 'seulement dormir', 'remplacer l’arbitre FIFA', 'changer les règles en secret'], 0, 'Observation.'),
      qz('Sécurité collective :', ['ignorer les chaussures', 'matériel adapté, espaces dégagés, consignes respectées', 'courir dans les poteaux', 'hydratation nulle'], 1, 'Sécurité.'),
    ],
  },
];

const emc3e: TopicData[] = [
  {
    title: 'Citoyenneté, droits et devoirs',
    content:
      "Citoyen : membre d’une communauté politique avec des droits et des devoirs.\nDroits : libertés fondamentales, droit à l’éducation, à la sécurité…\nDevoirs : respecter la loi, les autres, participer à la vie collective (selon l’âge : assiduité scolaire, respect du règlement intérieur…).\nDémocratie : souveraineté du peuple, élections, pluralisme, État de droit.",
    example: 'Au collège : droit d’être respecté / devoir de respecter le règlement et les camarades.',
    keyPoints: ['Citoyen', 'Droits', 'Devoirs', 'Démocratie', 'Loi'],
    exercise: ex('Un citoyen a :', ['seulement des droits', 'des droits et des devoirs', 'aucun cadre', 'uniquement des devoirs sans droits'], 1, 'Droits + devoirs.', 'EMC.', 'facile'),
    exercises: [
      ex('Citoyen :', ['droits seuls', 'droits et devoirs', 'aucun cadre', 'devoirs seuls'], 1, 'Les deux.', 'Citoyenneté.', 'facile'),
      ex('La démocratie repose surtout sur :', ['un seul avis imposé sans élection', 'participation et règles communes', 'l’absence de loi', 'la force seule'], 1, 'Souveraineté populaire / droit.', 'Démocratie.', 'facile'),
      ex('Le règlement intérieur d’un établissement :', ['est optionnel pour tous', 'fixe des règles de vie collective', 'remplace le code pénal entier', 'interdit d’apprendre'], 1, 'Vie scolaire.', 'Devoirs.', 'intermediaire'),
      ex('Respecter la loi c’est :', ['un devoir du citoyen', 'interdit en démocratie', 'réservé aux touristes', 'une option sportive'], 0, 'État de droit.', 'Devoirs.', 'intermediaire'),
      ex('Le pluralisme signifie :', ['une seule opinion autorisée', 'la coexistence d’opinions et partis différents', 'l’absence d’élections', 'la fin de l’école'], 1, 'Démocratie.', 'Pluralisme.', 'difficile'),
    ],
    quiz: [
      qz('Droit à l’éducation :', ['droit fondamental pour les enfants', 'interdit au Gabon', 'réservé aux adultes seulement', 'un sport'], 0, 'Droits.'),
      qz('État de droit :', ['pouvoirs soumis au droit', 'absence totale de règles', 'loi du plus fort', 'anarchie'], 0, 'Principe.'),
    ],
  },
];

const emc5e: TopicData[] = [
  {
    title: 'Vivre ensemble : respect, discrimination, harcèlement',
    content:
      "Respect : considérer la dignité de chacun.\nDiscrimination : traitement défavorable fondé sur un critère illégitime (origine, sexe, religion, handicap…).\nHarcèlement : violences répétées (y compris en ligne) qui isolent et blessent.\nRéagir : dire non, en parler à un adulte de confiance, ne pas diffuser, soutenir la victime.",
    example: 'Moqueries répétées sur l’apparence ou l’origine = harcèlement / discrimination possible.',
    keyPoints: ['Respect', 'Discrimination', 'Harcèlement', 'Solidarité', 'Signalement'],
    exercise: ex('Le harcèlement se caractérise surtout par :', ['un compliment unique', 'des actes répétés qui isolent/blessent', 'un devoir de maths', 'une règle de grammaire'], 1, 'Répétition + nuisance.', 'EMC.', 'facile'),
    exercises: [
      ex('Harcèlement :', ['compliment unique', 'actes répétés nuisibles', 'devoir de maths', 'grammaire'], 1, 'Répétition.', 'Définition.', 'facile'),
      ex('Face au harcèlement, une bonne attitude :', ['rire avec les agresseurs', 'en parler à un adulte / ne pas isoler la victime', 'aggraver en ligne', 'ignorer toujours sans rien faire si on est témoin engagé'], 1, 'Signaler + soutenir.', 'Réagir.', 'intermediaire'),
      ex('Discrimination :', ['égalité de traitement', 'traitement défavorable illégitime', 'sport collectif', 'échauffement'], 1, 'Inégalité illégitime.', 'Droit.', 'facile'),
      ex('Le cyberharcèlement :', ['n’existe pas', 'utilise le numérique pour harceler', 'est un exercice d’EPS', 'est une leçon de fractions'], 1, 'En ligne.', 'Numérique.', 'intermediaire'),
      ex('La dignité humaine implique :', ['qu’on peut humilier librement', 'le respect de chaque personne', 'l’exclusion systématique', 'l’interdiction d’apprendre'], 1, 'Valeur.', 'Respect.', 'difficile'),
    ],
    quiz: [
      qz('Témoin de harcèlement :', ['encourager', 'soutenir la victime et alerter', 'filmer pour humilier', 'participer'], 1, 'Responsabilité.'),
      qz('Égalité ≠ :', ['mêmes droits fondamentaux', 'droit d’humilier autrui', 'accès à l’école', 'respect'], 1, 'Limites.'),
    ],
  },
];

const espagnol5e: TopicData[] = [
  {
    title: 'Saludos, presentaciones y verbos ser / tener',
    content:
      "Saludos: hola, buenos días, buenas tardes, adiós, hasta luego.\nPresentarse: Me llamo… / Soy de… / Tengo … años.\nSer: soy, eres, es, somos, sois, son (identidad, origen).\nTener: tengo, tienes, tiene, tenemos, tenéis, tienen (edad, posesión).",
    example: 'Hola, me llamo Amina, soy de Libreville y tengo doce años.',
    keyPoints: ['Saludos', 'Me llamo', 'Ser', 'Tener', 'Números / edad'],
    exercise: ex('« Me llamo » significa :', ['je mange', 'je m’appelle', 'j’habite', 'j’ai'], 1, 'Présentation.', 'Espagnol.', 'facile'),
    exercises: [
      ex('Me llamo = ', ['je mange', 'je m’appelle', 'j’habite', 'j’ai'], 1, 'Nom.', 'Lexique.', 'facile'),
      ex('Soy de Gabón = ', ['je mange du Gabon', 'je suis du Gabon', 'j’ai le Gabon', 'je cours'], 1, 'Ser + origen.', 'Ser.', 'facile'),
      ex('Tengo 12 años = ', ['je suis 12 ans', 'j’ai 12 ans', 'je vais 12', 'je vois 12'], 1, 'Tener + edad.', 'Tener.', 'facile'),
      ex('Forme de ser pour « él/ella » :', ['soy', 'eres', 'es', 'somos'], 2, 'es.', 'Conjugaison.', 'intermediaire'),
      ex('Buenas noches s’emploie plutôt :', ['le matin tôt', 'le soir / pour dire bonne nuit', 'uniquement à midi', 'jamais'], 1, 'Saludo.', 'Civilité.', 'intermediaire'),
    ],
    quiz: [
      qz('« Hola » = ', ['au revoir', 'bonjour / salut', 'merci', 's’il vous plaît'], 1, 'Saludo.'),
      qz('« ¿Cómo te llamas? » demande :', ['l’âge seulement', 'le prénom', 'l’adresse mail', 'la note de maths'], 1, 'Nom.'),
    ],
  },
];

const espagnol4e: TopicData[] = [
  {
    title: 'Presente de indicativo — verbos regulares',
    content:
      "Tres grupos: -ar (hablar), -er (comer), -ir (vivir).\nHablar: hablo, hablas, habla, hablamos, habláis, hablan.\nComer: como, comes, come, comemos, coméis, comen.\nVivir: vivo, vives, vive, vivimos, vivís, viven.\nNegación: no + verbo. Interrogación: ¿…?",
    example: 'Hablo francés y como fruta. ¿Vives en Port-Gentil?',
    keyPoints: ['-ar -er -ir', 'Presente', 'Negación', 'Interrogación'],
    exercise: ex('Yo ___ español (hablar).', ['hablo', 'hablas', 'habla', 'hablamos'], 0, 'yo → hablo.', 'Presente.', 'facile'),
    exercises: [
      ex('Yo ___ español (hablar)', ['hablo', 'hablas', 'habla', 'hablamos'], 0, 'hablo.', 'AR.', 'facile'),
      ex('Ella ___ arroz (comer)', ['como', 'comes', 'come', 'comemos'], 2, 'come.', 'ER.', 'facile'),
      ex('Nosotros ___ en Libreville (vivir)', ['vivo', 'vives', 'vive', 'vivimos'], 3, 'vivimos.', 'IR.', 'intermediaire'),
      ex('Negation: « Je ne parle pas »', ['No hablo', 'Hablo no', 'No hablar', 'Hablo sí'], 0, 'no + verbo.', 'Negación.', 'intermediaire'),
      ex('¿___ tú fútbol? (jugar → irreg. but pattern question)', ['Juego', 'Juegas', 'Juega', 'Jugamos'], 1, 'tú → juegas (irregular jugar).', 'Question.', 'difficile'),
    ],
    quiz: [
      qz('Terminaison « yo » des réguliers -ar :', ['-o', '-as', '-a', '-amos'], 0, '-o.'),
      qz('¿Cómo estás? = ', ['Comment tu t’appelles ?', 'Comment vas-tu ?', 'Où habites-tu ?', 'Quel âge as-tu ?'], 1, 'Forme.'),
    ],
  },
];

const methodoBac: TopicData[] = [
  {
    title: 'Méthodologie BAC : gérer l’épreuve écrite',
    content:
      "Avant : dormir, matériel, connaître le format (coefficients, durée).\nPendant : lire tout le sujet, choisir (si choix), horodater, brouillon structuré, écrire lisible, soigner l’orthographe.\nDissertation : problématique + plan annoncé + parties équilibrées + exemples.\nSciences : lire l’énoncé entier, ordonner les questions, justifier, application numérique avec unités.\nFin : se relire 10 minutes (accords, calculs, oubli de question).",
    example: 'Sur 4 h : 15 min lecture/plan, 3 h rédaction, 20–30 min relecture.',
    keyPoints: ['Gestion du temps', 'Brouillon', 'Problématique', 'Justifications', 'Relecture'],
    exercise: ex('En début d’épreuve, le plus utile est souvent :', ['écrire sans lire', 'lire le sujet en entier et organiser son temps', 'dormir', 'changer de salle'], 1, 'Lecture + plan.', 'Méthodo.', 'facile'),
    exercises: [
      ex('Début d’épreuve :', ['écrire sans lire', 'lire et organiser le temps', 'dormir', 'changer de salle'], 1, 'Organisation.', 'BAC.', 'facile'),
      ex('Une problématique sert à :', ['décorer', 'guider le devoir par une question claire', 'remplacer les exemples', 'compter les mots seulement'], 1, 'Question directrice.', 'Dissertation.', 'facile'),
      ex('En sciences, oublier les unités :', ['est recommandé', 'fait souvent perdre des points', 'double la note', 'est obligatoire'], 1, 'Rigueur.', 'Sciences.', 'intermediaire'),
      ex('Le brouillon sert à :', ['être illisible pour le correcteur final', 'structurer idées / calculs avant la copie', 'remplacer la copie', 'dessiner seulement'], 1, 'Préparation.', 'Méthode.', 'intermediaire'),
      ex('Relire en fin d’épreuve permet surtout de :', ['découvrir un nouveau sujet hors temps', 'corriger accords, calculs, oublis', 'annuler le coefficient', 'changer d’examen'], 1, 'Relecture.', 'Stratégie.', 'difficile'),
    ],
    quiz: [
      qz('Choisir un sujet (quand il y a choix) selon :', ['le plus long texte seulement', 'celui qu’on maîtrise le mieux', 'le voisin', 'au hasard sans lire'], 1, 'Maîtrise.'),
      qz('Annoncer le plan en introduction :', ['interdit', 'aide le correcteur à suivre', 'remplace le développement', 'est une faute'], 1, 'Clarté.'),
    ],
  },
  {
    title: 'Méthodologie BAC : oral et stress',
    content:
      "Oral : saluer, présenter le plan, parler distinctement, regarder le jury, gérer le temps de préparation.\nSi blanc : reformuler la question, revenir au plan, exemple simple.\nStress : respiration lente, phrases courtes, acceptance d’un trac modéré (alerte positive).\nAprès une erreur : corriger calmement plutôt que s’excuser longuement.",
    example: 'Préparation 20 min : 5 min idées, 10 min plan détaillé, 5 min accroche + conclusion.',
    keyPoints: ['Plan oral', 'Élocution', 'Respiration', 'Gestion d’erreur', 'Temps'],
    exercise: ex('En cas de trou de mémoire à l’oral :', ['rester silencieux 10 min', 'reformuler et revenir au plan / exemple', 'quitter la salle aussitôt', 'parler d’un autre examen'], 1, 'Stratégie.', 'Oral.', 'facile'),
    exercises: [
      ex('Trou de mémoire :', ['silence long', 'reformuler + plan/exemple', 'partir', 'changer d’examen'], 1, 'Rebond.', 'Oral.', 'facile'),
      ex('Le trac modéré :', ['est toujours une catastrophe', 'peut aider à être concentré s’il est géré', 'interdit de parler', 'annule la note'], 1, 'Stress utile.', 'Gestion.', 'intermediaire'),
      ex('Respiration lente avant d’entrer :', ['aggrave forcément', 'aide souvent à calmer le rythme cardiaque', 'remplace la révision', 'est ridicule et inutile toujours'], 1, 'Ancrage.', 'Stress.', 'facile'),
      ex('À l’oral, un plan clair permet au jury de :', ['s’ennuyer', 'suivre et évaluer l’organisation', 'dormir', 'changer le sujet en secret'], 1, 'Organisation.', 'Jury.', 'intermediaire'),
      ex('Corriger une erreur à voix haute :', ['est interdit', 'montre de la maîtrise si c’est fait calmement', 'annule toute la prestation', 'oblige à recommencer l’année'], 1, 'Correction.', 'Attitude.', 'difficile'),
    ],
    quiz: [
      qz('Saluer le jury :', ['inutile', 'marque de respect et de sérieux', 'fait perdre des points', 'est une faute'], 1, 'Posture.'),
      qz('Préparation écrite à l’oral sert à :', ['lire mot à mot tout le temps sans lever les yeux', 'structurer sans coller au papier', 'remplacer la parole', 'dessiner seulement'], 1, 'Support.'),
    ],
  },
];

export function getExtra_3e_eps(): Subject {
  return makeSubject('eps', 'EPS', 'Activity', 'lime', '3e', '3ème', eps3e);
}
export function getExtra_4e_eps(): Subject {
  return makeSubject('eps', 'EPS', 'Activity', 'lime', '4e', '4ème', eps4e);
}
export function getExtra_3e_emc(): Subject {
  return makeSubject('emc', 'EMC', 'Scale', 'slate', '3e', '3ème', emc3e);
}
export function getExtra_5e_emc(): Subject {
  return makeSubject('emc', 'EMC', 'Scale', 'slate', '5e', '5ème', emc5e);
}
export function getExtra_5e_espagnol(): Subject {
  return makeSubject('espagnol', 'Espagnol', 'Languages', 'rose', '5e', '5ème', espagnol5e);
}
export function getExtra_4e_espagnol(): Subject {
  return makeSubject('espagnol', 'Espagnol', 'Languages', 'rose', '4e', '4ème', espagnol4e);
}
export function getExtra_methodo_bac(): Subject {
  return makeSubject('methodologie', 'Méthodologie BAC', 'BookMarked', 'fuchsia', 'terminale', 'Terminale', methodoBac);
}

export function getExtraSubjectsForLevelV7(levelId: string): Subject[] {
  const base = getExtraSubjectsForLevelV6(levelId);
  const out = [...base];
  if (levelId === '3e') {
    out.push(getExtra_3e_eps(), getExtra_3e_emc());
  }
  if (levelId === '4e') {
    out.push(getExtra_4e_eps(), getExtra_4e_espagnol());
  }
  if (levelId === '5e') {
    out.push(getExtra_5e_emc(), getExtra_5e_espagnol());
  }
  return out;
}
