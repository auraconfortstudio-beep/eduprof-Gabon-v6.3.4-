/**
 * Contenus pédagogiques ancrés Gabon — EduProf
 * Géographie, histoire, EMC, environnement, culture : exemples et repères locaux.
 * Originaux EduProf (non officiels) ; alignés sur les enjeux scolaires gabonais.
 */
import { makeSubject, type Subject, type TopicData, type TopicExercise } from './types';

function ex(
  q: string,
  opts: string[],
  ans: number,
  exp: string,
  method: string,
  difficulty: 'facile' | 'intermediaire' | 'difficile' = 'intermediaire'
): TopicExercise {
  return { q, opts, ans, exp, method, difficulty };
}
function qz(q: string, opts: string[], ans: number, exp: string) {
  return { q, opts, ans, exp };
}

const geoGabonCm2: TopicData[] = [
  {
    title: 'Le Gabon : mon pays sur la carte',
    content:
      "Le Gabon est un pays d’Afrique centrale, traversé par l’équateur.\nCapitale : Libreville (Estuaire). Autres villes importantes : Port-Gentil (Ogooué-Maritime), Franceville (Haut-Ogooué), Oyem (Woleu-Ntem).\nPays frontaliers : Cameroun, Guinée équatoriale, République du Congo.\nFaçade maritime : océan Atlantique.\nLe pays est divisé en provinces (ex. Estuaire, Haut-Ogooué, Ngounié, Nyanga, Ogooué-Ivindo, Ogooué-Lolo, Ogooué-Maritime, Woleu-Ntem, Moyen-Ogooué).",
    example: 'Libreville se trouve sur l’estuaire du Komo, au bord de l’Atlantique.',
    keyPoints: ['Afrique centrale', 'Libreville', 'Provinces', 'Frontières', 'Atlantique'],
    exercise: ex('La capitale du Gabon est :', ['Port-Gentil', 'Franceville', 'Libreville', 'Oyem'], 2, 'Libreville.', 'Repère.', 'facile'),
    exercises: [
      ex('Capitale du Gabon :', ['Port-Gentil', 'Franceville', 'Libreville', 'Oyem'], 2, 'Libreville.', 'Géo.', 'facile'),
      ex('Océan qui baigne le Gabon :', ['Indien', 'Atlantique', 'Pacifique', 'Arctique'], 1, 'Atlantique.', 'Façade.', 'facile'),
      ex('Pays frontalier du Gabon :', ['Nigeria', 'Cameroun', 'Ghana', 'Sénégal'], 1, 'Cameroun (entre autres).', 'Frontières.', 'facile'),
      ex('Port-Gentil se situe surtout dans la province :', ['Woleu-Ntem', 'Ogooué-Maritime', 'Haut-Ogooué', 'Nyanga'], 1, 'Ogooué-Maritime.', 'Provinces.', 'intermediaire'),
      ex('L’équateur traverse :', ['seulement l’Europe', 'le Gabon (Afrique centrale)', 'uniquement le Canada', 'l’Antarctique habité'], 1, 'Position.', 'Climat/latitude.', 'intermediaire'),
    ],
    quiz: [
      qz('Franceville est associée au :', ['Haut-Ogooué', 'désert du Sahara', 'Pôle Nord', 'Europe'], 0, 'Province.'),
      qz('Le Komo est lié à :', ['Libreville / estuaire', 'un volcan d’Asie', 'un glacier', 'un désert'], 0, 'Hydrologie locale.'),
    ],
  },
];

const geoGabonCollege: TopicData[] = [
  {
    title: 'Ressources et environnement au Gabon',
    content:
      "Ressources : pétrole (important pour l’économie), manganèse, fer, bois tropicaux, biodiversité forestière et marine.\nForêt du bassin du Congo : le Gabon en conserve une part majeure ; parcs nationaux (ex. Lopé, Ivindo, Moukalaba-Doudou…).\nEnjeux : diversification économique, gestion durable des forêts, urbanisation de Libreville et Port-Gentil, pollution, emploi des jeunes.\nDéveloppement durable : exploiter les richesses sans détruire le patrimoine pour les générations futures.",
    example: 'Le parc de la Lopé illustre la coexistence forêt / savane et le patrimoine mondial.',
    keyPoints: ['Pétrole', 'Bois', 'Parcs nationaux', 'Bassin du Congo', 'Développement durable'],
    exercise: ex('Une ressource majeure de l’économie gabonaise :', ['blé nordique', 'pétrole', 'banquise', 'charbon polaire'], 1, 'Hydrocarbures.', 'Économie.', 'facile'),
    exercises: [
      ex('Ressource majeure :', ['blé nordique', 'pétrole', 'banquise', 'charbon polaire'], 1, 'Pétrole.', 'Éco.', 'facile'),
      ex('Le bassin du Congo est surtout :', ['un désert', 'un massif forestier d’Afrique centrale', 'une mer intérieure', 'une chaîne alpine'], 1, 'Forêt.', 'Environnement.', 'facile'),
      ex('Un enjeu du développement durable au Gabon :', ['couper toute la forêt sans plan', 'concilier exploitation et conservation', 'interdire toute école', 'abandonner les ports'], 1, 'Équilibre.', 'DD.', 'intermediaire'),
      ex('Port-Gentil est historiquement lié à :', ['l’industrie pétrolière / le port', 'un glacier', 'la culture du blé seul', 'l’absence de mer'], 0, 'Littoral économique.', 'Villes.', 'intermediaire'),
      ex('Parcs nationaux gabonais servent surtout à :', ['remplacer les villes', 'protéger biodiversité et paysages', 'extraire le pétrole uniquement', 'interdire le tourisme durable'], 1, 'Conservation.', 'Parcs.', 'difficile'),
    ],
    quiz: [
      qz('Manganèse au Gabon :', ['ressource minière importante', 'un type de poisson seulement', 'un climat', 'une province inexistante'], 0, 'Mine.'),
      qz('Diversification économique vise à :', ['dépendre d’une seule ressource', 'développer plusieurs secteurs', 'fermer les écoles', 'quitter l’Afrique'], 1, 'Stratégie.'),
    ],
  },
];

const histGabon: TopicData[] = [
  {
    title: 'Repères d’histoire du Gabon',
    content:
      "Peuples et royaumes / sociétés précoloniales sur le territoire (migrations bantu, réseaux commerciaux).\nPériode coloniale : présence française ; Libreville fondée au XIXe siècle (nom lié à des captifs libérés).\nIndépendance : 17 août 1960.\nAprès 1960 : construction de l’État, urbanisation, économie des hydrocarbures, place dans l’Afrique centrale et les organisations internationales.\nMémoire : figures et dates à situer dans le programme d’histoire-géographie / EMC local.",
    example: 'Fête nationale : 17 août — indépendance du Gabon.',
    keyPoints: ['Précolonial', 'Libreville', '17 août 1960', 'État indépendant', 'Afrique centrale'],
    exercise: ex('Date de l’indépendance du Gabon :', ['14 juillet 1789', '17 août 1960', '1er janvier 2000', '11 novembre 1918'], 1, '17 août 1960.', 'Repère.', 'facile'),
    exercises: [
      ex('Indépendance du Gabon :', ['1789', '17 août 1960', '2000', '1918'], 1, '1960.', 'Chronologie.', 'facile'),
      ex('Libreville tire son nom d’un contexte lié à :', ['un volcan', 'des captifs libérés / fondation au XIXe s.', 'un glacier', 'une bataille de 1945 en Europe seule'], 1, 'Toponymie.', 'Ville.', 'intermediaire'),
      ex('Le Gabon indépendant se situe dans :', ['l’Union européenne comme État membre fondateur', 'l’Afrique centrale', 'l’Amérique du Sud', 'l’Océanie'], 1, 'Géopolitique.', 'Situation.', 'facile'),
      ex('Après 1960, une transformation majeure :', ['disparition totale des villes', 'urbanisation et économie des hydrocarbures', 'retour au Paléolithique', 'fin de toute école'], 1, 'XXe s.', 'Mutations.', 'intermediaire'),
      ex('Étudier l’histoire du Gabon permet surtout de :', ['ignorer le présent', 'comprendre la société et les institutions d’aujourd’hui', 'remplacer les maths', 'apprendre uniquement l’histoire de la Chine'], 1, 'Sens de la discipline.', 'Finalités.', 'difficile'),
    ],
    quiz: [
      qz('17 août au Gabon :', ['fête nationale / indépendance', 'Noël', 'un jour sans nom', 'un match obligatoire'], 0, 'Mémoire.'),
      qz('Période coloniale au Gabon liée surtout à :', ['la France', 'le Japon médiéval', 'l’Empire inca', 'la Russie seule'], 0, 'Histoire.'),
    ],
  },
];

const emcGabon: TopicData[] = [
  {
    title: 'Institutions et vie civique au Gabon',
    content:
      "L’élève gabonais vit dans un État de droit : Constitution, lois, institutions de la République.\nRepères : Président de la République, Gouvernement, Parlement (Assemblée nationale / Sénat selon l’organisation en vigueur), justice.\nAu quotidien : règlement de l’école, respect d’autrui, participation (délégués, clubs, service à la communauté).\nSymboles : drapeau tricolore (vert, jaune, bleu), hymne « La Concorde », devise et armoiries à connaître selon le programme EMC.",
    example: 'Le vert évoque la forêt ; le jaune l’équateur / la richesse ; le bleu la mer.',
    keyPoints: ['Constitution', 'Institutions', 'Symboles', 'École', 'Citoyenneté'],
    exercise: ex('Les couleurs du drapeau gabonais sont :', ['rouge blanc bleu', 'vert jaune bleu', 'noir jaune rouge', 'vert rouge blanc'], 1, 'Vert, jaune, bleu.', 'Symboles.', 'facile'),
    exercises: [
      ex('Drapeau du Gabon :', ['rouge blanc bleu', 'vert jaune bleu', 'noir jaune rouge', 'vert rouge blanc'], 1, 'V-J-B.', 'Symboles.', 'facile'),
      ex('L’hymne national du Gabon est :', ['La Marseillaise', 'La Concorde', 'Nkosi Sikelel’', 'God Save the King'], 1, 'La Concorde.', 'Symboles.', 'facile'),
      ex('À l’école, le délégué de classe :', ['remplace le chef de l’État', 'représente les élèves et fait le lien avec l’équipe éducative', 'écrit les lois du pays', 'dirige l’armée'], 1, 'Vie scolaire.', 'Participation.', 'intermediaire'),
      ex('L’État de droit signifie surtout que :', ['personne n’obéit à la loi', 'les pouvoirs et les citoyens sont soumis au droit', 'la force prime toujours', 'il n’y a pas d’institutions'], 1, 'Principe.', 'EMC.', 'intermediaire'),
      ex('Connaître la Constitution aide à :', ['seulement réciter sans comprendre', 'comprendre l’organisation des pouvoirs et les droits', 'remplacer l’histoire', 'ignorer les devoirs'], 1, 'Civisme.', 'Institutions.', 'difficile'),
    ],
    quiz: [
      qz('Vert du drapeau évoque souvent :', ['la forêt / la nature', 'le désert polaire', 'un volcan d’Europe', 'la neige'], 0, 'Symbolique.'),
      qz('Respecter le règlement intérieur :', ['devoir de l’élève', 'interdit', 'réservé aux visiteurs', 'option sportive'], 0, 'Devoirs.'),
    ],
  },
];

const frGabon: TopicData[] = [
  {
    title: 'Lire le monde depuis le Gabon : textes et oralité',
    content:
      "La littérature et l’oralité d’Afrique centrale nourrissent la culture gabonaise : contes, proverbes, chants, romans et poésie d’auteurs d’Afrique francophone.\nÀ l’école : analyser un récit, un poème ou un article en le reliant à des réalités locales (ville, forêt, famille, école, migrations).\nCompétences : repérer thème, point de vue, figures de style ; produire un texte argumentatif sur un enjeu gabonais (environnement, éducation, vivre ensemble).\nAttention : citer correctement ; ne pas inventer de fausses attributions d’œuvres.",
    example: 'Sujet possible : « Pourquoi protéger la forêt gabonaise ? » — arguments écologiques, économiques, culturels.',
    keyPoints: ['Oralité', 'Francophonie', 'Thème local', 'Argumentation', 'Citation'],
    exercise: ex('Un proverbe relève surtout de :', ['la seule chimie', 'l’oralité et la sagesse populaire', 'la géométrie', 'la comptabilité'], 1, 'Tradition orale.', 'Culture.', 'facile'),
    exercises: [
      ex('Proverbe :', ['chimie', 'oralité / sagesse', 'géométrie', 'compta'], 1, 'Oralité.', 'Culture.', 'facile'),
      ex('Argumenter sur la forêt gabonaise peut mobiliser :', ['aucun fait', 'biodiversité, climat, ressources, emplois', 'uniquement la conjugaison latine', 'la météo de l’Antarctique seule'], 1, 'Enjeux locaux.', 'Argumentation.', 'intermediaire'),
      ex('Francophonie :', ['uniquement la France hexagonale', 'espace des langues et cultures de langue française, y compris en Afrique', 'une province du Gabon', 'un sport'], 1, 'Espace linguistique.', 'Culture.', 'facile'),
      ex('Dans un commentaire, un exemple gabonais bien choisi :', ['est hors sujet par nature', 'ancre l’analyse dans le réel de l’élève', 'remplace toute lecture du texte', 'est interdit'], 1, 'Ancrage.', 'Méthode.', 'intermediaire'),
      ex('Produire un texte sur « vivre ensemble à Libreville » exige :', ['des insultes', 'thèse, arguments, exemples précis, respect d’autrui', 'copier un sujet de physique', 'ignorer la ponctuation'], 1, 'Écrit argumentatif.', 'Production.', 'difficile'),
    ],
    quiz: [
      qz('Oralité :', ['transmission par la parole (contes, proverbes…)', 'uniquement l’imprimerie européenne', 'un calcul', 'une équation'], 0, 'Culture.'),
      qz('Citer une œuvre :', ['inventer l’auteur', ' indiquer auteur / titre avec exactitude', 'ne jamais nommer', 'remplacer par une pub'], 1, 'Honnêteté intellectuelle.'),
    ],
  },
];

const svtGabon: TopicData[] = [
  {
    title: 'Biodiversité et forêt gabonaise',
    content:
      "Biodiversité : diversité des espèces, des gènes et des écosystèmes.\nForêt dense humide du Gabon : arbres de canopée, sous-bois, interactions (pollinisation, chaînes alimentaires).\nMenaces : déforestation localisée, braconnage, pollution, changement climatique.\nGestes : respect des parcs, réduction du gaspillage, information, projets scolaires d’éducation à l’environnement.",
    example: 'Observer un écosystème forestier : producteurs (plantes), consommateurs, décomposeurs.',
    keyPoints: ['Biodiversité', 'Écosystème forestier', 'Menaces', 'Parcs', 'Éco-gestes'],
    exercise: ex('La biodiversité désigne :', ['une seule espèce', 'la diversité du vivant', 'un type de roche', 'un vent'], 1, 'Diversité du vivant.', 'SVT.', 'facile'),
    exercises: [
      ex('Biodiversité :', ['une espèce', 'diversité du vivant', 'roche', 'vent'], 1, 'Diversité.', 'Définition.', 'facile'),
      ex('Dans une forêt, les plantes vertes sont surtout :', ['consommateurs tertiaires', 'producteurs (photosynthèse)', 'décomposeurs exclusifs', 'prédateurs de mammifères'], 1, 'Producteurs.', 'Écosystème.', 'facile'),
      ex('Une menace pour la forêt gabonaise :', ['la photosynthèse', 'déforestation / braconnage / pollution', 'la pluie équatoriale', 'la biodiversité elle-même'], 1, 'Pressions.', 'Menaces.', 'intermediaire'),
      ex('Un parc national vise surtout à :', ['augmenter le braconnage', 'protéger milieux et espèces', 'remplacer Libreville', 'interdire toute recherche'], 1, 'Conservation.', 'Parcs.', 'intermediaire'),
      ex('Chaîne alimentaire forestière typique commence par :', ['un lion seul sans plantes', 'des producteurs végétaux', 'un carburant', 'un ordinateur'], 1, 'Producteurs.', 'Chaînes.', 'difficile'),
    ],
    quiz: [
      qz('Photosynthèse :', ['plante utilise lumière pour produire matière organique', 'animal produit du pétrole', 'roche fond', 'élève dort'], 0, 'Producteurs.'),
      qz('Éducation à l’environnement à l’école :', ['inutile au Gabon', 'aide à comprendre et protéger le milieu de vie', 'remplace toutes les matières', 'interdit les sciences'], 1, 'Citoyenneté.'),
    ],
  },
];

const pcGabon: TopicData[] = [
  {
    title: 'Énergie au quotidien au Gabon',
    content:
      "Formes d’énergie : chimique (pétrole, biomasse), électrique (réseau, groupes), thermique, mécanique…\nRessource nationale : hydrocarbures ; enjeux de transition (efficacité, renouvelables possibles : solaire, hydraulique selon sites).\nSécurité : installation électrique domestique, risques d’incendie, bon usage des appareils.\nUnités : joule, wattheure ; puissance vs énergie.",
    example: 'Éteindre les lumières et débrancher chargeurs limite le gaspillage d’électricité à la maison à Libreville comme ailleurs.',
    keyPoints: ['Formes d’énergie', 'Hydrocarbures', 'Électricité', 'Sécurité', 'Économies d’énergie'],
    exercise: ex('Le pétrole est surtout une énergie de type :', ['nucléaire pure', 'chimique fossile', 'solaire directe', 'éolienne'], 1, 'Combustible fossile.', 'Énergie.', 'facile'),
    exercises: [
      ex('Pétrole :', ['nucléaire', 'chimique fossile', 'solaire direct', 'éolien'], 1, 'Fossile.', 'PC.', 'facile'),
      ex('Économiser l’électricité à la maison :', ['laisser tout allumé', 'éteindre / débrancher inutile', 'doubler les climatiseurs ouverts sans besoin', 'couper les disjoncteurs des voisins'], 1, 'Gestes.', 'Citoyenneté.', 'facile'),
      ex('Puissance électrique se mesure en :', ['mètres', 'watts (W)', 'litres', 'degrés Celsius seulement'], 1, 'Watt.', 'Unités.', 'intermediaire'),
      ex('Risque électrique domestique :', ['toucher une installation endommagée sous tension', 'lire un livre', 'marcher dans la cour', 'boire de l’eau'], 0, 'Sécurité.', 'Prévention.', 'intermediaire'),
      ex('Transition énergétique au Gabon pose la question de :', ['ignorer toute ressource', 'diversifier et utiliser mieux l’énergie', 'interdire l’école', 'supprimer l’Atlantique'], 1, 'Enjeux nationaux.', 'Société.', 'difficile'),
    ],
    quiz: [
      qz('Énergie vs puissance :', ['puissance = débit d’énergie / temps', 'identiques toujours', 'puissance est une longueur', 'énergie se mesure en amperes seulement'], 0, 'Grandeurs.'),
      qz('Biomasse :', ['matière organique utilisable énergétiquement (bois…)', 'un alliage d’acier uniquement', 'un gaz noble', 'un type de pile nucléaire'], 0, 'Local.'),
    ],
  },
];

const anglaisGabon: TopicData[] = [
  {
    title: 'Talking about Gabon in English',
    content:
      "Key facts: Gabon is in Central Africa. The capital is Libreville. It is on the Atlantic coast. Official language: French. Natural resources: oil, timber, manganese. Much of the country is covered by rainforest.\nUseful sentences:\n- Gabon is located in Central Africa.\n- Libreville is the capital city.\n- The official language is French.\n- The rainforest is rich in biodiversity.",
    example: 'My country is Gabon. I live in Libreville. It is hot and humid near the coast.',
    keyPoints: ['Location', 'Capital', 'Language', 'Rainforest', 'Resources'],
    exercise: ex('The capital of Gabon is :', ['Port-Gentil', 'Libreville', 'Oyem', 'Franceville'], 1, 'Libreville.', 'Facts.', 'facile'),
    exercises: [
      ex('Capital of Gabon :', ['Port-Gentil', 'Libreville', 'Oyem', 'Franceville'], 1, 'Libreville.', 'Vocab.', 'facile'),
      ex('Gabon is in :', ['Southern Europe', 'Central Africa', 'East Asia', 'North America'], 1, 'Central Africa.', 'Geography.', 'facile'),
      ex('Official language of Gabon :', ['only English', 'French', 'only Spanish', 'only Mandarin'], 1, 'French.', 'Language.', 'facile'),
      ex('“Rainforest” in this context refers to :', ['a desert', 'dense tropical forest', 'a glacier', 'a shopping mall'], 1, 'Forêt dense.', 'Vocab.', 'intermediaire'),
      ex('Complete: Gabon ___ on the Atlantic coast.', ['is located / lies', 'are', 'be', 'going'], 0, 'is located / lies.', 'Grammar.', 'intermediaire'),
    ],
    quiz: [
      qz('Oil is a :', ['natural resource', 'type of school subject only', 'province name only', 'dance'], 0, 'Resource.'),
      qz('“Biodiversity” means :', ['variety of living things', 'only one animal', 'a car brand', 'a verb tense'], 0, 'Science vocab.'),
    ],
  },
];


// ——— Vague + : densification pédagogique gabonaise ———

const histGabonPlus: TopicData[] = [
  {
    title: 'Les provinces du Gabon et leur identité',
    content:
      "Le Gabon compte neuf provinces : Estuaire (Libreville), Haut-Ogooué (Franceville), Moyen-Ogooué (Lambaréné), Ngounié (Mouila), Nyanga (Tchibanga), Ogooué-Ivindo (Makokou), Ogooué-Lolo (Koulamoutou), Ogooué-Maritime (Port-Gentil), Woleu-Ntem (Oyem).\nChaque province a des particularités : littoral et port à Ogooué-Maritime, forêt dense à l’est, zone frontalière au nord (Woleu-Ntem).\nConnaître les provinces aide à situer l’actualité, les déplacements et les enjeux de développement.",
    example: 'Port-Gentil = Ogooué-Maritime ; Franceville = Haut-Ogooué ; Oyem = Woleu-Ntem.',
    keyPoints: ['9 provinces', 'Chefs-lieux', 'Estuaire', 'Ogooué-Maritime', 'Haut-Ogooué'],
    exercise: ex('Combien de provinces le Gabon compte-t-il ?', ['5', '7', '9', '12'], 2, 'Neuf provinces.', 'Géo-admin.', 'facile'),
    exercises: [
      ex('Nombre de provinces :', ['5', '7', '9', '12'], 2, '9 provinces.', 'Admin.', 'facile'),
      ex('Chef-lieu du Haut-Ogooué :', ['Oyem', 'Franceville', 'Mouila', 'Tchibanga'], 1, 'Franceville.', 'Provinces.', 'facile'),
      ex('Port-Gentil se trouve en :', ['Woleu-Ntem', 'Ogooué-Maritime', 'Nyanga', 'Ngounié'], 1, 'Ogooué-Maritime.', 'Littoral.', 'facile'),
      ex('Oyem est le chef-lieu de :', ['Estuaire', 'Woleu-Ntem', 'Ogooué-Ivindo', 'Moyen-Ogooué'], 1, 'Woleu-Ntem.', 'Nord.', 'intermediaire'),
      ex('Lambaréné est associée au :', ['Haut-Ogooué', 'Moyen-Ogooué', 'Nyanga', 'Estuaire'], 1, 'Moyen-Ogooué.', 'Intérieur.', 'intermediaire'),
    ],
    quiz: [
      qz('Makokou est chef-lieu de :', ['Ogooué-Ivindo', 'Estuaire', 'Nyanga', 'Ngounié'], 0, 'Est forestier.'),
      qz('Tchibanga est en :', ['Nyanga', 'Estuaire', 'Haut-Ogooué', 'Woleu-Ntem'], 0, 'Sud.'),
    ],
  },
  {
    title: 'Symboles de la République gabonaise',
    content:
      "Drapeau : trois bandes horizontales vert, jaune, bleu.\nVert : forêts ; jaune : soleil / équateur / richesses ; bleu : mer.\nHymne : « La Concorde ».\nDevise et armoiries rappellent l’unité et le travail.\nLe 17 août est la fête nationale (indépendance 1960).",
    example: 'À l’école, on apprend l’hymne et le sens des couleurs du drapeau.',
    keyPoints: ['Vert-jaune-bleu', 'La Concorde', '17 août', 'Forêt / mer / soleil'],
    exercise: ex('L’hymne national du Gabon est :', ['La Marseillaise', 'La Concorde', 'Nkosi Sikelel’', 'L’Internationale'], 1, 'La Concorde.', 'Symboles.', 'facile'),
    exercises: [
      ex('Hymne du Gabon :', ['La Marseillaise', 'La Concorde', 'Nkosi Sikelel’', 'God Save the King'], 1, 'La Concorde.', 'Civisme.', 'facile'),
      ex('Le vert du drapeau évoque surtout :', ['la banquise', 'la forêt', 'le désert', 'un volcan'], 1, 'Forêt.', 'Symboles.', 'facile'),
      ex('Le bleu du drapeau évoque surtout :', ['la mer', 'le sable', 'la neige', 'le feu'], 0, 'Atlantique.', 'Symboles.', 'facile'),
      ex('Fête nationale :', ['1er janvier', '17 août', '25 décembre', '14 juillet'], 1, 'Indépendance.', 'Mémoire.', 'facile'),
      ex('Le jaune peut évoquer :', ['uniquement la guerre', 'soleil / équateur / richesses', 'la glace', 'l’absence de ressources'], 1, 'Symbolique.', 'Culture.', 'intermediaire'),
    ],
    quiz: [
      qz('Ordre des couleurs (haut → bas) :', ['bleu-jaune-vert', 'vert-jaune-bleu', 'jaune-vert-bleu', 'rouge-blanc-bleu'], 1, 'V-J-B.'),
      qz('17 août 1960 :', ['indépendance', 'fondation de Rome', 'fin de la Préhistoire', 'Noël'], 0, 'Repère.'),
    ],
  },
  {
    title: 'De la colonisation à l’État indépendant',
    content:
      "Au XIXe siècle, la présence coloniale française s’affirme sur le territoire ; Libreville est fondée dans ce contexte.\nLe XXe siècle voit l’organisation coloniale, puis la vague de décolonisation africaine.\nLe 17 août 1960, le Gabon devient un État souverain.\nDepuis : institutions républicaines, urbanisation, économie des hydrocarbures, place en Afrique centrale.",
    example: 'Comprendre 1960 permet de relier passé colonial et République actuelle.',
    keyPoints: ['Colonisation', 'Libreville', '17 août 1960', 'Souveraineté', 'Afrique centrale'],
    exercise: ex('Le Gabon devient indépendant en :', ['1958', '1960', '1967', '1990'], 1, '1960.', 'Chronologie.', 'facile'),
    exercises: [
      ex('Indépendance :', ['1958', '1960', '1967', '1990'], 1, '1960.', 'Histoire.', 'facile'),
      ex('Puissance coloniale principale au Gabon :', ['Portugal seul', 'France', 'Japon', 'Brésil'], 1, 'France.', 'Cadre.', 'facile'),
      ex('Libreville est fondée dans un contexte :', ['préhistorique uniquement', 'XIXe s. / période coloniale', 'an 2000', 'Empire romain'], 1, 'XIXe s.', 'Ville.', 'intermediaire'),
      ex('Souveraineté signifie surtout :', ['dépendance totale', 'capacité d’un État à se gouverner', 'absence de capital', 'fin de toute loi'], 1, 'État.', 'EMC/Hist.', 'intermediaire'),
      ex('Après 1960, un défi majeur :', ['absence de territoire', 'développement et construction institutionnelle', 'disparition de l’Atlantique', 'fin de l’école'], 1, 'Défis.', 'Lien présent.', 'difficile'),
    ],
    quiz: [
      qz('Décolonisation en Afrique (vague majeure) :', ['années 1960', 'années 1920 seulement', 'Antiquité', '2020 uniquement'], 0, 'Contexte.'),
      qz('État indépendant implique :', ['frontières et institutions propres', 'aucune capitale', 'pas de population', 'pas de langues'], 0, 'État.'),
    ],
  },
];

const geoGabonPlus: TopicData[] = [
  {
    title: 'Climat et végétation au Gabon',
    content:
      "Le Gabon est traversé par l’équateur : climat chaud et humide sur une grande partie du territoire.\nForêt dense humide dominante ; mangroves sur le littoral ; savanes localisées.\nSaisons : période plus pluvieuse / période relativement moins pluvieuse selon les zones.\nLa forêt conditionne biodiversité, ressources (bois) et enjeux de conservation.",
    example: 'À Libreville, chaleur et humidité sont fréquentes toute l’année.',
    keyPoints: ['Équateur', 'Chaud et humide', 'Forêt dense', 'Littoral', 'Biodiversité'],
    exercise: ex('Le climat dominant au Gabon est plutôt :', ['polaire', 'chaud et humide', 'désertique froid', 'alpin'], 1, 'Équatorial / tropical humide.', 'Climat.', 'facile'),
    exercises: [
      ex('Climat dominant :', ['polaire', 'chaud et humide', 'désertique froid', 'alpin'], 1, 'Humide.', 'Géo.', 'facile'),
      ex('Végétation la plus étendue :', ['toundra', 'forêt dense', 'banquise', 'steppe sibérienne'], 1, 'Forêt.', 'Biomes.', 'facile'),
      ex('L’équateur traverse :', ['uniquement l’Europe', 'le Gabon', 'seulement le Canada', 'l’Antarctique habité'], 1, 'Position.', 'Latitude.', 'facile'),
      ex('Enjeu lié à la forêt :', ['aucune ressource', 'conservation et gestion durable', 'interdiction totale d’étudier la nature', 'absence de pluie'], 1, 'DD.', 'Environnement.', 'intermediaire'),
      ex('Mangrove se trouve surtout :', ['au pôle Nord', 'sur le littoral', 'uniquement à Franceville sans eau', 'dans le désert'], 1, 'Côtes.', 'Milieux.', 'intermediaire'),
    ],
    quiz: [
      qz('Forêt dense gabonaise :', ['grande biodiversité', 'absence totale d’arbres', 'glace permanente', 'désert absolu'], 0, 'Biodiversité.'),
      qz('Chaleur + humidité favorisent :', ['la forêt tropicale', 'la banquise', 'le permafrost', 'les glaciers alpins'], 0, 'Lien climat-végétation.'),
    ],
  },
  {
    title: 'Villes et urbanisation au Gabon',
    content:
      "Libreville : capitale politique, principale agglomération.\nPort-Gentil : ville économique liée au port et au pétrole.\nFranceville, Oyem, Lambaréné, Mouila… : pôles régionaux.\nUrbanisation : croissance des villes, défis de logement, transport, emploi, services.\nExode rural et attractivité de la capitale structurent une partie des migrations internes.",
    example: 'Beaucoup d’activités administratives se concentrent à Libreville.',
    keyPoints: ['Libreville', 'Port-Gentil', 'Pôles régionaux', 'Urbanisation', 'Migrations'],
    exercise: ex('La capitale politique du Gabon est :', ['Port-Gentil', 'Franceville', 'Libreville', 'Oyem'], 2, 'Libreville.', 'Villes.', 'facile'),
    exercises: [
      ex('Capitale politique :', ['Port-Gentil', 'Franceville', 'Libreville', 'Oyem'], 2, 'Libreville.', 'Admin.', 'facile'),
      ex('Ville très liée au pétrole / port :', ['Oyem', 'Port-Gentil', 'Makokou', 'Tchibanga'], 1, 'Port-Gentil.', 'Éco.', 'facile'),
      ex('Urbanisation signifie surtout :', ['retour exclusif aux villages', 'croissance de la population urbaine', 'fin des villes', 'disparition des routes'], 1, 'Villes.', 'Géo.', 'intermediaire'),
      ex('Un défi urbain fréquent :', ['absence totale d’habitants', 'logement, transport, services', 'trop de glaciers', 'manque d’océans sur Terre'], 1, 'Services.', 'Enjeux.', 'intermediaire'),
      ex('Exode rural :', ['fuite des villes vers la forêt uniquement', 'départ de campagnes vers les villes', 'immigration depuis Mars', 'fin de l’agriculture mondiale'], 1, 'Migrations.', 'Société.', 'difficile'),
    ],
    quiz: [
      qz('Franceville est un pôle du :', ['Haut-Ogooué', 'littoral exclusif', 'Pôle Nord', 'Europe'], 0, 'Intérieur.'),
      qz('Concentrer les services à Libreville peut créer :', ['aucun effet', 'déséquilibres territoriaux', 'la fin du pays', 'un climat polaire'], 1, 'Aménagement.'),
    ],
  },
  {
    title: 'Ressources naturelles et développement',
    content:
      "Ressources : pétrole, manganèse, bois, fer, biodiversité, pêche côtière.\nL’économie a longtemps dépendu fortement des hydrocarbures.\nEnjeu : diversification (agriculture, tourisme durable, services, industrie de transformation).\nDéveloppement durable : exploiter sans détruire le patrimoine pour les générations futures.\nParcs nationaux et aires protégées illustrent la volonté de conservation.",
    example: 'Le pétrole finance une part importante de l’État ; la forêt est un patrimoine mondialement reconnu.',
    keyPoints: ['Pétrole', 'Mines', 'Bois', 'Diversification', 'Développement durable'],
    exercise: ex('Ressource énergétique majeure du Gabon :', ['blé nordique', 'pétrole', 'banquise', 'charbon polaire'], 1, 'Hydrocarbures.', 'Éco.', 'facile'),
    exercises: [
      ex('Ressource majeure :', ['blé nordique', 'pétrole', 'banquise', 'charbon polaire'], 1, 'Pétrole.', 'Éco.', 'facile'),
      ex('Diversification économique vise à :', ['dépendre d’une seule ressource', 'développer plusieurs secteurs', 'fermer les écoles', 'quitter l’Afrique'], 1, 'Stratégie.', 'SES.', 'intermediaire'),
      ex('Le manganèse est :', ['un type de poisson seulement', 'une ressource minière', 'un climat', 'une province'], 1, 'Mine.', 'Ressources.', 'facile'),
      ex('Parc national sert surtout à :', ['augmenter le braconnage', 'protéger milieux et espèces', 'remplacer Libreville', 'interdire toute recherche utile'], 1, 'Conservation.', 'Environnement.', 'intermediaire'),
      ex('Développement durable = ', ['tout extraire sans limite', 'répondre aux besoins présents sans compromettre l’avenir', 'interdire toute activité', 'ignorer la forêt'], 1, 'Définition.', 'DD.', 'difficile'),
    ],
    quiz: [
      qz('Bois tropical gabonais :', ['ressource forestière', 'uniquement un déchet', 'un gaz noble', 'une province'], 0, 'Forêt.'),
      qz('Dépendre d’une seule ressource est :', ['toujours sans risque', 'une vulnérabilité économique', 'obligatoire', 'impossible'], 1, 'Risque.'),
    ],
  },
];

const emcGabonPlus: TopicData[] = [
  {
    title: 'Vivre ensemble à l’école gabonaise',
    content:
      "Le règlement intérieur fixe des règles de vie collective : assiduité, respect, sécurité.\nDroits de l’élève : être respecté, apprendre dans de bonnes conditions.\nDevoirs : travailler, respecter autrui, ne pas harceler, prendre soin du matériel.\nLe délégué de classe représente les élèves et fait le lien avec l’équipe éducative.\nLe dialogue et la médiation aident à régler les conflits sans violence.",
    example: 'Signaler un harcèlement à un adulte de confiance est un acte responsable.',
    keyPoints: ['Règlement', 'Droits / devoirs', 'Délégué', 'Respect', 'Non-violence'],
    exercise: ex('Le délégué de classe :', ['dirige l’armée', 'représente les élèves', 'écrit la Constitution', 'remplace le chef de l’État'], 1, 'Représentation.', 'Vie scolaire.', 'facile'),
    exercises: [
      ex('Rôle du délégué :', ['diriger l’armée', 'représenter les élèves', 'écrire les lois', 'remplacer le Président'], 1, 'Lien élèves-école.', 'EMC.', 'facile'),
      ex('Harcèlement :', ['un compliment unique', 'actes répétés qui isolent ou blessent', 'un devoir de maths', 'une règle de grammaire'], 1, 'Répétition + nuisance.', 'Respect.', 'facile'),
      ex('Face au harcèlement, une bonne attitude :', ['aggraver en ligne', 'soutenir la victime et alerter un adulte', 'rire avec les agresseurs', 'ignorer toujours si on est témoin engagé'], 1, 'Signaler.', 'Citoyenneté.', 'intermediaire'),
      ex('Respecter le règlement intérieur :', ['devoir de l’élève', 'interdit', 'réservé aux visiteurs', 'option sportive'], 0, 'Devoirs.', 'École.', 'facile'),
      ex('La violence à l’école :', ['est une solution durable', 'doit être refusée ; on privilégie le dialogue', 'est obligatoire', 'remplace les notes'], 1, 'Non-violence.', 'Valeurs.', 'difficile'),
    ],
    quiz: [
      qz('Droit de l’élève :', ['être humilié librement', 'être respecté et apprendre', 'désobéir sans limite', 'détruire le matériel'], 1, 'Dignité.'),
      qz('Médiation :', ['régler un conflit par le dialogue', 'aggraver la bagarre', 'ignorer le règlement', 'quitter l’école définitivement'], 0, 'Paix.'),
    ],
  },
  {
    title: 'Médias, information et esprit critique',
    content:
      "S’informer : radio, télévision, presse, Internet, réseaux sociaux.\nToute information n’est pas vraie : vérifier la source, la date, croiser les points de vue.\nFake news et rumeurs se propagent vite, surtout en ligne.\nCitoyenneté numérique : ne pas diffamer, respecter la vie privée, signaler les contenus dangereux.\nAu Gabon comme ailleurs, l’esprit critique protège des manipulations.",
    example: 'Avant de partager une rumeur sur WhatsApp, vérifier l’origine de l’info.',
    keyPoints: ['Sources', 'Vérification', 'Fake news', 'Réseaux sociaux', 'Esprit critique'],
    exercise: ex('Face à une info choquante en ligne, le plus sage est souvent :', ['la partager immédiatement', 'vérifier la source avant de diffuser', 'insulter l’auteur', 'croire sans lire'], 1, 'Vérifier.', 'Médias.', 'facile'),
    exercises: [
      ex('Bonne réaction face à une rumeur :', ['partager sans lire', 'vérifier la source', 'insulter', 'croire automatiquement'], 1, 'Esprit critique.', 'EMC.', 'facile'),
      ex('Fake news :', ['information toujours officielle', 'fausse information présentée comme vraie', 'un exercice de maths', 'un drapeau'], 1, 'Désinformation.', 'Médias.', 'facile'),
      ex('Croiser les sources signifie :', ['lire une seule publication', 'comparer plusieurs médias / points de vue', 'fermer Internet', 'ignorer la date'], 1, 'Méthode.', 'Info.', 'intermediaire'),
      ex('Respecter la vie privée en ligne :', ['publier les secrets d’autrui', 'ne pas diffuser d’images humiliantes sans consentement', 'voler des mots de passe', 'diffamer'], 1, 'Numérique.', 'Éthique.', 'intermediaire'),
      ex('L’esprit critique sert à :', ['tout refuser sans raison', 'évaluer la fiabilité des informations', 'arrêter d’apprendre', 'remplacer l’école'], 1, 'Citoyenneté.', 'Compétence.', 'difficile'),
    ],
    quiz: [
      qz('Source fiable est plutôt :', ['anonyme sans date ni auteur', 'identifiable, datée, vérifiable', 'toujours une rumeur', 'un message privé non sourcé'], 1, 'Critères.'),
      qz('Diffamer :', ['porter atteinte à la réputation par des accusations graves', 'féliciter quelqu’un', 'apprendre une leçon', 'ranger sa chambre'], 0, 'Droit.'),
    ],
  },
];

const frGabonPlus: TopicData[] = [
  {
    title: 'Contes et proverbes : l’oralité gabonaise',
    content:
      "L’oralité transmet valeurs, humour, interdits et sagesse : contes, proverbes, chants, devinettes.\nUn conte a souvent une situation initiale, des épreuves, une morale.\nLe proverbe condense une leçon de vie en une formule mémorable.\nEn classe : raconter, reformuler, dégager le thème et la morale, comparer avec d’autres récits d’Afrique centrale.\nÉcrire un conte moderne ancré à Libreville, au village ou en forêt.",
    example: 'Un proverbe sur le travail ou le respect des aînés peut illustrer une rédaction.',
    keyPoints: ['Oralité', 'Conte', 'Proverbe', 'Morale', 'Transmission'],
    exercise: ex('Un proverbe relève surtout de :', ['la chimie', 'l’oralité et la sagesse populaire', 'la géométrie', 'la comptabilité'], 1, 'Tradition orale.', 'Culture.', 'facile'),
    exercises: [
      ex('Proverbe :', ['chimie', 'oralité / sagesse', 'géométrie', 'compta'], 1, 'Oralité.', 'Français.', 'facile'),
      ex('La morale d’un conte :', ['est toujours absente', 'enseigne une leçon de vie', 'est une équation', 'est un drapeau'], 1, 'Sens.', 'Lecture.', 'facile'),
      ex('Situation initiale d’un conte :', ['termine l’histoire', 'présente le cadre et l’équilibre de départ', 'est la conclusion seule', 'est un calcul'], 1, 'Schéma narratif.', 'Récit.', 'intermediaire'),
      ex('Réécrire un conte « à Libreville » permet de :', ['ignorer toute culture', 'ancrer le récit dans le réel de l’élève', 'remplacer la grammaire par le silence', 'interdire l’oral'], 1, 'Création.', 'Production.', 'intermediaire'),
      ex('L’oralité et l’écrit :', ['s’opposent toujours sans lien', 'peuvent se enrichir mutuellement en classe', 'sont interdits au Gabon', 'ne servent qu’aux maths'], 1, 'Complémentarité.', 'Culture.', 'difficile'),
    ],
    quiz: [
      qz('Transmettre un conte à l’oral développe :', ['uniquement la peur', 'mémoire, expression, écoute', 'rien', 'seulement le calcul mental'], 1, 'Compétences.'),
      qz('Thème d’un conte peut être :', ['uniquement une formule chimique', 'le respect, la ruse, la solidarité…', 'un numéro de téléphone', 'une note de musique seule'], 1, 'Sens.'),
    ],
  },
  {
    title: 'Argumenter sur un enjeu gabonais',
    content:
      "Texte argumentatif : thèse, arguments, exemples, conclusion.\nSujets possibles : protection de la forêt, importance de l’école, vivre ensemble en ville, gestion des déchets à Libreville, rôle des jeunes.\nConnecteurs : car, donc, cependant, en outre, ainsi…\nExemples concrets (parc national, quartier, expérience scolaire) renforcent le devoir.\nRespect d’autrui : on critique des idées, pas les personnes.",
    example: 'Thèse : « Il faut protéger la forêt gabonaise. » → biodiversité, climat, ressources, tourisme durable.',
    keyPoints: ['Thèse', 'Arguments', 'Exemples locaux', 'Connecteurs', 'Respect'],
    exercise: ex('Dans un texte argumentatif, la thèse est :', ['un exemple isolé', 'l’idée principale défendue', 'un connecteur', 'un titre seul'], 1, 'Position.', 'Argumenter.', 'facile'),
    exercises: [
      ex('La thèse :', ['un exemple', 'l’idée défendue', 'un connecteur', 'un titre seul'], 1, 'Position.', 'Méthode.', 'facile'),
      ex('Un bon exemple sur la forêt gabonaise :', ['hors sujet total', 'parc national, biodiversité, climat', 'uniquement une conjugaison latine', 'la météo de l’Antarctique'], 1, 'Ancrage.', 'Exemple.', 'intermediaire'),
      ex('« Cependant » introduit :', ['une cause pure', 'une opposition / restriction', 'une addition neutre seulement', 'une date'], 1, 'Connecteur.', 'Langue.', 'facile'),
      ex('Argumenter sans respect d’autrui :', ['est recommandé', 'affaiblit le discours civique', 'est obligatoire au BAC', 'remplace les exemples'], 1, 'Éthique.', 'EMC/Fr.', 'intermediaire'),
      ex('Conclusion efficace :', ['ouvre une nouvelle question sans lien', 'rappelle la thèse et ouvre modestement', 'copie l’intro mot à mot', 'insulte le lecteur'], 1, 'Clôture.', 'Méthode.', 'difficile'),
    ],
    quiz: [
      qz('« Donc », « ainsi » marquent souvent :', ['l’opposition', 'la conséquence', 'le lieu', 'la couleur'], 1, 'Logique.'),
      qz('Sujet gabonais pertinent :', ['uniquement la conjugaison du latin', 'éducation, forêt, vivre ensemble', 'météo martienne', 'histoire de la banquise seule'], 1, 'Ancrage.'),
    ],
  },
];

const svtGabonPlus: TopicData[] = [
  {
    title: 'Chaînes alimentaires en forêt gabonaise',
    content:
      "Producteurs : plantes vertes (photosynthèse).\nConsommateurs primaires : herbivores ; secondaires : carnivores…\nDécomposeurs : recyclent la matière organique.\nEn forêt dense : interactions complexes, grande biodiversité.\nPerturbations : déforestation locale, braconnage, pollution — fragilisent les chaînes.",
    example: 'Feuilles → insecte → oiseau → prédateur ; champignons et bactéries décomposent les débris.',
    keyPoints: ['Producteurs', 'Consommateurs', 'Décomposeurs', 'Biodiversité', 'Perturbations'],
    exercise: ex('Les plantes vertes sont surtout :', ['consommateurs tertiaires', 'producteurs', 'décomposeurs exclusifs', 'prédateurs'], 1, 'Photosynthèse.', 'SVT.', 'facile'),
    exercises: [
      ex('Plantes vertes :', ['consommateurs tertiaires', 'producteurs', 'décomposeurs seuls', 'prédateurs'], 1, 'Producteurs.', 'Chaînes.', 'facile'),
      ex('Un herbivore est :', ['producteur', 'consommateur primaire', 'un minéral', 'un climat'], 1, 'Niveau trophique.', 'Écologie.', 'facile'),
      ex('Décomposeurs :', ['produisent la lumière', 'recyclent la matière organique', 'sont des provinces', 'sont des drapeaux'], 1, 'Recyclage.', 'Écosystème.', 'intermediaire'),
      ex('Braconnage peut :', ['renforcer toutes les chaînes', 'déséquilibrer les populations', 'créer de la forêt', 'arrêter la pluie'], 1, 'Menace.', 'Conservation.', 'intermediaire'),
      ex('Grande biodiversité forestière signifie :', ['une seule espèce', 'de nombreuses espèces en interaction', 'absence de vie', 'un désert'], 1, 'Diversité.', 'Forêt.', 'difficile'),
    ],
    quiz: [
      qz('Photosynthèse :', ['plante utilise la lumière pour produire matière organique', 'animal produit du pétrole', 'roche fond', 'élève dort'], 0, 'Base.'),
      qz('Protéger un parc national aide à :', ['détruire les chaînes', 'préserver espèces et milieux', 'augmenter le braconnage', 'supprimer la pluie'], 1, 'Conservation.'),
    ],
  },
  {
    title: 'Santé et hygiène au quotidien',
    content:
      "Hygiène corporelle, lavage des mains, eau potable : gestes qui limitent les infections.\nVaccination : prépare le système immunitaire.\nPaludisme et autres maladies : moustiquaires, assainissement, consultation médicale.\nAlimentation équilibrée et activité physique soutiennent la santé.\nÀ l’école : propreté des latrines, gestion des déchets, sensibilisation.",
    example: 'Se laver les mains avant de manger réduit le risque de maladies diarrhéiques.',
    keyPoints: ['Lavage des mains', 'Eau potable', 'Vaccination', 'Prévention', 'Assainissement'],
    exercise: ex('Se laver les mains avant de manger sert surtout à :', ['rien', 'limiter les microbes pathogènes', 'remplacer les vaccins toujours', 'créer de l’eau'], 1, 'Hygiène.', 'Santé.', 'facile'),
    exercises: [
      ex('Lavage des mains :', ['inutile', 'limite les microbes', 'remplace toute médecine', 'crée de l’eau'], 1, 'Prévention.', 'SVT.', 'facile'),
      ex('Vaccination :', ['guérit toutes les fractures', 'prépare les défenses avant infection', 'remplace l’eau potable', 'est un sport'], 1, 'Immunité.', 'Prévention.', 'intermediaire'),
      ex('Moustiquaire aide surtout contre :', ['les fractures', 'certaines maladies transmises par moustiques', 'les fautes d’orthographe', 'le froid polaire'], 1, 'Paludisme etc.', 'Santé.', 'facile'),
      ex('Eau non potable peut transmettre :', ['uniquement la joie', 'des maladies', 'des diplômes', 'du pétrole'], 1, 'Risque.', 'Hygiène.', 'intermediaire'),
      ex('Gestion des déchets à l’école :', ['jeter n’importe où', 'réduire, trier, respecter les espaces', 'brûler dans les salles', 'ignorer les latrines'], 1, 'Cadre de vie.', 'Citoyenneté.', 'difficile'),
    ],
    quiz: [
      qz('Prévention :', ['agir avant la maladie', 'uniquement après complication grave', 'interdire l’école', 'supprimer l’eau'], 0, 'Santé publique.'),
      qz('Alimentation équilibrée :', ['variété et modération', 'un seul aliment toute la vie', 'aucun légume jamais', 'seulement du sucre'], 0, 'Nutrition.'),
    ],
  },
];

const sesGabon: TopicData[] = [
  {
    title: 'Économie gabonaise : acteurs et enjeux',
    content:
      "Acteurs : État, entreprises (dont secteur pétrolier), ménages, banques, commerce extérieur.\nEmploi des jeunes : formation, stages, entrepreneuriat, secteur public et privé.\nUrbanisation de Libreville et Port-Gentil : opportunités et inégalités.\nCommerce : importations / exportations (pétrole, bois, manganèse…).\nPolitiques publiques : éducation, santé, infrastructures, diversification.",
    example: 'Un jeune qui se forme augmente ses chances d’emploi — lien éducation / économie.',
    keyPoints: ['État', 'Entreprises', 'Emploi', 'Exportations', 'Diversification'],
    exercise: ex('Une exportation gabonaise traditionnelle majeure :', ['banquise', 'pétrole', 'neige', 'blé polaire'], 1, 'Hydrocarbures.', 'SES.', 'facile'),
    exercises: [
      ex('Exportation majeure :', ['banquise', 'pétrole', 'neige', 'blé polaire'], 1, 'Pétrole.', 'Éco.', 'facile'),
      ex('L’État peut intervenir par :', ['uniquement le silence', 'éducation, santé, infrastructures', 'suppression de toute école', 'fin des routes'], 1, 'Politiques.', 'SES.', 'intermediaire'),
      ex('Emploi des jeunes dépend en partie de :', ['la formation et l’activité économique', 'la couleur du ciel seule', 'l’absence de villes', 'l’interdiction d’apprendre'], 0, 'Travail.', 'Société.', 'intermediaire'),
      ex('Importer signifie :', ['vendre à l’étranger seulement', 'acheter des biens venant de l’extérieur', 'fermer les ports', 'interdire le commerce'], 1, 'Commerce.', 'Vocabulaire.', 'facile'),
      ex('Diversifier l’économie gabonaise :', ['augmenter la dépendance au seul pétrole', 'développer d’autres secteurs', 'supprimer l’agriculture utile', 'ignorer les services'], 1, 'Stratégie.', 'Développement.', 'difficile'),
    ],
    quiz: [
      qz('Ménages dans l’économie :', ['consomment, travaillent, épargnent…', 'n’existent pas', 'sont des provinces', 'sont des parcs'], 0, 'Acteurs.'),
      qz('Infrastructure exemple :', ['route, port, école, réseau électrique', 'uniquement un rêve', 'un proverbe', 'une conjugaison'], 0, 'Développement.'),
    ],
  },
];

const anglaisGabonPlus: TopicData[] = [
  {
    title: 'Describing my city in Gabon',
    content:
      "Useful vocabulary: capital, coastal, rainforest, market, school, neighbourhood.\nStructures: There is / There are ; It is located in… ; People can…\nExample paragraph: Libreville is the capital of Gabon. It is on the Atlantic coast. There are markets, schools and offices. The weather is often hot and humid.",
    example: 'Port-Gentil is an important coastal city linked to the oil industry.',
    keyPoints: ['There is/are', 'Location', 'Capital', 'Coast', 'Weather'],
    exercise: ex('Libreville is the ___ of Gabon.', ['village only', 'capital', 'desert', 'glacier'], 1, 'Capital city.', 'Vocab.', 'facile'),
    exercises: [
      ex('Libreville is the ___ of Gabon.', ['village only', 'capital', 'desert', 'glacier'], 1, 'Capital.', 'English.', 'facile'),
      ex('Gabon is in ___ Africa.', ['Central', 'Northern Europe only', 'Antarctica', 'East Asia only'], 0, 'Central Africa.', 'Geo.', 'facile'),
      ex('« There are many schools » means :', ['il n’y a aucune école', 'il y a beaucoup d’écoles', 'il pleut', 'c’est la nuit'], 1, 'There are.', 'Grammar.', 'facile'),
      ex('Port-Gentil is especially linked to :', ['ice hockey only', 'oil / the port', 'skiing only', 'polar research only'], 1, 'Economy.', 'Facts.', 'intermediaire'),
      ex('Complete: The rainforest is rich in ___.', ['biodiversity', 'icebergs only', 'deserts only', 'snow only'], 0, 'Nature vocab.', 'Science.', 'intermediaire'),
    ],
    quiz: [
      qz('Humid weather means :', ['sec comme un désert', 'humide', 'gelé', 'neigeux'], 1, 'Climate.'),
      qz('Neighbourhood means :', ['quartier', 'pays entier', 'océan', 'continent'], 0, 'City life.'),
    ],
  },
  {
    title: 'School life in Gabon (English)',
    content:
      "Vocabulary: timetable, subject, homework, teacher, classmate, break, exam.\nPhrases: My favourite subject is… / We have maths on Monday… / I do my homework in the evening.\nPoliteness: Please, thank you, excuse me.\nLink to local reality: CEPE, BEPC, BAC preparation; studying in French and learning English as a foreign language.",
    example: 'I study English because it helps me communicate and find opportunities.',
    keyPoints: ['School vocab', 'Timetable', 'Homework', 'Politeness', 'Exams'],
    exercise: ex('« Homework » means :', ['vacances', 'devoirs', 'cantine', 'stade'], 1, 'School work.', 'Vocab.', 'facile'),
    exercises: [
      ex('Homework = ', ['vacances', 'devoirs', 'cantine', 'stade'], 1, 'Devoirs.', 'School.', 'facile'),
      ex('My favourite subject is maths. « Subject » = ', ['matière', 'cartable', 'cour', 'bus'], 0, 'Matière.', 'Vocab.', 'facile'),
      ex('« Please » is used to :', ['insult someone', 'be polite when asking', 'sleep', 'run only'], 1, 'Politeness.', 'Functions.', 'facile'),
      ex('BEPC is :', ['a type of fruit only', 'an exam (college level in Gabon)', 'a river only', 'a dance only'], 1, 'Local exams.', 'Culture.', 'intermediaire'),
      ex('Complete: We ___ English twice a week.', ['has', 'have', 'having', 'had always only'], 1, 'have.', 'Grammar.', 'intermediaire'),
    ],
    quiz: [
      qz('Classmate = ', ['camarade de classe', 'directeur seulement', 'parent', 'bus'], 0, 'School.'),
      qz('Exam preparation means :', ['préparer un examen', 'ignorer les cours', 'dormir en classe', 'quitter l’école'], 0, 'Study.'),
    ],
  },
];

const pcGabonPlus: TopicData[] = [
  {
    title: 'Eau, pureté et traitement au quotidien',
    content:
      "L’eau potable est essentielle à la santé.\nEau de pluie, eau de rivière, eau du robinet : qualités différentes.\nTraitements possibles : filtration, ébullition, produits adaptés selon les consignes sanitaires.\nÉconomiser l’eau : fermer les robinets, réparer les fuites.\nAu Gabon : accès à l’eau varie selon les quartiers et les zones ; enjeu de service public et d’hygiène.",
    example: 'Faire bouillir l’eau suspecte (quand c’est recommandé) peut réduire certains risques microbiens.',
    keyPoints: ['Eau potable', 'Traitement', 'Économies', 'Hygiène', 'Service'],
    exercise: ex('L’eau potable est :', ['toujours de l’eau de mer pure', 'propre à la consommation', 'uniquement de la glace', 'un pétrole'], 1, 'Consommation.', 'PC/SVT.', 'facile'),
    exercises: [
      ex('Eau potable :', ['mer pure toujours', 'propre à boire', 'glace seule', 'pétrole'], 1, 'Définition.', 'Santé.', 'facile'),
      ex('Économiser l’eau à la maison :', ['laisser couler sans besoin', 'fermer le robinet / réparer fuites', 'ouvrir toutes les vannes', 'polluer volontairement'], 1, 'Gestes.', 'Citoyenneté.', 'facile'),
      ex('Faire bouillir peut aider à :', ['créer du pétrole', 'réduire certains microbes', 'fabriquer du fer', 'arrêter la pluie'], 1, 'Traitement.', 'Prévention.', 'intermediaire'),
      ex('Polluer une rivière :', ['améliore l’eau potable', 'nuit à la santé et aux écosystèmes', 'est sans effet', 'crée des écoles'], 1, 'Environnement.', 'Impact.', 'intermediaire'),
      ex('Accès à l’eau est un enjeu de :', ['uniquement de mode', 'santé publique et développement', 'conjugaison latine', 'football seul'], 1, 'Société.', 'Gabon.', 'difficile'),
    ],
    quiz: [
      qz('Filtration de l’eau :', ['peut retirer certaines particules', 'ajoute toujours du sel de mer', 'crée de l’or', 'remplace l’école'], 0, 'Traitement.'),
      qz('Fuite d’eau non réparée :', ['gaspillage', 'économie', 'production de pétrole', 'création de forêt'], 0, 'Gestes.'),
    ],
  },
];


export function getGabon_cm2_geo(): Subject {
  return makeSubject('geographie', 'Géographie', 'Map', 'teal', 'cm2', 'CM2', [...geoGabonCm2, ...geoGabonPlus.slice(0, 1)]);
}
export function getGabon_college_geo(): Subject {
  return makeSubject('geographie', 'Géographie', 'Map', 'teal', 'college-gabon', 'Collège', [...geoGabonCollege, ...geoGabonPlus]);
}
export function getGabon_histoire(): Subject {
  return makeSubject('histoire', 'Histoire', 'Landmark', 'orange', 'gabon-hist', 'Gabon', [...histGabon, ...histGabonPlus]);
}
export function getGabon_emc(): Subject {
  return makeSubject('emc', 'EMC', 'Scale', 'slate', 'gabon-emc', 'Gabon', [...emcGabon, ...emcGabonPlus]);
}
export function getGabon_francais(): Subject {
  return makeSubject('francais', 'Français', 'BookOpen', 'amber', 'gabon-fr', 'Gabon', [...frGabon, ...frGabonPlus]);
}
export function getGabon_svt(): Subject {
  return makeSubject('svt', 'SVT', 'Leaf', 'green', 'gabon-svt', 'Gabon', [...svtGabon, ...svtGabonPlus]);
}
export function getGabon_pc(): Subject {
  return makeSubject('physique-chimie', 'Physique-Chimie', 'Atom', 'indigo', 'gabon-pc', 'Gabon', [...pcGabon, ...pcGabonPlus]);
}
export function getGabon_anglais(): Subject {
  return makeSubject('anglais', 'Anglais', 'Languages', 'red', 'gabon-en', 'Gabon', [...anglaisGabon, ...anglaisGabonPlus]);
}

/** Sujets ancrés Gabon à fusionner par niveau */
export function getGabon_ses(): Subject {
  return makeSubject('ses', 'SES', 'TrendingUp', 'emerald', 'gabon-ses', 'Gabon', sesGabon);
}

export function getGabonSubjectsForLevel(levelId: string): Subject[] {
  const out: Subject[] = [];
  if (levelId === 'cm2') {
    out.push(getGabon_cm2_geo(), getGabon_emc(), getGabon_histoire(), getGabon_francais());
  }
  if (['6e', '5e', '4e', '3e'].includes(levelId)) {
    out.push(
      getGabon_college_geo(),
      getGabon_histoire(),
      getGabon_emc(),
      getGabon_francais(),
      getGabon_svt(),
      getGabon_pc(),
      getGabon_anglais(),
    );
  }
  if (['seconde', 'premiere', 'terminale'].includes(levelId)) {
    out.push(
      getGabon_college_geo(),
      getGabon_histoire(),
      getGabon_francais(),
      getGabon_svt(),
      getGabon_anglais(),
      getGabon_ses(),
      getGabon_emc(),
      getGabon_pc(),
    );
  }
  return out;
}
