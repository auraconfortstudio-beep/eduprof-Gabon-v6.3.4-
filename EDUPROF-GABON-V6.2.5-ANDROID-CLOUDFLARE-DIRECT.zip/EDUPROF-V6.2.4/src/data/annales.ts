/**
 * Architecture annales EduProf Gabon.
 * Aucune annale n'est présentée comme officielle sans source vérifiée.
 * Les sujets avec subjectText/correctionText sont des ENTRAÎNEMENTS originaux
 * EduProf (edu_prof_training) — ils ne reproduisent aucun sujet protégé.
 */

export type ExamKind = 'CEPE' | 'BEPC' | 'BAC' | 'UNIVERSITE' | 'AUTRE';

export type AnnaleVerificationStatus =
  | 'placeholder'
  | 'unverified'
  | 'verified_official'
  | 'edu_prof_training';

export interface AnnaleEntry {
  id: string;
  exam: ExamKind | string;
  year: string;
  level: string;
  series?: string | null;
  subject: string;
  session?: string | null;
  /** true uniquement si source officielle vérifiée */
  official: boolean;
  verificationStatus: AnnaleVerificationStatus;
  source: string;
  url?: string;
  /** sujet / corrigé : absents tant que non fournis officiellement */
  subjectText?: string | null;
  correctionText?: string | null;
}

/** Catalogue : placeholders structurels + sujets d'entraînement originaux EduProf */
export const ANNALES_CATALOG: AnnaleEntry[] = [
  // ——— CEPE / CEP (CM2) ———
  {
    id: 'cepe-entrainement-maths-2024',
    exam: 'CEPE',
    year: '2024',
    level: 'CM2',
    subject: 'Mathématiques',
    session: 'Entraînement EduProf',
    official: false,
    verificationStatus: 'edu_prof_training',
    source: 'Sujet d’entraînement original EduProf Gabon — non officiel',
    subjectText: `ÉPREUVE DE MATHÉMATIQUES — Entraînement CEPE / CEP
Durée indicative : 1 h 30. Calculatrice non autorisée sauf indication contraire.

PARTIE A — Calculs et nombres (8 points)

1. Écris en lettres le nombre 45 078. (1 pt)
2. Décompose 3 456 en unités, dizaines, centaines, milliers. (1 pt)
3. Calcule : 234 + 567 − 89. (1 pt)
4. Calcule : 48 × 25. (1 pt)
5. Effectue la division euclidienne de 157 par 12 (quotient et reste). (1 pt)
6. Simplifie la fraction 18/24. (1 pt)
7. Calcule 3/4 + 1/8. (1 pt)
8. Un cahier coûte 1 250 F. Combien coûtent 6 cahiers ? (1 pt)

PARTIE B — Géométrie et mesures (6 points)

9. Un rectangle mesure 12 cm de longueur et 5 cm de largeur. Calcule son périmètre et son aire. (2 pts)
10. Convertis : 2,5 m = … cm ; 3 200 g = … kg. (1 pt)
11. Un triangle a pour côtés 3 cm, 4 cm et 5 cm. Est-il rectangle ? Justifie. (2 pts)
12. Quelle est la mesure de l’angle plat ? (1 pt)

PARTIE C — Problèmes (6 points)

13. Une classe de 36 élèves part en sortie. On forme des groupes de 6. Combien de groupes complets ? (2 pts)
14. Un réservoir contient 48 L d’eau. On en utilise 3/8. Combien de litres restent-ils ? (2 pts)
15. Un terrain rectangulaire de 40 m sur 25 m est clôturé. Le mètre de grillage coûte 1 500 F. Quel est le coût total de la clôture ? (2 pts)`,
    correctionText: `CORRIGÉ — Entraînement CEPE Maths EduProf

1. Quarante-cinq mille soixante-dix-huit.
2. 3 milliers + 4 centaines + 5 dizaines + 6 unités.
3. 234 + 567 = 801 ; 801 − 89 = 712.
4. 48 × 25 = 1 200.
5. 157 = 12 × 13 + 1 → quotient 13, reste 1.
6. 18/24 = 3/4 (diviser numérateur et dénominateur par 6).
7. 3/4 = 6/8 ; 6/8 + 1/8 = 7/8.
8. 1 250 × 6 = 7 500 F.
9. Périmètre = 2×(12+5) = 34 cm ; Aire = 12×5 = 60 cm².
10. 2,5 m = 250 cm ; 3 200 g = 3,2 kg.
11. Oui : 3²+4²=9+16=25=5² (théorème de Pythagore réciproque).
12. 180°.
13. 36 ÷ 6 = 6 groupes.
14. 3/8 de 48 = 18 L utilisés ; reste 48 − 18 = 30 L.
15. Périmètre = 2×(40+25)=130 m ; coût = 130 × 1 500 = 195 000 F.`,
  },
  {
    id: 'cepe-entrainement-fr-2024',
    exam: 'CEPE',
    year: '2024',
    level: 'CM2',
    subject: 'Français',
    session: 'Entraînement EduProf',
    official: false,
    verificationStatus: 'edu_prof_training',
    source: 'Sujet d’entraînement original EduProf Gabon — non officiel',
    subjectText: `ÉPREUVE DE FRANÇAIS — Entraînement CEPE
Durée indicative : 1 h 30.

I. DICTÉE / ORTHOGRAPHE (préparer une phrase type)
Le petit pêcheur gabonais ramène chaque matin des poissons frais sur le marché de Libreville.

II. QUESTIONS DE COMPRÉHENSION (texte libre — résumé)
Un texte court décrit la vie d’un élève de Port-Gentil qui aide sa famille le week-end.

1. Qui est le personnage principal ?
2. Où se déroule l’histoire ?
3. Que fait-il le week-end ?
4. Donne un synonyme de « aider ».
5. Conjugue au présent : « (aller) — (faire) » à la 1re personne du pluriel.

III. GRAMMAIRE ET CONJUGAISON
6. Souligne le sujet et encadre le verbe : « Les oiseaux chantent dans les arbres. »
7. Donne le féminin de : un instituteur ; un lion ; un acteur.
8. Conjugue le verbe « écrire » au passé composé (je, tu, il).
9. Remplace le nom souligné par un pronom : « Marie lit un livre. »
10. Accorde correctement : « Les belles (maison) de (mon) village. »

IV. RÉDACTION (8–12 lignes)
Raconte une journée passée avec ta famille ou tes amis. Utilise au moins trois temps différents.`,
    correctionText: `CORRIGÉ INDICATIF — Français CEPE (entraînement)

Compréhension : réponses selon le texte fourni en classe.
5. nous allons ; nous faisons.
6. Sujet : Les oiseaux ; verbe : chantent.
7. une institutrice ; une lionne ; une actrice.
8. j’ai écrit ; tu as écrit ; il a écrit.
9. Elle le lit. / Elle lit.
10. Les belles maisons de mon village.
Rédaction : évaluation sur cohérence, orthographe, temps utilisés et respect du sujet.`,
  },
  {
    id: 'cepe-2023-placeholder',
    exam: 'CEPE',
    year: '2023',
    level: 'CM2',
    subject: 'Toutes matières',
    official: false,
    verificationStatus: 'placeholder',
    source: 'Annale officielle non encore disponible — consulter Ministère / DGEC',
  },

  // ——— BEPC (3e) ———
  {
    id: 'bepc-entrainement-maths-2024',
    exam: 'BEPC',
    year: '2024',
    level: '3e',
    subject: 'Mathématiques',
    session: 'Entraînement EduProf',
    official: false,
    verificationStatus: 'edu_prof_training',
    source: 'Sujet d’entraînement original EduProf Gabon — non officiel',
    subjectText: `ÉPREUVE DE MATHÉMATIQUES — Entraînement BEPC
Durée indicative : 2 h. Calculatrice scientifique autorisée selon règles locales.

EXERCICE 1 — Nombres et calcul littéral (5 pts)
1. Simplifie : (2x + 3)(x − 1) − x(x + 2).
2. Résous dans ℝ : 3(x − 2) = 2x + 5.
3. Factorise : x² − 9.

EXERCICE 2 — Géométrie (6 pts)
Dans le plan, ABC est un triangle tel que AB = 6 cm, AC = 8 cm, BC = 10 cm.
1. Montre que ABC est rectangle en A.
2. Calcule l’aire de ABC.
3. Calcule la longueur de la médiane issue de A.

EXERCICE 3 — Fonctions (5 pts)
Soit f la fonction définie par f(x) = 2x − 3.
1. Calcule f(0), f(2), f(−1).
2. Résous f(x) = 5.
3. Trace dans un repère le graphique de f sur [−2 ; 4].

EXERCICE 4 — Statistiques / proportionnalité (4 pts)
Les notes d’un devoir de 10 élèves sont : 8, 12, 10, 15, 9, 14, 11, 13, 10, 16.
1. Calcule la moyenne.
2. Détermine la médiane.
3. Un article coûte 12 000 F après une réduction de 20 %. Quel était le prix initial ?`,
    correctionText: `CORRIGÉ — BEPC Maths entraînement EduProf

Ex1
1. (2x+3)(x−1)=2x²−2x+3x−3=2x²+x−3 ; moins x²+2x → 2x²+x−3−x²−2x = x² − x − 3.
2. 3x − 6 = 2x + 5 → x = 11.
3. x² − 9 = (x − 3)(x + 3).

Ex2
1. AB²+AC²=36+64=100=BC² → rectangle en A (Pythagore).
2. Aire = (AB×AC)/2 = 24 cm².
3. Médiane ma = (1/2)√(2AB²+2AC²−BC²)= (1/2)√(72+128−100)= (1/2)√100 = 5 cm.

Ex3
1. f(0)=−3 ; f(2)=1 ; f(−1)=−5.
2. 2x−3=5 → x=4.
3. Droite passant par (0,−3) et (2,1).

Ex4
1. Somme = 118 ; moyenne = 11,8.
2. Notes ordonnées : 8,9,10,10,11,12,13,14,15,16 → médiane = (11+12)/2 = 11,5.
3. Prix initial P : 0,8P = 12 000 → P = 15 000 F.`,
  },
  {
    id: 'bepc-entrainement-fr-2024',
    exam: 'BEPC',
    year: '2024',
    level: '3e',
    subject: 'Français',
    session: 'Entraînement EduProf',
    official: false,
    verificationStatus: 'edu_prof_training',
    source: 'Sujet d’entraînement original EduProf Gabon — non officiel',
    subjectText: `ÉPREUVE DE FRANÇAIS — Entraînement BEPC
Durée indicative : 3 h (selon organisation locale).

I. ORTHOGRAPHE / DICTÉE préparée
Préparez une dictée sur un texte narratif court (environ 80–100 mots) portant sur la vie scolaire ou l’environnement au Gabon.

II. QUESTIONS SUR UN TEXTE
À partir d’un extrait (à fournir en classe) :
1. Présentez le type de texte et le thème principal.
2. Relevez deux figures de style et expliquez-les.
3. Expliquez le sens de deux expressions dans le contexte.
4. Quelle est la thèse ou le message de l’auteur ?

III. RÉDACTION / ESSAI
Sujet au choix :
A) « Les avantages et les inconvénients des réseaux sociaux pour les élèves du collège. »
B) Racontez un événement qui a changé votre regard sur l’environnement ou la solidarité.

Consignes : introduction, développement structuré (2 à 3 paragraphes), conclusion. Environ 250–350 mots.`,
    correctionText: `CORRIGÉ INDICATIF — Français BEPC (entraînement)

I. Orthographe : notation sur accords, conjugaisons, homophones.
II. Selon le texte : identifier narratif/argumentatif ; métaphore, comparaison, personnification, etc.
III. Grille type : respect du sujet (4), structure (4), richesse lexicale et syntaxe (4), orthographe (4), originalité/arguments (4). Total 20.`,
  },
  {
    id: 'bepc-entrainement-svt-2024',
    exam: 'BEPC',
    year: '2024',
    level: '3e',
    subject: 'SVT',
    session: 'Entraînement EduProf',
    official: false,
    verificationStatus: 'edu_prof_training',
    source: 'Sujet d’entraînement original EduProf Gabon — non officiel',
    subjectText: `ÉPREUVE DE SVT — Entraînement BEPC

PARTIE A — Restitution de connaissances (8 pts)
1. Schématisez et légendez le trajet de l’air dans l’appareil respiratoire humain.
2. Définissez : photosynthèse, écosystème, biodiversité.
3. Citez deux causes de la pollution de l’eau au Gabon et deux conséquences sur la santé ou l’environnement.

PARTIE B — Raisonnement scientifique (12 pts)
On étudie la digestion de l’amidon.
Document 1 : en présence de salive, l’amidon est transformé en maltose (test à l’eau iodée négatif après quelques minutes).
Document 2 : à 0 °C, la réaction est très lente ; à 37 °C elle est rapide ; au-delà de 60 °C elle s’arrête.
1. Quel est le rôle de la salive dans cette expérience ?
2. Interprétez l’influence de la température.
3. Proposez une expérience témoin.
4. Reliez ces observations à la notion d’enzyme.`,
    correctionText: `CORRIGÉ INDICATIF — SVT BEPC entraînement

A1. Fossés nasaux → pharynx → larynx → trachée → bronches → bronchioles → alvéoles.
A2. Photosynthèse : synthèse de matière organique par les végétaux chlorophylliens à partir de CO₂, H₂O et lumière. Écosystème : ensemble formé par un milieu et les êtres vivants qui y interagissent. Biodiversité : diversité des espèces, des gènes et des écosystèmes.
A3. Ex. : rejets industriels/domestiques, déforestation riveraine ; maladies hydriques, mortalité aquatique.
B1. La salive contient une enzyme (amylase) qui hydrolyse l’amidon.
B2. Activité optimale autour de 37 °C (température corporelle) ; dénaturation à haute température.
B3. Tube sans salive ou salive bouillie.
B4. L’amylase est une enzyme (catalyseur biologique sensible à la température).`,
  },
  {
    id: 'bepc-entrainement-pc-2024',
    exam: 'BEPC',
    year: '2024',
    level: '3e',
    subject: 'Physique-Chimie',
    session: 'Entraînement EduProf',
    official: false,
    verificationStatus: 'edu_prof_training',
    source: 'Sujet d’entraînement original EduProf Gabon — non officiel',
    subjectText: `ÉPREUVE DE PHYSIQUE-CHIMIE — Entraînement BEPC

1. Chimie (10 pts)
a) Écrivez l’équation de la combustion complète du méthane CH₄.
b) Calculez la masse de CO₂ produite par la combustion de 16 g de CH₄ (C=12, H=1, O=16).
c) Qu’est-ce qu’un acide ? Donnez un exemple courant et son effet sur le tournesol.

2. Physique (10 pts)
a) Un circuit série comporte une pile 4,5 V et deux lampes identiques. Que peut-on dire des intensités ?
b) Calculez la résistance d’une lampe parcourue par 0,3 A sous 4,5 V (loi d’Ohm).
c) Une lentille convergente a une distance focale de 10 cm. Où se forme l’image d’un objet placé à 15 cm de la lentille ? (formule 1/p + 1/p' = 1/f)`,
    correctionText: `CORRIGÉ — PC BEPC entraînement

1a. CH₄ + 2 O₂ → CO₂ + 2 H₂O
1b. n(CH₄)=16/16=1 mol → n(CO₂)=1 mol → m=44 g.
1c. Substance qui libère des H⁺ en solution (ou selon définition enseignée) ; ex. vinaigre / HCl ; tournesol vire au rouge.
2a. Même intensité dans tout le circuit série.
2b. R = U/I = 4,5/0,3 = 15 Ω.
2c. 1/15 + 1/p' = 1/10 → 1/p' = 1/10 − 1/15 = 1/30 → p' = 30 cm (image réelle).`,
  },
  {
    id: 'bepc-2023-maths',
    exam: 'BEPC',
    year: '2023',
    level: '3e',
    subject: 'Mathématiques',
    official: false,
    verificationStatus: 'placeholder',
    source: 'Annale officielle non encore disponible',
  },
  {
    id: 'bepc-2023-fr',
    exam: 'BEPC',
    year: '2023',
    level: '3e',
    subject: 'Français',
    official: false,
    verificationStatus: 'placeholder',
    source: 'Annale officielle non encore disponible',
  },

  // ——— BAC ———
  {
    id: 'bac-entrainement-c-maths-2024',
    exam: 'BAC',
    year: '2024',
    level: 'Terminale C',
    series: 'C',
    subject: 'Mathématiques',
    session: 'Entraînement EduProf',
    official: false,
    verificationStatus: 'edu_prof_training',
    source: 'Sujet d’entraînement original EduProf Gabon — non officiel',
    subjectText: `ÉPREUVE DE MATHÉMATIQUES — Terminale C — Entraînement BAC
Durée indicative : 4 h.

EXERCICE 1 — Suites (5 pts)
Soit (uₙ) définie par u₀ = 2 et uₙ₊₁ = (1/2)uₙ + 3.
1. Calculez u₁, u₂, u₃.
2. On pose vₙ = uₙ − 6. Montrez que (vₙ) est géométrique et précisez sa raison.
3. Exprimez uₙ en fonction de n. Déterminez lim uₙ.

EXERCICE 2 — Fonctions (6 pts)
Soit f(x) = (x² − 1)/(x − 2) pour x ≠ 2.
1. Étudiez les limites en 2 et en ±∞.
2. Calculez f'(x) et dressez le tableau de variations.
3. Déterminez les asymptotes.

EXERCICE 3 — Probabilités (4 pts)
Une urne contient 3 boules rouges et 5 boules bleues. On tire successivement 2 boules sans remise.
1. Probabilité d’obtenir deux rouges.
2. Probabilité d’obtenir une rouge et une bleue (dans n’importe quel ordre).

EXERCICE 4 — Géométrie dans l’espace / nombres complexes (5 pts)
Selon le programme de la série : au choix — équation de plan, produit scalaire, ou module/argument d’un complexe z = 1 + i√3.`,
    correctionText: `CORRIGÉ INDICATIF — BAC C Maths entraînement

Ex1
1. u₁ = 4 ; u₂ = 5 ; u₃ = 5,5.
2. vₙ₊₁ = uₙ₊₁ − 6 = (1/2)uₙ + 3 − 6 = (1/2)(uₙ − 6) = (1/2)vₙ → géométrique de raison 1/2.
3. vₙ = 2×(1/2)ⁿ = 2^{1−n} ; uₙ = 6 + 2^{1−n} → lim = 6.

Ex2
Limites : en 2± selon signe du numérateur en 2 (=3) → ±∞ ; en ±∞ → ∞ (degré 1).
Asymptote verticale x=2 ; asymptote oblique y=x+2 (division euclidienne).
Dérivée et variations selon calcul.

Ex3
1. (3/8)×(2/7)=6/56=3/28.
2. (3/8)×(5/7)+(5/8)×(3/7)=30/56=15/28.

Ex4
|z|=2 ; arg(z)=π/3.`,
  },
  {
    id: 'bac-entrainement-d-svt-2024',
    exam: 'BAC',
    year: '2024',
    level: 'Terminale D',
    series: 'D',
    subject: 'SVT',
    session: 'Entraînement EduProf',
    official: false,
    verificationStatus: 'edu_prof_training',
    source: 'Sujet d’entraînement original EduProf Gabon — non officiel',
    subjectText: `ÉPREUVE DE SVT — Terminale D — Entraînement BAC

PARTIE I — Restitution organisée de connaissances (8 pts)
« La méiose et la fécondation assurent la stabilité du caryotype de l’espèce au fil des générations. »
Expliquez et illustrez cette affirmation (schémas autorisés).

PARTIE II — Exploitation de documents (12 pts)
Documents (à fournir) : courbe de glycémie, rôle de l’insuline et du glucagon, cas de diabète de type 1 et 2.
1. Décrivez les variations de la glycémie après un repas chez un sujet sain.
2. Expliquez le rôle de l’insuline.
3. Comparez diabète de type 1 et type 2.
4. Proposez des mesures de prévention adaptées au contexte gabonais (alimentation, activité physique).`,
    correctionText: `CORRIGÉ INDICATIF — BAC D SVT

I. Méiose : réduction chromatique (2n → n) ; fécondation : restauration 2n. Schémas chromosomes homologues, crossing-over, caryotype.
II. 1. Pic postprandial puis retour à la normale (~1 g/L).
2. Hormone hypoglycémiante (stockage glycogène, captation cellulaire).
3. Type 1 : destruction cellules β, insulinothérapie ; type 2 : résistance à l’insuline, souvent liée au mode de vie.
4. Alimentation variée, limitation sucres rapides, sport régulier, suivi médical.`,
  },
  {
    id: 'bac-entrainement-a-philo-2024',
    exam: 'BAC',
    year: '2024',
    level: 'Terminale A',
    series: 'A',
    subject: 'Philosophie',
    session: 'Entraînement EduProf',
    official: false,
    verificationStatus: 'edu_prof_training',
    source: 'Sujet d’entraînement original EduProf Gabon — non officiel',
    subjectText: `ÉPREUVE DE PHILOSOPHIE — Terminale A — Entraînement BAC
Durée indicative : 4 h. Traitez UN sujet au choix.

Sujet 1 — Dissertation
La technique nous rend-elle plus libres ?

Sujet 2 — Dissertation
Peut-on être heureux sans être libre ?

Sujet 3 — Explication de texte
(Texte à choisir parmi un extrait d’auteur au programme : Platon, Descartes, Rousseau, Sartre, etc. — fourni en classe.)

Consignes dissertation : introduction (accroche, définition des termes, problématique, plan), développement en 2 ou 3 parties argumentées avec exemples, conclusion (synthèse + ouverture).`,
    correctionText: `CORRIGÉ MÉTHODOLOGIQUE — Philo BAC entraînement

Grille type :
- Problématisation claire et définitions (4 pts)
- Plan cohérent et progressif (4 pts)
- Arguments et exemples (culture générale, auteurs, actualité gabonaise/africaine) (6 pts)
- Rigueur du style et orthographe (3 pts)
- Conclusion (3 pts)

Pistes sujet 1 : technique comme prolongation du corps (outil) vs aliénation (dépendance, surveillance) ; liberté comme autonomie du jugement.
Pistes sujet 2 : bonheur eudémonique (vertu) vs hédoniste ; liberté condition du choix authentique (Sartre) vs déterminismes.`,
  },
  {
    id: 'bac-entrainement-c-pc-2024',
    exam: 'BAC',
    year: '2024',
    level: 'Terminale C',
    series: 'C',
    subject: 'Physique-Chimie',
    session: 'Entraînement EduProf',
    official: false,
    verificationStatus: 'edu_prof_training',
    source: 'Sujet d’entraînement original EduProf Gabon — non officiel',
    subjectText: `ÉPREUVE DE PHYSIQUE-CHIMIE — Terminale C — Entraînement

CHIMIE (10 pts)
1. Équilibres acide-base : calculez le pH d’une solution d’acide fort monoprotoné de concentration 0,01 mol·L⁻¹.
2. Cinétique : facteurs influençant la vitesse de réaction (température, concentration, catalyseur).
3. Oxydoréduction : équilibrez en milieu acide : MnO₄⁻ + Fe²⁺ → Mn²⁺ + Fe³⁺.

PHYSIQUE (10 pts)
4. Mécanique : un mobile de masse 2 kg part du repos sous une force constante de 10 N. Calculez l’accélération et la vitesse après 3 s (frottements négligés).
5. Ondes : relation v = λf. Une onde de fréquence 50 Hz se propage à 20 m·s⁻¹. Quelle est sa longueur d’onde ?
6. Électricité : énergie stockée dans un condensateur E = (1/2)CU².`,
    correctionText: `CORRIGÉ — PC BAC C entraînement

1. pH = −log(0,01) = 2.
2. ↑T → ↑vitesse ; ↑concentration réactifs → ↑vitesse ; catalyseur abaisse Ea.
3. MnO₄⁻ + 8 H⁺ + 5 Fe²⁺ → Mn²⁺ + 4 H₂O + 5 Fe³⁺.
4. a = F/m = 5 m·s⁻² ; v = at = 15 m·s⁻¹.
5. λ = v/f = 0,4 m.
6. Formule rappelée ; application numérique selon données fournies.`,
  },
  {
    id: 'bac-2023-c-maths',
    exam: 'BAC',
    year: '2023',
    level: 'Terminale C',
    series: 'C',
    subject: 'Mathématiques',
    official: false,
    verificationStatus: 'placeholder',
    source: 'Annale officielle non encore disponible',
  },
  {
    id: 'bac-2023-d-svt',
    exam: 'BAC',
    year: '2023',
    level: 'Terminale D',
    series: 'D',
    subject: 'SVT',
    official: false,
    verificationStatus: 'placeholder',
    source: 'Annale officielle non encore disponible',
  },
  {
    id: 'bac-2023-a-philo',
    exam: 'BAC',
    year: '2023',
    level: 'Terminale A',
    series: 'A',
    subject: 'Philosophie',
    official: false,
    verificationStatus: 'placeholder',
    source: 'Annale officielle non encore disponible',
  },
  {
    id: 'bepc-entrainement-anglais-2024',
    exam: 'BEPC',
    year: '2024',
    level: '3e',
    subject: 'Anglais',
    session: 'Entraînement EduProf',
    official: false,
    verificationStatus: 'edu_prof_training',
    source: 'Sujet d’entraînement original EduProf Gabon — non officiel',
    subjectText: `ENGLISH PAPER — BEPC Training (EduProf)
Duration: about 2 hours.

PART A — Reading comprehension
Read a short text about school life in Gabon (to be provided in class).
1. Where does the story take place?
2. What is the main character’s problem?
3. Find a synonym in the text for “happy”.
4. True or false: The character arrives late to school. Justify.

PART B — Grammar and vocabulary
5. Put the verbs in the correct tense: Yesterday I (go) to the market. I (buy) some fruit.
6. Complete: She has lived here ___ 2018. (since / for / during)
7. Comparative: Rewrite — “This book is more interesting than that one.” using “as … as” (negative form).
8. Choose: If it rains, we ___ at home. (stay / will stay / stayed)

PART C — Writing
Write a short paragraph (80–120 words): “Describe your favourite subject at school and explain why.”`,
    correctionText: `ANSWER KEY — English BEPC training

5. went ; bought
6. since
7. This book is not as boring as that one. / That book is not as interesting as this one.
8. will stay (1st conditional)
Writing: content, grammar, vocabulary, coherence.`,
  },
  {
    id: 'bepc-entrainement-hg-2024',
    exam: 'BEPC',
    year: '2024',
    level: '3e',
    subject: 'Histoire-Géographie',
    session: 'Entraînement EduProf',
    official: false,
    verificationStatus: 'edu_prof_training',
    source: 'Sujet d’entraînement original EduProf Gabon — non officiel',
    subjectText: `HISTOIRE-GÉOGRAPHIE — Entraînement BEPC

HISTOIRE (10 pts)
1. Présentez en une dizaine de lignes les causes de la Seconde Guerre mondiale.
2. Qu’est-ce que la Shoah ? Citez deux lieux de mémoire.
3. Expliquez le rôle de la Résistance en Europe.

GÉOGRAPHIE (10 pts)
4. Situer le Gabon : continent, façades maritimes, pays frontaliers.
5. Quelles sont les principales ressources naturelles du Gabon ?
6. Définissez développement durable et donnez un exemple applicable au Gabon (forêt, pétrole, villes).`,
    correctionText: `CORRIGÉ INDICATIF — HG BEPC

1. Traité de Versailles, crise 1929, totalitarismes, expansionnisme nazi.
2. Génocide des Juifs d’Europe par le régime nazi ; Auschwitz, Yad Vashem, mémoriaux locaux.
3. Actions armées, réseaux, information, sabotage contre l’occupation.
4. Afrique centrale ; Atlantique ; Cameroun, Guinée équatoriale, Congo, etc.
5. Pétrole, manganèse, bois, biodiversité.
6. Répondre aux besoins présents sans compromettre les générations futures ; gestion durable de la forêt, diversification économique.`,
  },
  {
    id: 'bac-entrainement-d-maths-2024',
    exam: 'BAC',
    year: '2024',
    level: 'Terminale D',
    series: 'D',
    subject: 'Mathématiques',
    session: 'Entraînement EduProf',
    official: false,
    verificationStatus: 'edu_prof_training',
    source: 'Sujet d’entraînement original EduProf Gabon — non officiel',
    subjectText: `MATHÉMATIQUES — Terminale D — Entraînement BAC

EXERCICE 1 — Suites (5 pts)
u₀ = 1 ; uₙ₊₁ = 0,8 uₙ + 2.
1. Calculez u₁ et u₂.
2. On pose vₙ = uₙ − 10. Montrez que (vₙ) est géométrique.
3. Exprimez uₙ puis lim uₙ.

EXERCICE 2 — Fonction exponentielle / log (selon programme D) (6 pts)
Étudiez f(x) = eˣ − x (limites, dérivée, variations, minimum).

EXERCICE 3 — Probabilités (5 pts)
Une maladie touche 2 % d’une population. Un test est positif chez 95 % des malades et 3 % des non-malades.
1. Représentez par un arbre.
2. Probabilité qu’une personne prise au hasard soit positive.
3. Probabilité qu’elle soit malade sachant qu’elle est positive (Bayes).

EXERCICE 4 — QCM / calculs courts (4 pts)
Questions sur dérivées, primitives, pourcentages.`,
    correctionText: `CORRIGÉ INDICATIF — BAC D Maths

Ex1 : u₁ = 2,8 ; u₂ = 4,24. vₙ₊₁ = 0,8 vₙ ; vₙ = (1−10)×0,8ⁿ = −9×0,8ⁿ ; uₙ = 10 − 9×0,8ⁿ → lim 10.
Ex2 : f′(x)=eˣ−1 ; min en 0, f(0)=1 ; f→+∞ en ±∞.
Ex3 : P(pos)=0,02×0,95+0,98×0,03 ; puis Bayes P(M|pos)=P(pos|M)P(M)/P(pos).`,
  },
  {
    id: 'bac-entrainement-a-fr-2024',
    exam: 'BAC',
    year: '2024',
    level: 'Terminale A',
    series: 'A',
    subject: 'Français',
    session: 'Entraînement EduProf',
    official: false,
    verificationStatus: 'edu_prof_training',
    source: 'Sujet d’entraînement original EduProf Gabon — non officiel',
    subjectText: `FRANÇAIS — Terminale A — Entraînement

I. Commentaire ou dissertation (au choix selon format local)
Sujet dissertation : « Peut-on éduquer sans contraindre ? »
OU commentaire d’un extrait (texte fourni en classe) d’un auteur francophone africain ou du programme.

II. Consignes
- Introduction avec problématique
- Développement organisé
- Conclusion
- Soin de la langue (orthographe, syntaxe, vocabulaire)`,
    correctionText: `MÉTHODE — Français BAC A
Problématiser le sujet ; définir « éduquer » et « contraindre » ; plan dialectique ou thématique ; exemples (école, famille, société gabonaise) ; auteurs (Rousseau, Kant, contemporains).`,
  },
  {
    id: 'cepe-entrainement-hg-2024',
    exam: 'CEPE',
    year: '2024',
    level: 'CM2',
    subject: 'Histoire-Géographie / EMC',
    session: 'Entraînement EduProf',
    official: false,
    verificationStatus: 'edu_prof_training',
    source: 'Sujet d’entraînement original EduProf Gabon — non officiel',
    subjectText: `HISTOIRE-GÉOGRAPHIE — Entraînement CEPE

1. Cite les pays frontaliers du Gabon.
2. Quelle est la capitale du Gabon ?
3. Nomme deux ressources naturelles du Gabon.
4. Qu’est-ce qu’un continent ? Sur quel continent se trouve le Gabon ?
5. Explique en 3–4 phrases ce qu’est le respect des règles à l’école (EMC).`,
    correctionText: `1. Cameroun, Guinée équatoriale, Congo (et selon cartes : São Tomé en façade).
2. Libreville.
3. Pétrole, bois, manganèse…
4. Grande étendue de terre ; Afrique.
5. Respect des autres, du travail, de la ponctualité, etc.`,
  },

  {
    id: 'bepc-entrainement-hist-2025',
    exam: 'BEPC',
    year: '2025',
    level: '3e',
    subject: 'Histoire',
    session: 'Entraînement EduProf',
    official: false,
    verificationStatus: 'edu_prof_training',
    source: 'Sujet d’entraînement original EduProf Gabon — non officiel',
    subjectText: `HISTOIRE — Entraînement BEPC 2025 (EduProf)

1. Présentez les causes de la Seconde Guerre mondiale (8–10 lignes).
2. Qu’est-ce qu’un régime totalitaire ? Illustrez par un exemple.
3. Expliquez ce qu’est la décolonisation et citez deux États africains devenus indépendants après 1960.
4. Document (imaginaire) : extrait sur la création de l’ONU — questions de compréhension et d’esprit critique.`,
    correctionText: `CORRIGÉ INDICATIF
1. Versailles, crise 1929, totalitarismes, expansionnisme.
2. Parti unique, contrôle de la société, idéologie officielle ; ex. nazisme.
3. Accès à la souveraineté des colonies ; nombreux États africains dans les années 1960.
4. Selon document fourni en classe.`,
  },
  {
    id: 'bac-entrainement-c-maths-2025',
    exam: 'BAC',
    year: '2025',
    level: 'Terminale C',
    series: 'C',
    subject: 'Mathématiques',
    session: 'Entraînement EduProf',
    official: false,
    verificationStatus: 'edu_prof_training',
    source: 'Sujet d’entraînement original EduProf Gabon — non officiel',
    subjectText: `MATHÉMATIQUES Tle C — Entraînement 2025

Ex1 — Suite : u₀=4, uₙ₊₁=0,5 uₙ+3. Étudier (uₙ), limite.
Ex2 — Fonction f(x)=ln(x)+x sur ]0;+∞[. Dérivée, variations, limite en 0⁺ et +∞.
Ex3 — Loi binomiale n=10, p=0,3. P(X=2), espérance.
Ex4 — Géométrie / complexes selon programme local.`,
    correctionText: `Pistes : vₙ=uₙ−6 géométrique raison 1/2 ; lim uₙ=6.
f′(x)=1/x+1>0 ; f croissante ; lim 0⁺=−∞ ; lim +∞=+∞.
E(X)=np=3 ; P(X=2)=C(10,2)(0,3)²(0,7)⁸.`,
  },

];


export const OFFICIAL_SOURCE_HINTS = [
  { name: "Ministère de l'Éducation Nationale du Gabon", url: 'https://www.education.gouv.ga' },
  { name: 'Centre des Examens et Concours / DGEC', url: 'https://www.education.gouv.ga' },
] as const;

export function isOfficialAnnale(a: AnnaleEntry): boolean {
  return a.official === true && a.verificationStatus === 'verified_official';
}

export function statusLabel(s: AnnaleVerificationStatus): string {
  switch (s) {
    case 'verified_official':
      return 'Officiel vérifié';
    case 'edu_prof_training':
      return 'Entraînement EduProf';
    case 'unverified':
      return 'Non vérifié';
    default:
      return 'Placeholder — non officiel';
  }
}

/** Affichage élève : CEPE → CEP */
export function examDisplayName(exam: string): string {
  if (exam === 'CEPE' || exam === 'CEP') return 'CEP';
  return exam;
}

/** Normalise filtre UI CEP ↔ CEPE */
export function examMatchesFilter(entryExam: string, filter: string): boolean {
  if (filter === 'all') return true;
  if (filter === 'CEP' || filter === 'CEPE') {
    return entryExam === 'CEPE' || entryExam === 'CEP';
  }
  return entryExam === filter;
}

/** Niveaux parcours liés à chaque examen */
export function levelIdForExam(exam: string): string | null {
  const e = exam.toUpperCase();
  if (e === 'CEPE' || e === 'CEP') return 'cm2';
  if (e === 'BEPC') return '3e';
  if (e === 'BAC') return 'terminale';
  return null;
}

export function examForLevelId(levelId: string): ExamKind | null {
  if (levelId === 'cm2') return 'CEPE';
  if (levelId === '3e') return 'BEPC';
  if (levelId === 'terminale') return 'BAC';
  return null;
}

export function getAnnaleById(id: string, catalog: AnnaleEntry[] = ANNALES_CATALOG): AnnaleEntry | undefined {
  return catalog.find((a) => a.id === id);
}

export function listExamKinds(catalog: AnnaleEntry[] = ANNALES_CATALOG): string[] {
  const order = ['CEPE', 'BEPC', 'BAC'];
  const present = new Set(catalog.map((a) => a.exam));
  return order.filter((e) => present.has(e) || (e === 'CEPE' && present.has('CEP')));
}

export function listYearsForExam(exam: string, catalog: AnnaleEntry[] = ANNALES_CATALOG): string[] {
  const years = new Set<string>();
  for (const a of catalog) {
    if (examMatchesFilter(a.exam, exam)) years.add(a.year);
  }
  return [...years].sort((a, b) => b.localeCompare(a));
}

export function listSubjectsForExamYear(
  exam: string,
  year: string,
  catalog: AnnaleEntry[] = ANNALES_CATALOG
): string[] {
  const subjects = new Set<string>();
  for (const a of catalog) {
    if (examMatchesFilter(a.exam, exam) && a.year === year) subjects.add(a.subject);
  }
  return [...subjects].sort((a, b) => a.localeCompare(b, 'fr'));
}

export function filterAnnales(
  catalog: AnnaleEntry[],
  opts: { exam?: string; year?: string; subject?: string; q?: string }
): AnnaleEntry[] {
  const q = (opts.q || '').trim().toLowerCase();
  return catalog.filter((a) => {
    if (opts.exam && opts.exam !== 'all' && !examMatchesFilter(a.exam, opts.exam)) return false;
    if (opts.year && a.year !== opts.year) return false;
    if (opts.subject && a.subject !== opts.subject) return false;
    if (!q) return true;
    return (
      a.exam.toLowerCase().includes(q) ||
      a.subject.toLowerCase().includes(q) ||
      a.level.toLowerCase().includes(q) ||
      a.year.includes(q) ||
      (a.series || '').toLowerCase().includes(q) ||
      a.id.toLowerCase().includes(q)
    );
  });
}

export function hasSubjectText(a: AnnaleEntry): boolean {
  return !!(a.subjectText && a.subjectText.trim());
}

export function hasCorrectionText(a: AnnaleEntry): boolean {
  return !!(a.correctionText && a.correctionText.trim());
}

/** Contexte pédagogique pour Maël (ne prétend jamais être correction officielle) */
export function buildAnnaleTutorContext(a: AnnaleEntry): {
  level: string;
  subjectName: string;
  series?: string;
  lessonTitle: string;
  questionPrefix: string;
} {
  const levelId = levelIdForExam(a.exam) || 'cm2';
  const officialNote = isOfficialAnnale(a)
    ? 'Annale officielle vérifiée.'
    : a.verificationStatus === 'edu_prof_training'
      ? "Sujet d'entraînement EduProf (non officiel) — explique pédagogiquement sans le présenter comme correction officielle."
      : 'Sujet non encore disponible officiellement — aide l’élève à se préparer sans inventer un sujet officiel.';
  return {
    level: levelId,
    subjectName: a.subject,
    series: a.series || undefined,
    lessonTitle: `${examDisplayName(a.exam)} ${a.year} — ${a.subject}`,
    questionPrefix: `[Contexte annale] Examen: ${examDisplayName(a.exam)} | Année: ${a.year} | Matière: ${a.subject}${a.series ? ` | Série: ${a.series}` : ''} | Statut: ${statusLabel(a.verificationStatus)}. ${officialNote}`,
  };
}

export function annalesStats(catalog: AnnaleEntry[] = ANNALES_CATALOG) {
  const byExam: Record<string, number> = {};
  let withText = 0;
  let withCorrection = 0;
  let placeholders = 0;
  for (const a of catalog) {
    byExam[a.exam] = (byExam[a.exam] || 0) + 1;
    if (hasSubjectText(a)) withText++;
    if (hasCorrectionText(a)) withCorrection++;
    if (a.verificationStatus === 'placeholder') placeholders++;
  }
  return {
    total: catalog.length,
    byExam,
    withSubjectText: withText,
    withCorrection,
    placeholders,
  };
}
