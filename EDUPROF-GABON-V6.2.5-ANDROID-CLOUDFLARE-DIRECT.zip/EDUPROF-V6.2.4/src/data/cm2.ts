import { makeSubject, type Subject } from './types';

export function getCM2Subjects(): Subject[] {
  return [
    makeSubject('mathematiques', 'Mathématiques', 'Calculator', 'blue', 'cm2', 'CM2', [
      {
        title: "Les nombres entiers jusqu'au million",
        content:
          "Les nombres entiers permettent de compter et de mesurer. Un nombre comme 345 678 se lit « trois cent quarante-cinq mille six cent soixante-dix-huit ». Les chiffres sont groupés par trois en partant de la droite : les unités, les milliers, les millions. Chaque groupe de trois chiffres est appelé une « classe ».",
        example:
          "Le nombre 1 234 567 se décompose : 1 million, 234 milliers, 567 unités = 1 000 000 + 234 000 + 567",
        keyPoints: [
          "Les nombres entiers s'écrivent avec les chiffres de 0 à 9",
          "On groupe les chiffres par trois en partant de la droite",
          "Chaque groupe de trois chiffres forme une classe : unités, milliers, millions",
          "Le zéro est un chiffre comme les autres",
        ],
        exercise: {
          q: "Comment s'écrit le nombre « cinq cent vingt-trois mille quatre cent un » en chiffres ?",
          opts: ["523 401", "523 410", "532 401", "523 400"],
          ans: 0,
          exp: "On écrit chaque groupe : « cinq cent vingt-trois mille » = 523 000, « quatre cent un » = 401. Donc 523 000 + 401 = 523 401.",
          method:
            "Sépare le nombre en groupes de mots : d'abord les milliers, puis les unités. Écris chaque groupe en chiffres puis assemble-les.",
        },
        quiz: [
          { q: "Combien de chiffres a le nombre 1 000 000 ?", opts: ["5", "6", "7", "8"], ans: 2, exp: "1 000 000 s'écrit avec 7 chiffres : un 1 suivi de six 0." },
          { q: "Dans le nombre 456 789, que représente le chiffre 4 ?", opts: ["4 unités", "4 milliers", "4 centaines de milliers", "4 dizaines"], ans: 2, exp: "Le 4 est en 6e position en partant de la droite, donc il représente 4 centaines de milliers (400 000)." },
          { q: "Comment lit-on le nombre 80 000 ?", opts: ["Huit mille", "Huit cent mille", "Quatre-vingt mille", "Huit millions"], ans: 2, exp: "80 000 se lit « quatre-vingt mille » car 80 = quatre-vingts." },
        ],
      },
      {
        title: "Les opérations : addition et soustraction",
        content:
          "L'addition permet de réunir des quantités. La soustraction permet de calculer la différence entre deux nombres. Pour poser une addition, on aligne les chiffres par colonne (unités sous unités, dizaines sous dizaines...) et on additionne de droite à gauche. Pour la soustraction, même principe mais on retranche le plus petit du plus grand.",
        example:
          "Addition : 345 + 678 = 1023. On pose : 5+8=13 (on retient 1, on écrit 3), 4+7+1=12 (on retient 1, on écrit 2), 3+6+1=10. Résultat : 1023.",
        keyPoints: [
          "On additionne de droite à gauche (unités d'abord)",
          "Quand le résultat dépasse 9, on retient la dizaine",
          "La soustraction vérifie : a - b = c alors c + b = a",
          "On peut toujours vérifier une soustraction par une addition",
        ],
        exercise: {
          q: "Calcule : 4567 + 3892",
          opts: ["8459", "8359", "8469", "8458"],
          ans: 0,
          exp: "7+2=9, 6+9=15 (j'écris 5, je retiens 1), 5+8+1=14 (j'écris 4, je retiens 1), 4+3+1=8. Résultat : 8459.",
          method: "Pose l'opération en colonnes, additionne de droite à gauche, n'oublie pas les retenues.",
        },
        quiz: [
          { q: "Quel est le résultat de 1000 - 456 ?", opts: ["644", "544", "654", "554"], ans: 1, exp: "1000 - 456 = 544. On peut vérifier : 544 + 456 = 1000." },
          { q: "Quand on additionne 67 + 85, quelle retenue obtient-on ?", opts: ["Aucune", "1", "2", "3"], ans: 1, exp: "7+5=12, on retient 1. Puis 6+8+1=15. Résultat : 152." },
          { q: "Vérifie : 500 - 237 = ?", opts: ["263", "273", "363", "253"], ans: 0, exp: "500 - 237 = 263. Vérification : 263 + 237 = 500." },
        ],
      },
      {
        title: "Les fractions simples",
        content:
          "Une fraction représente une partie d'un tout. Le nombre du haut s'appelle le numérateur (combien de parts on prend), le nombre du bas s'appelle le dénominateur (en combien de parts le tout est divisé). Par exemple, 3/4 signifie qu'on a divisé quelque chose en 4 parts égales et qu'on en prend 3.",
        example:
          "Si je coupe une pizza en 8 parts égales et que j'en mange 3, j'ai mangé 3/8 (trois huitièmes) de la pizza.",
        keyPoints: [
          "Le numérateur est en haut, le dénominateur en bas",
          "Le dénominateur ne peut jamais être 0",
          "Plus le dénominateur est grand, plus les parts sont petites",
          "1/2 = un demi, 1/3 = un tiers, 1/4 = un quart",
        ],
        exercise: {
          q: "Si je partage un gâteau en 6 parts égales et que je mange 2 parts, quelle fraction du gâteau ai-je mangée ?",
          opts: ["2/6 (ou 1/3)", "2/4", "6/2", "1/6"],
          ans: 0,
          exp: "Le gâteau est divisé en 6 parts (dénominateur = 6), et j'en mange 2 (numérateur = 2). Donc 2/6, ce qui se simplifie en 1/3.",
          method: "Le dénominateur = nombre total de parts. Le numérateur = nombre de parts prises.",
        },
        quiz: [
          { q: "Quel est le numérateur dans la fraction 3/5 ?", opts: ["5", "3", "15", "8"], ans: 1, exp: "Le numérateur est le nombre du haut, donc 3." },
          { q: "Laquelle de ces fractions est la plus grande ?", opts: ["1/2", "1/4", "1/8", "1/3"], ans: 0, exp: "Plus le dénominateur est petit, plus la part est grande. 1/2 est la plus grande." },
          { q: "Combien font 1/4 + 1/4 ?", opts: ["1/8", "2/4 (ou 1/2)", "1/16", "2/8"], ans: 1, exp: "On additionne les numérateurs : 1+1=2, le dénominateur reste 4. Donc 2/4 = 1/2." },
        ],
      },
    ]),
    makeSubject('francais', 'Français', 'BookOpen', 'amber', 'cm2', 'CM2', [
      {
        title: "Les classes de mots",
        content:
          "En français, chaque mot appartient à une « classe » (ou nature). Les principales classes sont : le nom (personne, animal, chose), le verbe (l'action), l'adjectif (il décrit le nom), l'article (le, la, les, un, une, des), le pronom (il, elle, nous), l'adverbe (rapidement, bien, hier), la préposition (à, de, dans, sur), la conjonction (et, mais, parce que).",
        example:
          "Dans « Le chat noir dort », « Le » = article, « chat » = nom, « noir » = adjectif, « dort » = verbe.",
        keyPoints: [
          "Le nom désigne une personne, un animal ou une chose",
          "Le verbe exprime une action ou un état",
          "L'adjectif donne une qualité au nom",
          "L'adverbe modifie le sens d'un verbe, un adjectif ou un autre adverbe",
        ],
        exercise: {
          q: 'Dans la phrase « Elle court vite », quelle est la nature du mot « vite » ?',
          opts: ["Nom", "Verbe", "Adverbe", "Adjectif"],
          ans: 2,
          exp: "« Vite » modifie le verbe « court » en indiquant comment elle court. C'est un adverbe de manière.",
          method: "Demande-toi : ce mot modifie-t-il un verbe ? Indique-t-il comment, quand, où ? Si oui, c'est un adverbe.",
        },
        quiz: [
          { q: 'Quel est le nom dans « La maîtresse explique la leçon » ?', opts: ["explique", "la", "maîtresse", "leçon"], ans: 2, exp: "« Maîtresse » désigne une personne. C'est un nom." },
          { q: 'Quel est le verbe dans « Les enfants jouent dans le parc » ?', opts: ["les", "jouent", "dans", "parc"], ans: 1, exp: "« Jouent » exprime l'action faite par les enfants. C'est le verbe conjugué." },
          { q: 'Quel est l\'adjectif dans « Un grand chien aboie » ?', opts: ["un", "grand", "chien", "aboie"], ans: 1, exp: "« Grand » décrit le nom « chien ». C'est un adjectif qualificatif." },
        ],
      },
      {
        title: "La conjugaison : le présent",
        content:
          "Le présent de l'indicatif sert à parler de ce qui se passe maintenant. Les verbes en -er : je parle, tu parles, il parle, nous parlons, vous parlez, ils parlent. Les verbes en -ir (2e groupe) : je finis, tu finis, il finit, nous finissons, vous finissez, ils finissent. Les verbes irréguliers comme « être », « avoir », « aller » doivent être appris par cœur.",
        example:
          "Conjugaison de « être » au présent : je suis, tu es, il/elle est, nous sommes, vous êtes, ils/elles sont.",
        keyPoints: [
          "Le présent décrit une action qui se passe maintenant",
          "Les verbes en -er ont des terminaisons régulières",
          "Les verbes en -ir du 2e groupe prennent -issons à « nous »",
          "Être, avoir, aller sont irréguliers et très fréquents",
        ],
        exercise: {
          q: 'Conjugue le verbe « manger » à « nous » au présent :',
          opts: ["nous mangons", "nous mangeons", "nous mangons", "nous mangeont"],
          ans: 1,
          exp: 'Le verbe « manger » garde le « e » devant les terminaisons en -ons et -ez pour garder le son « j » doux. Donc : nous mangeons.',
          method: "Pour les verbes en -ger, on garde le « e » devant -ons et -ez pour le son doux.",
        },
        quiz: [
          { q: 'Comment s\'écrit « ils (être) » au présent ?', opts: ["ils est", "ils sont", "ils être", "ils étent"], ans: 1, exp: 'Le verbe « être » à la 3e personne du pluriel est « sont ».' },
          { q: 'Quel est le présent de « finir » à « je » ?', opts: ["je fini", "je finis", "je finit", "je finie"], ans: 1, exp: 'Le verbe « finir » (2e groupe) à « je » prend la terminaison -is : je finis.' },
          { q: 'Quel verbe est mal conjugué ?', opts: ["je parle", "tu parles", "il parlent", "nous parlons"], ans: 2, exp: 'À « il/elle », le verbe « parler » prend -e : il parle (sans -ent). « Ils parlent » est correct.' },
        ],
      },
    ]),
    makeSubject('decouverte-du-monde', 'Découverte du monde', 'Globe', 'green', 'cm2', 'CM2', [
      {
        title: "Le cycle de l'eau",
        content:
          "L'eau sur Terre circule en permanence entre le ciel, la terre et les océans. Le soleil chauffe l'eau des océans, des rivières et des lacs : c'est l'évaporation. La vapeur d'eau monte dans le ciel et se refroidit pour former des nuages : c'est la condensation. Quand les gouttes deviennent trop lourdes, elles tombent : c'est la précipitation (pluie, neige). L'eau coule dans les rivières et retourne à l'océan, et le cycle recommence.",
        example:
          "Quand tu vois de la buée sur une vitre en hiver, c'est la condensation : la vapeur d'eau de l'air chaud touche le verre froid et se transforme en gouttelettes.",
        keyPoints: [
          "L'eau s'évapore sous l'effet de la chaleur du soleil",
          "La vapeur se refroidit et forme des nuages (condensation)",
          "Les nuages libèrent l'eau sous forme de pluie ou de neige",
          "Le cycle recommence en permanence",
        ],
        exercise: {
          q: "Comment s'appelle le passage de l'eau liquide à la vapeur ?",
          opts: ["Condensation", "Évaporation", "Précipitation", "Fonte"],
          ans: 1,
          exp: "L'évaporation est le passage de l'eau liquide à l'état de vapeur sous l'effet de la chaleur.",
          method: "Retiens : évaporation = liquide vers vapeur (monte), condensation = vapeur vers liquide (nuages).",
        },
        quiz: [
          { q: "Qu'est-ce qui fait évaporer l'eau ?", opts: ["Le vent", "Le soleil", "La lune", "La pluie"], ans: 1, exp: "La chaleur du soleil fait évaporer l'eau des océans et des rivières." },
          { q: "Les nuages se forment par :", opts: ["Évaporation", "Condensation", "Précipitation", "Fonte"], ans: 1, exp: "La vapeur d'eau se refroidit et se condense pour former les nuages." },
          { q: "La pluie est une forme de :", opts: ["Évaporation", "Condensation", "Précipitation", "Érosion"], ans: 2, exp: "La pluie, la neige et la grêle sont des précipitations." },
        ],
      },
    ]),
    makeSubject('histoire', 'Histoire', 'Landmark', 'orange', 'cm2', 'CM2', [
      {
        title: "Les grandes périodes de l'histoire",
        content:
          "L'histoire est divisée en 5 grandes périodes : 1) La Préhistoire (de l'apparition de l'homme à l'invention de l'écriture, vers -3500), 2) L'Antiquité (de -3500 à 476, fin de l'Empire romain), 3) Le Moyen Âge (de 476 à 1492, découverte de l'Amérique), 4) Les Temps modernes (de 1492 au XIXe s.), 5) L'Époque contemporaine (XIXe-XXIe s., avec pour le Gabon l'indépendance du 17 août 1960).",
        example: "Les pyramides d'Égypte ont été construites pendant l'Antiquité, il y a environ 4500 ans.",
        keyPoints: [
          "La Préhistoire se termine avec l'invention de l'écriture",
          "L'Antiquité va de -3500 à 476 (chute de Rome)",
          "Le Moyen Âge va de 476 à 1492 (découverte de l'Amérique)",
          "L'époque contemporaine va jusqu'à nos jours ; pour le Gabon, repère majeur : indépendance du 17 août 1960",
        ],
        exercise: {
          q: "Quel événement marque la fin de la Préhistoire ?",
          opts: ["La chute de Rome", "L'invention de l'écriture", "La découverte de l'Amérique", "L'indépendance du Gabon"],
          ans: 1,
          exp: "L'invention de l'écriture (vers -3500) marque la fin de la Préhistoire et le début de l'Antiquité.",
          method: "Retiens les 5 dates clés : -3500 (écriture), 476 (chute de Rome), 1492 (Amérique), 1789 (Révolution).",
        },
        quiz: [
          { q: "Dans quelle période se situe l'Empire romain ?", opts: ["Préhistoire", "Antiquité", "Moyen Âge", "Temps modernes"], ans: 1, exp: "L'Empire romain fait partie de l'Antiquité, de -753 à 476." },
          { q: "Quelle date marque l'indépendance du Gabon ?", opts: ["1492", "1789", "17 août 1960", "476"], ans: 2, exp: "Le Gabon est indépendant depuis le 17 août 1960." },
          { q: "Que s'est-il passé en 1492 ?", opts: ["Chute de Rome", "Découverte de l'Amérique", "indépendance du Gabon", "Invention de l'écriture"], ans: 1, exp: "Christophe Colomb découvre l'Amérique en 1492, marquant la fin du Moyen Âge." },
        ],
      },
    ]),
    makeSubject('geographie', 'Géographie', 'Map', 'teal', 'cm2', 'CM2', [
      {
        title: "Le Gabon : situation et relief",
        content:
          "Le Gabon est un pays d'Afrique centrale, situé sur l'équateur. Il est bordé par le Cameroun au nord, le Congo à l'est et au sud, et l'océan Atlantique à l'ouest. La capitale politique est Libreville. Le Gabon a un relief varié : des plaines côtières, des plateaux intérieurs et des montagnes à l'est. Le fleuve principal est l'Ogooué. Le climat est équatorial : chaud et humide toute l'année.",
        example: "Libreville, la capitale, se trouve sur la côte atlantique, à l'embouchure de l'estuaire du Komo.",
        keyPoints: [
          "Le Gabon est en Afrique centrale, traversé par l'équateur",
          "La capitale est Libreville, sur la côte atlantique",
          "Le fleuve principal est l'Ogooué",
          "Le climat est équatorial : chaud et humide",
        ],
        exercise: {
          q: "Quelle est la capitale du Gabon ?",
          opts: ["Port-Gentil", "Franceville", "Libreville", "Oyem"],
          ans: 2,
          exp: "Libreville est la capitale politique du Gabon, située sur la côte atlantique.",
          method: "Retiens : Libreville = capitale, Port-Gentil = capitale économique, Franceville = ville de l'intérieur.",
        },
        quiz: [
          { q: "Quel océan borde le Gabon à l'ouest ?", opts: ["Indien", "Atlantique", "Pacifique", "Arctique"], ans: 1, exp: "Le Gabon est bordé à l'ouest par l'océan Atlantique." },
          { q: "Quel est le fleuve principal du Gabon ?", opts: ["Le Congo", "Le Nil", "L'Ogooué", "Le Niger"], ans: 2, exp: "L'Ogooué est le plus long fleuve du Gabon, il traverse le pays d'est en ouest." },
          { q: "Quel pays ne borde PAS le Gabon ?", opts: ["Cameroun", "Congo", "Guinée équatoriale", "Tchad"], ans: 3, exp: "Le Tchad n'est pas frontalier du Gabon. Les pays frontaliers sont : Cameroun, Congo, Guinée équatoriale." },
        ],
      },
    ]),
    makeSubject('anglais', 'Anglais', 'Languages', 'red', 'cm2', 'CM2', [
      {
        title: "Se présenter en anglais",
        content:
          "Pour se présenter en anglais, on utilise des phrases simples : « My name is... » (Je m'appelle...), « I am... years old » (J'ai... ans), « I live in... » (J'habite à...), « I like... » (J'aime...). Les pronoms personnels sont : I (je), you (tu/vous), he (il), she (elle), it (ça), we (nous), they (ils/elles).",
        example: "My name is Kévin. I am 11 years old. I live in Libreville. I like football.",
        keyPoints: [
          "My name = mon nom, I am = je suis, I live = j'habite",
          "On dit « I am » et non « I have » pour l'âge",
          "Les pronoms : I, you, he, she, it, we, they",
          "On utilise « like » pour exprimer ses goûts",
        ],
        exercise: {
          q: 'Comment dit-on « J\'ai 10 ans » en anglais ?',
          opts: ["I have 10 years", "I am 10 years old", "I am 10 years", "I have 10 years old"],
          ans: 1,
          exp: 'En anglais, on utilise « to be » (être) pour l\'âge : « I am 10 years old ».',
          method: 'Retiens : en anglais on EST un âge, on ne L\'A pas. « I am [âge] years old ».',
        },
        quiz: [
          { q: 'Comment dit-on « Je m\'appelle Sarah » en anglais ?', opts: ["My name is Sarah", "I call Sarah", "I name Sarah", "My Sarah"], ans: 0, exp: "« My name is... » est la formule standard pour se présenter." },
          { q: 'Que veut dire « I live in Gabon » ?', opts: ["J'aime le Gabon", "J'habite au Gabon", "Je viens du Gabon", "Je visite le Gabon"], ans: 1, exp: "« To live » = habiter. « I live in » = j'habite à/au." },
          { q: 'Quel pronom utilise-t-on pour « elle » en anglais ?', opts: ["he", "it", "she", "her"], ans: 2, exp: "« She » est le pronom sujet féminin (elle)." },
        ],
      },
    ]),
    makeSubject('eps', 'EPS', 'Activity', 'lime', 'cm2', 'CM2', [
      {
        title: "L'échauffement et la santé",
        content:
          "Avant toute activité physique, il faut s'échauffer pour préparer son corps. L'échauffement fait monter la température du corps, prépare les muscles et les articulations, et évite les blessures. Un bon échauffement dure 10 à 15 minutes et comprend : des petits déplacements (marche, jogging léger), des rotations articulaires (chevilles, genoux, épaules), des étirements doux. Après l'effort, on fait des étirements pour récupérer.",
        example: "Avant un match de football, on court légèrement 5 minutes, puis on fait des gammes (talons-fesses, montées de genoux) et des rotations.",
        keyPoints: [
          "L'échauffement dure 10 à 15 minutes",
          "Il prépare les muscles et évite les blessures",
          "On commence doucement et on augmente progressivement",
          "Après l'effort, on s'étire pour récupérer",
        ],
        exercise: {
          q: "Pourquoi faut-il s'échauffer avant le sport ?",
          opts: ["Pour gagner du temps", "Pour éviter les blessures", "Pour impressionner", "Ce n'est pas nécessaire"],
          ans: 1,
          exp: "L'échauffement prépare les muscles, tendons et articulations à l'effort, réduisant le risque de blessure.",
          method: "Retiens : échauffement = préparation du corps = moins de blessures.",
        },
        quiz: [
          { q: "Combien de temps doit durer un échauffement ?", opts: ["2 minutes", "10 à 15 minutes", "1 heure", "30 secondes"], ans: 1, exp: "Un bon échauffement dure entre 10 et 15 minutes pour préparer le corps efficacement." },
          { q: "Que fait-on après l'effort ?", opts: ["Rien", "Des étirements", "Dormir", "Manger"], ans: 1, exp: "Les étirements après l'effort aident à récupérer et à éviter les courbatures." },
          { q: "Quel exercice fait partie de l'échauffement ?", opts: ["Sprint maximal", "Jogging léger", "Haltères lourds", "Rien"], ans: 1, exp: "Le jogging léger fait monter la température du corps progressivement." },
        ],
      },
    ]),
  ];
}
