import type { Level, Subject, Series } from './types';
import { ensureUniqueChapterIds } from './types';
import { getCM2Subjects } from './cm2';
import { get5eSubjects, get4eSubjects, get3eSubjects } from './college';
import { getSecondeSubjects, getPremiereSeries, getTerminaleSeries, getUniversiteFilieres, buildTerminaleBMathDemo } from './lycee-universite';
import { getSeriesSpecificSubjects } from './seriesPedagogy';
import { getV26SubjectsForLevel } from './v26Content';
import { getExamPrepSubjectsForLevel, getExamPrepForTerminaleSeries, getExamPrepForPremiereSeries } from './examPrepContent';
import { getExtraSubjectsForLevelV7 as getExtraSubjectsForLevel, mergeUniversityFilieres, getExtraForPremiereSeries, getExtra_terminale_svt, getExtra_terminale_pc, getExtra_seconde_anglais, getExtra_terminale_anglais, getExtra_terminale_francais_A, getExtra_terminale_philo_langage, getExtra_methodo_bac } from './extraContent';
import { getGabonSubjectsForLevel } from './gabonContent';

/**
 * Fusionne les matières existantes avec le pack pédagogique Gabon V2.6.
 * Les chapitres V2.6 (sources IPN/IGS) sont placés en tête.
 * IDs re-normalisés pour garantir 0 doublon après fusion.
 * Aucun contenu étranger n'est ajouté.
 */
function mergeSubjects(existing: Subject[], v26: Subject[]): Subject[] {
  const byName = new Map<string, Subject>();
  for (const s of existing) {
    byName.set(s.name, s);
  }
  for (const s of v26) {
    const prev = byName.get(s.name);
    if (prev) {
      byName.set(
        s.name,
        ensureUniqueChapterIds({
          ...prev,
          chapters: [...s.chapters, ...prev.chapters],
          description: `${prev.description} · Pack Gabon (progressions officielles IPN)`,
        })
      );
    } else {
      byName.set(
        s.name,
        ensureUniqueChapterIds({
          ...s,
          description: `${s.description} · Pack Gabon (progressions officielles IPN)`,
        })
      );
    }
  }
  return Array.from(byName.values()).map(ensureUniqueChapterIds);
}

/** Injecte Philosophie V2.6 + contenus ExamPrep dans les séries Première. */
function mergePremiereSeries(series: Series[]): Series[] {
  const v26Philo = getV26SubjectsForLevel('premiere').filter(s => s.name === 'Philosophie');
  return series.map(ser => {
    let subjects = ser.subjects;
    const name = ser.name.toLowerCase();
    if (
      name.includes('a1') ||
      name.includes('a2') ||
      name.includes('a ') ||
      name === 'a' ||
      name.includes('litt') ||
      subjects.some(s => s.name === 'Philosophie')
    ) {
      if (v26Philo.length) subjects = mergeSubjects(subjects, v26Philo);
    }
    const prep = getExamPrepForPremiereSeries(ser.name);
    if (prep.length) subjects = mergeSubjects(subjects, prep);
    const extraP = getExtraForPremiereSeries(ser.name);
    if (extraP.length) subjects = mergeSubjects(subjects, extraP);
    subjects = mergeSubjects(subjects, getGabonSubjectsForLevel('premiere'));
    return { ...ser, subjects };
  });
}


/** Injecte contenus d'entraînement ExamPrep dans les séries Terminale (C/D maths, A philo). */
function mergeTerminaleSeries(series: Series[]): Series[] {
  return series.map(ser => {
    let subjects = ser.subjects;
    const extra = getExamPrepForTerminaleSeries(ser.name);
    if (extra.length) subjects = mergeSubjects(subjects, extra);
    const n = ser.name.toLowerCase();
    if (n.includes('d') || n.includes('c') || n.includes('scient')) {
      subjects = mergeSubjects(subjects, [getExtra_terminale_svt(), getExtra_terminale_pc()]);
    }
    if (n.includes('a') || n.includes('litt')) {
      subjects = mergeSubjects(subjects, [
        getExtra_terminale_francais_A(),
        getExtra_terminale_philo_langage(),
        getExtra_terminale_anglais(),
      ]);
    } else {
      subjects = mergeSubjects(subjects, [getExtra_terminale_anglais()]);
    }
    subjects = mergeSubjects(subjects, [getExtra_methodo_bac()]);
    subjects = mergeSubjects(subjects, getGabonSubjectsForLevel('terminale'));
    return { ...ser, subjects };
  });
}

/**
 * Ajoute la matière de démonstration Terminale B — Mathématiques (chapitre
 * "Fonctions" à 5 leçons) APRÈS toute fusion, pour ne jamais passer par
 * ensureUniqueChapterIds (qui ne renumérote que la 1ère leçon d'un chapitre —
 * limite connue du générateur historique, voir lycee-universite.ts).
 */
function attachDemoMultiLessonSubject(series: Series[]): Series[] {
  return series.map((ser) =>
    ser.id === 'serie-b' ? { ...ser, subjects: [...ser.subjects, buildTerminaleBMathDemo()] } : ser
  );
}

export function getLevels(): Level[] {
  return [
    {
      id: 'cm2',
      name: 'CM2',
      category: 'primaire',
      icon: 'GraduationCap',
      color: 'emerald',
      description: 'Cours Moyen 2ème année - Primaire (≈ 5e année)',
      subjects: mergeSubjects(
        mergeSubjects(getCM2Subjects(), getV26SubjectsForLevel('cm2')),
        getGabonSubjectsForLevel('cm2')
      ),
    },
    {
      id: '6e',
      name: '6ème',
      category: 'college',
      icon: 'BookOpen',
      color: 'blue',
      description: 'Sixième - Entrée au collège · Pack Gabon 2024-2025',
      // V2.6 fournit Maths / SVT / PC 6e ; on ne clone plus le CM2 pour ces matières
      subjects: mergeSubjects(
        mergeSubjects(
          mergeSubjects(
            getCM2Subjects()
              .filter(s => !['Mathématiques', 'SVT', 'Physique-Chimie'].includes(s.name))
              .map(s => ({ ...s, id: `6e-${s.id.replace('cm2-', '')}` })),
            getV26SubjectsForLevel('6e')
          ),
          getExtraSubjectsForLevel('6e')
        ),
        getGabonSubjectsForLevel('6e')
      ),
    },
    {
      id: '5e',
      name: '5ème',
      category: 'college',
      icon: 'BookOpen',
      color: 'cyan',
      description: 'Cinquième - Collège',
      subjects: mergeSubjects(
        mergeSubjects(
          mergeSubjects(
            mergeSubjects(get5eSubjects(), getV26SubjectsForLevel('5e')),
            getExamPrepSubjectsForLevel('5e')
          ),
          getExtraSubjectsForLevel('5e')
        ),
        getGabonSubjectsForLevel('5e')
      ),
    },
    {
      id: '4e',
      name: '4ème',
      category: 'college',
      icon: 'BookOpen',
      color: 'teal',
      description: 'Quatrième - Collège',
      subjects: mergeSubjects(
        mergeSubjects(
          mergeSubjects(
            mergeSubjects(get4eSubjects(), getV26SubjectsForLevel('4e')),
            getExamPrepSubjectsForLevel('4e')
          ),
          getExtraSubjectsForLevel('4e')
        ),
        getGabonSubjectsForLevel('4e')
      ),
    },
    {
      id: '3e',
      name: '3ème',
      category: 'college',
      icon: 'BookOpen',
      color: 'indigo',
      description: 'Troisième - Préparation au BEPC',
      subjects: mergeSubjects(
        mergeSubjects(
          mergeSubjects(
            mergeSubjects(get3eSubjects(), getV26SubjectsForLevel('3e')),
            getExamPrepSubjectsForLevel('3e')
          ),
          getExtraSubjectsForLevel('3e')
        ),
        getGabonSubjectsForLevel('3e')
      ),
    },
    {
      id: 'seconde',
      name: 'Seconde',
      category: 'lycee',
      icon: 'School',
      color: 'violet',
      description: 'Seconde LE · Seconde S (tronc commun partagé)',
      hasSeries: true,
      series: (() => {
        const common = mergeSubjects(
          mergeSubjects(
            mergeSubjects(
              mergeSubjects(getSecondeSubjects(), getV26SubjectsForLevel('seconde')),
              getExamPrepSubjectsForLevel('seconde')
            ),
            [getExtra_seconde_anglais()]
          ),
          getGabonSubjectsForLevel('seconde')
        );
        // Tronc commun PARTAGE + packs spécifiques LE / S (IDs distincts)
        const leExtra = getSeriesSpecificSubjects('seconde', 'serie-le');
        const sExtra = getSeriesSpecificSubjects('seconde', 'serie-s');
        return [
          {
            id: 'serie-le',
            name: 'Seconde LE',
            subjects: mergeSubjects(common, leExtra),
          },
          {
            id: 'serie-s',
            name: 'Seconde S',
            subjects: mergeSubjects(common, sExtra),
          },
        ];
      })(),
    },
    {
      id: 'premiere',
      name: 'Première',
      category: 'lycee',
      icon: 'School',
      color: 'purple',
      description: 'Première — A1 · A2 · B · S (compat. A/C/D)',
      hasSeries: true,
      series: mergePremiereSeries(getPremiereSeries()),
    },
    {
      id: 'terminale',
      name: 'Terminale',
      category: 'lycee',
      icon: 'Award',
      color: 'fuchsia',
      description: 'Terminale — A1 · A2 · B · C · D (compat. A)',
      hasSeries: true,
      series: attachDemoMultiLessonSubject(mergeTerminaleSeries(getTerminaleSeries())),
    },
    {
      id: 'universite',
      name: 'Université',
      category: 'universite',
      icon: 'GraduationCap',
      color: 'rose',
      description: 'Filières universitaires',
      hasFilieres: true,
      filieres: mergeUniversityFilieres(getUniversiteFilieres()),
    },
  ];
}

export function getLevelById(id: string): Level | undefined {
  return getLevels().find(l => l.id === id);
}

export function getAllSubjects(): { levelId: string; levelName: string; subject: import('./types').Subject }[] {
  const results: { levelId: string; levelName: string; subject: import('./types').Subject }[] = [];
  for (const level of getLevels()) {
    if (level.subjects) {
      for (const subject of level.subjects) {
        results.push({ levelId: level.id, levelName: level.name, subject });
      }
    }
    if (level.series) {
      for (const series of level.series) {
        for (const subject of series.subjects) {
          results.push({ levelId: level.id, levelName: `${level.name} ${series.name}`, subject });
        }
      }
    }
    if (level.filieres) {
      for (const filiere of level.filieres) {
        for (const subject of filiere.subjects) {
          results.push({ levelId: level.id, levelName: `${level.name} ${filiere.name}`, subject });
        }
      }
    }
  }
  return results;
}
