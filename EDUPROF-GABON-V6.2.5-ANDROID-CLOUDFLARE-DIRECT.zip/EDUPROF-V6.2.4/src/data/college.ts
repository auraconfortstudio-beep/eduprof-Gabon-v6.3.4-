import { makeSubject, type Subject } from './types';

// ─── 5e ──────────────────────────────────────────────────────────
export function get5eSubjects(): Subject[] {
  return [
    makeSubject('mathematiques', 'Mathématiques', 'Calculator', 'blue', '5e', '5ème', [
      {
        title: 'Les fractions et opérations',
        content:
          "Une fraction représente une partie d'un tout. Pour additionner ou soustraire deux fractions, elles doivent avoir le même dénominateur. Si les dénominateurs sont différents, on les réduit au même dénominateur. Pour multiplier deux fractions, on multiplie les numérateurs entre eux et les dénominateurs entre eux. Pour diviser, on multiplie par l'inverse de la deuxième fraction.",
        example: '1/4 + 2/4 = 3/4 (même dénominateur). 1/3 + 1/4 = 4/12 + 3/12 = 7/12 (dénominateur commun = 12).',
        keyPoints: [
          'Pour additionner/soustraire : même dénominateur requis',
          'Pour multiplier : numérateur × numérateur, dénominateur × dénominateur',
          'Pour diviser : multiplier par l\'inverse',
          'On peut simplifier une fraction en divisant numérateur et dénominateur par le même nombre',
        ],
        exercise: {
          q: 'Calcule : 2/3 × 4/5',
          opts: ['8/15', '6/8', '8/3', '10/12'],
          ans: 0,
          exp: 'On multiplie les numérateurs (2×4=8) et les dénominateurs (3×5=15). Résultat : 8/15.',
          method: 'Pour multiplier : multiplie les numérateurs, multiplie les dénominateurs.',
        },
        quiz: [
          { q: 'Calcule 1/2 + 1/4', opts: ['2/6', '3/4', '2/4', '1/6'], ans: 1, exp: 'On réduit au même dénominateur : 2/4 + 1/4 = 3/4.' },
          { q: 'Calcule 3/4 ÷ 1/2', opts: ['3/8', '6/4 (ou 3/2)', '3/2', '4/3'], ans: 1, exp: 'Diviser par 1/2 = multiplier par 2/1. Donc 3/4 × 2/1 = 6/4 = 3/2.' },
          { q: 'Simplifie la fraction 6/9', opts: ['2/3', '3/4', '1/3', '6/3'], ans: 0, exp: 'On divise par 3 : 6÷3=2, 9÷3=3. Donc 2/3.' },
        ],
      },
      {
        title: 'Le triangle et ses propriétés',
        content:
          "Un triangle est une figure géométrique à 3 côtés. La somme des angles d'un triangle fait toujours 180°. Il existe plusieurs types de triangles : équilatéral (3 côtés égaux, 3 angles de 60°), isocèle (2 côtés égaux), rectangle (un angle droit de 90°). L'inégalité triangulaire dit que la somme de deux côtés est toujours supérieure au troisième côté.",
        example: "Un triangle avec des angles de 50°, 60° et 70° : 50+60+70 = 180°. C'est un triangle valide.",
        keyPoints: [
          'La somme des angles d\'un triangle = 180°',
          'Triangle équilatéral : 3 côtés et 3 angles égaux',
          'Triangle isocèle : 2 côtés égaux',
          'Triangle rectangle : un angle de 90°',
        ],
        exercise: {
          q: 'Dans un triangle, deux angles mesurent 45° et 90°. Combien mesure le troisième angle ?',
          opts: ['45°', '90°', '135°', '180°'],
          ans: 0,
          exp: 'La somme fait 180°. 180 - 45 - 90 = 45°. C\'est un triangle rectangle isocèle.',
          method: 'Soustrais les deux angles connus de 180° pour trouver le troisième.',
        },
        quiz: [
          { q: "Quelle est la somme des angles d'un triangle ?", opts: ['90°', '180°', '270°', '360°'], ans: 1, exp: 'La somme des trois angles d\'un triangle est toujours de 180°.' },
          { q: "Un triangle équilatéral a des angles de :", opts: ['30° chacun', '60° chacun', '90° chacun', '45° chacun'], ans: 1, exp: '180° ÷ 3 = 60°. Chaque angle d\'un triangle équilatéral mesure 60°.' },
          { q: 'Un triangle peut avoir les côtés 3, 5, 9 ?', opts: ['Oui', 'Non', 'Parfois', 'Ça dépend'], ans: 1, exp: '3+5=8 < 9. L\'inégalité triangulaire n\'est pas respectée, ce triangle n\'existe pas.' },
        ],
      },
    ]),
    makeSubject('francais', 'Français', 'BookOpen', 'amber', '5e', '5ème', [
      {
        title: 'Le récit et ses étapes',
        content:
          "Un récit est une histoire racontée. Il suit généralement 5 étapes (schéma narratif) : 1) La situation initiale (le décor, les personnages), 2) L'élément perturbateur (un événement qui déclenche l'histoire), 3) Les péripéties (les aventures, les actions), 4) L'élément de résolution (la solution), 5) La situation finale (comment ça finit).",
        example: "Dans Le Petit Chaperon Rouge : 1) Chaperon va voir sa grand-mère, 2) Elle rencontre le loup, 3) Le loup mange la grand-mère, 4) Le chasseur arrive, 5) La grand-mère est sauvée.",
        keyPoints: [
          'Le schéma narratif a 5 étapes',
          'La situation initiale présente le décor',
          "L'élément perturbateur déclenche l'action",
          'La situation finale clôt le récit',
        ],
        exercise: {
          q: "Qu'est-ce que l'élément perturbateur dans un récit ?",
          opts: ["La fin de l'histoire", "L'événement qui déclenche l'action", 'Le décor', 'Les personnages'],
          ans: 1,
          exp: "L'élément perturbateur est l'événement qui rompt la situation initiale et déclenche l'action.",
          method: "Demande-toi : qu'est-ce qui change et lance l'histoire ? C'est l'élément perturbateur.",
        },
        quiz: [
          { q: "Combien d'étapes a le schéma narratif ?", opts: ['3', '4', '5', '6'], ans: 2, exp: 'Le schéma narratif a 5 étapes : initiale, perturbateur, péripéties, résolution, finale.' },
          { q: "Qu'est-ce que la situation initiale ?", opts: ['La fin', 'Le début, le décor', 'L\'action', 'La solution'], ans: 1, exp: 'La situation initiale présente le décor et les personnages au début.' },
          { q: 'Les péripéties sont :', opts: ['La fin', 'Les aventures et actions', 'Le décor', 'Les personnages'], ans: 1, exp: 'Les péripéties sont les actions et aventures qui forment le cœur du récit.' },
        ],
      },
      {
        title: 'Les temps du passé',
        content:
          "Le passé composé exprime une action terminée : « j'ai mangé ». L'imparfait décrit une action qui dure ou un état dans le passé : « je mangeais ». Le passé simple est utilisé dans les récits écrits : « il mangea ». Le plus-que-parfait exprime une action antérieure à une autre action passée : « j'avais mangé ».",
        example: "Quand je suis arrivé (passé composé), elle mangeait (imparfait) car elle n'avait pas encore fini (plus-que-parfait) de préparer le repas.",
        keyPoints: [
          'Passé composé : action terminée (auxiliaire + participe)',
          'Imparfait : action qui dure, description (-ait, -ais)',
          'Passé simple : récit écrit (-a, -it)',
          'Plus-que-parfait : antériorité (avais + participe)',
        ],
        exercise: {
          q: 'Quel temps utilise-t-on pour décrire une scène dans le passé ?',
          opts: ['Passé composé', 'Imparfait', 'Passé simple', 'Futur'],
          ans: 1,
          exp: "L'imparfait est utilisé pour décrire un décor, une scène ou une habitude dans le passé.",
          method: 'Retiens : description/habitude = imparfait, action ponctuelle = passé composé.',
        },
        quiz: [
          { q: 'Comment se forme le passé composé ?', opts: ['Auxiliaire + participe', 'Verbe + -ait', 'Verbe + -a', 'Auxiliaire + -ais'], ans: 0, exp: 'Le passé composé = auxiliaire avoir/être + participe passé.' },
          { q: 'Quel temps pour « Il faisait beau hier » ?', opts: ['Passé composé', 'Imparfait', 'Passé simple', 'Futur'], ans: 1, exp: '« Faisait » est à l\'imparfait, utilisé pour décrire une scène.' },
          { q: 'Le plus-que-parfait exprime :', opts: ['Une action future', 'Une action antérieure au passé', 'Une action présente', 'Une habitude'], ans: 1, exp: 'Le plus-que-parfait exprime une action encore plus ancienne qu\'une autre action passée.' },
        ],
      },
    ]),
    makeSubject('anglais', 'Anglais', 'Languages', 'red', '5e', '5ème', [
      {
        title: 'Le comparatif et le superlatif',
        content:
          "En anglais, pour comparer : court (1 syllabe) : add -er / -est : tall → taller → the tallest. Long (2+ syllabes) : more + adj / the most + adj : beautiful → more beautiful → the most beautiful. Irréguliers : good → better → the best, bad → worse → the worst. On utilise « than » pour le comparatif : « taller than ».",
        example: "Mount Everest is the highest mountain. / A cheetah is faster than a lion. / This is the best book.",
        keyPoints: [
          'Mots courts : +er / +est (tall → taller → tallest)',
          'Mots longs : more / the most (beautiful → more beautiful)',
          'Irréguliers : good → better → best, bad → worse → worst',
          'On utilise « than » pour comparer',
        ],
        exercise: {
          q: 'Compare : « A whale is (big) than a dolphin »',
          opts: ['biger', 'bigger', 'more big', 'biggest'],
          ans: 1,
          exp: 'Big est court, on double le g et ajoute -er : bigger. « A whale is bigger than a dolphin. »',
          method: 'Mot court → double la consonne finale si nécessaire + -er. Utilise « than » pour la comparaison.',
        },
        quiz: [
          { q: 'Quel est le comparatif de « good » ?', opts: ['gooder', 'better', 'more good', 'best'], ans: 1, exp: 'Good est irrégulier : good → better → the best.' },
          { q: 'Comment dit-on « le plus grand » ?', opts: ['the taller', 'the tallest', 'the most tall', 'the taller than'], ans: 1, exp: 'Tall est court : the tallest (avec -est et « the »).' },
          { q: 'Quel est le superlatif de « bad » ?', opts: ['the baddest', 'the worst', 'the most bad', 'the worse'], ans: 1, exp: 'Bad est irrégulier : bad → worse → the worst.' },
        ],
      },
    ]),
    makeSubject('svt', 'SVT', 'Leaf', 'green', '5e', '5ème', [
      {
        title: 'La respiration et les échanges gazeux',
        content:
          "Tous les êtres vivants respirent. La respiration consiste à absorber du dioxygène (O2) et à rejeter du dioxyde de carbone (CO2). Chez l'humain, l'air entre par le nez ou la bouche, passe par la trachée, puis les bronches et arrive dans les alvéoles pulmonaires. C'est là que se font les échanges gazeux : le dioxygène passe dans le sang et le CO2 passe dans l'air expiré.",
        example: "Quand tu cours, tu respires plus vite car tes muscles ont besoin de plus de dioxygène pour fonctionner.",
        keyPoints: [
          'La respiration : absorber O2, rejeter CO2',
          "L'air passe par le nez, la trachée, les bronches, les alvéoles",
          "Les échanges gazeux se font dans les alvéoles pulmonaires",
          'Le sang transporte le dioxygène vers les muscles',
        ],
        exercise: {
          q: 'Quel gaz absorbe-t-on en respirant ?',
          opts: ['Dioxyde de carbone', 'Dioxygène', 'Azote', 'Hydrogène'],
          ans: 1,
          exp: 'On absorbe du dioxygène (O2) et on rejette du dioxyde de carbone (CO2).',
          method: 'Retiens : O2 entre (oxygène), CO2 sort (dioxyde de carbone).',
        },
        quiz: [
          { q: 'Où se font les échanges gazeux ?', opts: ['Dans le nez', 'Dans la trachée', 'Dans les alvéoles', 'Dans le cœur'], ans: 2, exp: 'Les alvéoles pulmonaires sont le lieu des échanges gazeux entre l\'air et le sang.' },
          { q: 'Quel gaz rejette-t-on en expirant ?', opts: ['O2', 'CO2', 'Azote', 'Hélium'], ans: 1, exp: 'On rejette du dioxyde de carbone (CO2) en expirant.' },
          { q: "Par où entre l'air en premier ?", opts: ['Les alvéoles', 'Le nez ou la bouche', 'La trachée', 'Les bronches'], ans: 1, exp: "L'air entre d'abord par le nez ou la bouche, puis va vers la trachée." },
        ],
      },
    ]),
    makeSubject('physique-chimie', 'Physique-Chimie', 'Atom', 'indigo', '5e', '5ème', [
      {
        title: "Les états de la matière",
        content:
          "La matière existe en 3 états principaux : solide, liquide et gazeux. Dans un solide, les particules sont serrées et immobiles (forme fixe). Dans un liquide, les particules sont proches mais peuvent glisser (prend la forme du récipient). Dans un gaz, les particules sont éloignées et libres (remplit tout l'espace disponible). On peut passer d'un état à l'autre par changement de température : fusion (solide→liquide), solidification (liquide→solide), vaporisation (liquide→gaz), liquéfaction (gaz→liquide).",
        example: "La glace fond à 0°C (fusion). L'eau bout à 100°C (vaporisation). La vapeur d'eau se condense sur une vitre froide (liquéfaction).",
        keyPoints: [
          '3 états : solide, liquide, gazeux',
          'Solide : forme fixe, particules serrées',
          'Liquide : prend la forme du récipient',
          'Gaz : remplit tout l\'espace disponible',
        ],
        exercise: {
          q: "Comment s'appelle le passage de l'état liquide à l'état gazeux ?",
          opts: ['Fusion', 'Solidification', 'Vaporisation', 'Condensation'],
          ans: 2,
          exp: "La vaporisation est le passage du liquide au gaz (par exemple, l'eau qui bout).",
          method: 'Retiens : fusion = solide→liquide, vaporisation = liquide→gaz, condensation = gaz→liquide.',
        },
        quiz: [
          { q: "À quelle température l'eau gèle-t-elle ?", opts: ['0°C', '50°C', '100°C', '-10°C'], ans: 0, exp: "L'eau gèle (solidification) à 0°C." },
          { q: 'Dans un gaz, les particules sont :', opts: ['Serrées et immobiles', 'Proches et glissantes', 'Éloignées et libres', 'Inexistantes'], ans: 2, exp: 'Dans un gaz, les particules sont très éloignées et se déplacent librement.' },
          { q: 'La fusion est le passage :', opts: ['Liquide→gaz', 'Solide→liquide', 'Gaz→liquide', 'Liquide→solide'], ans: 1, exp: 'La fusion est le passage de l\'état solide à l\'état liquide (la glace qui fond).' },
        ],
      },
    ]),
    makeSubject('histoire', 'Histoire', 'Landmark', 'orange', '5e', '5ème', [
      {
        title: "Peuples et sociétés du Gabon avant la colonisation",
        content:
          "Bien avant la colonisation, le territoire de l'actuel Gabon était peuplé de sociétés organisées : villages, chefferies, réseaux d'échanges (fer, sel, produits de la forêt, contacts avec la côte). Les langues et cultures des peuples du Gabon (fang, punu, nzebi, myene, téké, kota, etc.) se sont formées sur le temps long. L'histoire du Gabon ne commence pas en 1960 : elle inclut ces périodes antérieures, transmises aussi par l'oralité.",
        example: "Les routes commerciales et les migrations bantu ont façonné l'Afrique centrale longtemps avant les frontières modernes.",
        keyPoints: [
          'Sociétés organisées avant la colonisation',
          'Échanges régionaux (fer, sel, forêt, côte)',
          'Peuples et langues du Gabon',
          'Oralité et mémoire',
        ],
        exercise: {
          q: "Avant la colonisation, le territoire gabonais connaissait :",
          opts: ['aucune société organisée', 'des villages, chefferies et échanges', 'uniquement des usines pétrolières', 'uniquement Internet'],
          ans: 1,
          exp: "Des sociétés organisées et des échanges existaient bien avant la colonisation.",
          method: "Ne réduis pas l'histoire du Gabon à la seule période coloniale.",
        },
        quiz: [
          { q: "L'oralité au Gabon sert surtout à :", opts: ['rien', 'transmettre histoires et valeurs', 'remplacer les maths', 'interdire l\'école'], ans: 1, exp: 'Contes, proverbes, généalogies.' },
          { q: "Le Gabon se situe en :", opts: ['Afrique australe polaire', 'Afrique centrale', 'Europe', 'Asie de l\'Est'], ans: 1, exp: 'Afrique centrale.' },
          { q: "Réduire l'histoire du Gabon à 1960 seulement :", opts: ['est complet', 'oublie les périodes antérieures', 'est obligatoire', 'est la seule méthode scientifique'], ans: 1, exp: 'Il faut la longue durée.' },
        ],
      },
    ]),
    makeSubject('geographie', 'Géographie', 'Map', 'teal', '5e', '5ème', [
      {
        title: 'Les climats et la végétation',
        content:
          "Le climat d'une région dépend de sa latitude (distance par rapport à l'équateur), de son altitude et de sa proximité avec la mer. On distingue plusieurs grandes zones climatiques : équatorial (chaud et humide toute l'année), tropical (saison sèche et saison des pluies), désertique (sec et chaud), tempéré (4 saisons), polaire (très froid). Chaque climat correspond à une végétation spécifique : forêt équatoriale, savane, désert, forêt tempérée, toundra.",
        example: "Le Gabon a un climat équatorial : il fait chaud et humide toute l'année, avec une forêt dense qui couvre la majeure partie du pays.",
        keyPoints: [
          'Le climat dépend de la latitude, l\'altitude, la mer',
          'Climat équatorial : chaud et humide toute l\'année',
          'Climat tropical : saison sèche + saison des pluies',
          'Chaque climat correspond à une végétation',
        ],
        exercise: {
          q: 'Quel climat a le Gabon ?',
          opts: ['Tempéré', 'Désertique', 'Équatorial', 'Polaire'],
          ans: 2,
          exp: "Le Gabon, situé sur l'équateur, a un climat équatorial : chaud et humide toute l'année.",
          method: "Regarde la position par rapport à l'équateur : sur l'équateur = équatorial, près = tropical.",
        },
        quiz: [
          { q: 'Quelle végétation correspond au climat équatorial ?', opts: ['Désert', 'Forêt dense', 'Toundra', 'Savane'], ans: 1, exp: 'Le climat équatorial produit une forêt dense et humide.' },
          { q: 'Combien de saisons a le climat tropical ?', opts: ['1', '2', '4', '6'], ans: 1, exp: 'Le climat tropical a 2 saisons : une saison sèche et une saison des pluies.' },
          { q: 'Quel facteur influence le climat ?', opts: ['La latitude', 'L\'altitude', 'La mer', 'Tous ces facteurs'], ans: 3, exp: 'Le climat dépend de la latitude, l\'altitude et la proximité de la mer.' },
        ],
      },
    ]),
    makeSubject('technologie', 'Technologie', 'Cog', 'slate', '5e', '5ème', [
      {
        title: "L'énergie et ses sources",
        content:
          "L'énergie est nécessaire au fonctionnement des objets techniques. Il existe des énergies renouvelables (soleil, vent, eau, biomasse) qui se renouvellent naturellement, et des énergies non renouvelables (pétrole, charbon, gaz, nucléaire) qui s'épuisent. Le choix de la source d'énergie a un impact sur l'environnement : les énergies fossiles produisent du CO2, les renouvelables sont plus propres.",
        example: "Un panneau solaire transforme l'énergie du soleil en électricité. Une voiture à essence utilise l'énergie du pétrole.",
        keyPoints: [
          'Énergies renouvelables : soleil, vent, eau, biomasse',
          'Énergies non renouvelables : pétrole, charbon, gaz, nucléaire',
          'Les énergies fossiles produisent du CO2',
          'Les renouvelables sont plus propres mais intermittentes',
        ],
        exercise: {
          q: 'Le pétrole est une énergie :',
          opts: ['Renouvelable', 'Non renouvelable', 'Propre', 'Inépuisable'],
          ans: 1,
          exp: "Le pétrole est une énergie fossile non renouvelable : il s'épuise et produit du CO2.",
          method: "Demande-toi : cette énergie se renouvelle-t-elle naturellement ? Si non, c'est non renouvelable.",
        },
        quiz: [
          { q: 'Quelle est une énergie renouvelable ?', opts: ['Pétrole', 'Charbon', 'Soleil', 'Gaz'], ans: 2, exp: "L'énergie solaire est renouvelable car le soleil se renouvelle en permanence." },
          { q: 'Quel gaz les énergies fossiles produisent-elles ?', opts: ['O2', 'CO2', 'Azote', 'Hélium'], ans: 1, exp: 'Les énergies fossiles produisent du dioxyde de carbone (CO2), un gaz à effet de serre.' },
          { q: "L'éolienne utilise l'énergie :", opts: ['Du soleil', 'Du vent', 'De l\'eau', 'Du pétrole'], ans: 1, exp: "L'éolienne transforme l'énergie du vent en électricité." },
        ],
      },
    ]),
    makeSubject('espagnol', 'Espagnol', 'Languages', 'rose', '5e', '5ème', [
      {
        title: 'Se présenter en espagnol',
        content:
          "Pour se présenter en espagnol : « Me llamo... » (Je m'appelle...), « Tengo... años » (J'ai... ans), « Vivo en... » (J'habite à...), « Me gusta... » (J'aime...). Les pronoms personnels : yo (je), tú (tu), él/ella (il/elle), nosotros/nosotras (nous), vosotros/vosotras (vous), ellos/ellas (ils/elles).",
        example: "Me llamo Carlos. Tengo 13 años. Vivo en Libreville. Me gusta el fútbol.",
        keyPoints: [
          'Me llamo = je m\'appelle',
          'Tengo... años = j\'ai... ans',
          'Vivo en = j\'habite à',
          'Me gusta = j\'aime',
        ],
        exercise: {
          q: 'Comment dit-on « J\'ai 13 ans » en espagnol ?',
          opts: ['Tengo 13 años', 'Soy 13 años', 'Tengo 13', 'Yo 13 años'],
          ans: 0,
          exp: 'En espagnol, on utilise « tener » (avoir) : « Tengo 13 años ».',
          method: 'Retiens : Tengo (du verbe tener) + nombre + años.',
        },
        quiz: [
          { q: 'Que veut dire « Me llamo » ?', opts: ["J'habite", "Je m'appelle", "J'aime", "J'ai"], ans: 1, exp: '« Me llamo » signifie « je m\'appelle ».' },
          { q: 'Comment dit-on « J\'aime le football » ?', opts: ['Me gusta el fútbol', 'Me llamo el fútbol', 'Vivo el fútbol', 'Tengo el fútbol'], ans: 0, exp: '« Me gusta » = j\'aime, « el fútbol » = le football.' },
          { q: 'Que veut dire « Vivo en Gabón » ?', opts: ["J'aime le Gabon", "J'habite au Gabon", "Je viens du Gabon", "Je visite le Gabon"], ans: 1, exp: '« Vivir » = habiter. « Vivo en » = j\'habite à/au.' },
        ],
      },
    ]),
  ];
}

// ─── 4e ──────────────────────────────────────────────────────────
export function get4eSubjects(): Subject[] {
  return [
    makeSubject('mathematiques', 'Mathématiques', 'Calculator', 'blue', '4e', '4ème', [
      {
        title: 'Le théorème de Pythagore',
        content:
          "Le théorème de Pythagore s'applique dans un triangle rectangle. Il dit : dans un triangle rectangle, le carré de l'hypoténuse (le côté le plus long, opposé à l'angle droit) est égal à la somme des carrés des deux autres côtés. Si on note a et b les deux côtés de l'angle droit et c l'hypoténuse : a² + b² = c². Ce théorème permet de calculer une longueur quand on connaît les deux autres.",
        example: "Si a = 3 et b = 4, alors c² = 9 + 16 = 25, donc c = √25 = 5. C'est le fameux triangle 3-4-5.",
        keyPoints: [
          "Le théorème s'applique uniquement dans un triangle rectangle",
          "L'hypoténuse est le côté le plus long, opposé à l'angle droit",
          'a² + b² = c² (où c est l\'hypoténuse)',
          'Permet de calculer une longueur inconnue',
        ],
        exercise: {
          q: "Dans un triangle rectangle, les côtés de l'angle droit mesurent 6 et 8. Quelle est la longueur de l'hypoténuse ?",
          opts: ['10', '14', '12', '100'],
          ans: 0,
          exp: 'c² = 6² + 8² = 36 + 64 = 100. Donc c = √100 = 10.',
          method: 'Calcule a² + b², puis prends la racine carrée du résultat pour obtenir c.',
        },
        quiz: [
          { q: "Qu'est-ce que l'hypoténuse ?", opts: ['Le côté le plus court', 'Le côté le plus long', "L'angle droit", 'La hauteur'], ans: 1, exp: "L'hypoténuse est le côté le plus long du triangle rectangle, opposé à l'angle droit." },
          { q: 'Si a=5 et b=12, quelle est l\'hypoténuse ?', opts: ['13', '17', '15', '60'], ans: 0, exp: 'c² = 25 + 144 = 169, c = √169 = 13.' },
          { q: "Le théorème de Pythagore s'applique :", opts: ['Dans tout triangle', 'Dans un triangle rectangle', 'Dans un cercle', 'Dans un carré'], ans: 1, exp: "Le théorème de Pythagore ne s'applique que dans les triangles rectangles." },
        ],
      },
      {
        title: 'Les puissances',
        content:
          "Une puissance est une écriture qui simplifie les multiplications répétées. a^n signifie « a multiplié n fois par lui-même ». Par exemple, 2³ = 2 × 2 × 2 = 8. Les règles : a^m × a^n = a^(m+n), a^m ÷ a^n = a^(m-n), (a^m)^n = a^(m×n), a^0 = 1, a^(-n) = 1/a^n. Les puissances de 10 sont très utilisées en sciences : 10³ = 1000, 10^6 = 1 000 000.",
        example: "10² = 100, 10³ = 1000, 10^6 = 1 million. 2^4 = 16 (2×2×2×2).",
        keyPoints: [
          'a^n = a multiplié n fois par lui-même',
          'a^m × a^n = a^(m+n)',
          'a^0 = 1 (tout nombre à la puissance 0 vaut 1)',
          'a^(-n) = 1/a^n',
        ],
        exercise: {
          q: 'Calcule : 2³ × 2²',
          opts: ['2⁵ (ou 32)', '2⁶ (ou 64)', '4⁵ (ou 1024)', '2 (ou 2)'],
          ans: 0,
          exp: '2³ × 2² = 2^(3+2) = 2⁵ = 32. On additionne les exposants quand on multiplie les mêmes bases.',
          method: 'Quand on multiplie des puissances de même base, on additionne les exposants : a^m × a^n = a^(m+n).',
        },
        quiz: [
          { q: 'Combien fait 5² ?', opts: ['10', '25', '52', '7'], ans: 1, exp: '5² = 5 × 5 = 25.' },
          { q: 'Combien fait 10⁰ ?', opts: ['0', '1', '10', '100'], ans: 1, exp: 'Tout nombre à la puissance 0 vaut 1.' },
          { q: 'Combien fait 2^(-1) ?', opts: ['-2', '0.5', '1', '-1'], ans: 1, exp: '2^(-1) = 1/2 = 0.5.' },
        ],
      },
    ]),
    makeSubject('francais', 'Français', 'BookOpen', 'amber', '4e', '4ème', [
      {
        title: 'Les figures de style',
        content:
          "Les figures de style rendent le langage plus expressif. La comparaison rapproche deux éléments avec un outil de comparaison (comme, tel, semblable à) : « fort comme un lion ». La métaphore rapproche sans outil : « cet homme est un lion ». La personnification donne des traits humains à des non-humains : « le vent murmure ». L'hyperbole exagère : « je meurs de faim ».",
        example: 'Comparaison : « elle est belle comme une rose ». Métaphore : « cette femme est une rose ». Personnification : « la lune sourit ».',
        keyPoints: [
          'Comparaison : rapproche avec un outil (comme, tel)',
          'Métaphore : rapproche sans outil de comparaison',
          'Personnification : donne des traits humains à un objet/animal',
          'Hyperbole : exagère la réalité',
        ],
        exercise: {
          q: 'Quelle figure de style est utilisée dans « Le soleil sourit » ?',
          opts: ['Comparaison', 'Métaphore', 'Personnification', 'Hyperbole'],
          ans: 2,
          exp: 'On donne la capacité humaine de sourire au soleil. C\'est une personnification.',
          method: 'Demande-toi : donne-t-on un trait humain à un non-humain ? Si oui, c\'est une personnification.',
        },
        quiz: [
          { q: 'Quelle est la différence entre comparaison et métaphore ?', opts: ['Aucune', 'La comparaison utilise un outil (comme)', 'La métaphore utilise un outil', 'La métaphore est plus longue'], ans: 1, exp: 'La comparaison utilise un outil de comparaison (comme, tel), la métaphore non.' },
          { q: '« Je meurs de faim » est une :', opts: ['Comparaison', 'Métaphore', 'Hyperbole', 'Personnification'], ans: 2, exp: 'C\'est une exagération, donc une hyperbole.' },
          { q: '« Cet homme est un lion » est une :', opts: ['Comparaison', 'Métaphore', 'Personnification', 'Hyperbole'], ans: 1, exp: 'On assimile l\'homme à un lion sans outil de comparaison, c\'est une métaphore.' },
        ],
      },
      {
        title: 'Les propositions et la phrase complexe',
        content:
          "Une phrase complexe contient plusieurs propositions. Une proposition est un groupe de mots avec un verbe. On distingue : la proposition indépendante (elle se suffit à elle-même), la proposition principale (elle commande une subordonnée), la proposition subordonnée (elle dépend d'une autre). Les propositions peuvent être coordonnées (avec et, mais, ou, donc...) ou juxtaposées (avec :, ;, ,) ou subordonnées (avec qui, que, parce que...).",
        example: "« Il pleut et je reste à la maison » : deux propositions coordonnées par « et ».",
        keyPoints: [
          'Une proposition = un groupe de mots avec un verbe',
          'Proposition indépendante : se suffit à elle-même',
          'Proposition principale : commande une subordonnée',
          'Coordonnées (et, mais, ou) / juxtaposées (:, ;) / subordonnées (qui, que, parce que)',
        ],
        exercise: {
          q: 'Combien de propositions y a-t-il dans « Je mange et je dors » ?',
          opts: ['1', '2', '3', '4'],
          ans: 1,
          exp: 'Il y a deux verbes conjugués (mange, dors), donc deux propositions, coordonnées par « et ».',
          method: 'Compte les verbes conjugués : un verbe = une proposition.',
        },
        quiz: [
          { q: 'Qu\'est-ce qu\'une proposition indépendante ?', opts: ['Elle dépend d\'une autre', 'Elle se suffit à elle-même', 'Elle n\'a pas de verbe', 'Elle est toujours première'], ans: 1, exp: 'Une proposition indépendante se suffit à elle-même, elle a un sens complet.' },
          { q: '« Il pleut parce qu\'il y a des nuages » contient :', opts: ['1 proposition', '2 propositions subordonnées', '2 propositions coordonnées', '3 propositions'], ans: 1, exp: 'Deux propositions reliées par « parce que » : une principale et une subordonnée.' },
          { q: 'Les propositions coordonnées sont reliées par :', opts: ['Qui, que', 'Et, mais, ou, donc', ':, ;', 'Parce que'], ans: 1, exp: 'Les coordonnantes sont : et, mais, ou, donc, or, ni, car.' },
        ],
      },
    ]),
    makeSubject('anglais', 'Anglais', 'Languages', 'red', '4e', '4ème', [
      {
        title: 'Le prétérit et le past continuous',
        content:
          "Le prétérit (past simple) exprime une action terminée dans le passé : « I played football yesterday ». On ajoute -ed aux verbes réguliers. Le past continuous décrit une action en cours dans le passé : « I was playing when he arrived ». On utilise was/were + verbe-ing. Le prétérit pour une action ponctuelle, le past continuous pour une action en cours interrompue.",
        example: "I was studying (action en cours) when the phone rang (action ponctuelle qui interrompt).",
        keyPoints: [
          'Prétérit : action terminée (verbe + -ed pour les réguliers)',
          'Past continuous : was/were + verbe-ing',
          'Prétérit = action ponctuelle',
          'Past continuous = action en cours dans le passé',
        ],
        exercise: {
          q: 'Conjugue au prétérit : « She (visit) her grandmother »',
          opts: ['visit', 'visited', 'visiting', 'visits'],
          ans: 1,
          exp: 'Visit est un verbe régulier : on ajoute -ed → visited.',
          method: 'Verbe régulier au prétérit : ajoute -ed à la base verbale.',
        },
        quiz: [
          { q: 'Comment forme-t-on le past continuous ?', opts: ['have + participe', 'was/were + verbe-ing', 'verbe + -ed', 'will + verbe'], ans: 1, exp: 'Le past continuous = was/were + verbe-ing.' },
          { q: 'Quel temps pour « I was reading when she called » ?', opts: ['Présent', 'Prétérit', 'Past continuous + prétérit', 'Futur'], ans: 2, exp: '« Was reading » = past continuous, « called » = prétérit.' },
          { q: 'Le prétérit exprime :', opts: ['Une action en cours', 'Une action terminée', 'Une habitude présente', 'Une action future'], ans: 1, exp: 'Le prétérit exprime une action terminée dans le passé.' },
        ],
      },
    ]),
    makeSubject('svt', 'SVT', 'Leaf', 'green', '4e', '4ème', [
      {
        title: 'La reproduction humaine',
        content:
          "La reproduction humaine est sexuée. Elle implique la fusion d'un spermatozoïde (cellule reproductrice mâle) et d'un ovule (cellule reproductrice femelle), c'est la fécondation. La fécondation a lieu dans les trompes de Fallope. L'ovule fécondé (cellule-œuf) se fixe ensuite dans l'utérus où il se développe pendant 9 mois : c'est la grossesse. Le bébé naît ensuite par accouchement.",
        example: "Un spermatozoïde (très petit, mobile) féconde un ovule (plus grand, immobile) pour former une cellule-œuf.",
        keyPoints: [
          'La fécondation = fusion du spermatozoïde et de l\'ovule',
          'La fécondation a lieu dans les trompes de Fallope',
          "L'ovule fécondé se développe dans l'utérus pendant 9 mois",
          'Le bébé naît par accouchement',
        ],
        exercise: {
          q: "Comment s'appelle la fusion du spermatozoïde et de l'ovule ?",
          opts: ['Grossesse', 'Fécondation', 'Accouchement', 'Ovulation'],
          ans: 1,
          exp: "La fécondation est la fusion d'un spermatozoïde et d'un ovule, qui forme une cellule-œuf.",
          method: 'Retiens : fécondation = fusion des deux cellules reproductrices.',
        },
        quiz: [
          { q: "Où a lieu la fécondation ?", opts: ["Dans l'utérus", 'Dans les trompes de Fallope', 'Dans les ovaires', 'Dans le vagin'], ans: 1, exp: "La fécondation a lieu dans les trompes de Fallope, puis l'ovule fécondé migre vers l'utérus." },
          { q: "Combien de temps dure la grossesse ?", opts: ['6 mois', '9 mois', '12 mois', '3 mois'], ans: 1, exp: "La grossesse dure environ 9 mois, pendant lesquels le bébé se développe dans l'utérus." },
          { q: 'Quelle est la cellule reproductrice mâle ?', opts: ['L\'ovule', 'Le spermatozoïde', 'La cellule-œuf', 'L\'utérus'], ans: 1, exp: 'Le spermatozoïde est la cellule reproductrice mâle, petit et mobile.' },
        ],
      },
    ]),
    makeSubject('physique-chimie', 'Physique-Chimie', 'Atom', 'indigo', '4e', '4ème', [
      {
        title: "L'atome et la matière",
        content:
          "Toute la matière est composée d'atomes. Un atome est constitué d'un noyau (protons + neutrons) autour duquel gravitent des électrons. Le noyau est petit mais lourd, les électrons sont légers. Un atome est électriquement neutre : autant de protons (positifs) que d'électrons (négatifs). Les atomes se combinent pour former des molécules : par exemple, H2O = 2 atomes d'hydrogène + 1 atome d'oxygène.",
        example: "L'eau (H2O) est une molécule composée de 2 atomes d'hydrogène et 1 atome d'oxygène.",
        keyPoints: [
          "L'atome = noyau (protons + neutrons) + électrons",
          "Le noyau est petit mais contient presque toute la masse",
          'Un atome est électriquement neutre',
          'Les atomes forment des molécules (H2O, CO2...)',
        ],
        exercise: {
          q: 'De quoi est composé le noyau d\'un atome ?',
          opts: ['Électrons uniquement', 'Protons et neutrons', 'Molécules', 'Atomes'],
          ans: 1,
          exp: 'Le noyau est composé de protons (positifs) et de neutrons (neutres). Les électrons gravitent autour.',
          method: 'Retiens : noyau = protons + neutrons, électrons = autour du noyau.',
        },
        quiz: [
          { q: 'Quelle est la charge d\'un proton ?', opts: ['Négative', 'Positive', 'Neutre', 'Variable'], ans: 1, exp: 'Le proton a une charge positive.' },
          { q: 'La molécule H2O contient combien d\'atomes ?', opts: ['1', '2', '3', '4'], ans: 2, exp: 'H2O = 2 atomes d\'hydrogène + 1 atome d\'oxygène = 3 atomes.' },
          { q: 'L\'électron a une charge :', opts: ['Positive', 'Négative', 'Neutre', 'Variable'], ans: 1, exp: "L'électron a une charge négative." },
        ],
      },
    ]),
    makeSubject('histoire', 'Histoire', 'Landmark', 'orange', '4e', '4ème', [
      {
        title: "L'indépendance du Gabon (1960)",
        content:
          "Le Gabon accède à l'indépendance le 17 août 1960. Cette date marque la fin de la période coloniale et la naissance de l'État gabonais souverain. L'indépendance s'inscrit dans le mouvement de décolonisation de l'Afrique dans les années 1960. Depuis, le pays construit ses institutions, développe ses villes (Libreville, Port-Gentil, Franceville…) et valorise ses ressources (pétrole, bois, mines) tout en relevant les défis du développement et de l'unité nationale.",
        example: "Le 17 août est la fête nationale du Gabon : on commémore l'indépendance et la souveraineté du pays.",
        keyPoints: [
          '17 août 1960 : indépendance du Gabon',
          'Fin de la période coloniale',
          'État souverain en Afrique centrale',
          'Fête nationale gabonaise',
        ],
        exercise: {
          q: "Quelle est la date de l'indépendance du Gabon ?",
          opts: ['14 juillet 1789', '17 août 1960', '1er janvier 2000', '11 novembre 1918'],
          ans: 1,
          exp: "Le Gabon est indépendant depuis le 17 août 1960.",
          method: 'Retiens : 17 août 1960 = fête nationale / indépendance.',
        },
        quiz: [
          { q: "En quelle année le Gabon devient-il indépendant ?", opts: ['1958', '1960', '1962', '1970'], ans: 1, exp: 'Indépendance en 1960.' },
          { q: "La capitale du Gabon indépendant est :", opts: ['Port-Gentil', 'Libreville', 'Franceville', 'Oyem'], ans: 1, exp: 'Libreville est la capitale politique.' },
          { q: "L'indépendance du Gabon s'inscrit surtout dans :", opts: ['la Révolution industrielle européenne seule', 'la décolonisation de l\'Afrique', 'la Préhistoire', 'la fondation de Rome'], ans: 1, exp: 'Vague d\'indépendances africaines vers 1960.' },
        ],
      },
    ]),
    makeSubject('geographie', 'Géographie', 'Map', 'teal', '4e', '4ème', [
      {
        title: "L'urbanisation et les villes",
        content:
          "L'urbanisation est la croissance des villes. Aujourd'hui, plus de la moitié de la population mondiale vit en ville. Les villes attirent les populations par les emplois, les services, les études. Mais l'urbanisation pose des problèmes : logements, transports, pollution, pauvreté. Dans les pays en développement, des bidonvilles se forment autour des grandes villes. Au Gabon, Libreville concentre une grande partie de la population.",
        example: "Libreville, la capitale du Gabon, attire de nombreux ruraux qui cherchent du travail et des services.",
        keyPoints: [
          "Plus de la moitié de l'humanité vit en ville",
          "Les villes attirent par les emplois et les services",
          "L'urbanisation pose des problèmes : logement, transports, pollution",
          "Les bidonvilles se forment dans les pays en développement",
        ],
        exercise: {
          q: "Quelle proportion de la population mondiale vit en ville aujourd'hui ?",
          opts: ['Environ 10%', 'Environ 30%', 'Plus de la moitié', 'Environ 90%'],
          ans: 2,
          exp: "Aujourd'hui, plus de la moitié de la population mondiale vit en ville, et ce nombre augmente.",
          method: "Retiens : l'urbanisation est un phénomène mondial majeur, plus de 50% en ville.",
        },
        quiz: [
          { q: 'Pourquoi les villes attirent-elles les populations ?', opts: ['Pour le calme', 'Pour les emplois et services', 'Pour la nature', 'Pour l\'agriculture'], ans: 1, exp: "Les villes attirent par les emplois, les services (santé, école) et les opportunités." },
          { q: "Qu'est-ce qu'un bidonville ?", opts: ['Un quartier riche', 'Un quartier pauvre avec des habitations précaires', 'Un parc', 'Une zone rurale'], ans: 1, exp: "Un bidonville est un quartier où s'entassent des populations pauvres dans des habitations précaires." },
          { q: "Au Gabon, quelle ville concentre beaucoup de population ?", opts: ['Oyem', 'Libreville', 'Makokou', 'Tchibanga'], ans: 1, exp: "Libreville, la capitale, concentre une grande partie de la population gabonaise." },
        ],
      },
    ]),
    makeSubject('technologie', 'Technologie', 'Cog', 'slate', '4e', '4ème', [
      {
        title: 'Le programme et l\'algorithme',
        content:
          "Un programme est une suite d'instructions données à un ordinateur pour accomplir une tâche. Un algorithme est la méthode, la logique pour résoudre un problème. On écrit les algorithmes en langage naturel ou en pseudo-code, puis on les traduit en langage de programmation. Les structures de base : la séquence (instructions en ordre), la condition (si... alors...), la boucle (répéter... jusqu'à...).",
        example: "Algorithme pour faire du thé : 1) Faire bouillir de l'eau, 2) Mettre le thé dans la tasse, 3) Verser l'eau, 4) Attendre 3 minutes, 5) Retirer le thé.",
        keyPoints: [
          'Un programme = suite d\'instructions pour un ordinateur',
          'Un algorithme = méthode pour résoudre un problème',
          'Séquence : instructions en ordre',
          'Condition (si...alors) et boucle (répéter...jusqu\'à)',
        ],
        exercise: {
          q: "Qu'est-ce qu'un algorithme ?",
          opts: ['Un langage de programmation', 'Une méthode pour résoudre un problème', 'Un ordinateur', 'Un programme'],
          ans: 1,
          exp: "Un algorithme est la méthode, la logique étape par étape pour résoudre un problème, avant de le traduire en programme.",
          method: "Demande-toi : est-ce la logique (algorithme) ou le code (programme) ?",
        },
        quiz: [
          { q: "Qu'est-ce qu'une condition en programmation ?", opts: ['Une boucle', 'Un test (si...alors)', 'Une séquence', 'Une variable'], ans: 1, exp: "Une condition permet d'exécuter des instructions seulement si un test est vrai." },
          { q: 'À quoi sert une boucle ?', opts: ['À tester une condition', 'À répéter des instructions', 'À stocker une valeur', 'À afficher un résultat'], ans: 1, exp: "Une boucle permet de répéter des instructions plusieurs fois." },
          { q: 'La différence entre algorithme et programme :', opts: ['Aucune', 'L\'algorithme est la logique, le programme est le code', 'Le programme est la logique', 'L\'algorithme est plus rapide'], ans: 1, exp: "L'algorithme est la méthode (logique), le programme est la traduction en code." },
        ],
      },
    ]),
    makeSubject('espagnol', 'Espagnol', 'Languages', 'rose', '4e', '4ème', [
      {
        title: 'Le passé simple en espagnol',
        content:
          "Le passé simple (pretérito indefinido) en espagnol exprime une action terminée dans le passé. Pour les verbes en -ar : -é, -aste, -ó, -amos, -asteis, -aron. Pour les verbes en -er/-ir : -í, -iste, -ió, -imos, -isteis, -ieron. Exemple : hablar → hablé, hablaste, habló... Il est utilisé pour des actions ponctuelles : « Ayer comí pizza » (Hier j'ai mangé une pizza).",
        example: "Ayer fui al cine. (Hier je suis allé au cinéma.) / Comí una manzana. (J'ai mangé une pomme.)",
        keyPoints: [
          'Le pretérito indefinido exprime une action terminée',
          'Verbes en -ar : -é, -aste, -ó, -amos, -asteis, -aron',
          'Verbes en -er/-ir : -í, -iste, -ió, -imos, -isteis, -ieron',
          'Utilisé pour des actions ponctuelles dans le passé',
        ],
        exercise: {
          q: 'Conjugue « hablar » à « yo » au passé simple :',
          opts: ['hablo', 'hablé', 'hablaba', 'hablaré'],
          ans: 1,
          exp: 'Le verbe hablar (en -ar) à yo au passé simple prend la terminaison -é : hablé.',
          method: 'Verbe en -ar + yo au passé = radical + -é.',
        },
        quiz: [
          { q: 'Comment dit-on « je mangeai » (comer) ?', opts: ['comí', 'comé', 'comí', 'comó'], ans: 0, exp: 'Comer (en -er) à yo prend -í : comí.' },
          { q: 'Que veut dire « Ayer fui al cine » ?', opts: ['Demain j\'irai au cinéma', 'Hier je suis allé au cinéma', 'Je vais au cinéma', 'J\'aime le cinéma'], ans: 1, exp: '« Ayer » = hier, « fui » = je suis allé (ir, irrégulier).' },
          { q: 'Le passé simple espagnol exprime :', opts: ['Une action future', 'Une action terminée', 'Une habitude', 'Une description'], ans: 1, exp: 'Le pretérito indefinido exprime une action ponctuelle terminée dans le passé.' },
        ],
      },
    ]),
  ];
}

// ─── 3e ──────────────────────────────────────────────────────────
export function get3eSubjects(): Subject[] {
  return [
    makeSubject('mathematiques', 'Mathématiques', 'Calculator', 'blue', '3e', '3ème', [
      {
        title: 'Le théorème de Thalès',
        content:
          "Le théorème de Thalès s'applique quand deux droites parallèles sont coupées par deux droites sécantes. Il dit que les longueurs des segments formés sont proportionnelles. Si (BC) et (DE) sont parallèles, alors : AB/AD = AC/AE = BC/DE. Ce théorème permet de calculer des longueurs inconnues dans des configurations de triangles.",
        example: "Si AB = 3, AD = 5, BC = 6, alors DE = ? On a : 3/5 = 6/DE, donc DE = (5×6)/3 = 10.",
        keyPoints: [
          "Le théorème s'applique avec deux droites parallèles",
          'Les longueurs sont proportionnelles : AB/AD = AC/AE = BC/DE',
          'Permet de calculer des longueurs inconnues',
          "Vérifie que les droites sont bien parallèles avant de l'appliquer",
        ],
        exercise: {
          q: 'Si AB = 4, AD = 6, AC = 8, quelle est la valeur de AE ?',
          opts: ['10', '12', '14', '16'],
          ans: 1,
          exp: 'AB/AD = AC/AE → 4/6 = 8/AE → AE = (8×6)/4 = 12.',
          method: 'Écris la proportionnalité : AB/AD = AC/AE, puis isole la valeur inconnue.',
        },
        quiz: [
          { q: "Quand peut-on appliquer le théorème de Thalès ?", opts: ['Dans tout triangle', 'Avec deux droites parallèles coupées par deux sécantes', 'Dans un cercle', 'Dans un carré'], ans: 1, exp: "Le théorème de Thalès nécessite deux droites parallèles coupées par deux droites sécantes." },
          { q: 'Si AB = 2, AD = 4, BC = 3, alors DE = ?', opts: ['5', '6', '7', '8'], ans: 1, exp: '2/4 = 3/DE → DE = (4×3)/2 = 6.' },
          { q: 'Le théorème de Thalès utilise :', opts: ['Les angles', 'Les proportions', 'Les aires', 'Les puissances'], ans: 1, exp: "Le théorème de Thalès utilise les proportions entre les longueurs des segments." },
        ],
      },
      {
        title: 'Les fonctions et équations',
        content:
          "Une fonction est une relation qui à chaque nombre x associe un nombre y. On note f(x) = y. Par exemple, f(x) = 2x + 3 : pour x = 4, f(4) = 11. Une équation est une égalité avec une inconnue. Pour résoudre une équation, on isole l'inconnue. Par exemple : 2x + 3 = 11 → 2x = 8 → x = 4.",
        example: "f(x) = 3x - 5. Pour x = 2 : f(2) = 3×2 - 5 = 1. L'image de 2 par f est 1.",
        keyPoints: [
          'Une fonction associe à chaque x un y = f(x)',
          'f(x) = ax + b est une fonction affine',
          'Résoudre une équation = isoler l\'inconnue',
          'On peut vérifier en remplaçant x par la solution',
        ],
        exercise: {
          q: 'Résous l\'équation : 3x - 7 = 14',
          opts: ['x = 5', 'x = 7', 'x = 3', 'x = 21'],
          ans: 1,
          exp: '3x - 7 = 14 → 3x = 21 → x = 7. Vérification : 3×7 - 7 = 14.',
          method: 'Isole x : ajoute 7 des deux côtés, puis divise par 3.',
        },
        quiz: [
          { q: 'Si f(x) = 2x + 1, combien vaut f(3) ?', opts: ['5', '6', '7', '8'], ans: 2, exp: 'f(3) = 2×3 + 1 = 7.' },
          { q: 'Résous : x + 5 = 12', opts: ['x = 5', 'x = 7', 'x = 17', 'x = 60'], ans: 1, exp: 'x = 12 - 5 = 7.' },
          { q: 'Une fonction affine a la forme :', opts: ['f(x) = ax + b', 'f(x) = x²', 'f(x) = 1/x', 'f(x) = √x'], ans: 0, exp: 'Une fonction affine s\'écrit f(x) = ax + b.' },
        ],
      },
    ]),
    makeSubject('francais', 'Français', 'BookOpen', 'amber', '3e', '3ème', [
      {
        title: 'L\'argumentation et le texte persuasif',
        content:
          "Un texte argumentatif vise à convaincre ou persuader le lecteur. Il se compose de : une thèse (l'opinion défendue), des arguments (les raisons qui soutiennent la thèse), des exemples (des illustrations concrètes). On peut utiliser des connecteurs logiques : d'abord, ensuite, en effet, cependant, donc, par conséquent. L'objectif est d'amener le lecteur à partager le point de vue de l'auteur.",
        example: "Thèse : « Le sport est bénéfique pour la santé. » Argument : « Il renforce le cœur. » Exemple : « Les sportifs ont moins de maladies cardiovasculaires. »",
        keyPoints: [
          'Un texte argumentatif défend une thèse',
          'Les arguments soutiennent la thèse',
          'Les exemples illustrent les arguments',
          'Les connecteurs logiques structurent le texte',
        ],
        exercise: {
          q: "Qu'est-ce qu'une thèse dans un texte argumentatif ?",
          opts: ['Un exemple', 'L\'opinion défendue', 'Un argument', 'Une conclusion'],
          ans: 1,
          exp: "La thèse est l'opinion, le point de vue que l'auteur défend dans son texte.",
          method: "Demande-toi : quelle est l'opinion principale de l'auteur ? C'est la thèse.",
        },
        quiz: [
          { q: 'Quel est le rôle d\'un argument ?', opts: ['Illustrer', 'Soutenir la thèse', 'Contredire', 'Résumer'], ans: 1, exp: "Un argument soutient la thèse en donnant une raison." },
          { q: '« En effet » est un connecteur :', opts: ['D\'opposition', 'De cause', 'D\'addition', 'De conclusion'], ans: 1, exp: '« En effet » introduit une explication, une cause.' },
          { q: 'Un exemple sert à :', opts: ['Donner une opinion', 'Illustrer un argument', 'Contredire', 'Finir le texte'], ans: 1, exp: "Un exemple illustre concrètement un argument." },
        ],
      },
    ]),
    makeSubject('anglais', 'Anglais', 'Languages', 'red', '3e', '3ème', [
      {
        title: 'Le present perfect et le modaux',
        content:
          "Le present perfect exprime une action passée avec un lien au présent : « I have eaten » (j'ai mangé). On utilise have/has + participe passé. Les marqueurs : already, yet, just, ever, never, for, since. Les modaux (can, must, should, might...) expriment la possibilité, l'obligation, le conseil : « You should study » (tu devrais étudier), « You must go » (tu dois aller).",
        example: "I have lived here for 5 years. / She has already finished. / You should rest.",
        keyPoints: [
          'Present perfect : have/has + participe passé',
          'Exprime une action passée liée au présent',
          'Marqueurs : already, yet, just, for, since',
          'Modaux : can, must, should, might (possibilité, obligation, conseil)',
        ],
        exercise: {
          q: 'Conjugue : « She (finish) her homework already »',
          opts: ['finished', 'has finished', 'is finishing', 'finishes'],
          ans: 1,
          exp: 'Avec « already » et un lien au présent, on utilise le present perfect : has finished.',
          method: 'already/just/ever/never → present perfect : have/has + participe passé.',
        },
        quiz: [
          { q: 'Comment forme-t-on le present perfect ?', opts: ['verbe + -ed', 'have/has + participe passé', 'was + verbe-ing', 'will + verbe'], ans: 1, exp: 'Le present perfect = have/has + participe passé.' },
          { q: 'Quel modal pour un conseil ?', opts: ['must', 'should', 'can', 'will'], ans: 1, exp: "« Should » exprime un conseil : you should study." },
          { q: '« I have lived here since 2010 » utilise :', opts: ['for', 'since', 'already', 'just'], ans: 1, exp: '« Since » est utilisé avec un point de départ (2010), « for » avec une durée.' },
        ],
      },
    ]),
    makeSubject('svt', 'SVT', 'Leaf', 'green', '3e', '3ème', [
      {
        title: 'La génétique et l\'hérédité',
        content:
          "La génétique étudie l'hérédité, c'est-à-dire la transmission des caractères des parents aux enfants. Chaque être humain possède 46 chromosomes (23 paires) dans chacune de ses cellules. Les gènes, situés sur les chromosomes, portent les informations génétiques. Chaque enfant reçoit la moitié de ses chromosomes de son père et l'autre moitié de sa mère. C'est pourquoi on ressemble à ses parents sans être identique.",
        example: "La couleur des yeux est déterminée par des gènes. Si tes parents ont les yeux bruns, tu as plus de chances d'avoir les yeux bruns aussi.",
        keyPoints: [
          'L\'humain a 46 chromosomes (23 paires)',
          'Les gènes portent l\'information génétique',
          'On reçoit la moitié des chromosomes de chaque parent',
          'L\'hérédité explique pourquoi on ressemble à ses parents',
        ],
        exercise: {
          q: 'Combien de chromosomes possède un être humain ?',
          opts: ['23', '46', '48', '92'],
          ans: 1,
          exp: 'Un être humain possède 46 chromosomes, organisés en 23 paires, dans chacune de ses cellules.',
          method: 'Retiens : 46 chromosomes = 23 paires. La moitié vient du père, l\'autre de la mère.',
        },
        quiz: [
          { q: 'Où se trouvent les gènes ?', opts: ['Dans le sang', 'Sur les chromosomes', 'Dans le cœur', 'Dans la peau'], ans: 1, exp: 'Les gènes sont situés sur les chromosomes, dans le noyau des cellules.' },
          { q: 'Combien de chromosomes reçoit-on de chaque parent ?', opts: ['46', '23', '92', 'Aucun'], ans: 1, exp: 'On reçoit 23 chromosomes de chaque parent, soit 46 au total.' },
          { q: 'La génétique étudie :', opts: ['Les maladies', 'L\'hérédité', 'L\'écologie', 'La respiration'], ans: 1, exp: "La génétique étudie l'hérédité, la transmission des caractères." },
        ],
      },
    ]),
    makeSubject('physique-chimie', 'Physique-Chimie', 'Atom', 'indigo', '3e', '3ème', [
      {
        title: 'Les réactions chimiques',
        content:
          "Une réaction chimique est une transformation de la matière : des réactifs (substances de départ) se transforment en produits (nouvelles substances). La réaction respecte la conservation de la masse (Lavoisier) : rien ne se perd, rien ne se crée, tout se transforme. On écrit une équation chimique : réactifs → produits. Par exemple : C + O₂ → CO₂ (combustion du carbone).",
        example: "La combustion du méthane : CH₄ + 2O₂ → CO₂ + 2H₂O. Les réactifs (CH₄ et O₂) se transforment en produits (CO₂ et H₂O).",
        keyPoints: [
          'Une réaction chimique transforme les réactifs en produits',
          'La masse se conserve (rien ne se perd, rien ne se crée)',
          'On écrit : réactifs → produits',
          'L\'équation doit être équilibrée (autant d\'atomes de chaque côté)',
        ],
        exercise: {
          q: 'Qui a énoncé le principe de conservation de la masse ?',
          opts: ['Newton', 'Lavoisier', 'Einstein', 'Pasteur'],
          ans: 1,
          exp: "Lavoisier a énoncé : « Rien ne se perd, rien ne se crée, tout se transforme. » C'est le principe de conservation de la masse.",
          method: 'Retiens : Lavoisier = conservation de la masse dans les réactions chimiques.',
        },
        quiz: [
          { q: 'Dans une réaction chimique, les substances de départ s\'appellent :', opts: ['Les produits', 'Les réactifs', 'Les catalyseurs', 'Les solvants'], ans: 1, exp: 'Les réactifs sont les substances de départ qui se transforment en produits.' },
          { q: 'Dans C + O₂ → CO₂, que sont C et O₂ ?', opts: ['Les produits', 'Les réactifs', 'Les catalyseurs', 'Les déchets'], ans: 1, exp: 'C et O₂ sont les réactifs (à gauche de la flèche), CO₂ est le produit (à droite).' },
          { q: 'La conservation de la masse signifie :', opts: ['La masse diminue', 'La masse augmente', 'La masse reste identique', 'La masse disparaît'], ans: 2, exp: 'La masse totale des réactifs = la masse totale des produits.' },
        ],
      },
    ]),
    makeSubject('histoire', 'Histoire', 'Landmark', 'orange', '3e', '3ème', [
      {
        title: 'La Première Guerre mondiale',
        content:
          "La Première Guerre mondiale (1914-1918) a opposé les Alliés (dont la France, le Royaume-Uni, la Russie, puis les USA) aux Empires centraux (Allemagne, Autriche-Hongrie). Les causes : rivalités coloniales, nationalisme, alliances militaires. L'étincelle : l'assassinat de l'archiduc François-Ferdinand à Sarajevo (28 juin 1914). La guerre a fait environ 10 millions de morts. Elle s'est terminée le 11 novembre 1918 (armistice).",
        example: "Le 11 novembre 1918, à 11 heures, l'armistice est signé dans un wagon à Rethondes. C'est la fin des combats.",
        keyPoints: [
          'La Première Guerre mondiale : 1914-1918',
          'Alliés vs Empires centraux',
          'Assassinat de François-Ferdinand à Sarajevo (28 juin 1914)',
          'Armistice le 11 novembre 1918',
        ],
        exercise: {
          q: 'Quand a eu lieu l\'armistice de la Première Guerre mondiale ?',
          opts: ['11 novembre 1918', '11 novembre 1914', '28 juin 1914', '8 mai 1945'],
          ans: 0,
          exp: "L'armistice a été signé le 11 novembre 1918, marquant la fin des combats de la Première Guerre mondiale.",
          method: 'Retiens : 11 novembre 1918 = armistice de la Première Guerre mondiale.',
        },
        quiz: [
          { q: 'Quel événement a déclenché la Première Guerre mondiale ?', opts: ['La chute de Rome', 'L\'assassinat de François-Ferdinand', 'La Révolution russe', 'L\'indépendance du Gabon'], ans: 1, exp: "L'assassinat de l'archiduc François-Ferdinand à Sarajevo le 28 juin 1914 a déclenché la guerre." },
          { q: 'Combien de morts a fait la Première Guerre mondiale ?', opts: ['1 million', '10 millions', '50 millions', '100 millions'], ans: 1, exp: 'La Première Guerre mondiale a fait environ 10 millions de morts.' },
          { q: 'Parmi les Alliés de 1914-1918 on trouve notamment :', opts: ['Empires centraux', 'Alliés', 'Pays neutres', 'Aucun camp'], ans: 1, exp: 'Les Alliés comprenaient notamment la France, le Royaume-Uni et la Russie.' },
        ],
      },
    ]),
    makeSubject('geographie', 'Géographie', 'Map', 'teal', '3e', '3ème', [
      {
        title: 'Le développement et les inégalités',
        content:
          "Le développement désigne le niveau de vie et le bien-être d'une population. On le mesure avec l'IDH (Indicateur de Développement Humain) qui prend en compte l'espérance de vie, l'éducation et le revenu. Il existe de grandes inégalités entre les pays développés (Europe, Amérique du Nord, Japon) et les pays en développement (Afrique, Asie du Sud). Le Gabon est un pays en développement avec des ressources naturelles (pétrole, manganèse) mais des inégalités importantes.",
        example: "L'IDH du Gabon est moyen : le pays a des ressources mais la richesse est mal répartie.",
        keyPoints: [
          'Le développement = niveau de vie et bien-être',
          'L\'IDH mesure : espérance de vie, éducation, revenu',
          'Inégalités entre pays développés et en développement',
          'Le Gabon a des ressources mais des inégalités',
        ],
        exercise: {
          q: 'Que mesure l\'IDH ?',
          opts: ['La population uniquement', 'L\'espérance de vie, l\'éducation et le revenu', 'Le PIB uniquement', 'La superficie'],
          ans: 1,
          exp: "L'IDH (Indicateur de Développement Humain) prend en compte l'espérance de vie, le niveau d'éducation et le revenu par habitant.",
          method: 'Retiens : IDH = santé + éducation + revenu.',
        },
        quiz: [
          { q: 'Le Gabon est un pays :', opts: ['Développé', 'En développement', 'Émergent', 'Pauvre'], ans: 1, exp: 'Le Gabon est un pays en développement avec des ressources naturelles mais des inégalités.' },
          { q: 'Quelles ressources naturelles a le Gabon ?', opts: ['Or et argent', 'Pétrole et manganèse', 'Diamant et uranium', 'Blé et riz'], ans: 1, exp: 'Le Gabon est riche en pétrole et en manganèse (minerais).' },
          { q: 'Un pays développé a généralement :', opts: ['Un IDH bas', 'Un IDH élevé', 'Pas d\'IDH', 'Un IDH négatif'], ans: 1, exp: "Les pays développés ont un IDH élevé (bonne santé, éducation, revenus)." },
        ],
      },
    ]),
    makeSubject('eps', 'EPS', 'Activity', 'lime', '3e', '3ème', [
      {
        title: 'La préparation physique et la santé',
        content:
          "La préparation physique vise à améliorer ses capacités pour un sport ou pour la santé. Elle comprend : le cardio-training (endurance), le renforcement musculaire (force), les étirements (souplesse). Une bonne hygiène de vie associe activité physique régulière (au moins 30 minutes par jour), alimentation équilibrée, sommeil suffisant (8 heures), hydratation. Le sport réduit le stress, prévient les maladies cardiovasculaires et améliore la santé mentale.",
        example: "Courir 30 minutes 3 fois par semaine, manger équilibré, dormir 8 heures = bonne hygiène de vie.",
        keyPoints: [
          'Au moins 30 minutes d\'activité physique par jour',
          'Le sport prévient les maladies cardiovasculaires',
          'Une bonne hygiène de vie : sport + alimentation + sommeil',
          'Le sport améliore aussi la santé mentale',
        ],
        exercise: {
          q: "Combien de temps d'activité physique est recommandé par jour ?",
          opts: ['10 minutes', '30 minutes', '2 heures', '5 minutes'],
          ans: 1,
          exp: "L'OMS recommande au moins 30 minutes d'activité physique par jour pour rester en bonne santé.",
          method: 'Retiens : 30 minutes par jour minimum pour rester en bonne santé.',
        },
        quiz: [
          { q: 'Le sport aide à :', opts: ['Augmenter le stress', 'Réduire le stress', 'Avoir moins de sommeil', 'Manger plus'], ans: 1, exp: "L'activité physique régulière réduit le stress et améliore la santé mentale." },
          { q: 'Combien d\'heures de sommeil sont recommandées ?', opts: ['4 heures', '6 heures', '8 heures', '12 heures'], ans: 2, exp: "8 heures de sommeil sont recommandées pour un adolescent." },
          { q: 'Une bonne hygiène de vie associe :', opts: ['Sport uniquement', 'Sport + alimentation + sommeil', 'Alimentation uniquement', 'Sommeil uniquement'], ans: 1, exp: 'Une bonne hygiène de vie combine activité physique, alimentation équilibrée et sommeil suffisant.' },
        ],
      },
    ]),
  ];
}
