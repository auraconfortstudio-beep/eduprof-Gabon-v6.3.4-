/**
 * Contenus pédagogiques + exercices d’entraînement EduProf Gabon (originaux, non officiels).
 * Chaque unité : cours + plusieurs exercices (facile → difficile) + quiz.
 */
import { makeSubject, type Subject, type TopicData, type TopicExercise } from './types';

function ex(
  q: string,
  opts: string[],
  ans: number,
  exp: string,
  method: string,
  difficulty: 'facile' | 'intermediaire' | 'difficile' = 'intermediaire'
): TopicExercise {
  return { q, opts, ans, exp, method, difficulty };
}

function qz(q: string, opts: string[], ans: number, exp: string) {
  return { q, opts, ans, exp };
}

// ——— 5e Maths ———
const maths5e: TopicData[] = [
  {
    title: 'Nombres relatifs et opérations',
    content:
      "Les nombres relatifs comprennent les positifs, les négatifs et zéro. Sur une droite graduée, les négatifs sont à gauche de 0.\\n\\nAddition : mêmes signes → on additionne les valeurs absolues et on garde le signe ; signes contraires → on soustrait et on garde le signe de la plus grande valeur absolue.\\n\\nMultiplication / division : signes identiques → résultat positif ; signes contraires → résultat négatif.",
    example: '(−5)+(−3)=−8 ; (−5)+8=3 ; (−4)×(−3)=12 ; (−12)÷3=−4.',
    keyPoints: ['Droite graduée', 'Règles de signes', 'Valeur absolue', 'Opposé'],
    exercise: ex('(−7)+(+3) = ?', ['−10', '−4', '4', '10'], 1, 'Signes contraires : 7−3=4, signe du plus grand en VA (−) → −4.', 'Règle d’addition des relatifs.', 'facile'),
    exercises: [
      ex('(−7)+(+3) = ?', ['−10', '−4', '4', '10'], 1, '7−3=4 avec signe − → −4.', 'Addition relatifs.', 'facile'),
      ex('(−6)×(+4) = ?', ['24', '−24', '−10', '10'], 1, 'Signes contraires → négatif : −24.', 'Règle des signes.', 'facile'),
      ex('(−15)+(−8)+(10) = ?', ['−13', '−33', '13', '7'], 0, '−15−8=−23 ; −23+10=−13.', 'Calcul en chaîne.', 'intermediaire'),
      ex('L’opposé de (−12) est :', ['−12', '12', '0', '1/12'], 1, 'L’opposé de −a est a.', 'Définition.', 'facile'),
      ex('(−2)³ = ?', ['−6', '−8', '8', '6'], 1, '(−2)×(−2)×(−2)=4×(−2)=−8.', 'Puissance impaire d’un négatif.', 'difficile'),
    ],
    quiz: [
      qz('Sur une droite, −3 est à … de 0', ['droite', 'gauche', 'même place', 'au-dessus'], 1, 'Négatifs à gauche.'),
      qz('(+5)×(−1)×(−2) = ?', ['−10', '10', '−7', '7'], 1, 'Deux négatifs → positif global.'),
    ],
  },
  {
    title: 'Symétrie centrale et axiale',
    content:
      "Symétrie axiale (réflexion) : chaque point et son image sont à égale distance de l’axe, de part et d’autre.\\nSymétrie centrale de centre O : O est le milieu du segment joignant un point à son image (demi-tour de 180°).\\nCes transformations conservent les distances, les angles et les aires.",
    example: 'Si O est milieu de [AA′], A′ est le symétrique de A par rapport à O.',
    keyPoints: ['Axe', 'Centre', 'Conservation des longueurs', 'Image d’une figure'],
    exercise: ex('Dans une symétrie centrale de centre O, si OA=4 cm alors OA′= ?', ['2 cm', '4 cm', '8 cm', '0'], 1, 'O milieu ⇒ OA=OA′.', 'Définition.', 'facile'),
    exercises: [
      ex('Dans une symétrie centrale de centre O, si OA=4 cm alors OA′= ?', ['2 cm', '4 cm', '8 cm', '0'], 1, 'O milieu ⇒ distances égales.', 'Définition.', 'facile'),
      ex('Le symétrique d’un segment de 5 cm par une symétrie axiale mesure :', ['2,5 cm', '5 cm', '10 cm', 'variable'], 1, 'Conservation des longueurs.', 'Propriété.', 'facile'),
      ex('Combien d’axes de symétrie a un carré ?', ['1', '2', '3', '4'], 3, 'Deux diagonales + deux médianes.', 'Géométrie plane.', 'intermediaire'),
      ex('Le symétrique du point (2;−1) par rapport à l’origine O(0;0) est :', ['(−2;1)', '(2;1)', '(−2;−1)', '(1;−2)'], 0, 'Symétrie centrale : (−x;−y).', 'Coordonnées.', 'difficile'),
    ],
    quiz: [
      qz('Une symétrie axiale s’appelle aussi :', ['translation', 'réflexion', 'homothétie', 'rotation 90°'], 1, 'Réflexion / miroir.'),
      qz('La symétrie centrale est une rotation de :', ['90°', '180°', '270°', '360°'], 1, 'Demi-tour.'),
    ],
  },
];

// ——— 4e Maths ———
const maths4e: TopicData[] = [
  {
    title: 'Théorème de Pythagore',
    content:
      "Dans un triangle rectangle, si c est l’hypoténuse et a, b les côtés de l’angle droit : a² + b² = c².\\n\\nRéciproque : si dans un triangle a² + b² = c² (c plus grand côté), alors le triangle est rectangle en l’angle opposé à c.\\n\\nApplications : calcul de longueurs, vérification d’angle droit, distances.",
    example: '3²+4²=9+16=25=5² → triangle 3-4-5 rectangle.',
    keyPoints: ['Hypoténuse', 'a²+b²=c²', 'Réciproque', 'Triangle 3-4-5'],
    exercise: ex('Côtés 6 et 8, triangle rectangle. Hypoténuse ?', ['10', '14', '7', '12'], 0, '√(36+64)=√100=10.', 'Pythagore.', 'facile'),
    exercises: [
      ex('Côtés de l’angle droit 6 et 8. Hypoténuse ?', ['10', '14', '7', '12'], 0, '√(36+64)=10.', 'a²+b²=c².', 'facile'),
      ex('Hypoténuse 13, un côté 5. L’autre côté ?', ['12', '8', '10', '18'], 0, '√(169−25)=√144=12.', 'c²−a²=b².', 'intermediaire'),
      ex('Triangle de côtés 7, 24, 25. Est-il rectangle ?', ['Oui', 'Non', 'Impossible', 'Seulement isocèle'], 0, '49+576=625=25².', 'Réciproque.', 'intermediaire'),
      ex('Échelle de 5 m appuyée à 3 m du mur. Hauteur atteinte ?', ['4 m', '8 m', '2 m', '√34 m'], 0, '√(25−9)=4.', 'Modélisation.', 'difficile'),
      ex('Dans un carré de côté 5, longueur de la diagonale ?', ['5', '10', '5√2', '25'], 2, '√(25+25)=√50=5√2.', 'Pythagore dans le carré.', 'difficile'),
    ],
    quiz: [
      qz('L’hypoténuse est :', ['le plus petit côté', 'le côté opposé à l’angle droit', 'un côté de l’angle droit', 'la hauteur'], 1, 'Côté opposé à 90°.'),
      qz('Si a²+b² < c² (c plus grand), le triangle est :', ['rectangle', 'acutangle', 'obtusangle', 'équilatéral'], 2, 'Angle opposé à c obtus.'),
    ],
  },
  {
    title: 'Puissances et notation scientifique',
    content:
      "aⁿ = a multiplié n fois. a¹=a ; a⁰=1 (a≠0) ; a⁻ⁿ=1/aⁿ.\\n\\nProduits : aᵐ×aⁿ=aᵐ⁺ⁿ ; quotient aᵐ/aⁿ=aᵐ⁻ⁿ ; (aᵐ)ⁿ=aᵐⁿ.\\n\\nNotation scientifique : nombre écrit A×10ⁿ avec 1≤|A|<10.",
    example: '4 700 000=4,7×10⁶ ; 0,0032=3,2×10⁻³.',
    keyPoints: ['Exposants', 'Puissances négatives', 'Notation scientifique'],
    exercise: ex('45 000 en notation scientifique', ['4,5×10⁴', '45×10³', '4,5×10³', '0,45×10⁵'], 0, '4,5×10⁴.', '1 chiffre avant la virgule.', 'facile'),
    exercises: [
      ex('45 000 = ?', ['4,5×10⁴', '45×10³', '4,5×10³', '0,45×10⁵'], 0, '4,5×10⁴.', 'Notation scientifique.', 'facile'),
      ex('10⁻³ = ?', ['0,001', '0,01', '1000', '−1000'], 0, '1/1000=0,001.', 'Puissance négative.', 'facile'),
      ex('2³ × 2⁵ = ?', ['2⁸', '2¹⁵', '4⁸', '2²'], 0, '2³⁺⁵=2⁸.', 'Produit de puissances.', 'intermediaire'),
      ex('(3²)³ = ?', ['3⁵', '3⁶', '9³', '3⁹'], 1, '3²ˣ³=3⁶.', '(aᵐ)ⁿ=aᵐⁿ.', 'intermediaire'),
      ex('0,00056 = ?', ['5,6×10⁻⁴', '56×10⁻⁵', '5,6×10⁻³', '0,56×10⁻³'], 0, '5,6×10⁻⁴.', 'Notation scientifique.', 'difficile'),
    ],
    quiz: [
      qz('a⁰ (a≠0) vaut :', ['0', '1', 'a', 'indéfini'], 1, 'Convention a⁰=1.'),
      qz('Dans A×10ⁿ scientifique, |A| est :', ['<1', 'entre 1 et 10', '>10', 'entier seulement'], 1, '1≤|A|<10.'),
    ],
  },
];

// ——— 3e Maths ———
const maths3e: TopicData[] = [
  {
    title: 'Théorème de Thalès et applications',
    content:
      "Si une droite parallèle à un côté d’un triangle coupe les deux autres côtés, elle détermine des segments proportionnels.\\n\\nConfiguration : (DE)∥(BC), D sur [AB], E sur [AC] ⇒ AD/AB = AE/AC = DE/BC.\\n\\nRéciproque (sous conditions) : égalité des rapports ⇒ parallélisme. Utile pour calculer des longueurs manquantes.",
    example: 'AD=3, AB=9, AE=2, DE∥BC ⇒ AC=6.',
    keyPoints: ['Parallélisme', 'Rapports égaux', 'Longueurs', 'Réciproque'],
    exercise: ex('DE∥BC, AD=4, DB=6, AE=5. AC = ?', ['7,5', '12,5', '9', '5'], 1, 'AD/AB=4/10=0,4 ; AC=5/0,4=12,5.', 'Thalès.', 'facile'),
    exercises: [
      ex('DE∥BC, AD=4, DB=6, AE=5. AC = ?', ['7,5', '12,5', '9', '5'], 1, '4/10=AE/AC ⇒ AC=12,5.', 'Thalès.', 'facile'),
      ex('DE∥BC, AB=12, AD=3, AC=20. AE = ?', ['5', '4', '15', '8'], 0, 'AD/AB=3/12=1/4 ; AE=20/4=5.', 'Proportionnalité.', 'intermediaire'),
      ex('AD/AB=2/5, AE=6, DE∥BC. AC = ?', ['15', '12', '9', '2,4'], 0, '2/5=6/AC ⇒ AC=15.', 'Thalès.', 'intermediaire'),
      ex('Dans un triangle, AD=5, AB=15, AE=4, AC=12. Peut-on conclure DE∥BC ?', ['Oui', 'Non', 'Seulement si angle droit', 'Données insuffisantes'], 0, '5/15=4/12=1/3 → réciproque.', 'Réciproque de Thalès.', 'difficile'),
      ex('DE∥BC, DE=4, BC=10, AD=6. AB = ?', ['15', '12', '2,4', '24'], 0, 'DE/BC=AD/AB ⇒ 4/10=6/AB ⇒ AB=15.', 'Rapport DE/BC.', 'difficile'),
    ],
    quiz: [
      qz('Thalès nécessite :', ['un angle droit', 'une parallèle à un côté', 'un cercle', 'des côtés égaux'], 1, 'Parallélisme.'),
      qz('Les rapports de Thalès sont :', ['des sommes', 'des produits', 'des quotients de longueurs', 'des angles'], 2, 'Segments proportionnels.'),
    ],
  },
  {
    title: 'Équations et inéquations du premier degré',
    content:
      "Équation ax+b=c : isoler x en appliquant les mêmes opérations des deux côtés.\\n\\nInéquation : même principe, mais multiplier ou diviser par un nombre négatif inverse le sens de l’inégalité.\\n\\nSolution d’une inéquation : souvent un intervalle de ℝ.",
    example: '3x−5≥7 ⇒ 3x≥12 ⇒ x≥4 ; S=[4;+∞[.',
    keyPoints: ['Isoler x', 'Sens de l’inégalité', 'Intervalle solution'],
    exercise: ex('Résoudre −2x+4<10', ['x>−3', 'x<−3', 'x>3', 'x<3'], 0, '−2x<6 ⇒ x>−3 (division par −2).', 'Inverser si facteur négatif.', 'facile'),
    exercises: [
      ex('3x−5=10. x = ?', ['5', '15/3', '5', '3'], 0, '3x=15 ⇒ x=5.', 'Équation simple.', 'facile'),
      ex('−2x+4<10. Solution :', ['x>−3', 'x<−3', 'x>3', 'x<3'], 0, 'Inverser en divisant par −2.', 'Inéquation.', 'facile'),
      ex('5−x≥2. S = ?', ['x≤3', 'x≥3', 'x≤7', 'x≥−3'], 0, '−x≥−3 ⇒ x≤3.', 'Sens inversé.', 'intermediaire'),
      ex('(2x−1)/3=5. x = ?', ['8', '16', '7', '5,5'], 0, '2x−1=15 ⇒ 2x=16 ⇒ x=8.', 'Multiplier par 3.', 'intermediaire'),
      ex('−4(x−1)≥12. S = ?', ['x≤−2', 'x≥−2', 'x≤4', 'x≥4'], 0, 'x−1≤−3 ⇒ x≤−2.', 'Développer puis inverser.', 'difficile'),
    ],
    quiz: [
      qz('Multiplier une inégalité par −1 :', ['conserve le sens', 'inverse le sens', 'interdit', 'met au carré'], 1, 'Règle des inéquations.'),
      qz('[2;5[ contient :', ['5', '2', '1', '6'], 1, '2 inclus, 5 exclu.'),
    ],
  },
  {
    title: 'Trigonométrie dans le triangle rectangle',
    content:
      "Dans un triangle rectangle d’angle aigu Â :\\ncos Â = adjacent / hypoténuse\\nsin Â = opposé / hypoténuse\\ntan Â = opposé / adjacent\\n\\nIdentité : cos²Â + sin²Â = 1.",
    example: 'Côtés 3 ; 4 ; 5. Angle opposé à 3 : sin=3/5, cos=4/5, tan=3/4.',
    keyPoints: ['sin, cos, tan', 'Hypoténuse', 'Identité fondamentale'],
    exercise: ex('Hypoténuse 10, opposé à Â = 6. sin Â = ?', ['0,6', '0,8', '1,5', '0,5'], 0, '6/10=0,6.', 'Définition sinus.', 'facile'),
    exercises: [
      ex('Hypoténuse 10, opposé 6. sin Â ?', ['0,6', '0,8', '1,5', '0,5'], 0, 'opposé/hyp=0,6.', 'sin.', 'facile'),
      ex('adjacent 8, hyp 10. cos Â ?', ['0,8', '0,6', '1,25', '0,2'], 0, '8/10=0,8.', 'cos.', 'facile'),
      ex('opposé 5, adjacent 12. tan Â ?', ['5/12', '12/5', '5/13', '13/5'], 0, 'opp/adj=5/12.', 'tan.', 'intermediaire'),
      ex('sin Â=0,6 et triangle rectangle. cos Â = ? (positif)', ['0,8', '0,4', '1,0', '0,36'], 0, 'cos²=1−0,36=0,64 ⇒ cos=0,8.', 'Identité.', 'difficile'),
      ex('tan Â=3/4, adjacent=8. opposé = ?', ['6', '32/3', '4', '10'], 0, 'opp=tan×adj=6.', 'Définition tan.', 'intermediaire'),
    ],
    quiz: [
      qz('tan Â = ?', ['adj/opp', 'opp/adj', 'opp/hyp', 'adj/hyp'], 1, 'opposé/adjacent.'),
      qz('cos²+sin² vaut :', ['0', '1', '2', 'tan'], 1, 'Identité fondamentale.'),
    ],
  },
  {
    title: 'Statistiques : moyenne, médiane, étendue',
    content:
      "Moyenne = somme / effectif.\\nMédiane = valeur centrale de la série ordonnée (ou demi-somme des deux centrales si effectif pair).\\nÉtendue = max − min.\\nCes indicateurs résument une série de données (notes, mesures…).",
    example: '8,10,12,14,16 → moyenne 12 ; médiane 12 ; étendue 8.',
    keyPoints: ['Moyenne', 'Médiane', 'Étendue', 'Série ordonnée'],
    exercise: ex('Série 5,7,9,11,13. Médiane ?', ['9', '8', '11', '7'], 0, 'Terme central.', 'Ordonner puis milieu.', 'facile'),
    exercises: [
      ex('Série 5,7,9,11,13. Médiane ?', ['9', '8', '11', '7'], 0, 'Valeur centrale.', 'Médiane.', 'facile'),
      ex('Notes 10,12,8,15,10. Moyenne ?', ['11', '10', '12', '9'], 0, '55/5=11.', 'Somme/effectif.', 'facile'),
      ex('Série 3,5,7,9. Médiane ?', ['5', '6', '7', '4'], 1, '(5+7)/2=6.', 'Effectif pair.', 'intermediaire'),
      ex('Étendue de 4,9,2,11,7 ?', ['9', '7', '5', '11'], 0, '11−2=9.', 'max−min.', 'facile'),
      ex('Moyenne de 6 notes = 12. Somme des notes ?', ['72', '18', '6', '2'], 0, '6×12=72.', 'Moyenne×effectif.', 'intermediaire'),
    ],
    quiz: [
      qz('L’étendue mesure :', ['le centre', 'la dispersion max−min', 'la moyenne', 'l’effectif'], 1, 'max−min.'),
      qz('Pour médiane, on doit d’abord :', ['calculer la moyenne', 'ordonner la série', 'multiplier', 'élever au carré'], 1, 'Série ordonnée.'),
    ],
  },
];

// ——— 3e autres matières ———
const francais3e: TopicData[] = [
  {
    title: 'La dissertation et le plan dialectique',
    content:
      "Dissertation argumentative : introduire (accroche, définitions, problématique, plan), développer (arguments + exemples), conclure (bilan + ouverture).\\n\\nPlan dialectique courant : thèse → antithèse → synthèse.\\nConnecteurs : d’abord, ensuite, cependant, en revanche, donc, ainsi…",
    example: 'Sujet sur les réseaux sociaux : utilité / dangers / usage responsable.',
    keyPoints: ['Problématique', 'Thèse-antithèse-synthèse', 'Exemples', 'Connecteurs'],
    exercise: ex('La problématique sert à :', ['raconter', 'formuler la question du devoir', 'lister des mots', 'copier le sujet'], 1, 'Elle guide l’argumentation.', 'Méthode.', 'facile'),
    exercises: [
      ex('La problématique sert à :', ['raconter', 'formuler la question traitée', 'lister le vocabulaire', 'copier le sujet'], 1, 'Question directrice.', 'Méthode dissertation.', 'facile'),
      ex('Un connecteur d’opposition :', ['donc', 'cependant', 'parce que', 'd’abord'], 1, 'Cependant, toutefois, or…', 'Connecteurs.', 'facile'),
      ex('Dans un plan dialectique, l’antithèse :', ['répète la thèse', 'présente l’objection', 'conclut', 'cite seulement'], 1, 'Contre-argument.', 'Plan.', 'intermediaire'),
      ex('L’introduction d’une dissertation doit contenir :', ['uniquement la conclusion', 'problématique et annonce du plan', 'seulement des exemples', 'la bibliographie'], 1, 'Cadre du devoir.', 'Structure.', 'intermediaire'),
      ex('« Ainsi », « donc », « c’est pourquoi » introduisent :', ['une opposition', 'une conséquence', 'une cause', 'une concession'], 1, 'Connecteurs logiques de conséquence.', 'Langue.', 'difficile'),
    ],
    quiz: [
      qz('La synthèse dans un plan dialectique vise à :', ['ignorer la thèse', 'dépasser l’opposition', 'copier l’antithèse', 'finir sans bilan'], 1, 'Dépassement.'),
      qz('Un exemple dans une dissertation doit être :', ['hors sujet', 'précis et au service de l’argument', 'très long seul', 'en langue étrangère'], 1, 'Pertinence.'),
    ],
  },
  {
    title: 'Les figures de style essentielles',
    content:
      "Comparaison (outil : comme, tel que) ; métaphore (sans outil) ; personnification ; hyperbole ; antithèse ; litote.\\n\\nÀ l’examen : relever, nommer, expliquer l’effet (image, émotion, persuasion).",
    example: '« La forêt est un poumon vert » → métaphore.',
    keyPoints: ['Comparaison', 'Métaphore', 'Personnification', 'Hyperbole', 'Antithèse'],
    exercise: ex('« Le soleil sourit » est une :', ['comparaison', 'personnification', 'hyperbole', 'antithèse'], 1, 'Traits humains au soleil.', 'Figures.', 'facile'),
    exercises: [
      ex('« Le soleil sourit » :', ['comparaison', 'personnification', 'hyperbole', 'antithèse'], 1, 'Humanisation.', 'Personnification.', 'facile'),
      ex('« Rapide comme l’éclair » :', ['métaphore', 'comparaison', 'antithèse', 'litote'], 1, 'Présence de « comme ».', 'Comparaison.', 'facile'),
      ex('« C’est un lion au combat » (sans comme) :', ['comparaison', 'métaphore', 'hyperbole pure', 'antiphrase'], 1, 'Identification directe.', 'Métaphore.', 'intermediaire'),
      ex('« Je meurs de faim » souvent :', ['litote', 'hyperbole', 'antithèse', 'chiasme'], 1, 'Exagération.', 'Hyperbole.', 'intermediaire'),
      ex('« Guerre et paix » dans un titre peut illustrer :', ['métaphore', 'antithèse', 'comparaison', 'paronomase'], 1, 'Opposition de termes.', 'Antithèse.', 'difficile'),
    ],
    quiz: [
      qz('Sans outil de comparaison, l’image est souvent une :', ['comparaison', 'métaphore', 'énumération', 'apostrophe'], 1, 'Métaphore.'),
      qz('La litote consiste à :', ['exagérer', 'atténuer pour faire entendre plus', 'répéter', 'contredire'], 1, 'Dire peu pour suggérer beaucoup.'),
    ],
  },
];

const anglais3e: TopicData[] = [
  {
    title: 'Present perfect and past simple',
    content:
      "Past simple : action finished at a definite time (yesterday, in 2020, last week) → V-ed or irregular.\\nPresent perfect : have/has + past participle — experience or result linked to now (ever, never, already, yet, since, for).\\n\\nI went to Port-Gentil last year. / I have been to Franceville twice.",
    example: 'She has lived in Libreville since 2019. (still relevant now)',
    keyPoints: ['have/has + V-ed', 'Time markers', 'Finished past vs present link'],
    exercise: ex('I ___ this book already.', ['read', 'have read', 'am reading', 'reads'], 1, 'Present perfect + already.', 'Link to now.', 'facile'),
    exercises: [
      ex('I ___ this book already.', ['read', 'have read', 'am reading', 'reads'], 1, 'already → present perfect.', 'Tenses.', 'facile'),
      ex('Yesterday we ___ to the market.', ['go', 'have gone', 'went', 'goes'], 2, 'yesterday → past simple.', 'Time marker.', 'facile'),
      ex('She has lived here ___ 2018.', ['for', 'since', 'during', 'ago'], 1, 'since + starting point.', 'since/for.', 'intermediaire'),
      ex('___ you ever eaten ndolé?', ['Did', 'Have', 'Do', 'Are'], 1, 'ever → present perfect.', 'Experience.', 'intermediaire'),
      ex('If it rains tomorrow, we ___ at home.', ['stay', 'will stay', 'stayed', 'staying'], 1, '1st conditional: will + base.', 'Conditionals.', 'difficile'),
    ],
    quiz: [
      qz('Marker for present perfect:', ['yesterday', 'last week', 'already', 'in 2015'], 2, 'already/yet/ever…'),
      qz('Past participle of go:', ['goed', 'went', 'gone', 'going'], 2, 'go-went-gone.'),
    ],
  },
];

const svt3e: TopicData[] = [
  {
    title: 'Immunité et défense de l’organisme',
    content:
      "Barrières naturelles (peau, muqueuses) puis immunité innée (phagocytose) et adaptative (lymphocytes, anticorps spécifiques).\\n\\nVaccination : introduction d’un antigène atténué ou inactivé pour induire une mémoire immunitaire sans provoquer la maladie.",
    example: 'Vaccin antitétanique → anticorps et mémoire anti-tétanos.',
    keyPoints: ['Barrières', 'Phagocytose', 'Anticorps', 'Vaccination', 'Mémoire'],
    exercise: ex('Rôle principal d’un vaccin :', ['guérir une infection en cours', 'préparer le système immunitaire', 'remplacer les antibiotiques', 'tuer toutes les bactéries'], 1, 'Mémoire avant infection.', 'Vaccination.', 'facile'),
    exercises: [
      ex('Rôle principal d’un vaccin :', ['guérir en cours', 'préparer l’immunité', 'remplacer antibiotiques', 'tuer tout microbe'], 1, 'Prévention.', 'Vaccin.', 'facile'),
      ex('Les anticorps sont produits par :', ['globules rouges', 'certains lymphocytes', 'plaquettes', 'neurones'], 1, 'Lymphocytes B / plasmocytes.', 'Immunité adaptative.', 'intermediaire'),
      ex('La phagocytose appartient surtout à :', ['immunité innée', 'uniquement vaccination', 'digestion intestinale', 'vision'], 0, 'Défense non spécifique.', 'Innée.', 'intermediaire'),
      ex('Un antibiotique est efficace contre :', ['virus seulement', 'bactéries (en général)', 'tous les microbes', 'les anticorps'], 1, 'Cible bactérienne.', 'Différence vaccin/antibiotique.', 'difficile'),
      ex('La peau est une barrière :', ['chimique uniquement', 'mécanique et biologique', 'inutile', 'seulement en hiver'], 1, 'Barrière naturelle.', 'Première ligne.', 'facile'),
    ],
    quiz: [
      qz('Mémoire immunitaire permet :', ['d’oublier l’antigène', 'une réponse plus rapide au 2e contact', 'd’éviter de manger', 'de remplacer le sang'], 1, 'Réponse secondaire.'),
      qz('Virus ≠ bactérie : les virus', ['ont un noyau vrai', 'nécessitent une cellule hôte pour se répliquer', 'se traitent toujours par antibiotique', 'sont des animaux'], 1, 'Parasites intracellulaires.'),
    ],
  },
];

const histoire3e: TopicData[] = [
  {
    title: 'La Seconde Guerre mondiale : causes et enjeux',
    content:
      "Causes : traité de Versailles, crise de 1929, montée des totalitarismes, expansion d’Hitler.\\nGuerre totale, Shoah (génocide des Juifs), Résistance, rôle des Alliés.\\nConséquences : ONU, Guerre froide, décolonisation.",
    example: 'Invasion de la Pologne — 1er septembre 1939.',
    keyPoints: ['Totalitarismes', 'Guerre totale', 'Shoah', 'ONU', '1939-1945'],
    exercise: ex('Début de la guerre en Europe :', ['indépendance du Gabon', 'invasion de la Pologne', 'Pearl Harbor', 'Stalingrad'], 1, '1er sept. 1939.', 'Repère.', 'facile'),
    exercises: [
      ex('Début guerre en Europe :', ['Libreville', 'invasion Pologne', 'Pearl Harbor', 'Stalingrad'], 1, '1939.', 'Chronologie.', 'facile'),
      ex('La Shoah désigne :', ['une bataille', 'le génocide des Juifs d’Europe', 'un traité', 'une alliance'], 1, 'Génocide nazi.', 'Vocabulaire.', 'facile'),
      ex('L’ONU est créée surtout pour :', ['coloniser', 'maintenir la paix internationale', 'remplacer l’école', 'interdire le commerce'], 1, 'Après 1945.', 'Conséquences.', 'intermediaire'),
      ex('Régime totalitaire nazi caractérisé par :', ['multipartisme', 'parti unique et contrôle total', 'liberté de presse', 'élections libres seulement'], 1, 'Totalitarisme.', 'Concepts.', 'intermediaire'),
      ex('Pearl Harbor (1941) provoque surtout :', ['entrée des USA dans la guerre', 'fin immédiate du nazisme', 'création de l’UE', 'indépendance du Gabon'], 0, 'Pacifique.', 'Chronologie mondiale.', 'difficile'),
    ],
    quiz: [
      qz('Années de la 2e GM :', ['1914-1918', '1939-1945', '1945-1950', '1929-1935'], 1, '1939-1945.'),
      qz('La Résistance :', ['soutenait l’occupant', 's’opposait à l’occupation', 'était neutre', 'n’existait qu’en Asie'], 1, 'Opposition à l’occupation.'),
    ],
  },
];

const geo3e: TopicData[] = [
  {
    title: 'Le Gabon : territoire, population, ressources',
    content:
      "Gabon : Afrique centrale, à cheval sur l’équateur, façade atlantique. Capitale : Libreville. Frontières : Cameroun, Guinée équatoriale, Congo.\\n\\nRessources : pétrole, manganèse, bois, biodiversité forestière.\\nEnjeux : diversification, urbanisation, développement durable.",
    example: 'Parcs nationaux (Lopé, Ivindo…) et économie encore dépendante des hydrocarbures.',
    keyPoints: ['Situation', 'Libreville', 'Ressources', 'Développement durable'],
    exercise: ex('Capitale du Gabon :', ['Port-Gentil', 'Franceville', 'Libreville', 'Oyem'], 2, 'Libreville.', 'Repère.', 'facile'),
    exercises: [
      ex('Capitale du Gabon :', ['Port-Gentil', 'Franceville', 'Libreville', 'Oyem'], 2, 'Libreville.', 'Géo.', 'facile'),
      ex('Ressource majeure :', ['blé d’exportation', 'pétrole', 'charbon sud-africain uniquement', 'riz mondial'], 1, 'Hydrocarbures.', 'Économie.', 'facile'),
      ex('Continent du Gabon :', ['Asie', 'Europe', 'Afrique', 'Amérique'], 2, 'Afrique centrale.', 'Situation.', 'facile'),
      ex('Développement durable vise à :', ['épuiser les ressources vite', 'répondre au présent sans compromettre le futur', 'interdire toute industrie', 'abandonner la forêt'], 1, 'Définition ONU/classique.', 'Concept.', 'intermediaire'),
      ex('Port-Gentil est surtout connu comme :', ['capitale politique', 'centre pétrolier / port', 'désert', 'volcan'], 1, 'Économie littorale.', 'Villes.', 'difficile'),
    ],
    quiz: [
      qz('Pays frontalier du Gabon :', ['Nigeria', 'Cameroun', 'Ghana', 'Sénégal'], 1, 'Cameroun (entre autres).'),
      qz('Le Gabon est traversé par :', ['le tropique du Cancer seulement', 'l’équateur', 'le cercle polaire', 'aucun parallèle'], 1, 'Équateur.'),
    ],
  },
];

const pc3e: TopicData[] = [
  {
    title: 'Lentilles et optique géométrique',
    content:
      "Lentille convergente : rayons parallèles à l’axe convergent au foyer image après la lentille.\\nRelation de conjugaison (conventions du programme) : 1/p + 1/p′ = 1/f.\\nConstructions : rayon par le centre optique non dévié ; parallèle → foyer ; par foyer objet → parallèle à l’axe.",
    example: 'f=10 cm, p=15 cm ⇒ p′=30 cm.',
    keyPoints: ['Foyer', 'Centre optique', 'Conjugaison', 'Grandissement'],
    exercise: ex('f=10 cm, p=15 cm. p′ ≈ ?', ['30 cm', '6 cm', '25 cm', '5 cm'], 0, '1/15+1/p′=1/10 ⇒ p′=30.', 'Conjugaison.', 'facile'),
    exercises: [
      ex('f=10 cm, p=15 cm. p′ ?', ['30 cm', '6 cm', '25 cm', '5 cm'], 0, '1/p′=1/10−1/15=1/30.', 'Formule.', 'facile'),
      ex('Une loupe est une lentille :', ['divergente', 'convergente', 'plane', 'cylindrique'], 1, 'Convergente.', 'Optique usuelle.', 'facile'),
      ex('Rayon passant par le centre optique d’une lentille mince :', ['est absorbé', 'n’est pas dévié', 'va toujours au foyer', 'se réfléchit'], 1, 'Propriété.', 'Construction.', 'intermediaire'),
      ex('f=20 cm, objet à 20 cm (sur F). Image :', ['à l’infini', 'sur F', 'sur 2F', 'impossible'], 0, '1/p+1/p′=1/f avec p=f ⇒ p′ infini.', 'Cas particulier.', 'difficile'),
      ex('Grandissement γ = p′/p (selon conventions). Si |γ|>1 l’image est :', ['plus petite', 'plus grande', 'identique', 'invisible'], 1, '|γ|>1 → agrandie.', 'Grandissement.', 'intermediaire'),
    ],
    quiz: [
      qz('Foyer image d’une convergente :', ['point où passent les rayons parallèles après la lentille', 'centre de la Terre', 'point d’absorption', 'source toujours'], 0, 'Définition foyer.'),
      qz('Lentille divergente : rayons parallèles après la lentille :', ['convergent', 'semblent diverger d’un foyer virtuel', 'disparaissent', 'deviennent sonores'], 1, 'Divergente.'),
    ],
  },
];

// ——— Seconde Maths ———
const mathsSeconde: TopicData[] = [
  {
    title: 'Fonctions : généralités et variations',
    content:
      "f associe à chaque x de Df un unique f(x).\\nImage de a : f(a). Antécédent de b : solution de f(x)=b.\\nVariations : croissante si x1<x2 ⇒ f(x1)≤f(x2) (sens large).\\nTableau de variations : résumé graphique / dérivé.",
    example: 'f(x)=x² décroissante sur (−∞;0], croissante sur [0;+∞[.',
    keyPoints: ['Df', 'Image / antécédent', 'Croissance', 'Extremums'],
    exercise: ex('f croissante sur [2;5], f(2)=1, f(5)=4. f(3) est :', ['<1', 'entre 1 et 4', '>4', 'toujours 2,5'], 1, 'f(2)≤f(3)≤f(5).', 'Croissance.', 'facile'),
    exercises: [
      ex('f croissante [2;5], f(2)=1, f(5)=4. f(3) :', ['<1', 'entre 1 et 4', '>4', '=2,5 forcément'], 1, 'Encadrement.', 'Croissance.', 'facile'),
      ex('Antécédent de 3 par f : x tel que :', ['f(3)=x', 'f(x)=3', 'x=3', 'f(x)=x'], 1, 'f(x)=3.', 'Vocabulaire.', 'facile'),
      ex('f(x)=2x−1. Antécédent de 5 :', ['2', '3', '4', '5'], 1, '2x−1=5 ⇒ x=3.', 'Équation.', 'intermediaire'),
      ex('Minimum de f(x)=x² sur ℝ :', ['0 en x=0', '1 en x=1', 'pas de min', '−1'], 0, 'Parabole.', 'Extremum.', 'intermediaire'),
      ex('Si f′(x)>0 sur I, f est :', ['décroissante', 'constante', 'croissante', 'nulle'], 2, 'Lien dérivée/variations.', 'Analyse.', 'difficile'),
    ],
    quiz: [
      qz('Df est :', ['l’image', 'l’ensemble de définition', 'la dérivée', 'la limite'], 1, 'Définition.'),
      qz('f(x)=1/x n’est pas définie en :', ['1', '0', '−1', '2'], 1, 'Division par 0.'),
    ],
  },
  {
    title: 'Vecteurs et colinéarité',
    content:
      "Vecteur : direction, sens, norme.\\nColinéaires : u⃗ = k v⃗. En coordonnées, u⃗(x;y) et v⃗(x′;y′) colinéaires ⇔ xy′−yx′=0.\\nRelation de Chasles : AB⃗+BC⃗=AC⃗.",
    example: 'u⃗(2;4), v⃗(1;2) : déterminant 0 → colinéaires.',
    keyPoints: ['Coordonnées', 'Colinéarité', 'Chasles', 'Norme'],
    exercise: ex('u⃗(3;6) et v⃗(1;2) colinéaires ?', ['Oui', 'Non', 'Seulement si même origine', 'Impossible'], 0, '3×2−6×1=0.', 'Déterminant.', 'facile'),
    exercises: [
      ex('u⃗(3;6), v⃗(1;2) colinéaires ?', ['Oui', 'Non', 'Selon origine', 'Non définis'], 0, 'Déterminant nul.', 'Colinéarité.', 'facile'),
      ex('u⃗(2;1), v⃗(4;3) colinéaires ?', ['Oui', 'Non', 'Oui si k=2', 'Toujours'], 1, '2×3−1×4=2≠0.', 'Test.', 'intermediaire'),
      ex('AB⃗+BC⃗ =', ['BA⃗', 'AC⃗', 'CB⃗', '0'], 1, 'Chasles.', 'Relation.', 'facile'),
      ex('Norme de u⃗(3;4) :', ['5', '7', '12', '1'], 0, '√(9+16)=5.', 'Pythagore.', 'intermediaire'),
      ex('u⃗=2v⃗ signifie :', ['orthogonaux', 'colinéaires même sens si 2>0', 'opposés', 'nuls'], 1, 'k=2>0.', 'Coefficient.', 'difficile'),
    ],
    quiz: [
      qz('Déterminant xy′−yx′=0 signifie :', ['orthogonaux', 'colinéaires', 'même norme', 'opposés'], 1, 'Colinéarité.'),
      qz('Vecteur nul :', ['norme 1', 'norme 0', 'toujours colinéaire à aucun', 'interdit'], 1, 'Norme nulle.'),
    ],
  },
];

// ——— Terminale ———
const mathsTerm: TopicData[] = [
  {
    title: 'Suites arithmétiques et géométriques',
    content:
      "Arithmétique : uₙ₊₁=uₙ+r ⇒ uₙ=u₀+nr.\\nGéométrique : uₙ₊₁=q uₙ ⇒ uₙ=u₀ qⁿ.\\nLimite géométrique : |q|<1 ⇒ qⁿ→0 ; q>1 ⇒ +∞ ; q≤−1 : divergente en général.",
    example: 'u₀=3, r=2 ⇒ uₙ=3+2n ; v₀=5, q=1/2 ⇒ vₙ=5/2ⁿ.',
    keyPoints: ['Raison', 'Terme général', 'Limite', 'Somme'],
    exercise: ex('Géométrique u₀=2, q=3. u₃=?', ['18', '54', '6', '24'], 1, '2×27=54.', 'uₙ=u₀qⁿ.', 'facile'),
    exercises: [
      ex('u₀=2, q=3. u₃=?', ['18', '54', '6', '24'], 1, '2×3³=54.', 'Géométrique.', 'facile'),
      ex('Arithmétique u₀=5, r=−2. u₄=?', ['−3', '3', '−1', '13'], 0, '5+4×(−2)=−3.', 'uₙ=u₀+nr.', 'facile'),
      ex('|q|<1. Limite de qⁿ ?', ['1', '0', '∞', 'q'], 1, 'Convergence vers 0.', 'Limites.', 'intermediaire'),
      ex('Somme 1+2+…+n =', ['n²', 'n(n+1)/2', '2n', 'n!'], 1, 'Formule classique.', 'Somme arithmétique.', 'intermediaire'),
      ex('uₙ=3×(1/2)ⁿ. lim uₙ ?', ['3', '0', '∞', '1/2'], 1, '|q|<1.', 'Limite.', 'difficile'),
    ],
    quiz: [
      qz('Raison d’une suite arithmétique :', ['quotient', 'différence constante', 'produit', 'exposant'], 1, 'uₙ₊₁−uₙ=r.'),
      qz('Suite géométrique de raison −1 :', ['converge vers 0', 'alterne souvent sans limite unique', 'tend vers −1', 'est croissante'], 1, 'Oscillation.'),
    ],
  },
  {
    title: 'Dérivation et étude de fonctions',
    content:
      "f′(x) = limite du taux d’accroissement.\\nRègles : (f+g)′=f′+g′ ; (kf)′=kf′ ; (fg)′=f′g+fg′ ; (1/g)′=−g′/g² ; (f∘g)′=(f′∘g)×g′.\\nSigne de f′ → variations de f ; f′=0 et changement de signe → extremum local possible.",
    example: 'f(x)=x² ⇒ f′=2x ; min en 0.',
    keyPoints: ['Dérivée', 'Règles', 'Variations', 'Extremums'],
    exercise: ex('Dérivée de 3x²−5x+1 ?', ['6x−5', '3x−5', '6x+1', '6x'], 0, 'Terme à terme.', 'Polynômes.', 'facile'),
    exercises: [
      ex('Dérivée de 3x²−5x+1', ['6x−5', '3x−5', '6x+1', '6x'], 0, '6x−5.', 'Règle.', 'facile'),
      ex('Dérivée de 1/x (x≠0)', ['−1/x²', '1/x²', '−x', 'ln x'], 0, '(x⁻¹)′=−x⁻².', 'Puissance.', 'intermediaire'),
      ex('f′(x)>0 sur I ⇒ f :', ['décroissante', 'constante', 'croissante', 'nulle'], 2, 'Lien signe/variations.', 'Analyse.', 'facile'),
      ex('f(x)=eˣ. f′(x)=', ['eˣ', 'xeˣ⁻¹', '1/eˣ', '0'], 0, 'Dérivée de exp = exp.', 'Exp.', 'intermediaire'),
      ex('f(x)=x³−3x. f′(x)=0 en :', ['x=±1', 'x=0 seulement', 'x=3', 'aucune'], 0, '3x²−3=0 ⇒ x²=1.', 'Extremums.', 'difficile'),
    ],
    quiz: [
      qz('(fg)′ =', ['f′g′', 'f′g+fg′', 'f+g', 'f′/g′'], 1, 'Produit.'),
      qz('Tangente horizontale si :', ['f(x)=0', 'f′(x)=0', 'f″(x)=0 seulement', 'x=0'], 1, 'pente nulle.'),
    ],
  },
  {
    title: 'Probabilités conditionnelles et indépendance',
    content:
      "P(A|B)=P(A∩B)/P(B) si P(B)>0.\\nIndépendance : P(A∩B)=P(A)P(B) ⇔ P(A|B)=P(A).\\nArbres et formule des probabilités totales ; Bayes pour inverser le conditionnement.",
    example: 'P(A)=0,3 ; P(B|A)=0,5 ⇒ P(A∩B)=0,15.',
    keyPoints: ['Conditionnelle', 'Indépendance', 'Arbre', 'Bayes'],
    exercise: ex('P(A)=0,4 ; P(B)=0,5 ; indépendants. P(A∩B)=?', ['0,9', '0,2', '0,1', '0,4'], 1, '0,4×0,5=0,2.', 'Indépendance.', 'facile'),
    exercises: [
      ex('Indépendants P(A)=0,4 P(B)=0,5. P(A∩B)?', ['0,9', '0,2', '0,1', '0,4'], 1, 'Produit.', 'Indépendance.', 'facile'),
      ex('P(A|B) se lit :', ['A ou B', 'A sachant B', 'B sachant A', 'A et B'], 1, 'Conditionnelle.', 'Vocabulaire.', 'facile'),
      ex('P(B)=0,2 ; P(A∩B)=0,05. P(A|B)=?', ['0,25', '0,4', '0,1', '4'], 0, '0,05/0,2=0,25.', 'Définition.', 'intermediaire'),
      ex('Formule des proba totales (partition B, B̄) :', ['P(A)=P(A|B)+P(A|B̄)', 'P(A)=P(A|B)P(B)+P(A|B̄)P(B̄)', 'P(A)=P(B)', 'P(A)=1'], 1, 'Totales.', 'Arbre.', 'difficile'),
      ex('Si A et B incompatibles, P(A∪B)=', ['P(A)P(B)', 'P(A)+P(B)', '0', '1'], 1, 'Pas d’intersection.', 'Réunion.', 'intermediaire'),
    ],
    quiz: [
      qz('Indépendance ⇔', ['P(A∪B)=1', 'P(A∩B)=P(A)P(B)', 'A=B', 'P(A)=0'], 1, 'Produit.'),
      qz('Bayes sert surtout à :', ['additionner', 'inverser un conditionnement', 'dériver', 'intégrer'], 1, 'P(cause|effet).'),
    ],
  },
];

const philoTerm: TopicData[] = [
  {
    title: 'Liberté et déterminisme',
    content:
      "Libre arbitre : pouvoir de choisir autrement. Autonomie (Kant) : obéir à la loi que la raison se donne.\\nDéterminisme : tout événement a une cause (liberté illusoire, ou liberté = connaissance des causes, Spinoza).\\nSartre : existence précède essence — l’homme est condamné à être libre et responsable.",
    example: 'Orientation scolaire : pressions sociales vs projet personnel.',
    keyPoints: ['Libre arbitre', 'Autonomie', 'Déterminisme', 'Responsabilité', 'Sartre'],
    exercise: ex('Pour Sartre, l’homme est libre car :', ['il obéit aux lois', 'pas d’essence fixée d’avance', 'déterminé par la société', 'instinct seul'], 1, 'Existence précède essence.', 'Existentialisme.', 'facile'),
    exercises: [
      ex('Sartre : liberté parce que :', ['lois', 'pas d’essence préalable', 'société', 'instinct'], 1, 'Existence > essence.', 'Sartre.', 'facile'),
      ex('Autonomie kantienne :', ['faire ce qu’on veut', 'loi morale rationnelle auto-imposée', 'suivre ses désirs', 'rejeter toute règle'], 1, 'Auto-nomos.', 'Kant.', 'intermediaire'),
      ex('Déterminisme affirme que :', ['rien n’a de cause', 'tout a une cause', 'seul le hasard existe', 'la liberté est absolue sans cause'], 1, 'Causalisme.', 'Concept.', 'facile'),
      ex('« Condamné à être libre » signifie surtout :', ['prison', 'impossibilité de ne pas choisir / responsabilité', 'fatalité biologique seule', 'obéissance'], 1, 'Responsabilité absolue.', 'Sartre.', 'difficile'),
      ex('Spinoza lie la liberté à :', ['l’ignorance', 'la connaissance des causes', 'le hasard', 'la foi seule'], 1, 'Liberté = comprendre.', 'Spinoza.', 'difficile'),
    ],
    quiz: [
      qz('Libre arbitre :', ['absence de choix', 'pouvoir de choisir autrement', 'déterminisme strict', 'hasard pur'], 1, 'Indétermination du choix.'),
      qz('Responsabilité morale suppose souvent :', ['aucune liberté', 'une forme de liberté', 'le sommeil', 'la seule génétique'], 1, 'Lien liberté/responsabilité.'),
    ],
  },
  {
    title: 'La conscience et l’inconscient',
    content:
      "Conscience : rapport de soi à soi (Descartes : cogito).\\nInconscient (Freud) : processus hors champ conscient influençant actes et symptômes ; refoulement.\\nQuestion : la conscience maîtrise-t-elle le sujet ?",
    example: 'Oubli répétitif pouvant renvoyer à un conflit psychique (lecture freudienne).',
    keyPoints: ['Cogito', 'Inconscient', 'Refoulement', 'Sujet'],
    exercise: ex('Le cogito affirme :', ['existence de Dieu seule', 'certitude de la pensée qui se saisit', 'inconscient', 'primauté du corps seule'], 1, 'Je pense donc je suis.', 'Descartes.', 'facile'),
    exercises: [
      ex('Cogito :', ['Dieu seul', 'certitude de la pensée', 'inconscient', 'corps seul'], 1, 'Descartes.', 'Cogito.', 'facile'),
      ex('Pour Freud, l’inconscient :', ['n’existe pas', 'influence à notre insu', '= conscience', 'est mesurable comme un muscle'], 1, 'Processus hors conscience.', 'Freud.', 'intermediaire'),
      ex('Le refoulement est :', ['un souvenir clair', 'un mécanisme écartant des contenus pénibles', 'une loi physique', 'une émotion joyeuse'], 1, 'Inconscient dynamique.', 'Freud.', 'intermediaire'),
      ex('« Je pense donc je suis » est un :', ['syllogisme long', 'premier principe de certitude pour Descartes', 'rejet de la raison', 'appel à l’inconscient'], 1, 'Méditations.', 'Descartes.', 'difficile'),
      ex('Critiquer le cogito peut porter sur :', ['la langue', 'le fait que « je » n’est pas si transparent (inconscient, langage…)', 'la météo', 'les maths seules'], 1, 'Philosophie contemporaine.', 'Débat.', 'difficile'),
    ],
    quiz: [
      qz('Inconscient freudien :', ['synonyme de cerveau', 'psychique non conscient', 'uniquement biologique', 'Dieu'], 1, 'Psychanalyse.'),
      qz('Conscience immédiate :', ['toujours fausse', 'rapport à soi dans l’acte de penser', 'uniquement mémoire', 'sommeil'], 1, 'Phénoménologie / Descartes.'),
    ],
  },
];

// ——— Première (tronc / séries) ———
const mathsPremiere: TopicData[] = [
  {
    title: 'Second degré : équations et parabole',
    content:
      "Équation ax²+bx+c=0 (a≠0). Discriminant Δ=b²−4ac.\\nΔ>0 : deux racines réelles ; Δ=0 : une racine double ; Δ<0 : pas de racine réelle.\\nForme canonique et représentation : parabole tournée vers le haut si a>0.",
    example: 'x²−3x+2=0 → (x−1)(x−2)=0.',
    keyPoints: ['Discriminant', 'Racines', 'Parabole', 'Sommet'],
    exercise: ex('Δ pour x²−3x+2', ['1', '9', '17', '−1'], 0, '9−8=1.', 'Δ=b²−4ac.', 'facile'),
    exercises: [
      ex('Δ de x²−3x+2', ['1', '9', '17', '−1'], 0, '9−8=1.', 'Discriminant.', 'facile'),
      ex('Racines de x²−3x+2=0', ['1 et 2', '−1 et −2', '3 et 2', '0 et 3'], 0, 'Factorisation ou formules.', 'Résolution.', 'facile'),
      ex('Si Δ<0', ['deux racines', 'une racine', 'aucune racine réelle', 'infinie'], 2, 'Pas de solution dans ℝ.', 'Signe Δ.', 'intermediaire'),
      ex('Sommet de y=ax²+bx+c : abscisse', ['−b/2a', 'b/2a', '−c/a', 'Δ'], 0, 'x_s=−b/(2a).', 'Parabole.', 'intermediaire'),
      ex('Produit des racines (si existent)', ['c/a', '−b/a', 'b/a', 'Δ'], 0, 'c/a (relations Viète).', 'Viète.', 'difficile'),
    ],
    quiz: [
      qz('a>0 pour ax²+… : parabole', ['vers le bas', 'vers le haut', 'horizontale', 'cercle'], 1, 'Convexité.'),
      qz('Formules des racines :', ['(−b±√Δ)/2a', 'b±√Δ', '−c±√Δ', '2a/b'], 0, 'Classique.'),
    ],
  },
];

const francaisPremiere: TopicData[] = [
  {
    title: 'Le commentaire de texte : méthode',
    content:
      "Commentaire : expliquer un texte en dégageant axes de lecture (procédés → effets → sens).\\nIntroduction : présentation (auteur, œuvre, extrait), problématique, axes.\\nDéveloppement : analyses précises (citations courtes). Conclusion : bilan + ouverture.",
    example: 'Axes possibles : vision de la nature / critique sociale / construction du personnage…',
    keyPoints: ['Problématique', 'Axes', 'Procédés', 'Citations'],
    exercise: ex('Un commentaire littéraire doit surtout :', ['résumer seulement', 'analyser procédés et sens', 'copier le texte', 'ignorer l’auteur'], 1, 'Analyse outillée.', 'Méthode.', 'facile'),
    exercises: [
      ex('Le commentaire vise à :', ['résumer seul', 'analyser forme et sens', 'copier', 'traduire'], 1, 'Lecture analytique.', 'Méthode.', 'facile'),
      ex('Une citation dans le commentaire doit être :', ['très longue toujours', 'courte et intégrée', 'en latin', 'sans guillemets'], 1, 'Pertinence.', 'Technique.', 'intermediaire'),
      ex('La problématique du commentaire :', ['une question de lecture sur l’extrait', 'un hors-sujet', 'une date', 'une biographie seule'], 0, 'Angle d’étude.', 'Intro.', 'intermediaire'),
      ex('Les figures de style servent à :', ['décorer seulement', 'produire des effets de sens', 'remplacer l’analyse', 'compter les mots'], 1, 'Outils d’interprétation.', 'Analyse.', 'difficile'),
      ex('Conclusion type :', ['nouveau sujet sans lien', 'bilan des axes + ouverture', 'copie de l’intro', 'liste de dates'], 1, 'Structure.', 'Méthode.', 'facile'),
    ],
    quiz: [
      qz('Axes de lecture :', ['parties du développement organisées', 'titres de romans', 'notes de bas de page seulement', 'oral uniquement'], 0, 'Plan.'),
      qz('Procédé stylistique :', ['métaphore, rythme, champ lexical…', 'uniquement la date', 'le prix du livre', 'l’éditeur'], 0, 'Forme.'),
    ],
  },
];

// ——— Exports ———
export function getExamPrep_5e_mathematiques(): Subject {
  return makeSubject('mathematiques', 'Mathématiques', 'Calculator', 'blue', '5e', '5ème', maths5e);
}
export function getExamPrep_4e_mathematiques(): Subject {
  return makeSubject('mathematiques', 'Mathématiques', 'Calculator', 'blue', '4e', '4ème', maths4e);
}
export function getExamPrep_3e_mathematiques(): Subject {
  return makeSubject('mathematiques', 'Mathématiques', 'Calculator', 'blue', '3e', '3ème', maths3e);
}
export function getExamPrep_3e_francais(): Subject {
  return makeSubject('francais', 'Français', 'BookOpen', 'amber', '3e', '3ème', francais3e);
}
export function getExamPrep_3e_anglais(): Subject {
  return makeSubject('anglais', 'Anglais', 'Languages', 'red', '3e', '3ème', anglais3e);
}
export function getExamPrep_3e_svt(): Subject {
  return makeSubject('svt', 'SVT', 'Leaf', 'green', '3e', '3ème', svt3e);
}
export function getExamPrep_3e_histoire(): Subject {
  return makeSubject('histoire', 'Histoire', 'Landmark', 'orange', '3e', '3ème', histoire3e);
}
export function getExamPrep_3e_geographie(): Subject {
  return makeSubject('geographie', 'Géographie', 'Map', 'teal', '3e', '3ème', geo3e);
}
export function getExamPrep_3e_pc(): Subject {
  return makeSubject('physique-chimie', 'Physique-Chimie', 'Atom', 'indigo', '3e', '3ème', pc3e);
}
export function getExamPrep_seconde_mathematiques(): Subject {
  return makeSubject('mathematiques', 'Mathématiques', 'Calculator', 'blue', 'seconde', 'Seconde', mathsSeconde);
}
export function getExamPrep_terminale_maths(): Subject {
  return makeSubject('mathematiques', 'Mathématiques', 'Calculator', 'blue', 'terminale-c', 'Terminale C', mathsTerm);
}
export function getExamPrep_terminale_philo(): Subject {
  return makeSubject('philosophie', 'Philosophie', 'Brain', 'purple', 'terminale-a', 'Terminale A', philoTerm);
}
export function getExamPrep_premiere_maths(): Subject {
  return makeSubject('mathematiques', 'Mathématiques', 'Calculator', 'blue', 'premiere', 'Première', mathsPremiere);
}
export function getExamPrep_premiere_francais(): Subject {
  return makeSubject('francais', 'Français', 'BookOpen', 'amber', 'premiere', 'Première', francaisPremiere);
}

export function getExamPrepSubjectsForLevel(levelId: string): Subject[] {
  const out: Subject[] = [];
  if (levelId === '5e') out.push(getExamPrep_5e_mathematiques());
  if (levelId === '4e') out.push(getExamPrep_4e_mathematiques());
  if (levelId === '3e') {
    out.push(
      getExamPrep_3e_mathematiques(),
      getExamPrep_3e_francais(),
      getExamPrep_3e_anglais(),
      getExamPrep_3e_svt(),
      getExamPrep_3e_histoire(),
      getExamPrep_3e_geographie(),
      getExamPrep_3e_pc(),
    );
  }
  if (levelId === 'seconde') out.push(getExamPrep_seconde_mathematiques());
  if (levelId === 'premiere') {
    out.push(getExamPrep_premiere_maths(), getExamPrep_premiere_francais());
  }
  return out;
}

export function getExamPrepForTerminaleSeries(seriesName: string): Subject[] {
  const n = seriesName.toLowerCase();
  const out: Subject[] = [];
  if (n.includes('c') || n.includes('d') || n.includes('scient')) {
    out.push(getExamPrep_terminale_maths());
  }
  if (n.includes('a') || n.includes('litt')) {
    out.push(getExamPrep_terminale_philo());
  }
  return out;
}

export function getExamPrepForPremiereSeries(seriesName: string): Subject[] {
  const n = seriesName.toLowerCase();
  const out: Subject[] = [getExamPrep_premiere_francais()];
  if (n.includes('c') || n.includes('d') || n.includes('scient') || n.includes('a')) {
    out.push(getExamPrep_premiere_maths());
  }
  return out;
}
