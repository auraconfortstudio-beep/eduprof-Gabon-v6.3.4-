export type LevelId =
  | 'cm2'
  | '6e'
  | '5e'
  | '4e'
  | '3e'
  | 'seconde'
  | 'premiere'
  | 'terminale'
  | 'universite';

export type LevelCategory = 'primaire' | 'college' | 'lycee' | 'universite';

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

export interface Exercise {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  difficulty: 'facile' | 'intermediaire' | 'difficile';
  explanation: string;
  method: string;
}

export interface Lesson {
  id: string;
  title: string;
  objective: string;
  content: string;
  example: string;
  keyPoints: string[];
  exercises: Exercise[];
  quiz: QuizQuestion[];
}

export interface Chapter {
  id: string;
  title: string;
  lessons: Lesson[];
}

export interface Subject {
  id: string;
  name: string;
  icon: string;
  color: string;
  description: string;
  chapters: Chapter[];
}

export interface Series {
  id: string;
  name: string;
  subjects: Subject[];
}

export interface Filiere {
  id: string;
  name: string;
  domain: string;
  levels: string[];
  subjects: Subject[];
}

export interface Level {
  id: LevelId;
  name: string;
  category: LevelCategory;
  icon: string;
  color: string;
  description: string;
  hasSeries?: boolean;
  series?: Series[];
  hasFilieres?: boolean;
  filieres?: Filiere[];
  subjects?: Subject[];
}

export type TopicExercise = {
  q: string;
  opts: string[];
  ans: number;
  exp: string;
  method: string;
  difficulty?: 'facile' | 'intermediaire' | 'difficile';
};

export interface TopicData {
  title: string;
  content: string;
  example: string;
  keyPoints: string[];
  /** Exercice principal (rétrocompat) */
  exercise: TopicExercise;
  /** Tous les exercices de l'unité (si fourni, prioritaire pour makeSubject) */
  exercises?: TopicExercise[];
  quiz: { q: string; opts: string[]; ans: number; exp: string }[];
}

/** Slug stable pour IDs uniques (évite collisions après fusion V2.6 + legacy). */
export function slugId(text: string, max = 32): string {
  return text
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '')
    .slice(0, max) || 'item';
}

/**
 * Construit une matière avec IDs déterministes et uniques par (niveau, matière, titre, index).
 * Format: {levelId}-{subjectId}-c{n}-{slug}-lecon1 / -ex{k} / -q{k}
 */
export function makeSubject(
  subjectId: string,
  subjectName: string,
  icon: string,
  color: string,
  levelId: string,
  levelName: string,
  topics: TopicData[]
): Subject {
  const sid = `${levelId}-${subjectId}`;
  const used = new Set<string>();
  return {
    id: sid,
    name: subjectName,
    icon,
    color,
    description: `Cours de ${subjectName} adaptés au niveau ${levelName}`,
    chapters: topics.map((t, ci) => {
      const exList = t.exercises && t.exercises.length > 0 ? t.exercises : [t.exercise];
      let base = `${sid}-c${ci + 1}-${slugId(t.title)}`;
      if (used.has(base)) {
        base = `${base}-x${ci + 1}`;
      }
      used.add(base);
      return {
        id: base,
        title: t.title,
        lessons: [
          {
            id: `${base}-lecon1`,
            title: t.title,
            objective: `Comprendre et maîtriser: ${t.title}`,
            content: t.content,
            example: t.example,
            keyPoints: t.keyPoints,
            exercises: exList.map((ex, ei) => ({
              id: `${base}-ex${ei + 1}`,
              question: ex.q,
              options: ex.opts,
              correctAnswer: ex.ans,
              difficulty: (ex.difficulty ?? 'facile') as 'facile' | 'intermediaire' | 'difficile',
              explanation: ex.exp,
              method: ex.method,
            })),
            quiz: t.quiz.map((qz, qi) => ({
              id: `${base}-q${qi + 1}`,
              question: qz.q,
              options: qz.opts,
              correctAnswer: qz.ans,
              explanation: qz.exp,
            })),
          },
        ],
      };
    }),
  };
}

/** Garantit l'unicité des IDs chapitre/leçon/exo/quiz après fusion de listes. */
export function ensureUniqueChapterIds(subject: Subject): Subject {
  const used = new Set<string>();
  const chapters = subject.chapters.map((ch, i) => {
    let base = ch.id;
    if (!base || used.has(base)) {
      base = `${subject.id}-c${i + 1}-${slugId(ch.title)}`;
      if (used.has(base)) base = `${base}-x${i + 1}`;
    }
    used.add(base);
    const lesson = ch.lessons[0];
    if (!lesson) {
      return { ...ch, id: base, lessons: [] };
    }
    return {
      ...ch,
      id: base,
      lessons: [
        {
          ...lesson,
          id: `${base}-lecon1`,
          exercises: lesson.exercises.map((ex, ei) => ({
            ...ex,
            id: `${base}-ex${ei + 1}`,
          })),
          quiz: lesson.quiz.map((qz, qi) => ({
            ...qz,
            id: `${base}-q${qi + 1}`,
          })),
        },
      ],
    };
  });
  return { ...subject, chapters };
}
