import { makeSubject, type Subject, type Series, type Filiere, type Chapter } from './types';
import { getSeriesSpecificSubjects } from './seriesPedagogy';

/**
 * Démonstration architecturale : 1 chapitre → PLUSIEURS leçons distinctes.
 * `makeSubject()` génère toujours exactement 1 leçon par chapitre (voir son
 * code) — ceci est une limite connue du générateur de contenu historique,
 * pas du modèle de données (`Chapter.lessons` est un tableau, donc N leçons
 * sont déjà supportées). Ce chapitre est construit à la main, en dehors de
 * `makeSubject`/`ensureUniqueChapterIds` (qui, eux, réduiraient un chapitre
 * à sa 1ère leçon), pour prouver que l'affichage, la récupération unitaire
 * et le contexte envoyé à Maël fonctionnent bien avec plusieurs leçons.
 */
function buildFonctionsChapterDemo(): Chapter {
  const base = 'terminale-b-mathematiques-c1-fonctions';
  const lesson = (n: number, title: string, objective: string, content: string, example: string, keyPoints: string[]) => ({
    id: `${base}-lecon${n}`,
    title,
    objective,
    content,
    example,
    keyPoints,
    exercises: [
      {
        id: `${base}-lecon${n}-ex1`,
        question: `Question d'application — ${title}`,
        options: ['Proposition A', 'Proposition B', 'Proposition C', 'Proposition D'],
        correctAnswer: 0,
        difficulty: 'intermediaire' as const,
        explanation: `Application directe de la leçon « ${title} ».`,
        method: 'Relire le cours puis identifier la notion clé mobilisée.',
      },
    ],
    quiz: [
      {
        id: `${base}-lecon${n}-q1`,
        question: `Vérification rapide — ${title}`,
        options: ['Vrai', 'Faux'],
        correctAnswer: 0,
        explanation: `Rappel du point clé de « ${title} ».`,
      },
    ],
  });

  return {
    id: base,
    title: 'Fonctions',
    lessons: [
      lesson(
        1,
        'Généralités sur les fonctions',
        'Comprendre ce qu\'est une fonction numérique et son vocabulaire de base.',
        "Une fonction f associe à chaque nombre x d'un ensemble de départ un unique nombre f(x). On note f: x ↦ f(x). Le nombre f(x) est l'image de x, et x est un antécédent de f(x).",
        "Pour f(x) = 2x + 1, l'image de 3 est f(3) = 7.",
        ['Fonction = association x → f(x)', 'Image vs antécédent', 'Notation f: x ↦ f(x)']
      ),
      lesson(
        2,
        'Ensemble de définition',
        "Déterminer pour quelles valeurs de x une fonction est définie.",
        "L'ensemble de définition Df d'une fonction f est l'ensemble des valeurs de x pour lesquelles f(x) existe. Il faut exclure les valeurs qui annulent un dénominateur ou rendent une racine négative.",
        "Pour f(x) = 1/(x-2), on exclut x = 2 : Df = ℝ \\ {2}.",
        ["Exclure les dénominateurs nuls", 'Exclure les racines de nombres négatifs', 'Noter Df avec précision']
      ),
      lesson(
        3,
        'Limites',
        "Étudier le comportement d'une fonction au voisinage d'un point ou de l'infini.",
        "La limite de f(x) quand x tend vers a décrit la valeur vers laquelle se rapproche f(x) lorsque x se rapproche de a. On note lim(x→a) f(x) = L. On étudie aussi les limites en +∞ et -∞.",
        "lim(x→+∞) 1/x = 0 : plus x grandit, plus 1/x se rapproche de 0.",
        ['Limite finie en un point', 'Limite à l\'infini', 'Formes indéterminées à traiter avec soin']
      ),
      lesson(
        4,
        'Continuité',
        "Savoir reconnaître si une fonction est continue en un point ou sur un intervalle.",
        "Une fonction f est continue en a si lim(x→a) f(x) = f(a) : pas de saut, pas de trou. Une fonction continue sur un intervalle peut se tracer sans lever le crayon.",
        "f(x) = x² est continue partout sur ℝ.",
        ['Continuité = pas de rupture du graphe', 'lim(x→a) f(x) = f(a)', 'Lien avec le théorème des valeurs intermédiaires']
      ),
      lesson(
        5,
        'Applications',
        "Mobiliser limites et continuité pour étudier des fonctions concrètes.",
        "On combine ensemble de définition, limites aux bornes et continuité pour dresser le tableau de variations complet d'une fonction et résoudre des problèmes concrets (optimisation, existence de solutions).",
        "Pour étudier f(x) = x² - 4x + 3 sur ℝ, on calcule ses limites en ±∞ et on étudie sa continuité avant de dresser son tableau de variations.",
        ['Synthèse : Df + limites + continuité', 'Tableau de variations', 'Théorème des valeurs intermédiaires pour l\'existence de solutions']
      ),
    ],
  };
}

export function buildTerminaleBMathDemo(): Subject {
  return {
    id: 'terminale-b-mathematiques',
    name: 'Mathématiques',
    icon: 'Calculator',
    color: 'blue',
    description: 'Cours de Mathématiques adaptés au niveau Terminale B',
    chapters: [buildFonctionsChapterDemo()],
  };
}

// ─── Seconde (tronc commun) ──────────────────────────────────────
export function getSecondeSubjects(): Subject[] {
  return [
    makeSubject('mathematiques', 'Mathématiques', 'Calculator', 'blue', 'seconde', 'Seconde', [
      {
        title: 'Les fonctions et variations',
        content:
          "Une fonction est une relation qui à chaque nombre x associe un nombre f(x). On peut la représenter graphiquement dans un repère. Les variations d'une fonction indiquent si elle croît (monte) ou décroît (descend). Une fonction affine f(x) = ax + b est croissante si a > 0, décroissante si a < 0. Le tableau de variations résume le comportement de la fonction.",
        example: "f(x) = 2x + 3. Pour x = 0, f(0) = 3. Pour x = 5, f(5) = 13. Comme a = 2 > 0, la fonction est croissante.",
        keyPoints: [
          'Une fonction associe à chaque x un nombre f(x)',
          'f(x) = ax + b est une fonction affine',
          'a > 0 → croissante, a < 0 → décroissante',
          'Le tableau de variations résume le comportement',
        ],
        exercise: {
          q: 'Si f(x) = -3x + 5, la fonction est :',
          opts: ['Croissante', 'Décroissante', 'Constante', 'Nulle'],
          ans: 1,
          exp: 'Comme a = -3 < 0, la fonction f(x) = -3x + 5 est décroissante.',
          method: 'Regarde le coefficient a : positif = croissante, négatif = décroissante.',
        },
        quiz: [
          { q: 'Si f(x) = 4x - 2, combien vaut f(3) ?', opts: ['10', '12', '14', '7'], ans: 0, exp: 'f(3) = 4×3 - 2 = 10.' },
          { q: 'Une fonction affine a pour forme :', opts: ['f(x) = x²', 'f(x) = ax + b', 'f(x) = 1/x', 'f(x) = √x'], ans: 1, exp: 'Une fonction affine s\'écrit f(x) = ax + b.' },
          { q: 'Si a = 0 dans f(x) = ax + b, la fonction est :', opts: ['Croissante', 'Décroissante', 'Constante', 'Nulle'], ans: 2, exp: 'Si a = 0, f(x) = b (constante), la fonction ne varie pas.' },
        ],
      },
      {
        title: 'Les vecteurs et la géométrie',
        content:
          "Un vecteur est un objet mathématique défini par une direction, un sens et une longueur (norme). On le note avec une flèche : AB→. Deux vecteurs sont égaux s'ils ont même direction, même sens et même longueur. On peut additionner des vecteurs (relation de Chasles : AB→ + BC→ = AC→) et les multiplier par un nombre réel. Les vecteurs sont utiles en physique pour représenter des forces et des vitesses.",
        example: "Si AB→ = (3, 2) et BC→ = (1, 4), alors AC→ = AB→ + BC→ = (4, 6).",
        keyPoints: [
          'Un vecteur a : direction, sens, longueur',
          'Relation de Chasles : AB→ + BC→ = AC→',
          'On peut multiplier un vecteur par un nombre',
          'Les vecteurs servent en physique (forces, vitesses)',
        ],
        exercise: {
          q: 'Si AB→ = (2, 3) et BC→ = (4, 1), quelles sont les coordonnées de AC→ ?',
          opts: ['(6, 4)', '(2, 2)', '(8, 3)', '(6, 3)'],
          ans: 0,
          exp: 'AC→ = AB→ + BC→ = (2+4, 3+1) = (6, 4). On additionne les coordonnées.',
          method: 'Pour additionner deux vecteurs, additionne leurs coordonnées : (x1+x2, y1+y2).',
        },
        quiz: [
          { q: 'La relation de Chasles dit :', opts: ['AB→ + BA→ = 0', 'AB→ + BC→ = AC→', 'AB→ = BC→', 'AB→ - BC→ = AC→'], ans: 1, exp: 'La relation de Chasles : AB→ + BC→ = AC→.' },
          { q: 'Un vecteur est défini par :', opts: ['Sa longueur uniquement', 'Direction, sens, longueur', 'Son origine uniquement', 'Sa couleur'], ans: 1, exp: 'Un vecteur a une direction, un sens et une longueur (norme).' },
          { q: 'Si AB→ = (5, 0), sa norme est :', opts: ['0', '5', '25', '10'], ans: 1, exp: 'La norme de (5, 0) = √(5² + 0²) = 5.' },
        ],
      },
    ]),
    makeSubject('francais', 'Français', 'BookOpen', 'amber', 'seconde', 'Seconde', [
      {
        title: 'Le théâtre et ses genres',
        content:
          "Le théâtre est destiné à être joué : dialogues, didascalies, actes et scènes. Comédie, tragédie, drame. Au Gabon, le théâtre et l'oralité interrogent pouvoir, famille, justice et mémoire.",
        example: "Repérer conflit et registre dans une scène étudiée en classe à Libreville ou ailleurs au Gabon.",
        keyPoints: [
          'Dialogues et didascalies',
          'Comédie / tragédie / drame',
          'Conflit dramatique',
          'Théâtre et société gabonaise',
        ],
        exercise: {
          q: 'Quelles sont les indications de mise en scène dans une pièce appelées ?',
          opts: ['Les dialogues', 'Les didascalies', 'Les monologues', 'Les actes'],
          ans: 1,
          exp: "Les didascalies sont les indications de mise en scène données par l'auteur (décor, gestes, ton...).",
          method: 'Retiens : didascalies = tout ce qui n\'est pas dit par les personnages mais indiqué par l\'auteur.',
        },
        quiz: [
          { q: 'La comédie se caractérise par :', opts: ['Une fin tragique', 'Une fin heureuse et l\'humour', 'Le sérieux', 'L\'absence de dialogue'], ans: 1, exp: 'La comédie fait rire et finit généralement bien.' },
          { q: 'Au Gabon, le théâtre peut traiter de :', opts: ['uniquement la chimie', 'pouvoir, famille, justice, mémoire', 'la géométrie seule', 'rien'], ans: 1, exp: 'Fonction sociale du théâtre.' },
          { q: 'Les didascalies servent à :', opts: ['remplacer les acteurs', 'guider la mise en scène', 'écrire un roman', 'calculer une fraction'], ans: 1, exp: 'Indications scéniques.' },
        ],
      },
    ]),
    makeSubject('svt', 'SVT', 'Leaf', 'green', 'seconde', 'Seconde', [
      {
        title: 'La cellule et l\'ADN',
        content:
          "Tous les êtres vivants sont composés de cellules. La cellule est l'unité de base du vivant. Elle contient un noyau qui renferme l'ADN (acide désoxyribonucléique), molécule qui porte l'information génétique. L'ADN a une structure en double hélice et est composé de nucléotides (A, T, G, C). Les gènes sont des portions d'ADN qui codent pour des protéines. Chaque cellule humaine contient environ 2 mètres d'ADN !",
        example: "L'ADN est comme un livre de recettes : chaque gène est une recette pour fabriquer une protéine spécifique.",
        keyPoints: [
          'La cellule est l\'unité de base du vivant',
          'L\'ADN porte l\'information génétique',
          'L\'ADN a une structure en double hélice',
          'Les gènes codent pour des protéines',
        ],
        exercise: {
          q: 'Où se trouve l\'ADN dans une cellule ?',
          opts: ['Dans le cytoplasme', 'Dans le noyau', 'Dans la membrane', 'Dans les mitochondries uniquement'],
          ans: 1,
          exp: "L'ADN se trouve principalement dans le noyau de la cellule, sous forme de chromosomes.",
          method: 'Retiens : noyau = chromosomes = ADN.',
        },
        quiz: [
          { q: 'Que sont les gènes ?', opts: ['Des cellules', 'Des portions d\'ADN', 'Des protéines', 'Des atomes'], ans: 1, exp: 'Les gènes sont des portions d\'ADN qui codent pour des protéines.' },
          { q: 'L\'ADN a une structure en :', opts: ['Spirale simple', 'Double hélice', 'Cercle', 'Ligne droite'], ans: 1, exp: 'L\'ADN a une structure en double hélice, découverte par Watson et Crick.' },
          { q: 'Les nucléotides de l\'ADN sont :', opts: ['A, T, G, C', 'A, U, G, C', 'A, B, C, D', 'X, Y, Z'], ans: 0, exp: 'Les 4 nucléotides de l\'ADN sont : Adénine, Thymine, Guanine, Cytosine.' },
        ],
      },
    ]),
    makeSubject('physique-chimie', 'Physique-Chimie', 'Atom', 'indigo', 'seconde', 'Seconde', [
      {
        title: 'Les molécules et la mole',
        content:
          "Une mole est une quantité de matière qui contient environ 6,02 × 10²³ entités (atomes, molécules...). Ce nombre s'appelle le nombre d'Avogadro (N_A). La masse molaire (M) est la masse d'une mole de substance, exprimée en g/mol. Par exemple, la masse molaire de l'eau (H₂O) est : 2×1 + 16 = 18 g/mol. La mole permet de compter des atomes et des molécules en utilisant des masses mesurables.",
        example: "Une mole d'eau (H₂O) pèse 18 g et contient 6,02 × 10²³ molécules d'eau.",
        keyPoints: [
          'Une mole = 6,02 × 10²³ entités (nombre d\'Avogadro)',
          'La masse molaire = masse d\'une mole (g/mol)',
          'Masse molaire de H₂O = 18 g/mol',
          'La mole permet de compter les atomes par la masse',
        ],
        exercise: {
          q: 'Combien d\'entités contient une mole ?',
          opts: ['6,02 × 10²³', '3 × 10²³', '1 × 10²³', '12 × 10²³'],
          ans: 0,
          exp: "Le nombre d'Avogadro est N_A = 6,02 × 10²³ entités par mole.",
          method: 'Retiens : 1 mole = 6,02 × 10²³ entités.',
        },
        quiz: [
          { q: 'Quelle est la masse molaire de H₂O ?', opts: ['16 g/mol', '18 g/mol', '20 g/mol', '2 g/mol'], ans: 1, exp: 'H₂O : 2×1 (H) + 16 (O) = 18 g/mol.' },
          { q: 'Le nombre d\'Avogadro vaut environ :', opts: ['10²³', '6,02 × 10²³', '10²⁶', '3 × 10²³'], ans: 1, exp: 'N_A ≈ 6,02 × 10²³ entités par mole.' },
          { q: 'La masse molaire s\'exprime en :', opts: ['g', 'g/mol', 'mol', 'kg'], ans: 1, exp: 'La masse molaire s\'exprime en grammes par mole (g/mol).' },
        ],
      },
    ]),
    makeSubject('ses', 'SES (Sciences Économiques et Sociales)', 'TrendingUp', 'emerald', 'seconde', 'Seconde', [
      {
        title: 'L\'entreprise et la production',
        content:
          "Une entreprise est une organisation qui produit des biens ou des services pour les vendre et réaliser un profit. On distingue les entreprises privées (détenues par des particuliers) et les entreprises publiques (détenues par l'État). L'entreprise combine des facteurs de production : le travail (salariés) et le capital (machines, locaux). Son objectif est de produire efficacement pour être rentable. Le chiffre d'affaires est le total des ventes.",
        example: "Une boulangerie produit du pain (bien) et le vend. Ses facteurs de production : le boulanger (travail) et le four (capital).",
        keyPoints: [
          'Une entreprise produit des biens ou des services',
          'Facteurs de production : travail + capital',
          'Objectif : produire et être rentable',
          'Chiffre d\'affaires = total des ventes',
        ],
        exercise: {
          q: 'Quels sont les deux facteurs de production principaux ?',
          opts: ['L\'argent et le temps', 'Le travail et le capital', 'Les clients et les produits', 'La publicité et les ventes'],
          ans: 1,
          exp: "Les deux facteurs de production sont le travail (salariés) et le capital (machines, équipements, locaux).",
          method: 'Retiens : production = travail (humains) + capital (machines).',
        },
        quiz: [
          { q: 'Qu\'est-ce que le chiffre d\'affaires ?', opts: ['Les bénéfices', 'Le total des ventes', 'Les dépenses', 'Le nombre de salariés'], ans: 1, exp: 'Le chiffre d\'affaires est le total des ventes de l\'entreprise.' },
          { q: 'Une entreprise publique est détenue par :', opts: ['Des particuliers', 'L\'État', 'Des étrangers', 'Des banques'], ans: 1, exp: 'Une entreprise publique est détenue par l\'État.' },
          { q: 'Le travail est un facteur de :', opts: ['Vente', 'Production', 'Marketing', 'Financement'], ans: 1, exp: 'Le travail (les salariés) est un facteur de production, avec le capital.' },
        ],
      },
    ]),
    makeSubject('histoire', 'Histoire', 'Landmark', 'orange', 'seconde', 'Seconde', [
      {
        title: 'La Seconde Guerre mondiale',
        content:
          "La Seconde Guerre mondiale (1939-1945) a opposé les Alliés (France, Royaume-Uni, URSS, USA) à l'Axe (Allemagne nazie, Italie fasciste, Japon). Les causes : le traité de Versailles humiliant, la crise économique, la montée des dictatures (Hitler, Mussolini). La guerre a fait environ 60 millions de morts, dont 6 millions de Juifs dans la Shoah. Elle s'est terminée avec la capitulation de l'Allemagne (8 mai 1945) et du Japon (2 septembre 1945, après Hiroshima et Nagasaki).",
        example: "Le débarquement de Normandie (6 juin 1944) a marqué le début de la libération de l'Europe occidentale.",
        keyPoints: [
          'La Seconde Guerre mondiale : 1939-1945',
          'Alliés vs Axe (Allemagne, Italie, Japon)',
          'Environ 60 millions de morts, dont 6 millions dans la Shoah',
          'Capitulation de l\'Allemagne : 8 mai 1945',
        ],
        exercise: {
          q: 'Quand l\'Allemagne a-t-elle capitulé ?',
          opts: ['8 mai 1945', '11 novembre 1918', '2 septembre 1945', '6 juin 1944'],
          ans: 0,
          exp: "L'Allemagne a capitulé le 8 mai 1945, marquant la fin de la guerre en Europe.",
          method: 'Retiens : 8 mai 1945 = capitulation allemande, 2 septembre 1945 = capitulation japonaise.',
        },
        quiz: [
          { q: 'Combien de morts a fait la Seconde Guerre mondiale ?', opts: ['10 millions', '60 millions', '100 millions', '1 million'], ans: 1, exp: 'La Seconde Guerre mondiale a fait environ 60 millions de morts.' },
          { q: 'La Shoah désigne :', opts: ['Le débarquement de Normandie', 'Le génocide des Juifs', 'La capitulation japonaise', 'La bataille de Stalingrad'], ans: 1, exp: 'La Shoah est le génocide de 6 millions de Juifs par les nazis.' },
          { q: 'Qui faisait partie de l\'Axe ?', opts: ['France, UK, USA', 'Allemagne, Italie, Japon', 'URSS, Chine, UK', 'USA, Canada, UK'], ans: 1, exp: 'L\'Axe était composé de l\'Allemagne nazie, de l\'Italie fasciste et du Japon.' },
        ],
      },
    ]),
    makeSubject('anglais', 'Anglais', 'Languages', 'red', 'seconde', 'Seconde', [
      {
        title: 'Le conditionnel et les hypothèses',
        content:
          "Le conditionnel en anglais exprime une hypothèse, un souhait ou une demande polie. Le conditionnel présent : would + verbe. « I would go if I had time. » Les phrases conditionnelles utilisent « if » : Type 1 (réel) : If + present, will + verbe. Type 2 (irréel) : If + past, would + verbe. « If I were rich, I would travel. » Type 3 (passé irréel) : If + past perfect, would have + participe.",
        example: "If I had money, I would buy a car. / I would like to help you. / If it rains, we will stay home.",
        keyPoints: [
          'Conditionnel présent : would + verbe',
          'Type 1 (réel) : If + present, will + verbe',
          'Type 2 (irréel) : If + past, would + verbe',
          'Type 3 (passé irréel) : If + past perfect, would have + participe',
        ],
        exercise: {
          q: 'Complète : « If I (be) you, I would study harder »',
          opts: ['am', 'was', 'were', 'be'],
          ans: 2,
          exp: 'Dans le type 2 (irréel), on utilise « were » pour toutes les personnes : If I were you.',
          method: 'Type 2 : If + sujet + were (toutes personnes), would + verbe.',
        },
        quiz: [
          { q: 'Comment forme-t-on le conditionnel présent ?', opts: ['will + verbe', 'would + verbe', 'should + verbe', 'must + verbe'], ans: 1, exp: 'Le conditionnel présent = would + verbe.' },
          { q: 'Quel type pour une condition réelle ?', opts: ['Type 1 (If + present, will)', 'Type 2 (If + past, would)', 'Type 3 (If + past perfect, would have)', 'Aucun'], ans: 0, exp: 'Le type 1 exprime une condition réelle : If + present, will + verbe.' },
          { q: '« I would like » exprime :', opts: ['Une obligation', 'Un souhait poli', 'Le passé', 'L\'interdiction'], ans: 1, exp: '« I would like » = je voudrais, c\'est une formule de souhait poli.' },
        ],
      },
    ]),
    makeSubject('espagnol', 'Espagnol', 'Languages', 'rose', 'seconde', 'Seconde', [
      {
        title: 'Le subjonctif présent',
        content:
          "Le subjonctif présent en espagnol exprime le doute, le souhait, l'émotion ou la volonté. Il se forme sur le radical de la 1re personne du présent + -e, -es, -e, -emos, -éis, -en pour les verbes en -ar, et -a, -as, -a, -amos, -áis, -an pour les -er/-ir. Exemple : hablar → hable, hables, hable... Il est utilisé après « que » quand le verbe principal exprime un doute, un souhait, une émotion.",
        example: "Espero que vengas (J'espère que tu viendras). / Quiero que estudies (Je veux que tu étudies).",
        keyPoints: [
          'Le subjonctif exprime doute, souhait, émotion, volonté',
          'Formé sur le radical de la 1re personne du présent',
          'Verbes en -ar : -e, -es, -e, -emos, -éis, -en',
          'Utilisé après « que » avec un verbe de volonté/émotion',
        ],
        exercise: {
          q: 'Conjugue « estudiar » à « yo » au subjonctif présent :',
          opts: ['estudio', 'estudie', 'estudio', 'estudiar'],
          ans: 1,
          exp: 'Le verbe estudiar (en -ar) au subjonctif : yo estudie (radical + -e).',
          method: 'Subjonctif -ar : radical + -e, -es, -e, -emos, -éis, -en.',
        },
        quiz: [
          { q: 'Quand utilise-t-on le subjonctif ?', opts: ['Pour exprimer une certitude', 'Pour exprimer un doute ou un souhait', 'Pour le passé', 'Pour le futur'], ans: 1, exp: 'Le subjonctif exprime le doute, le souhait, l\'émotion ou la volonté.' },
          { q: '« Espero que » est suivi du :', opts: ['Indicatif', 'Subjonctif', 'Infinitif', 'Impératif'], ans: 1, exp: '« Esperar que » (espérer que) est suivi du subjonctif.' },
          { q: 'Le subjonctif de « comer » à « yo » est :', opts: ['como', 'coma', 'comer', 'come'], ans: 1, exp: 'Comer (en -er) au subjonctif : yo coma (radical + -a).' },
        ],
      },
    ]),
  ];
}


/**
 * Construit les séries cibles : packs spécifiques (seriesPedagogy) + legacy A/C/D.
 * Les sujets spécifiques ont des IDs préfixés par série (progression individualisée).
 * Le pack littéraire legacy reste sous serie-a (A_CONFIRMER pour subdivision fine).
 */
function mergeSubjectLists(a: Subject[], b: Subject[]): Subject[] {
  const byName = new Map<string, Subject>();
  for (const s of a) byName.set(s.name, s);
  for (const s of b) {
    const prev = byName.get(s.name);
    if (!prev) byName.set(s.name, s);
    else {
      // Préfixer le pack série : prioriser le contenu spécifique en tête
      byName.set(s.name, {
        ...s,
        chapters: [...s.chapters, ...prev.chapters],
        description: s.description,
      });
    }
  }
  return Array.from(byName.values());
}

function expandLyceeSeries(level: 'premiere' | 'terminale', base: Series[]): Series[] {
  const byId = new Map(base.map((s) => [s.id, s]));
  const literary = byId.get('serie-a')?.subjects ?? [];
  const sciC = byId.get('serie-c')?.subjects ?? [];

  const build = (seriesId: string, name: string, shared: Subject[]): Series => {
    const specific = getSeriesSpecificSubjects(level, seriesId);
    return {
      id: seriesId,
      name,
      subjects: mergeSubjectLists(shared, specific),
    };
  };

  const extra: Series[] = [];
  if (level === 'premiere') {
    extra.push(
      build('serie-a1', 'Première A1', literary),
      build('serie-a2', 'Première A2', literary),
      build('serie-b', 'Première B', literary),
      build('serie-s', 'Première S', sciC)
    );
  } else {
    extra.push(
      build('serie-a1', 'Terminale A1', literary),
      build('serie-a2', 'Terminale A2', literary),
      build('serie-b', 'Terminale B', literary)
    );
    // Enrichir C et D existants sans supprimer le legacy
    const c = byId.get('serie-c');
    const d = byId.get('serie-d');
    if (c) {
      extra.push({
        id: 'serie-c',
        name: 'Terminale C',
        subjects: mergeSubjectLists(c.subjects, getSeriesSpecificSubjects('terminale', 'serie-c')),
      });
    }
    if (d) {
      extra.push({
        id: 'serie-d',
        name: 'Terminale D',
        subjects: mergeSubjectLists(d.subjects, getSeriesSpecificSubjects('terminale', 'serie-d')),
      });
    }
  }

  const preferredOrder =
    level === 'premiere'
      ? ['serie-a1', 'serie-a2', 'serie-b', 'serie-s', 'serie-a', 'serie-c', 'serie-d']
      : ['serie-a1', 'serie-a2', 'serie-b', 'serie-c', 'serie-d', 'serie-a'];

  const merged = [...extra, ...base];
  const seen = new Set<string>();
  const ordered: Series[] = [];
  for (const id of preferredOrder) {
    const s = merged.find((x) => x.id === id);
    if (s && !seen.has(s.id)) {
      ordered.push(s);
      seen.add(s.id);
    }
  }
  for (const s of merged) {
    if (!seen.has(s.id)) ordered.push(s);
  }
  return ordered;
}

/** Seconde LE / S : tronc commun PARTAGE + packs spécifiques distincts. */
export function getSecondeSeries(): Series[] {
  const common = getSecondeSubjects();
  return [
    {
      id: 'serie-le',
      name: 'Seconde LE',
      subjects: mergeSubjectLists(common, getSeriesSpecificSubjects('seconde', 'serie-le')),
    },
    {
      id: 'serie-s',
      name: 'Seconde S',
      subjects: mergeSubjectLists(common, getSeriesSpecificSubjects('seconde', 'serie-s')),
    },
  ];
}

// ─── Première et Terminale (avec séries) ─────────────────────────

export function getPremiereSeries(): Series[] {
  const base: Series[] = [
    {
      id: 'serie-c',
      name: 'Série C (Scientifique)',
      subjects: [
        makeSubject('mathematiques', 'Mathématiques', 'Calculator', 'blue', 'premiere-c', 'Première C', [
          {
            title: 'Les suites numériques',
            content:
              "Une suite est une liste ordonnée de nombres. Une suite arithmétique a un terme général u(n) = u(0) + n×r, où r est la raison. Une suite géométrique a un terme général u(n) = u(0) × q^n, où q est la raison. Les suites permettent de modéliser des phénomènes comme la croissance d'une population ou les intérêts bancaires. Une suite est convergente si elle tend vers une limite finie quand n tend vers l'infini.",
            example: "Suite arithmétique de raison 3 : 2, 5, 8, 11, 14... u(n) = 2 + 3n. Suite géométrique de raison 2 : 1, 2, 4, 8, 16... u(n) = 2^n.",
            keyPoints: [
              'Suite arithmétique : u(n) = u(0) + n×r',
              'Suite géométrique : u(n) = u(0) × q^n',
              'Les suites modélisent des phénomènes réels',
              'Une suite peut converger vers une limite',
            ],
            exercise: {
              q: 'Soit une suite arithmétique de raison 4 et de premier terme 3. Quel est le 10e terme ?',
              opts: ['43', '40', '34', '30'],
              ans: 0,
              exp: 'u(10) = 3 + 10×4 = 3 + 40 = 43. Le 10e terme est 43.',
              method: 'Pour une suite arithmétique : u(n) = u(0) + n×r.',
            },
            quiz: [
              { q: 'Suite géométrique de raison 2 et premier terme 1. Quel est le 5e terme ?', opts: ['16', '32', '10', '5'], ans: 1, exp: 'u(5) = 1 × 2^5 = 32.' },
              { q: 'Une suite arithmétique a pour raison -2. Elle est :', opts: ['Croissante', 'Décroissante', 'Constante', 'Géométrique'], ans: 1, exp: 'Une raison négative signifie que la suite est décroissante.' },
              { q: 'Le terme général d\'une suite géométrique est :', opts: ['u(0) + n×r', 'u(0) × q^n', 'u(0) × n', 'u(0) + r'], ans: 1, exp: 'Une suite géométrique : u(n) = u(0) × q^n.' },
            ],
          },
        ]),
        makeSubject('physique-chimie', 'Physique-Chimie', 'Atom', 'indigo', 'premiere-c', 'Première C', [
          {
            title: 'La mécanique de Newton',
            content:
              "Les trois lois de Newton décrivent le mouvement des corps. 1re loi (inertie) : un corps sans force reste immobile ou en mouvement rectiligne uniforme. 2e loi (fondamentale) : F = m×a, la force est égale à la masse fois l'accélération. 3e loi (action-réaction) : à toute action correspond une réaction opposée et égale. Ces lois permettent de comprendre le mouvement des planètes, des voitures, des projectiles.",
            example: "Une voiture de 1000 kg qui accélère à 2 m/s² subit une force F = 1000 × 2 = 2000 N.",
            keyPoints: [
              '1re loi : inertie (sans force, mouvement uniforme)',
              '2e loi : F = m × a',
              '3e loi : action = réaction (opposée et égale)',
              'Ces lois décrivent le mouvement des corps',
            ],
            exercise: {
              q: 'Une force de 50 N s\'applique sur un objet de 10 kg. Quelle est son accélération ?',
              opts: ['5 m/s²', '500 m/s²', '0,2 m/s²', '60 m/s²'],
              ans: 0,
              exp: 'F = m×a → a = F/m = 50/10 = 5 m/s².',
              method: 'Utilise F = m×a, donc a = F/m.',
            },
            quiz: [
              { q: 'La 2e loi de Newton est :', opts: ['F = m×a', 'E = mc²', 'F = G×m/r²', 'P = m×g'], ans: 0, exp: 'La 2e loi de Newton : F = m × a (force = masse × accélération).' },
              { q: 'La 3e loi dit :', opts: ['Tout corps attire tout autre', 'Action = réaction', 'L\'énergie se conserve', 'La vitesse est constante'], ans: 1, exp: 'La 3e loi : à toute action correspond une réaction opposée et égale.' },
              { q: 'Sans force, un corps en mouvement :', opts: ['S\'arrête', 'Accélère', 'Continue en ligne droite', 'Tourne'], ans: 2, exp: '1re loi (inertie) : sans force, un corps garde son mouvement rectiligne uniforme.' },
            ],
          },
        ]),
        makeSubject('svt', 'SVT', 'Leaf', 'green', 'premiere-c', 'Première C', [
          {
            title: 'L\'évolution des espèces',
            content:
              "L'évolution est le processus par lequel les espèces changent au fil du temps. Darwin a proposé la théorie de la sélection naturelle : les individus les mieux adaptés à leur environnement survivent et se reproduisent davantage, transmettant leurs caractères avantageux. Les mutations génétiques sont la source de la variation. Au fil des générations, ces variations accumulées peuvent donner naissance à de nouvelles espèces.",
            example: "Les girafes avec un cou plus long ont accès à plus de nourriture, survivent mieux et transmettent ce caractère à leurs descendants.",
            keyPoints: [
              'L\'évolution explique la diversité des espèces',
              'La sélection naturelle : les mieux adaptés survivent',
              'Les mutations génétiques créent la variation',
              'Les espèces évoluent sur des millions d\'années',
            ],
            exercise: {
              q: 'Qui a proposé la théorie de la sélection naturelle ?',
              opts: ['Mendel', 'Darwin', 'Pasteur', 'Lavoisier'],
              ans: 1,
              exp: "Charles Darwin a proposé la théorie de l'évolution par sélection naturelle en 1859.",
              method: 'Retiens : Darwin = évolution par sélection naturelle.',
            },
            quiz: [
              { q: 'La sélection naturelle favorise :', opts: ['Les plus forts', 'Les mieux adaptés', 'Les plus jeunes', 'Les plus grands'], ans: 1, exp: 'La sélection naturelle favorise les individus les mieux adaptés à leur environnement.' },
              { q: 'Les mutations génétiques sont :', opts: ['Rares', 'La source de la variation', 'Toujours néfastes', 'Inexistantes'], ans: 1, exp: 'Les mutations sont la source de la variation génétique sur laquelle agit la sélection.' },
              { q: 'L\'évolution des espèces se fait sur :', opts: ['Quelques années', 'Des millions d\'années', 'Quelques mois', 'Instantanément'], ans: 1, exp: 'L\'évolution est un processus lent qui se déroule sur des millions d\'années.' },
            ],
          },
        ]),
      ],
    },
    {
      id: 'serie-d',
      name: 'Série D (Scientifique)',
      subjects: [
        makeSubject('mathematiques', 'Mathématiques', 'Calculator', 'blue', 'premiere-d', 'Première D', [
          {
            title: 'Les probabilités',
            content:
              "Les probabilités mesurent la chance qu'un événement se réalise. La probabilité d'un événement A est P(A) = nombre de cas favorables / nombre de cas possibles. Elle est comprise entre 0 (impossible) et 1 (certain). Deux événements sont indépendants si la réalisation de l'un n'influence pas l'autre. P(A et B) = P(A) × P(B) si indépendants. P(A ou B) = P(A) + P(B) - P(A et B).",
            example: "Pile ou face : P(pile) = 1/2 = 0,5. Dé à 6 faces : P(6) = 1/6 ≈ 0,167.",
            keyPoints: [
              'P(A) = cas favorables / cas possibles',
              '0 ≤ P(A) ≤ 1',
              'Événements indépendants : P(A et B) = P(A) × P(B)',
              'P(A ou B) = P(A) + P(B) - P(A et B)',
            ],
            exercise: {
              q: 'Quelle est la probabilité de tirer un as dans un jeu de 52 cartes ?',
              opts: ['1/52', '4/52 (ou 1/13)', '1/4', '1/13'],
              ans: 1,
              exp: 'Il y a 4 as dans 52 cartes. P(as) = 4/52 = 1/13.',
              method: 'Compte les cas favorables (4 as) et divise par les cas possibles (52 cartes).',
            },
            quiz: [
              { q: 'La probabilité d\'un événement certain est :', opts: ['0', '0,5', '1', '100'], ans: 2, exp: 'Un événement certain a une probabilité de 1 (100%).' },
              { q: 'Si A et B sont indépendants, P(A et B) = ?', opts: ['P(A) + P(B)', 'P(A) × P(B)', 'P(A) - P(B)', 'P(A) / P(B)'], ans: 1, exp: 'Pour des événements indépendants : P(A et B) = P(A) × P(B).' },
              { q: 'P(pile) au pile ou face =', opts: ['1', '0,5', '0', '0,25'], ans: 1, exp: 'P(pile) = 1/2 = 0,5.' },
            ],
          },
        ]),
        makeSubject('svt', 'SVT', 'Leaf', 'green', 'premiere-d', 'Première D', [
          {
            title: 'Le système immunitaire',
            content:
              "Le système immunitaire défend l'organisme contre les microbes (virus, bactéries). Il comprend deux branches : l'immunité innée (rapide, non spécifique) et l'immunité adaptative (lente, spécifique, avec mémoire). Les globules blancs (leucocytes) sont les soldats du système immunitaire. Les lymphocytes B produisent des anticorps, les lymphocytes T détruisent les cellules infectées. La vaccination stimule le système immunitaire pour qu'il mémorise un microbe.",
            example: "Le vaccin contre le COVID-19 entraîne le système immunitaire à reconnaître et combattre le virus sans la maladie.",
            keyPoints: [
              'Le système immunitaire défend contre les microbes',
              'Immunité innée (rapide) et adaptative (spécifique, mémoire)',
              'Les lymphocytes B produisent des anticorps',
              'La vaccination stimule la mémoire immunitaire',
            ],
            exercise: {
              q: 'Que produisent les lymphocytes B ?',
              opts: ['Des globules rouges', 'Des anticorps', 'Des virus', 'Du sang'],
              ans: 1,
              exp: "Les lymphocytes B produisent des anticorps qui reconnaissent et neutralisent les microbes.",
              method: 'Retiens : lymphocytes B = anticorps, lymphocytes T = destruction directe.',
            },
            quiz: [
              { q: 'L\'immunité innée est :', opts: ['Lente et spécifique', 'Rapide et non spécifique', 'Lente et non spécifique', 'Rapide et spécifique'], ans: 1, exp: 'L\'immunité innée est rapide mais non spécifique.' },
              { q: 'À quoi sert la vaccination ?', opts: ['À guérir la maladie', 'À stimuler la mémoire immunitaire', 'À tuer les microbes', 'À produire du sang'], ans: 1, exp: "La vaccination stimule le système immunitaire pour qu'il mémorise un microbe." },
              { q: 'Les globules blancs sont aussi appelés :', opts: ['Hématies', 'Leucocytes', 'Plaquettes', 'Plasma'], ans: 1, exp: 'Les globules blancs = leucocytes, les soldats du système immunitaire.' },
            ],
          },
        ]),
        makeSubject('physique-chimie', 'Physique-Chimie', 'Atom', 'indigo', 'premiere-d', 'Première D', [
          {
            title: 'Les acides et les bases',
            content:
              "Un acide est une substance qui libère des ions H+ (protons). Une base libère des ions OH- (hydroxyde). Le pH mesure l'acidité : pH < 7 = acide, pH = 7 = neutre, pH > 7 = basique. L'échelle de pH va de 0 à 14. Une réaction acide-base produit du sel et de l'eau. Par exemple : HCl + NaOH → NaCl + H₂O. Les acides ont un goût acide, les bases un goût amer.",
            example: "Le citron est acide (pH ≈ 2). L'eau est neutre (pH = 7). Le savon est basique (pH ≈ 10).",
            keyPoints: [
              'Acide : libère H+, pH < 7',
              'Base : libère OH-, pH > 7',
              'Neutre : pH = 7',
              'Réaction acide-base → sel + eau',
            ],
            exercise: {
              q: 'Une solution a un pH de 3. Elle est :',
              opts: ['Neutre', 'Basique', 'Acide', 'Salée'],
              ans: 2,
              exp: "Un pH < 7 indique une solution acide. Le pH de 3 est nettement acide.",
              method: 'Retiens : pH < 7 = acide, pH = 7 = neutre, pH > 7 = basique.',
            },
            quiz: [
              { q: 'Le pH de l\'eau pure est :', opts: ['0', '7', '14', '3'], ans: 1, exp: 'L\'eau pure a un pH neutre de 7.' },
              { q: 'Une base libère quel ion ?', opts: ['H+', 'OH-', 'Na+', 'Cl-'], ans: 1, exp: 'Une base libère des ions hydroxyde OH-.' },
              { q: 'Le citron a un pH d\'environ :', opts: ['2 (acide)', '7 (neutre)', '12 (basique)', '14 (basique)'], ans: 0, exp: 'Le citron est acide, son pH est d\'environ 2.' },
            ],
          },
        ]),
      ],
    },
    {
      id: 'serie-a',
      name: 'Série A (Littéraire)',
      subjects: [
        makeSubject('francais', 'Français', 'BookOpen', 'amber', 'premiere-a', 'Première A', [
          {
            title: 'Littérature et francophonie : lire depuis le Gabon',
            content:
              "Les genres (roman, théâtre, poésie, conte, essai) et les registres (lyrique, tragique, comique, satirique…) servent à analyser les textes. En Afrique francophone et au Gabon : oralité (contes, proverbes), romans et poésie sur mémoire, identité, ville, forêt, indépendance. Au BAC : procédé → effet → sens, avec exemples ancrés dans le réel de l'élève gabonais quand c'est pertinent.",
            example: "Argumenter sur les contes gabonais ou la protection de la forêt : thèse, arguments, exemples.",
            keyPoints: [
              'Genres et registres',
              'Oralité gabonaise / africaine',
              'Francophonie',
              'Procédé → effet → sens',
            ],
            exercise: {
              q: 'L\'oralité africaine comprend surtout :',
              opts: ['uniquement les formules de maths', 'contes, proverbes, chants', 'le code de la route', 'les tables de multiplication'],
              ans: 1,
              exp: "Contes, proverbes et chants transmettent culture et valeurs.",
              method: "Ancre tes exemples dans la culture gabonaise.",
            },
            quiz: [
              { q: 'La francophonie désigne :', opts: ['uniquement Paris', 'l\'espace des cultures de langue française', 'une province du Gabon', 'un sport'], ans: 1, exp: 'Y compris en Afrique.' },
              { q: 'Un exemple gabonais dans un commentaire :', opts: ['est toujours hors sujet', 'ancre l\'analyse dans le réel de l\'élève', 'remplace la lecture', 'est interdit'], ans: 1, exp: 'Ancrage local.' },
              { q: 'Procédé → effet → sens sert à :', opts: ['réciter sans comprendre', 'analyser un texte en profondeur', 'compter les pages', 'ignorer le sujet'], ans: 1, exp: 'Méthode BAC.' },
            ],
          },
        ]),
        makeSubject('philosophie', 'Philosophie', 'Brain', 'purple', 'premiere-a', 'Première A', [
          {
            title: 'Qu\'est-ce que la philosophie ?',
            content:
              "La philosophie (du grec « amour de la sagesse ») est une discipline qui questionne le monde, la connaissance et l'existence. Elle pose des questions fondamentales : Qu'est-ce que le bonheur ? Qu'est-ce que la vérité ? Qu'est-ce que la justice ? Les grands philosophes : Socrate (le questionnement), Platon (la théorie des idées), Aristote (la logique), Descartes (le doute méthodique : « Je pense, donc je suis »), Kant (la morale).",
            example: "Socrate disait : « Je sais que je ne sais rien. » Il invitait à douter de ses certitudes pour mieux réfléchir.",
            keyPoints: [
              'La philosophie = amour de la sagesse',
              'Elle pose des questions fondamentales',
              'Socrate : le questionnement',
              'Descartes : « Je pense, donc je suis »',
            ],
            exercise: {
              q: 'Qui a dit « Je pense, donc je suis » ?',
              opts: ['Socrate', 'Platon', 'Descartes', 'Kant'],
              ans: 2,
              exp: "René Descartes a formulé « Je pense, donc je suis » (Cogito, ergo sum) comme fondement de sa philosophie.",
              method: 'Retiens : Descartes = doute méthodique + « Je pense, donc je suis ».',
            },
            quiz: [
              { q: 'Que signifie « philosophie » ?', opts: ['Amour du pouvoir', 'Amour de la sagesse', 'Amour de l\'art', 'Amour de la science'], ans: 1, exp: 'Philosophie = philo (amour) + sophia (sagesse) en grec.' },
              { q: 'Qui est connu pour le questionnement ?', opts: ['Descartes', 'Socrate', 'Kant', 'Aristote'], ans: 1, exp: 'Socrate est connu pour sa méthode de questionnement (la maïeutique).' },
              { q: 'La philosophie pose des questions sur :', opts: ['La technique uniquement', 'L\'existence, la vérité, la justice', 'Le sport', 'La cuisine'], ans: 1, exp: 'La philosophie questionne l\'existence, la connaissance, la morale, la vérité.' },
            ],
          },
        ]),
        makeSubject('anglais', 'Anglais', 'Languages', 'red', 'premiere-a', 'Première A', [
          {
            title: 'Les temps du passé et le récit',
            content:
              "En anglais, le récit utilise plusieurs temps du passé. Le past simple pour les actions successives : « He entered, sat down and ordered a coffee. » Le past continuous pour une action en cours : « The sun was shining. » Le past perfect pour une action antérieure : « She had finished before he arrived. » Ces temps permettent de créer une chronologie dans le récit.",
            example: "She had eaten (past perfect, avant) when he arrived (past simple, après). L'ordre chronologique est clair.",
            keyPoints: [
              'Past simple : actions successives',
              'Past continuous : action en cours dans le passé',
              'Past perfect : action antérieure à une autre',
              'Ces temps créent la chronologie du récit',
            ],
            exercise: {
              q: 'Quel temps pour exprimer une action antérieure à une autre dans le passé ?',
              opts: ['Past simple', 'Past continuous', 'Past perfect', 'Present perfect'],
              ans: 2,
              exp: "Le past perfect (had + participe passé) exprime une action antérieure à une autre action passée.",
              method: 'Retiens : past perfect = had + participe passé = action encore plus ancienne.',
            },
            quiz: [
              { q: 'Comment forme-t-on le past perfect ?', opts: ['verbe + -ed', 'was + verbe-ing', 'had + participe passé', 'have + participe'], ans: 2, exp: 'Le past perfect = had + participe passé.' },
              { q: '« He was reading when the phone rang » utilise :', opts: ['Past simple uniquement', 'Past continuous + past simple', 'Past perfect', 'Present'], ans: 1, exp: '« Was reading » = past continuous, « rang » = past simple.' },
              { q: 'Le past simple sert à :', opts: ['Décrire une action en cours', 'Exprimer des actions successives', 'Exprimer le futur', 'Décrire le présent'], ans: 1, exp: 'Le past simple exprime des actions successives et terminées dans le passé.' },
            ],
          },
        ]),
        makeSubject('histoire', 'Histoire', 'Landmark', 'orange', 'premiere-a', 'Première A', [
          {
            title: 'La décolonisation en Afrique',
            content:
              "La décolonisation est le processus par lequel les colonies ont obtenu leur indépendance, principalement après la Seconde Guerre mondiale (1945-1960). En Afrique, la décolonisation s'est faite parfois pacifiquement, parfois par la guerre (Algérie, Kenya). Le Gabon a obtenu son indépendance le 17 août 1960, pacifiquement, de la France. La décolonisation a posé de nouveaux défis : construction d'États, économie, frontières artificielles.",
            example: "Le Gabon est devenu indépendant le 17 août 1960, sans guerre, contrairement à l'Algérie.",
            keyPoints: [
              'La décolonisation a eu lieu après 1945',
              'Le Gabon est indépendant depuis le 17 août 1960',
              'Décolonisation parfois pacifique, parfois violente',
              'Défis : construction d\'États, frontières artificielles',
            ],
            exercise: {
              q: 'Quand le Gabon a-t- obtenu son indépendance ?',
              opts: ['17 août 1960', '5 octobre 1958', '1er janvier 1960', '17 août 1965'],
              ans: 0,
              exp: "Le Gabon a obtenu son indépendance de la France le 17 août 1960, pacifiquement.",
              method: 'Retiens : 17 août 1960 = indépendance du Gabon.',
            },
            quiz: [
              { q: 'De quel pays le Gabon a-t-il obtenu son indépendance ?', opts: ['Royaume-Uni', 'France', 'Belgique', 'Portugal'], ans: 1, exp: 'Le Gabon était une colonie française et a obtenu son indépendance de la France.' },
              { q: 'La décolonisation a principalement eu lieu après :', opts: ['La Première Guerre mondiale', 'La Seconde Guerre mondiale', 'La Guerre froide', '1990'], ans: 1, exp: 'La décolonisation s\'est principalement déroulée après la Seconde Guerre mondiale (1945-1960).' },
              { q: 'La décolonisation du Gabon a été :', opts: ['Violente', 'Pacifique', 'Longue', 'Inachevée'], ans: 1, exp: 'Le Gabon a obtenu son indépendance pacifiquement, contrairement à d\'autres pays.' },
            ],
          },
        ]),
      ],
    },
  ];
  return expandLyceeSeries('premiere', base);
}

export function getTerminaleSeries(): Series[] {
  const base: Series[] = [
    {
      id: 'serie-c',
      name: 'Série C (Scientifique)',
      subjects: [
        makeSubject('mathematiques', 'Mathématiques', 'Calculator', 'blue', 'terminale-c', 'Terminale C', [
          {
            title: 'Les intégrales et primitives',
            content:
              "Une primitive d'une fonction f est une fonction F telle que F'(x) = f(x). L'intégrale de f sur [a, b] est l'aire sous la courbe de f entre a et b. Elle se calcule avec F(b) - F(a). Les intégrales servent à calculer des aires, des volumes, des probabilités. La notation : ∫[a,b] f(x) dx = F(b) - F(a).",
            example: "Si f(x) = 2x, une primitive est F(x) = x². L'intégrale de 0 à 3 : F(3) - F(0) = 9 - 0 = 9.",
            keyPoints: [
              'Une primitive F vérifie F\'(x) = f(x)',
              'L\'intégrale = aire sous la courbe',
              '∫[a,b] f(x) dx = F(b) - F(a)',
              'Les intégrales servent à calculer aires, volumes, probabilités',
            ],
            exercise: {
              q: 'Quelle est la primitive de f(x) = 3x² ?',
              opts: ['x³', '6x', 'x³ + C', '3x³'],
              ans: 2,
              exp: "La primitive de 3x² est x³ + C (où C est une constante), car la dérivée de x³ est 3x².",
              method: 'Pour trouver une primitive : augmente la puissance de 1 et divise par la nouvelle puissance.',
            },
            quiz: [
              { q: 'L\'intégrale de f sur [a,b] se calcule par :', opts: ['F(a) - F(b)', 'F(b) - F(a)', 'F(a) × F(b)', 'F(a) + F(b)'], ans: 1, exp: 'L\'intégrale ∫[a,b] f(x) dx = F(b) - F(a).' },
              { q: 'Quelle est la primitive de f(x) = 1 ?', opts: ['x + C', '0', '1', 'x²'], ans: 0, exp: 'La primitive de 1 est x + C (car la dérivée de x est 1).' },
              { q: 'L\'intégrale représente :', opts: ['Une pente', 'Une aire sous la courbe', 'Une longueur', 'Un volume'], ans: 1, exp: 'L\'intégrale représente l\'aire sous la courbe de la fonction.' },
            ],
          },
        ]),
        makeSubject('physique-chimie', 'Physique-Chimie', 'Atom', 'indigo', 'terminale-c', 'Terminale C', [
          {
            title: "L'électricité et les circuits",
            content:
              "La loi d'Ohm dit que la tension U aux bornes d'un résistor est proportionnelle à l'intensité I : U = R × I, où R est la résistance (en ohms). La puissance électrique est P = U × I (en watts). Dans un circuit en série, l'intensité est la même partout. Dans un circuit en dérivation, la tension est la même aux bornes de chaque branche. L'énergie électrique consommée est E = P × t.",
            example: "Un résistor de 100 Ω traversé par 0,2 A a une tension U = 100 × 0,2 = 20 V.",
            keyPoints: [
              "Loi d'Ohm : U = R × I",
              "Puissance : P = U × I",
              "En série : même intensité partout",
              "En dérivation : même tension aux bornes",
            ],
            exercise: {
              q: 'Si U = 12 V et R = 4 Ω, quelle est l\'intensité I ?',
              opts: ['48 A', '3 A', '0,33 A', '16 A'],
              ans: 1,
              exp: "U = R × I → I = U/R = 12/4 = 3 A.",
              method: "Utilise la loi d'Ohm : I = U/R.",
            },
            quiz: [
              { q: "La loi d'Ohm est :", opts: ['U = R × I', 'P = U × I', 'E = P × t', 'F = m × a'], ans: 0, exp: "La loi d'Ohm : U = R × I." },
              { q: "Dans un circuit en série :", opts: ['La tension est la même', 'L\'intensité est la même', 'R = 0', 'P = 0'], ans: 1, exp: "Dans un circuit en série, l'intensité est la même partout." },
              { q: "La puissance électrique se calcule par :", opts: ['P = R × I', 'P = U × I', 'P = U / I', 'P = U² / R'], ans: 1, exp: "La puissance électrique : P = U × I (en watts)." },
            ],
          },
        ]),
      ],
    },
    {
      id: 'serie-d',
      name: 'Série D (Scientifique)',
      subjects: [
        makeSubject('svt', 'SVT', 'Leaf', 'green', 'terminale-d', 'Terminale D', [
          {
            title: 'La génétique moléculaire',
            content:
              "La génétique moléculaire étudie l'ADN et l'expression des gènes. L'ADN est transcrit en ARN messager (transcription), puis l'ARN est traduit en protéine (traduction). Ce flux d'information est appelé le dogme central de la biologie : ADN → ARN → Protéine. Les mutations peuvent modifier les protéines et causer des maladies. La PCR permet d'amplifier l'ADN pour l'étudier.",
            example: "Le gène de l'insuline est transcrit en ARN, puis traduit en protéine insuline qui régule la glycémie.",
            keyPoints: [
              "Dogme central : ADN → ARN → Protéine",
              "Transcription : ADN → ARN messager",
              "Traduction : ARN → Protéine",
              "Les mutations peuvent causer des maladies",
            ],
            exercise: {
              q: 'Quel est le dogme central de la biologie ?',
              opts: ['Protéine → ARN → ADN', 'ADN → ARN → Protéine', 'ARN → ADN → Protéine', 'ADN → Protéine → ARN'],
              ans: 1,
              exp: "Le dogme central : l'information va de l'ADN vers l'ARN, puis vers la protéine.",
              method: 'Retiens : ADN → ARN (transcription) → Protéine (traduction).',
            },
            quiz: [
              { q: "La transcription produit :", opts: ['Des protéines', 'De l\'ARN messager', 'De l\'ADN', 'Des cellules'], ans: 1, exp: "La transcription : ADN → ARN messager." },
              { q: "La traduction produit :", opts: ['De l\'ADN', 'De l\'ARN', 'Des protéines', 'Des lipides'], ans: 2, exp: "La traduction : ARN → protéine." },
              { q: "Une mutation peut :", opts: ['Modifier une protéine', 'Créer de l\'énergie', 'Arrêter la respiration', 'Créer de la matière'], ans: 0, exp: "Une mutation modifie l'ADN, ce qui peut changer la protéine produite et causer des maladies." },
            ],
          },
        ]),
        makeSubject('mathematiques', 'Mathématiques', 'Calculator', 'blue', 'terminale-d', 'Terminale D', [
          {
            title: 'Les statistiques et probabilités',
            content:
              "Les statistiques permettent de résumer et d'analyser des données. Les indicateurs : la moyenne (somme / effectif), la médiane (valeur centrale), l'écart-type (dispersion). En probabilités, la loi binomiale modélise des expériences à deux issues (succès/échec) répétées n fois. L'espérance E(X) = n × p, où p est la probabilité de succès. L'écart-type σ = √(n×p×(1-p)).",
            example: "On lance 10 fois une pièce. La probabilité d'obtenir pile suit une loi binomiale B(10, 0,5). L'espérance est 10 × 0,5 = 5 piles.",
            keyPoints: [
              "Moyenne = somme / effectif",
              "Médiane = valeur centrale",
              "Loi binomiale : E(X) = n × p",
              "Écart-type = √(n×p×(1-p))",
            ],
            exercise: {
              q: "On lance 20 fois un dé. Quelle est l'espérance du nombre de 6 ?",
              opts: ['20/6 (≈3,33)', '5', '10', '1'],
              ans: 0,
              exp: "Loi binomiale B(20, 1/6). E(X) = 20 × 1/6 ≈ 3,33. En moyenne, on obtient environ 3,33 fois le 6.",
              method: "Espérance d'une loi binomiale : E(X) = n × p.",
            },
            quiz: [
              { q: "La médiane est :", opts: ["La moyenne", "La valeur centrale", "Le maximum", "Le minimum"], ans: 1, exp: "La médiane est la valeur qui sépare les données en deux groupes égaux." },
              { q: "L'écart-type mesure :", opts: ["La moyenne", "La dispersion", "La médiane", "Le total"], ans: 1, exp: "L'écart-type mesure la dispersion des données autour de la moyenne." },
              { q: "E(X) pour une loi binomiale B(n, p) =", opts: ["n + p", "n × p", "n / p", "n - p"], ans: 1, exp: "L'espérance d'une loi binomiale est E(X) = n × p." },
            ],
          },
        ]),
      ],
    },
    {
      id: 'serie-a',
      name: 'Série A (Littéraire)',
      subjects: [
        makeSubject('philosophie', 'Philosophie', 'Brain', 'purple', 'terminale-a', 'Terminale A', [
          {
            title: 'Le bonheur et la morale',
            content:
              "Le bonheur est un état de satisfaction durable. Pour les philosophes : Épicure le définit comme l'absence de souffrance (ataraxie). Kant le distingue du devoir : agir moralement n'est pas chercher le bonheur mais faire son devoir. Les stoïciens (Sénèque, Épictète) considèrent que le bonheur vient de l'acceptation de ce qu'on ne contrôle pas. La question est : peut-on être heureux et moral en même temps ?",
            example: "Pour Épicure, le bonheur est simple : manger sobrement, avoir des amis, ne pas avoir peur. Pour Kant, on doit faire son devoir même si cela ne rend pas heureux.",
            keyPoints: [
              "Épicure : bonheur = absence de souffrance (ataraxie)",
              "Kant : le devoir prime sur le bonheur",
              "Les stoïciens : accepter ce qu'on ne contrôle pas",
              "Question : bonheur et morale sont-ils compatibles ?",
            ],
            exercise: {
              q: "Pour Épicure, le bonheur consiste en :",
              opts: ["La richesse", "L'absence de souffrance (ataraxie)", "Le pouvoir", "La gloire"],
              ans: 1,
              exp: "Épicure définit le bonheur comme l'ataraxie, c'est-à-dire l'absence de trouble et de souffrance.",
              method: "Retiens : Épicure = bonheur simple, absence de souffrance.",
            },
            quiz: [
              { q: "Pour Kant, qu'est-ce qui prime ?", opts: ["Le bonheur", "Le devoir", "L'argent", "La beauté"], ans: 1, exp: "Pour Kant, le devoir moral prime sur la recherche du bonheur." },
              { q: "Les stoïciens pensent que le bonheur vient de :", opts: ["La richesse", "L'acceptation de l'incontrôlable", "Le plaisir", "Le pouvoir"], ans: 1, exp: "Les stoïciens (Sénèque, Épictète) prônent l'acceptation de ce qu'on ne peut pas contrôler." },
              { q: "L'ataraxie est :", opts: ["La peur", "L'absence de trouble", "La colère", "La tristesse"], ans: 1, exp: "L'ataraxie est l'absence de trouble de l'âme, le bonheur pour Épicure." },
            ],
          },
        ]),
        makeSubject('francais', 'Français', 'BookOpen', 'amber', 'terminale-a', 'Terminale A', [
          {
            title: "L'engagement et la littérature",
            content:
              "Un texte engagé prend parti sur un sujet de société : justice, liberté, environnement, éducation, vivre ensemble.\nAu Gabon, on peut s'engager par l'écriture sur la forêt, les jeunes, la ville, la mémoire, les droits.\nL'élève apprend à repérer thèse, arguments, ton (indignation, appel, dénonciation) et à produire un paragraphe argumenté.",
            example: "Écrire pour défendre la protection d'un parc national gabonais ou le droit à l'éducation.",
            keyPoints: [
              'Prendre parti sur un sujet de société',
              'Thèse et arguments',
              'Enjeux gabonais (forêt, éducation, justice)',
              'Ton et destinataire',
            ],
            exercise: {
              q: "Un texte engagé vise surtout à :",
              opts: ["décrire une recette", "défendre une cause / interpeller", "conjuguer au hasard", "remplacer la géographie"],
              ans: 1,
              exp: "L'engagement littéraire agit sur le débat social.",
              method: "Thèse + arguments + exemples locaux.",
            },
            quiz: [
              { q: "Un sujet d'engagement au Gabon peut être :", opts: ["uniquement la conjugaison latine", "forêt, éducation, vivre ensemble", "la météo de l'Antarctique seule", "interdire l'école"], ans: 1, exp: "Enjeux locaux." },
              { q: "Dans un texte engagé, la thèse est :", opts: ["un exemple isolé", "l'idée principale défendue", "un titre de film seulement", "une date"], ans: 1, exp: "Position." },
              { q: "L'écriture engagée peut :", opts: ["seulement divertir sans idée", "dénoncer une injustice et proposer des valeurs", "remplacer les maths", "ignorer le lecteur"], ans: 1, exp: "Fonction." },
            ],
          },
        ]),
      ],
    },
  ];
  return expandLyceeSeries('terminale', base);
}

// ─── Université (filières) ──────────────────────────────────────
export function getUniversiteFilieres(): Filiere[] {
  return [
    {
      id: 'informatique',
      name: 'Informatique',
      domain: 'Sciences et Technologies',
      levels: ['Licence 1', 'Licence 2', 'Licence 3', 'Master 1', 'Master 2'],
      subjects: [
        makeSubject('algorithmique', 'Algorithmique', 'Code', 'blue', 'univ-info', 'Informatique', [
          {
            title: "La complexité des algorithmes",
            content:
              "La complexité d'un algorithme mesure son efficacité. La complexité temporelle compte le nombre d'opérations en fonction de la taille n des données. On utilise la notation grand O : O(1) = constant, O(n) = linéaire, O(n²) = quadratique, O(log n) = logarithmique, O(n log n) = quasi-linéaire. Un algorithme en O(n) est plus efficace qu'un algorithme en O(n²) pour de grandes données.",
            example: "Recherche linéaire dans un tableau : O(n). Recherche dichotomique dans un tableau trié : O(log n). Tri à bulles : O(n²). Tri fusion : O(n log n).",
            keyPoints: [
              "La complexité mesure l'efficacité",
              "O(1) = constant, O(n) = linéaire, O(n²) = quadratique",
              "O(log n) = logarithmique (très efficace)",
              "Un algorithme O(n) est meilleur qu'un algorithme O(n²)",
            ],
            exercise: {
              q: "Quelle est la complexité de la recherche dichotomique ?",
              opts: ["O(n)", "O(log n)", "O(n²)", "O(1)"],
              ans: 1,
              exp: "La recherche dichotomique divise les données par 2 à chaque étape, donc sa complexité est O(log n).",
              method: "Retiens : dichotomique = diviser par 2 = O(log n).",
            },
            quiz: [
              { q: "Quelle complexité est la plus efficace ?", opts: ["O(n²)", "O(n)", "O(log n)", "O(1)"], ans: 3, exp: "O(1) est le plus efficace : le temps ne dépend pas de la taille des données." },
              { q: "Le tri à bulles a une complexité de :", opts: ["O(n)", "O(n log n)", "O(n²)", "O(log n)"], ans: 2, exp: "Le tri à bulles a une complexité de O(n²) car il compare chaque élément avec tous les autres." },
              { q: "O(n) signifie :", opts: ["Constant", "Linéaire", "Quadratique", "Logarithmique"], ans: 1, exp: "O(n) = complexité linéaire, le temps est proportionnel à la taille des données." },
            ],
          },
        ]),
        makeSubject('bases-de-donnees', 'Bases de données', 'Database', 'indigo', 'univ-info', 'Informatique', [
          {
            title: "Le modèle relationnel et SQL",
            content:
              "Le modèle relationnel organise les données en tables (relations). Chaque table a des colonnes (attributs) et des lignes (enregistrements). SQL (Structured Query Language) permet de manipuler les données : SELECT (lire), INSERT (ajouter), UPDATE (modifier), DELETE (supprimer). Les clés primaires identifient chaque ligne, les clés étrangères relient les tables entre elles. La normalisation évite la redondance des données.",
            example: "SELECT nom, age FROM etudiants WHERE age > 20; — Cette requête récupère le nom et l'âge des étudiants de plus de 20 ans.",
            keyPoints: [
              "Le modèle relationnel = tables avec lignes et colonnes",
              "SQL : SELECT, INSERT, UPDATE, DELETE",
              "Clé primaire = identifiant unique",
              "Clé étrangère = lien entre tables",
            ],
            exercise: {
              q: "Quelle commande SQL permet de lire des données ?",
              opts: ["INSERT", "SELECT", "UPDATE", "DELETE"],
              ans: 1,
              exp: "SELECT permet de lire (récupérer) des données d'une table. Exemple : SELECT * FROM etudiants;",
              method: "Retiens : SELECT = lire, INSERT = ajouter, UPDATE = modifier, DELETE = supprimer.",
            },
            quiz: [
              { q: "À quoi sert une clé primaire ?", opts: ["À lier les tables", "À identifier chaque ligne", "À stocker des images", "À trier"], ans: 1, exp: "La clé primaire identifie de manière unique chaque ligne d'une table." },
              { q: "Quelle commande ajoute une ligne ?", opts: ["SELECT", "INSERT", "DELETE", "DROP"], ans: 1, exp: "INSERT ajoute une nouvelle ligne dans une table." },
              { q: "La normalisation sert à :", opts: ["Accélérer les requêtes", "Éviter la redondance", "Crypter les données", "Afficher les données"], ans: 1, exp: "La normalisation évite la redondance et les anomalies de mise à jour." },
            ],
          },
        ]),
      ],
    },
    {
      id: 'droit',
      name: 'Droit',
      domain: 'Sciences Juridiques et Politiques',
      levels: ['Licence 1', 'Licence 2', 'Licence 3', 'Master 1', 'Master 2'],
      subjects: [
        makeSubject('droit-civil', 'Droit Civil', 'Scale', 'amber', 'univ-droit', 'Droit', [
          {
            title: "Les sources du droit",
            content:
              "Les sources du droit sont les origines des règles juridiques. Les sources principales : la Constitution (sommet de la hiérarchie), les traités internationaux, la loi (votée par le Parlement), les règlements (décrets, arrêtés). Les sources secondaires : la jurisprudence (décisions des juges), la coutume, la doctrine (écrits des juristes). Au Gabon, la Constitution de 1991 (révisée) est la source suprême, suivie des lois et règlements.",
            example: "La Constitution gabonaise de 1991 est la loi fondamentale qui organise les pouvoirs et garantit les droits des citoyens.",
            keyPoints: [
              "La Constitution est la source suprême",
              "Les lois sont votées par le Parlement",
              "La jurisprudence = décisions des juges",
              "La doctrine = écrits des juristes",
            ],
            exercise: {
              q: "Quelle est la source suprême du droit au Gabon ?",
              opts: ["La jurisprudence", "La Constitution", "La coutume", "La doctrine"],
              ans: 1,
              exp: "La Constitution est la source suprême du droit. Toutes les autres normes doivent s'y conformer.",
              method: "Retiens la hiérarchie : Constitution > traités > lois > règlements > jurisprudence.",
            },
            quiz: [
              { q: "Qu'est-ce que la jurisprudence ?", opts: ["Les lois", "Les décisions des juges", "La Constitution", "Les traités"], ans: 1, exp: "La jurisprudence est l'ensemble des décisions des tribunaux qui interprètent et appliquent le droit." },
              { q: "Qui vote les lois ?", opts: ["Le président", "Le Parlement", "Les juges", "Le peuple directement"], ans: 1, exp: "Les lois sont votées par le Parlement (Assemblée nationale et Sénat)." },
              { q: "La doctrine est :", opts: ["Les écrits des juristes", "Les lois", "La Constitution", "Les juges"], ans: 0, exp: "La doctrine est l'ensemble des écrits des juristes qui analysent et commentent le droit." },
            ],
          },
        ]),
        makeSubject('droit-constitutionnel', 'Droit Constitutionnel', 'Landmark', 'orange', 'univ-droit', 'Droit', [
          {
            title: "L'organisation des pouvoirs",
            content:
              "L'organisation des pouvoirs repose sur la séparation des pouvoirs (Montesquieu) : le pouvoir législatif (fait les lois), le pouvoir exécutif (applique les lois) et le pouvoir judiciaire (juge les conflits). Cette séparation évite que le pouvoir soit concentré entre les mains d'une seule personne. Au Gabon, le Président est le chef de l'exécutif, le Parlement (Assemblée + Sénat) légifère, et les tribunaux jugent.",
            example: "Montesquieu a théorisé la séparation des pouvoirs dans 'De l'esprit des lois' (1748) pour éviter l'arbitraire.",
            keyPoints: [
              "Séparation des pouvoirs (Montesquieu)",
              "Législatif : fait les lois",
              "Exécutif : applique les lois",
              "Judiciaire : juge les conflits",
            ],
            exercise: {
              q: "Qui a théorisé la séparation des pouvoirs ?",
              opts: ["Rousseau", "Montesquieu", "Voltaire", "Locke"],
              ans: 1,
              exp: "Montesquieu a théorisé la séparation des pouvoirs dans 'De l'esprit des lois' (1748).",
              method: "Retiens : Montesquieu = séparation des pouvoirs.",
            },
            quiz: [
              { q: "Le pouvoir législatif :", opts: ["Applique les lois", "Fait les lois", "Juge les conflits", "Gouverne"], ans: 1, exp: "Le pouvoir législatif fait les lois (Parlement)." },
              { q: "Au Gabon, qui est le chef de l'exécutif ?", opts: ["Le Premier ministre", "Le Président", "Le Parlement", "Les juges"], ans: 1, exp: "Le Président de la République est le chef du pouvoir exécutif au Gabon." },
              { q: "Le pouvoir judiciaire :", opts: ["Fait les lois", "Applique les lois", "Juge les conflits", "Légifère"], ans: 2, exp: "Le pouvoir judiciaire juge les conflits et applique le droit (tribunaux)." },
            ],
          },
        ]),
      ],
    },
    {
      id: 'economie',
      name: 'Sciences Économiques',
      domain: 'Sciences Économiques et de Gestion',
      levels: ['Licence 1', 'Licence 2', 'Licence 3', 'Master 1', 'Master 2'],
      subjects: [
        makeSubject('microeconomie', 'Microéconomie', 'TrendingUp', 'emerald', 'univ-eco', 'Sciences Économiques', [
          {
            title: "L'offre, la demande et l'équilibre",
            content:
              "En microéconomie, le marché est régi par l'offre (quantité que les producteurs veulent vendre) et la demande (quantité que les consommateurs veulent acheter). Le prix d'équilibre est le prix où l'offre égale la demande. Si le prix est trop haut, il y a excès d'offre (surplus). Si le prix est trop bas, il y a excès de demande (pénurie). La loi de l'offre dit que le prix monte, l'offre augmente. La loi de la demande dit que le prix monte, la demande baisse.",
            example: "Sur le marché des mangues : si le prix est de 500 FCFA, les vendeurs offrent 1000 mangues et les acheteurs en veulent 800. Il y a surplus. Le prix va baisser pour atteindre l'équilibre.",
            keyPoints: [
              "L'offre = quantité que les producteurs veulent vendre",
              "La demande = quantité que les consommateurs veulent acheter",
              "Le prix d'équilibre : offre = demande",
              "Prix trop haut = surplus, prix trop bas = pénurie",
            ],
            exercise: {
              q: "Que se passe-t-il si le prix est trop bas ?",
              opts: ["Surplus", "Pénurie", "Équilibre", "Rien"],
              ans: 1,
              exp: "Si le prix est trop bas, la demande dépasse l'offre : il y a pénurie, ce qui fait monter le prix vers l'équilibre.",
              method: "Retiens : prix bas = demande > offre = pénurie. Prix haut = offre > demande = surplus.",
            },
            quiz: [
              { q: "Le prix d'équilibre est le prix où :", opts: ["L'offre > demande", "Offre = demande", "Demande > offre", "Le gouvernement décide"], ans: 1, exp: "Le prix d'équilibre est le prix où l'offre égale la demande." },
              { q: "La loi de la demande dit que :", opts: ["Prix monte, demande monte", "Prix monte, demande baisse", "Prix baisse, demande baisse", "Prix n'a pas d'effet"], ans: 1, exp: "La loi de la demande : quand le prix monte, la quantité demandée baisse." },
              { q: "Un surplus signifie :", opts: ["Offre > demande", "Demande > offre", "Offre = demande", "Pas de marché"], ans: 0, exp: "Un surplus = l'offre dépasse la demande, le prix est trop haut." },
            ],
          },
        ]),
        makeSubject('macroeconomie', 'Macroéconomie', 'BarChart3', 'teal', 'univ-eco', 'Sciences Économiques', [
          {
            title: "Le PIB et la croissance",
            content:
              "Le PIB (Produit Intérieur Brut) mesure la richesse créée par un pays en un an. Il peut être calculé par la production (somme des valeurs ajoutées), par les dépenses (consommation + investissement + exportations - importations) ou par les revenus. La croissance économique est le taux d'augmentation du PIB. Au Gabon, le PIB dépend fortement du pétrole. La croissance peut être intensive (plus de productivité) ou extensive (plus de facteurs).",
            example: "Si le PIB du Gabon passe de 1000 à 1050 milliards, la croissance est de 5%.",
            keyPoints: [
              "Le PIB mesure la richesse d'un pays",
              "PIB = C + I + (X - M) (dépenses)",
              "La croissance = taux d'augmentation du PIB",
              "Au Gabon, le PIB dépend du pétrole",
            ],
            exercise: {
              q: "Que mesure le PIB ?",
              opts: ["La population", "La richesse créée par un pays", "La superficie", "Le nombre d'entreprises"],
              ans: 1,
              exp: "Le PIB (Produit Intérieur Brut) mesure la valeur totale des biens et services produits dans un pays en un an.",
              method: "Retiens : PIB = richesse produite en un an.",
            },
            quiz: [
              { q: "La croissance économique est :", opts: ["La baisse du PIB", "L'augmentation du PIB", "La population", "L'inflation"], ans: 1, exp: "La croissance économique est le taux d'augmentation du PIB d'une année à l'autre." },
              { q: "Au Gabon, le PIB dépend surtout de :", opts: ["L'agriculture", "Le pétrole", "Le tourisme", "L'industrie"], ans: 1, exp: "Le PIB du Gabon dépend fortement de l'exploitation du pétrole." },
              { q: "PIB par les dépenses = ?", opts: ["C + I + (X - M)", "Salaire + profits", "Production - consommations", "Population × revenu"], ans: 0, exp: "PIB = Consommation + Investissement + (Exportations - Importations)." },
            ],
          },
        ]),
      ],
    },
    {
      id: 'medecine',
      name: 'Médecine',
      domain: 'Sciences de la Santé',
      levels: ['L1 Santé', 'L2 Médecine', 'L3 Médecine', 'DFASP 1', 'DFASP 2'],
      subjects: [
        makeSubject('anatomie', 'Anatomie', 'Activity', 'red', 'univ-med', 'Médecine', [
          {
            title: "Le système cardiovasculaire",
            content:
              "Le système cardiovasculaire comprend le cœur et les vaisseaux sanguins. Le cœur est une pompe à 4 cavités : 2 oreillettes (reçoivent le sang) et 2 ventricules (expulsent le sang). La circulation systémique envoie le sang oxygéné vers le corps. La circulation pulmonaire envoie le sang non oxygéné vers les poumons. Le sang artériel (oxygéné) est rouge vif, le sang veineux (non oxygéné) est rouge foncé.",
            example: "Le cœur bat environ 70 fois par minute au repos, pompant environ 5 litres de sang par minute.",
            keyPoints: [
              "Le cœur a 4 cavités : 2 oreillettes, 2 ventricules",
              "Circulation systémique : cœur → corps",
              "Circulation pulmonaire : cœur → poumons",
              "Sang artériel = oxygéné, sang veineux = non oxygéné",
            ],
            exercise: {
              q: "Combien de cavités a le cœur ?",
              opts: ["2", "3", "4", "6"],
              ans: 2,
              exp: "Le cœur a 4 cavités : 2 oreillettes (gauche et droite) et 2 ventricules (gauche et droite).",
              method: "Retiens : 4 cavités = 2 oreillettes + 2 ventricules.",
            },
            quiz: [
              { q: "Le sang artériel est :", opts: ["Non oxygéné", "Oxygéné", "Bleu", "Sans oxygène"], ans: 1, exp: "Le sang artériel est oxygéné (rouge vif), le sang veineux est non oxygéné (rouge foncé)." },
              { q: "La circulation pulmonaire envoie le sang vers :", opts: ["Le cerveau", "Les poumons", "Les muscles", "Le foie"], ans: 1, exp: "La circulation pulmonaire envoie le sang vers les poumons pour qu'il soit oxygéné." },
              { q: "Les oreillettes :", opts: ["Expulsent le sang", "Reçoivent le sang", "Filtrent le sang", "Stockent l'oxygène"], ans: 1, exp: "Les oreillettes reçoivent le sang qui revient au cœur, les ventricules l'expulsent." },
            ],
          },
        ]),
        makeSubject('physiologie', 'Physiologie', 'HeartPulse', 'rose', 'univ-med', 'Médecine', [
          {
            title: "Le système nerveux",
            content:
              "Le système nerveux contrôle et coordonne les fonctions du corps. Il se divise en : système nerveux central (cerveau + moelle épinière) et système nerveux périphérique (nerfs). Le neurone est l'unité de base : il transmet l'information électrique. Les neurotransmetteurs sont les messagers chimiques entre les neurones. Le système nerveux autonome contrôle les fonctions involontaires (cœur, digestion).",
            example: "Quand tu touches quelque chose de chaud, le signal voyage du doigt à la moelle épinière, qui ordonne au muscle de retirer la main : c'est un réflexe.",
            keyPoints: [
              "Système nerveux central : cerveau + moelle épinière",
              "Le neurone est l'unité de base",
              "Les neurotransmetteurs sont les messagers chimiques",
              "Le système autonome contrôle les fonctions involontaires",
            ],
            exercise: {
              q: "Quelle est l'unité de base du système nerveux ?",
              opts: ["La cellule musculaire", "Le neurone", "Le globule rouge", "La bactérie"],
              ans: 1,
              exp: "Le neurone est la cellule de base du système nerveux, il transmet l'information électrique.",
              method: "Retiens : neurone = unité de base = transmet l'information électrique.",
            },
            quiz: [
              { q: "Le système nerveux central comprend :", opts: ["Les nerfs", "Le cerveau et la moelle épinière", "Le cœur", "Les muscles"], ans: 1, exp: "Le système nerveux central = cerveau + moelle épinière." },
              { q: "Les neurotransmetteurs sont :", opts: ["Des cellules", "Des messagers chimiques", "Des muscles", "Des os"], ans: 1, exp: "Les neurotransmetteurs sont les messagers chimiques entre les neurones." },
              { q: "Un réflexe est contrôlé par :", opts: ["Le cerveau uniquement", "La moelle épinière", "Le cœur", "Les muscles"], ans: 1, exp: "Les réflexes sont contrôlés par la moelle épinière, sans passer par le cerveau (réponse rapide)." },
            ],
          },
        ]),
      ],
    },
  ];
}
