/**
 * EDUPROF V2.6 pedagogical pack — Gabon
 * Generated for integration V2.7 — DO NOT invent program content
 * Source: units READY_FOR_AUTHORING only (Maths/PC/SVT/Philo : progressions IPN-IGS 2024-2025)
 *
 * Français collège (6e-3e) ajouté depuis la progression officielle 2025-2026 :
 * Ministère de l'Éducation Nationale du Gabon / IPN — Département de Français,
 * "Proposition de progressions APC 6e-5e-4e-3e 2025-2026" (source publique : nzassy.com).
 */
import { makeSubject, type Subject, type TopicData } from './types';

const v26_3e_physique_chimie_topics: TopicData[] = [
  {
    title: "Construction d une image par une lentille convergente",
    content: "Construction d'une image par une lentille convergente.\n\nUne lentille convergente fait converger les rayons parallèles en un foyer.\n\nOn utilise des rayons particuliers pour construire l'image : rayon passant par le centre optique, rayon parallèle à l'axe, rayon passant par le foyer objet.",
    example: "Une loupe est une lentille convergente.",
    keyPoints: ["Lentille convergente", "Foyer", "Centre optique", "Image"],
    exercise: { q: "Une loupe est-elle une lentille convergente ou divergente ?", opts: ["Convergente", "Autre réponse (incorrecte)", "Réponse non appropriée", "Aucune de ces réponses"], ans: 0, exp: "Elle grossit en faisant converger les rayons.", method: "Elle grossit en faisant converger les rayons." },
    quiz: [
      { q: "Les rayons parallèles à l'axe, après une lentille convergente, passent par :", opts: ["Le centre optique seulement", "Le foyer image", "L'infini sans déviation", "Le sol"], ans: 1, exp: "Propriété de la lentille convergente." },
    ],
  },
  {
    title: "Evaluation diagnostique et chiffres significatifs",
    content: "Physique-Chimie 3e — Evaluation diagnostique et chiffres significatifs (progression IPN-IGS 2024-2025).\n\nActivité de diagnostic, remédiation ou révision générale selon le calendrier scolaire.",
    example: "Reprendre les exercices de lentilles, d'électricité ou de mesures déjà vus.",
    keyPoints: ["Evaluation diagnostique et chiffres significatifs"],
    exercise: { q: "Liste trois notions de Physique-Chimie que tu dois revoir pour le BEPC.", opts: ["Réponse libre (ex. lentilles, circuits, atomes)", "Autre réponse (incorrecte)", "Réponse non appropriée", "Aucune de ces réponses"], ans: 0, exp: "Selon ton programme et tes points faibles.", method: "Selon ton programme et tes points faibles." },
    quiz: [
      { q: "Le BEPC évalue notamment :", opts: ["Uniquement le sport", "Les acquis du collège", "Uniquement la Terminale", "Le permis de conduire"], ans: 1, exp: "Examen de fin de collège." },
    ],
  },
  {
    title: "Revision generale",
    content: "Physique-Chimie 3e — Revision generale (progression IPN-IGS 2024-2025).\n\nActivité de diagnostic, remédiation ou révision générale selon le calendrier scolaire.",
    example: "Reprendre les exercices de lentilles, d'électricité ou de mesures déjà vus.",
    keyPoints: ["Revision generale"],
    exercise: { q: "Liste trois notions de Physique-Chimie que tu dois revoir pour le BEPC.", opts: ["Réponse libre (ex. lentilles, circuits, atomes)", "Autre réponse (incorrecte)", "Réponse non appropriée", "Aucune de ces réponses"], ans: 0, exp: "Selon ton programme et tes points faibles.", method: "Selon ton programme et tes points faibles." },
    quiz: [
      { q: "Le BEPC évalue notamment :", opts: ["Uniquement le sport", "Les acquis du collège", "Uniquement la Terminale", "Le permis de conduire"], ans: 1, exp: "Examen de fin de collège." },
    ],
  },
];

export function getV26_3e_physique_chimie(): Subject {
  return makeSubject("physique-chimie", "Physique-Chimie", "Atom", "orange", "3e", "3e", v26_3e_physique_chimie_topics);
}

const v26_4e_physique_chimie_topics: TopicData[] = [
  {
    title: "ELECTRICITE",
    content: "Introduction à l'électricité en 4e : circuits et notions de base.\n\nUn circuit simple comporte un générateur (pile), des fils et un récepteur (lampe).\n\nLe courant circule si le circuit est fermé.\n\nUn interrupteur ouvre ou ferme le circuit.",
    example: "Allumer une lampe de poche : pile + interrupteur + ampoule.",
    keyPoints: ["Circuit", "Générateur", "Récepteur", "Fil", "Interrupteur"],
    exercise: { q: "Pourquoi une lampe ne s'allume-t-elle pas si le circuit est ouvert ?", opts: ["Le courant ne peut pas circuler", "Autre réponse (incorrecte)", "Réponse non appropriée", "Aucune de ces réponses"], ans: 0, exp: "Circuit ouvert = interruption du chemin du courant.", method: "Circuit ouvert = interruption du chemin du courant." },
    quiz: [
      { q: "Dans un circuit, la pile est un :", opts: ["Récepteur", "Générateur", "Isolant", "Interrupteur"], ans: 1, exp: "La pile fournit l'énergie électrique." },
    ],
  },
  {
    title: "Consommation du zinc dans une pile",
    content: "Consommation du zinc dans une pile : transformation chimique et courant.\n\nDans certaines piles, le zinc est consommé au fur et à mesure que la pile débite du courant.\n\nUne transformation chimique convertit de l'énergie chimique en énergie électrique.",
    example: "Une pile usée a souvent ses réactifs consommés.",
    keyPoints: ["Pile", "Zinc", "Transformation chimique", "Courant"],
    exercise: { q: "Que devient le zinc dans une pile qui fonctionne longtemps ?", opts: ["Il est consommé / transformé chimiquement", "Autre réponse (incorrecte)", "Réponse non appropriée", "Aucune de ces réponses"], ans: 0, exp: "Le zinc participe à la réaction et diminue.", method: "Le zinc participe à la réaction et diminue." },
    quiz: [
      { q: "Une pile convertit principalement :", opts: ["Lumière en son", "Énergie chimique en énergie électrique", "Chaleur en mouvement", "Masse en volume"], ans: 1, exp: "Principe de la pile." },
    ],
  },
  {
    title: "Redressement d une tension alternative",
    content: "Redressement d'une tension alternative : idée de base.\n\nUne tension alternative change de sens périodiquement (réseau électrique).\n\nUne tension continue garde le même sens (pile).\n\nLe redressement transforme une tension alternative en tension d'un seul sens.",
    example: "Les appareils électroniques ont souvent besoin d'une tension redressée.",
    keyPoints: ["Tension alternative", "Tension continue", "Redressement"],
    exercise: { q: "La tension d'une pile est-elle alternative ou continue ?", opts: ["Continue", "Autre réponse (incorrecte)", "Réponse non appropriée", "Aucune de ces réponses"], ans: 0, exp: "Sens constant.", method: "Sens constant." },
    quiz: [
      { q: "Le réseau EDM (électricité domestique) fournit en général une tension :", opts: ["Continue pure", "Alternative", "Nulle", "Magnétique"], ans: 1, exp: "Réseau alternatif." },
    ],
  },
  {
    title: "Evaluation diagnostique et chiffres significatifs",
    content: "Évaluation diagnostique et chiffres significatifs en Physique-Chimie 4e.\n\nLes chiffres significatifs indiquent la précision d'une mesure.",
    example: "Mesurer une longueur au cm près n'a pas la même précision qu'au mm près.",
    keyPoints: ["Diagnostique", "Chiffres significatifs"],
    exercise: { q: "Pourquoi fait-on une évaluation diagnostique en début d'année ?", opts: ["Pour connaître le niveau de départ des élèves", "Autre réponse (incorrecte)", "Réponse non appropriée", "Aucune de ces réponses"], ans: 0, exp: "Adapter l'enseignement.", method: "Adapter l'enseignement." },
    quiz: [
      { q: "Les chiffres significatifs renseignent surtout sur :", opts: ["La couleur", "La précision d'une mesure", "La masse du professeur", "Le coefficient"], ans: 1, exp: "Rôle des chiffres significatifs." },
    ],
  },
  {
    title: "Structure atomique des metaux",
    content: "Structure de l'atome et structure atomique des métaux (introduction 4e).\n\nL'atome comporte un noyau (protons + neutrons) et des électrons autour.\n\nLes métaux sont de bons conducteurs électriques, ce qui est lié à la mobilité de certains électrons.",
    example: "Le cuivre des fils électriques est un métal bon conducteur.",
    keyPoints: ["Atome", "Noyau", "Électron", "Proton", "Neutron", "Métal"],
    exercise: { q: "Où se trouvent les protons dans l'atome ?", opts: ["Dans le noyau", "Autre réponse (incorrecte)", "Réponse non appropriée", "Aucune de ces réponses"], ans: 0, exp: "Protons et neutrons forment le noyau.", method: "Protons et neutrons forment le noyau." },
    quiz: [
      { q: "Les électrons se trouvent :", opts: ["Uniquement dans le noyau", "Autour du noyau", "Seulement dans les métaux", "Nulle part"], ans: 1, exp: "Nuage électronique." },
    ],
  },
  {
    title: "Structure de l atome",
    content: "Structure de l'atome et structure atomique des métaux (introduction 4e).\n\nL'atome comporte un noyau (protons + neutrons) et des électrons autour.\n\nLes métaux sont de bons conducteurs électriques, ce qui est lié à la mobilité de certains électrons.",
    example: "Le cuivre des fils électriques est un métal bon conducteur.",
    keyPoints: ["Atome", "Noyau", "Électron", "Proton", "Neutron", "Métal"],
    exercise: { q: "Où se trouvent les protons dans l'atome ?", opts: ["Dans le noyau", "Autre réponse (incorrecte)", "Réponse non appropriée", "Aucune de ces réponses"], ans: 0, exp: "Protons et neutrons forment le noyau.", method: "Protons et neutrons forment le noyau." },
    quiz: [
      { q: "Les électrons se trouvent :", opts: ["Uniquement dans le noyau", "Autour du noyau", "Seulement dans les métaux", "Nulle part"], ans: 1, exp: "Nuage électronique." },
    ],
  },
  {
    title: "Sources et recepteurs de lumiere",
    content: "Optique : sources, récepteurs et propagation rectiligne de la lumière.\n\nSources : Soleil, lampe, flamme. Récepteurs : œil, cellule photoélectrique.\n\nDans un milieu homogène transparent, la lumière se propage en ligne droite.\n\nLa vitesse de la lumière dans le vide est d'environ 300 000 km/s.",
    example: "L'ombre d'un élève sous le soleil s'explique par la propagation rectiligne.",
    keyPoints: ["Source", "Récepteur", "Propagation rectiligne", "Vitesse de la lumière"],
    exercise: { q: "L'œil est-il une source ou un récepteur de lumière ?", opts: ["Récepteur", "Autre réponse (incorrecte)", "Réponse non appropriée", "Aucune de ces réponses"], ans: 0, exp: "L'œil reçoit la lumière.", method: "L'œil reçoit la lumière." },
    quiz: [
      { q: "Dans l'air, la lumière se propage en :", opts: ["Courbes libres", "Ligne droite", "Spirale", "Zigzag permanent"], ans: 1, exp: "Propagation rectiligne." },
    ],
  },
  {
    title: "Propagation rectiligne de la lumiere - Vitesse de la lumiere",
    content: "Optique : sources, récepteurs et propagation rectiligne de la lumière.\n\nSources : Soleil, lampe, flamme. Récepteurs : œil, cellule photoélectrique.\n\nDans un milieu homogène transparent, la lumière se propage en ligne droite.\n\nLa vitesse de la lumière dans le vide est d'environ 300 000 km/s.",
    example: "L'ombre d'un élève sous le soleil s'explique par la propagation rectiligne.",
    keyPoints: ["Source", "Récepteur", "Propagation rectiligne", "Vitesse de la lumière"],
    exercise: { q: "L'œil est-il une source ou un récepteur de lumière ?", opts: ["Récepteur", "Autre réponse (incorrecte)", "Réponse non appropriée", "Aucune de ces réponses"], ans: 0, exp: "L'œil reçoit la lumière.", method: "L'œil reçoit la lumière." },
    quiz: [
      { q: "Dans l'air, la lumière se propage en :", opts: ["Courbes libres", "Ligne droite", "Spirale", "Zigzag permanent"], ans: 1, exp: "Propagation rectiligne." },
    ],
  },
];

export function getV26_4e_physique_chimie(): Subject {
  return makeSubject("physique-chimie", "Physique-Chimie", "Atom", "orange", "4e", "4e", v26_4e_physique_chimie_topics);
}

const v26_5e_mathematiques_topics: TopicData[] = [
  {
    title: "SEQUENCE 1 : Figures symetriques par rapport a un point (partie A)",
    content: "Figures symétriques par rapport à un point (symétrie centrale) en 5e.\n\nLe symétrique de A par rapport à O est le point A' tel que O est le milieu de [AA'].\n\nOn dit que A' est l'image de A dans la symétrie de centre O.\n\nLes distances sont conservées : si A et B ont pour images A' et B', alors A'B' = AB.",
    example: "Si O est milieu de [AA'], A et A' sont symétriques par rapport à O.",
    keyPoints: ["Symétrie centrale", "Centre de symétrie", "Image"],
    exercise: { q: "O est milieu de [AA']. Que représente A' pour A ?", opts: ["Le symétrique de A par rapport à O", "Autre réponse (incorrecte)", "Réponse non appropriée", "Aucune de ces réponses"], ans: 0, exp: "Définition de la symétrie centrale.", method: "Définition de la symétrie centrale." },
    quiz: [
      { q: "Dans une symétrie de centre O, O est :", opts: ["Une extrémité", "Le milieu du segment joignant un point et son image", "Un sommet quelconque", "Un rayon"], ans: 1, exp: "Propriété fondamentale." },
    ],
  },
  {
    title: "SEQUENCE 2 : Nombres decimaux relatifs (partie A)",
    content: "Nombres décimaux relatifs : présentation et droite graduée.\n\nLes nombres relatifs comprennent les positifs, les négatifs et zéro.\n\nSur une droite graduée, les positifs sont d'un côté de 0, les négatifs de l'autre.\n\n−3 est l'opposé de 3.",
    example: "Température 5 °C le jour, −2 °C la nuit à l'intérieur du pays en saison sèche (exemple pédagogique).",
    keyPoints: ["Nombre relatif", "Positif", "Négatif", "Droite graduée", "Opposé"],
    exercise: { q: "Quel est l'opposé de 7 ?", opts: ["−7", "Autre réponse (incorrecte)", "Réponse non appropriée", "Aucune de ces réponses"], ans: 0, exp: "L'opposé de 7 est −7.", method: "L'opposé de 7 est −7." },
    quiz: [
      { q: "L'opposé de −5 est :", opts: ["−5", "5", "0", "10"], ans: 0, exp: "L'opposé de −5 est 5." },
    ],
  },
  {
    title: "SEQUENCE 3 : Figures symetriques par rapport a une droite (partie A)",
    content: "Figures symétriques par rapport à un point (symétrie centrale) en 5e.\n\nLe symétrique de A par rapport à O est le point A' tel que O est le milieu de [AA'].\n\nOn dit que A' est l'image de A dans la symétrie de centre O.\n\nLes distances sont conservées : si A et B ont pour images A' et B', alors A'B' = AB.",
    example: "Si O est milieu de [AA'], A et A' sont symétriques par rapport à O.",
    keyPoints: ["Symétrie centrale", "Centre de symétrie", "Image"],
    exercise: { q: "O est milieu de [AA']. Que représente A' pour A ?", opts: ["Le symétrique de A par rapport à O", "Autre réponse (incorrecte)", "Réponse non appropriée", "Aucune de ces réponses"], ans: 0, exp: "Définition de la symétrie centrale.", method: "Définition de la symétrie centrale." },
    quiz: [
      { q: "Dans une symétrie de centre O, O est :", opts: ["Une extrémité", "Le milieu du segment joignant un point et son image", "Un sommet quelconque", "Un rayon"], ans: 1, exp: "Propriété fondamentale." },
    ],
  },
];

export function getV26_5e_mathematiques(): Subject {
  return makeSubject("mathematiques", "Math\u00e9matiques", "Calculator", "blue", "5e", "5e", v26_5e_mathematiques_topics);
}

const v26_6e_mathematiques_topics: TopicData[] = [
{
    title: "SEQUENCE 1",
    content: "L'ensemble des nombres entiers naturels et la notion de multiple.\n\nLes nombres entiers naturels sont 0, 1, 2, 3, … On note souvent ℕ cet ensemble.\n\nUn multiple de a est un nombre de la forme a × k (k entier naturel).\n\nLes multiples de 5 : 0, 5, 10, 15, 20…",
    example: "15 est un multiple de 3 car 15 = 3 × 5.",
    keyPoints: ["Entier naturel", "Multiple", "Diviseur"],
    exercise: { q: "Cite 4 multiples de 4.", opts: ["0, 4, 8, 12 (par exemple)", "Autre réponse (incorrecte)", "Réponse non appropriée", "Aucune de ces réponses"], ans: 0, exp: "4×0, 4×1, 4×2, 4×3…", method: "4×0, 4×1, 4×2, 4×3…" },
    quiz: [
      { q: "Le plus petit multiple de 7 est :", opts: ["1", "7", "0", "14"], ans: 2, exp: "7 × 0 = 0." },
    ],
  },
{
    title: "SEQUENCE 2",
    content: "Droites, demi-droites et segments dans le plan.\n\nUne droite est illimitée dans les deux sens. Notation : (AB).\n\nUne demi-droite a une origine et s'étend d'un seul côté. Notation : [AB).\n\nUn segment a deux extrémités. Notation : [AB].",
    example: "Le bord d'une règle évoque un segment. Une ligne d'horizon évoque une droite.",
    keyPoints: ["Droite", "Demi-droite", "Segment", "Point"],
    exercise: { q: "Quelle notation pour le segment d'extrémités A et B ?", opts: ["[AB]", "Autre réponse (incorrecte)", "Réponse non appropriée", "Aucune de ces réponses"], ans: 0, exp: "Le segment se note [AB].", method: "Le segment se note [AB]." },
    quiz: [
      { q: "Une droite est :", opts: ["Limitée", "Illimitée des deux côtés", "Un segment", "Un point"], ans: 1, exp: "Définition de la droite." },
    ],
  },
{
    title: "SEQUENCE 3",
    content: "Droites, demi-droites et segments dans le plan.\n\nUne droite est illimitée dans les deux sens. Notation : (AB).\n\nUne demi-droite a une origine et s'étend d'un seul côté. Notation : [AB).\n\nUn segment a deux extrémités. Notation : [AB].",
    example: "Le bord d'une règle évoque un segment. Une ligne d'horizon évoque une droite.",
    keyPoints: ["Droite", "Demi-droite", "Segment", "Point"],
    exercise: { q: "Quelle notation pour le segment d'extrémités A et B ?", opts: ["[AB]", "Autre réponse (incorrecte)", "Réponse non appropriée", "Aucune de ces réponses"], ans: 0, exp: "Le segment se note [AB].", method: "Le segment se note [AB]." },
    quiz: [
      { q: "Une droite est :", opts: ["Limitée", "Illimitée des deux côtés", "Un segment", "Un point"], ans: 1, exp: "Définition de la droite." },
    ],
  },
{
    title: "SEQUENCE 5",
    content: "Droites, demi-droites et segments dans le plan.\n\nUne droite est illimitée dans les deux sens. Notation : (AB).\n\nUne demi-droite a une origine et s'étend d'un seul côté. Notation : [AB).\n\nUn segment a deux extrémités. Notation : [AB].",
    example: "Le bord d'une règle évoque un segment. Une ligne d'horizon évoque une droite.",
    keyPoints: ["Droite", "Demi-droite", "Segment", "Point"],
    exercise: { q: "Quelle notation pour le segment d'extrémités A et B ?", opts: ["[AB]", "Autre réponse (incorrecte)", "Réponse non appropriée", "Aucune de ces réponses"], ans: 0, exp: "Le segment se note [AB].", method: "Le segment se note [AB]." },
    quiz: [
      { q: "Une droite est :", opts: ["Limitée", "Illimitée des deux côtés", "Un segment", "Un point"], ans: 1, exp: "Définition de la droite." },
    ],
  },
{
    title: "SEQUENCE (NEEDS_HUMAN_REVIEW — intitulé incomplet dans la source)",
    content: "Les diviseurs d'un nombre entier naturel et les critères de divisibilité facilitent les calculs en 6e.\n\nUn entier d est un diviseur de n si la division de n par d donne un reste nul (n = d × k).\n\nCritère par 2 : le chiffre des unités est pair (0, 2, 4, 6, 8).\n\nCritère par 5 : le chiffre des unités est 0 ou 5.\n\nCritère par 3 : la somme des chiffres est divisible par 3.\n\nCritère par 9 : la somme des chiffres est divisible par 9.\n\nCritère par 10 : le chiffre des unités est 0.",
    example: "Les diviseurs de 12 sont 1, 2, 3, 4, 6, 12.",
    keyPoints: ["Diviseur", "Multiple", "Divisibilité par 2, 3, 5, 9, 10"],
    exercise: { q: "Liste les diviseurs de 18.", opts: ["1, 2, 3, 6, 9, 18", "0", "Impossible", "Aucune de ces réponses"], ans: 0, exp: "18 = 1×18 = 2×9 = 3×6.", method: "18 = 1×18 = 2×9 = 3×6." },
    quiz: [
      { q: "Un nombre divisible par 10 se termine par :", opts: ["5", "0", "2", "9"], ans: 1, exp: "Critère de divisibilité par 10." },
      { q: "Somme des chiffres de 81 :", opts: ["8", "9", "18", "1"], ans: 1, exp: "8+1=9." },
    ],
  },
{
    title: "SEQUENCE (NEEDS_HUMAN_REVIEW — intitulé incomplet dans la source)",
    content: "Construction et propriétés de base des triangles.\n\nPour construire un triangle de côtés a, b, c : tracer un côté, puis arcs de cercles pour les deux autres sommets.\n\nÉquilatéral : 3 côtés égaux. Isocèle : au moins 2 côtés égaux. Quelconque : 3 côtés de longueurs différentes.",
    example: "Un triangle de côtés 3 cm, 3 cm, 3 cm est équilatéral.",
    keyPoints: ["Triangle", "Équilatéral", "Isocèle", "Construction"],
    exercise: { q: "Un triangle a ses 3 côtés égaux. Comment s'appelle-t-il ?", opts: ["Équilatéral", "Autre réponse (incorrecte)", "Réponse non appropriée", "Aucune de ces réponses"], ans: 0, exp: "Trois côtés égaux = équilatéral.", method: "Trois côtés égaux = équilatéral." },
    quiz: [
      { q: "Triangle avec exactement 2 côtés égaux :", opts: ["Équilatéral", "Isocèle", "Rectangle", "Quelconque"], ans: 1, exp: "Isocèle : au moins deux côtés égaux (souvent exactement deux en collège)." },
    ],
  },
{
    title: "SEQUENCE (NEEDS_HUMAN_REVIEW — intitulé incomplet dans la source)",
    content: "Séquence de mathématiques 6e (programme gabonais IPN/IGS 2024-2025) : SEQUENCE.\n\nCette séquence porte sur : SEQUENCE. Suis les activités et exercices de ton manuel et de ton professeur.",
    example: "Exemple à compléter en classe avec le professeur.",
    keyPoints: ["SEQUENCE"],
    exercise: { q: "Rédige en deux phrases ce que tu as retenu sur : SEQUENCE.", opts: ["Réponse libre", "Autre réponse (incorrecte)", "Réponse non appropriée", "Aucune de ces réponses"], ans: 0, exp: "À valider avec le professeur selon le cours donné.", method: "À valider avec le professeur selon le cours donné." },
    quiz: [
      { q: "Cette séquence concerne :", opts: ["SEQUENCE", "Philosophie", "SVT uniquement", "EPS"], ans: 0, exp: "Intitulé de la séquence sourcée." },
    ],
  },
{
    title: "SEQUENCE 6 : Diviseurs",
    content: "Les diviseurs d'un nombre entier naturel et les critères de divisibilité facilitent les calculs en 6e.\n\nUn entier d est un diviseur de n si la division de n par d donne un reste nul (n = d × k).\n\nCritère par 2 : le chiffre des unités est pair (0, 2, 4, 6, 8).\n\nCritère par 5 : le chiffre des unités est 0 ou 5.\n\nCritère par 3 : la somme des chiffres est divisible par 3.\n\nCritère par 9 : la somme des chiffres est divisible par 9.\n\nCritère par 10 : le chiffre des unités est 0.",
    example: "Les diviseurs de 12 sont 1, 2, 3, 4, 6, 12.",
    keyPoints: ["Diviseur", "Multiple", "Divisibilité par 2, 3, 5, 9, 10"],
    exercise: { q: "Liste les diviseurs de 18.", opts: ["1, 2, 3, 6, 9, 18", "0", "Impossible", "Aucune de ces réponses"], ans: 0, exp: "18 = 1×18 = 2×9 = 3×6.", method: "18 = 1×18 = 2×9 = 3×6." },
    quiz: [
      { q: "Un nombre divisible par 10 se termine par :", opts: ["5", "0", "2", "9"], ans: 1, exp: "Critère de divisibilité par 10." },
      { q: "Somme des chiffres de 81 :", opts: ["8", "9", "18", "1"], ans: 1, exp: "8+1=9." },
    ],
  },
{
    title: "SEQUENCE 7 : Cercle",
    content: "Le cercle est une figure fondamentale de la géométrie en 6e.\n\nUn cercle de centre O et de rayon r est l'ensemble des points M tels que OM = r.\n\nLe diamètre est un segment passant par le centre, de longueur 2r.\n\nOn trace un cercle avec un compas : pointe au centre, écartement = rayon.",
    example: "Si le rayon mesure 3 cm, le diamètre mesure 6 cm.",
    keyPoints: ["Centre", "Rayon", "Diamètre", "Compas"],
    exercise: { q: "Le rayon d'un cercle mesure 5 cm. Quel est le diamètre ?", opts: ["10 cm", "0", "Impossible", "Aucune de ces réponses"], ans: 0, exp: "Diamètre = 2 × rayon = 10 cm.", method: "Diamètre = 2 × rayon = 10 cm." },
    quiz: [
      { q: "Le diamètre est égal à :", opts: ["Le rayon", "2 fois le rayon", "La moitié du rayon", "Le centre"], ans: 1, exp: "d = 2r." },
    ],
  },
{
    title: "Mediatrice",
    content: "La médiatrice d'un segment est une droite remarquable en géométrie.\n\nLa médiatrice du segment [AB] est la droite perpendiculaire à [AB] passant par le milieu de [AB].\n\nTout point de la médiatrice est à égale distance de A et de B.\n\nConstruction : ouvrir le compas à plus de la moitié de AB, tracer des arcs depuis A et B, relier les intersections.",
    example: "Si M est sur la médiatrice de [AB], alors MA = MB.",
    keyPoints: ["Médiatrice", "Milieu", "Perpendiculaire", "Équidistance"],
    exercise: { q: "Où se trouve le milieu d'un segment [AB] de 8 cm ?", opts: ["À 4 cm de A et de B", "Autre réponse (incorrecte)", "Réponse non appropriée", "Aucune de ces réponses"], ans: 0, exp: "Le milieu est à égale distance des extrémités : 8/2 = 4 cm.", method: "Le milieu est à égale distance des extrémités : 8/2 = 4 cm." },
    quiz: [
      { q: "Un point de la médiatrice de [AB] est :", opts: ["Plus proche de A", "Plus proche de B", "À égale distance de A et B", "Sur [AB]"], ans: 2, exp: "Propriété d'équidistance." },
    ],
  },
{
    title: "Semaine d integration et de remediation",
    content: "Semaine d'intégration et de remédiation : réinvestir les acquis des séquences précédentes.\n\nL'intégration consiste à mobiliser plusieurs compétences dans une situation.\n\nLa remédiation permet de retravailler les points non maîtrisés.",
    example: "Reprendre un exercice de divisibilité ou de construction géométrique raté en évaluation.",
    keyPoints: ["Intégration", "Remédiation", "Révision"],
    exercise: { q: "Choisis une notion déjà étudiée (diviseurs, cercle ou médiatrice) et écris une définition en une phrase.", opts: ["Réponse libre correcte", "Autre réponse (incorrecte)", "Réponse non appropriée", "Aucune de ces réponses"], ans: 0, exp: "Exemple : « Un diviseur de n est un entier qui divise n sans reste. »", method: "Exemple : « Un diviseur de n est un entier qui divise n sans reste. »" },
    quiz: [
      { q: "La remédiation sert à :", opts: ["Ignorer les erreurs", "Corriger et retravailler", "Changer de matière", "Finir l'année"], ans: 1, exp: "Objectif de la remédiation." },
    ],
  }
];

export function getV26_6e_mathematiques(): Subject {
  return makeSubject("mathematiques", "Math\u00e9matiques", "Calculator", "blue", "6e", "6e", v26_6e_mathematiques_topics);
}

const v26_6e_physique_chimie_topics: TopicData[] = [
  {
    title: "Trois etats de la matiere",
    content: "Les trois états de la matière : solide, liquide, gaz.\n\nSolide : forme et volume propres (craie, pierre).\n\nLiquide : volume propre, forme du récipient (eau d'un verre, huile de palme).\n\nGaz : ni forme ni volume propres (air de la classe).",
    example: "L'eau de pluie à Libreville est liquide. La glace dans un congélateur est solide. La vapeur d'eau au-dessus d'une casserole est un gaz.",
    keyPoints: ["Solide", "Liquide", "Gaz", "Forme", "Volume"],
    exercise: { q: "Dans quel état est le fer d'un clou à température ambiante ?", opts: ["Solide", "Autre réponse (incorrecte)", "Réponse non appropriée", "Aucune de ces réponses"], ans: 0, exp: "Le fer a une forme et un volume propres.", method: "Le fer a une forme et un volume propres." },
    quiz: [
      { q: "Un gaz a :", opts: ["Forme et volume propres", "Volume propre seulement", "Ni forme ni volume propres", "Forme propre seulement"], ans: 2, exp: "Propriété des gaz." },
    ],
  },
  {
    title: "Changements d etat de l eau",
    content: "Les trois états de la matière : solide, liquide, gaz.\n\nSolide : forme et volume propres (craie, pierre).\n\nLiquide : volume propre, forme du récipient (eau d'un verre, huile de palme).\n\nGaz : ni forme ni volume propres (air de la classe).",
    example: "L'eau de pluie à Libreville est liquide. La glace dans un congélateur est solide. La vapeur d'eau au-dessus d'une casserole est un gaz.",
    keyPoints: ["Solide", "Liquide", "Gaz", "Forme", "Volume"],
    exercise: { q: "Dans quel état est le fer d'un clou à température ambiante ?", opts: ["Solide", "Autre réponse (incorrecte)", "Réponse non appropriée", "Aucune de ces réponses"], ans: 0, exp: "Le fer a une forme et un volume propres.", method: "Le fer a une forme et un volume propres." },
    quiz: [
      { q: "Un gaz a :", opts: ["Forme et volume propres", "Volume propre seulement", "Ni forme ni volume propres", "Forme propre seulement"], ans: 2, exp: "Propriété des gaz." },
    ],
  },
  {
    title: "Evaluation diagnostique et remediation",
    content: "Évaluation diagnostique et remédiation en début d'année de Physique-Chimie 6e.\n\nL'évaluation diagnostique n'est pas un examen de passage : elle aide le professeur à adapter le cours.",
    example: "Questions sur les états de la matière déjà vus au primaire.",
    keyPoints: ["Diagnostic", "Remédiation"],
    exercise: { q: "Cite les trois états de la matière.", opts: ["Solide, liquide, gaz", "Autre réponse (incorrecte)", "Réponse non appropriée", "Aucune de ces réponses"], ans: 0, exp: "Les trois états macroscopiques de la matière.", method: "Les trois états macroscopiques de la matière." },
    quiz: [
      { q: "Une évaluation diagnostique sert surtout à :", opts: ["Sanctionner", "Repérer le niveau de départ", "Remplacer le BAC", "Noter le professeur"], ans: 1, exp: "Rôle du diagnostic." },
    ],
  },
];

export function getV26_6e_physique_chimie(): Subject {
  return makeSubject("physique-chimie", "Physique-Chimie", "Atom", "orange", "6e", "6e", v26_6e_physique_chimie_topics);
}

const v26_6e_svt_topics: TopicData[] = [
  {
    title: "Environnement et repartition des etres vivants",
    content: "Environnement et répartition des êtres vivants.\n\nL'environnement regroupe les éléments physiques et biologiques qui entourent un être vivant.\n\nAu Gabon, on trouve des milieux forestiers, côtiers, fluviaux, urbains — avec des espèces adaptées.",
    example: "Les poissons de l'Ogooué ne vivent pas dans la forêt dense comme les gorilles des plaines.",
    keyPoints: ["Environnement", "Milieu de vie", "Répartition", "Adaptation"],
    exercise: { q: "Cite deux milieux de vie différents au Gabon.", opts: ["Ex. forêt équatoriale, mangrove, savane, fleuve…", "Autre réponse (incorrecte)", "Réponse non appropriée", "Aucune de ces réponses"], ans: 0, exp: "Plusieurs réponses valides selon le cours.", method: "Plusieurs réponses valides selon le cours." },
    quiz: [
      { q: "La répartition des êtres vivants dépend notamment :", opts: ["Du hasard uniquement", "Des caractéristiques du milieu", "Du seul jour de la semaine", "Du nom de l'élève"], ans: 1, exp: "Lien milieu / espèces." },
    ],
  },
  {
    title: "Chapitre 2 : Le sol, un milieu de vie",
    content: "Le sol, un milieu de vie.\n\nLe sol abrite racines, vers de terre, insectes, micro-organismes.\n\nIl participe aux cycles de la matière et à la fertilité des cultures.",
    example: "Les vers de terre aèrent le sol des jardins et plantations.",
    keyPoints: ["Sol", "Milieu de vie", "Organismes du sol"],
    exercise: { q: "Cite un animal qui vit dans le sol.", opts: ["Ver de terre (exemple)", "Autre réponse (incorrecte)", "Réponse non appropriée", "Aucune de ces réponses"], ans: 0, exp: "De nombreux invertébrés peuplent le sol.", method: "De nombreux invertébrés peuplent le sol." },
    quiz: [
      { q: "Le sol est :", opts: ["Toujours stérile", "Un milieu de vie", "Un gaz", "Uniquement du béton"], ans: 1, exp: "Chapitre sourcé." },
    ],
  },
  {
    title: "Chapitre 3 : Les modifications du milieu et leurs consequences",
    content: "Les modifications du milieu et leurs conséquences.\n\nDéforestation, pollution, urbanisation modifient les milieux.\n\nLes conséquences peuvent être la disparition d'espèces ou la dégradation des ressources.",
    example: "La conversion d'une parcelle forestière en culture change les habitats locaux.",
    keyPoints: ["Modification du milieu", "Impact", "Conséquence"],
    exercise: { q: "Donne un exemple de modification du milieu par l'Homme.", opts: ["Ex. construction de route, déforestation, pollution…", "Autre réponse (incorrecte)", "Réponse non appropriée", "Aucune de ces réponses"], ans: 0, exp: "Plusieurs réponses possibles.", method: "Plusieurs réponses possibles." },
    quiz: [
      { q: "La pollution d'un fleuve peut :", opts: ["N'avoir aucun effet", "Affecter les êtres vivants aquatiques", "Créer des livres", "Augmenter le coefficient de maths"], ans: 1, exp: "Conséquence sur le milieu." },
    ],
  },
  {
    title: "Chapitre 4 : La gestion des ressources de l environnement eau sol et dechets",
    content: "Gestion des ressources de l'environnement : eau, sol et déchets.\n\nL'eau et le sol sont des ressources limitées à protéger.\n\nTrier et réduire les déchets limite la pollution.",
    example: "Ne pas jeter de plastiques dans les caniveaux de Libreville limite les inondations et la pollution.",
    keyPoints: ["Ressource", "Eau", "Sol", "Déchets", "Gestion"],
    exercise: { q: "Propose un geste simple pour réduire les déchets à l'école.", opts: ["Ex. utiliser une gourde, trier le papier…", "Autre réponse (incorrecte)", "Réponse non appropriée", "Aucune de ces réponses"], ans: 0, exp: "Tout geste de réduction ou de tri est valable.", method: "Tout geste de réduction ou de tri est valable." },
    quiz: [
      { q: "Jeter des déchets plastiques dans la nature :", opts: ["Améliore le sol", "Pollue et nuit aux êtres vivants", "Produit de l'eau potable", "Est obligatoire"], ans: 1, exp: "Impact des déchets." },
    ],
  },
  {
    title: "Chapitre 11 : La production de matiere par les etres vivants",
    content: "Environnement et répartition des êtres vivants.\n\nL'environnement regroupe les éléments physiques et biologiques qui entourent un être vivant.\n\nAu Gabon, on trouve des milieux forestiers, côtiers, fluviaux, urbains — avec des espèces adaptées.",
    example: "Les poissons de l'Ogooué ne vivent pas dans la forêt dense comme les gorilles des plaines.",
    keyPoints: ["Environnement", "Milieu de vie", "Répartition", "Adaptation"],
    exercise: { q: "Cite deux milieux de vie différents au Gabon.", opts: ["Ex. forêt équatoriale, mangrove, savane, fleuve…", "Autre réponse (incorrecte)", "Réponse non appropriée", "Aucune de ces réponses"], ans: 0, exp: "Plusieurs réponses valides selon le cours.", method: "Plusieurs réponses valides selon le cours." },
    quiz: [
      { q: "La répartition des êtres vivants dépend notamment :", opts: ["Du hasard uniquement", "Des caractéristiques du milieu", "Du seul jour de la semaine", "Du nom de l'élève"], ans: 1, exp: "Lien milieu / espèces." },
    ],
  },
  {
    title: "Chapitre 12 : Les ressources alimentaires de l Homme et les techniques de production des aliments",
    content: "Ressources alimentaires de l'Homme et techniques de production des aliments.\n\nL'Homme se nourrit de produits végétaux et animaux.\n\nAu Gabon : manioc, banane plantain, poisson, viandes, fruits… selon les régions.",
    example: "Le manioc est une base alimentaire dans de nombreuses localités gabonaises.",
    keyPoints: ["Ressource alimentaire", "Agriculture", "Élevage", "Pêche"],
    exercise: { q: "Cite deux aliments d'origine végétale courants au Gabon.", opts: ["Ex. manioc, banane plantain, riz…", "Autre réponse (incorrecte)", "Réponse non appropriée", "Aucune de ces réponses"], ans: 0, exp: "Plusieurs réponses valides.", method: "Plusieurs réponses valides." },
    quiz: [
      { q: "La pêche fournit surtout des aliments d'origine :", opts: ["Minérale", "Animale", "Gazeuse", "Métallique"], ans: 1, exp: "Poissons, fruits de mer." },
    ],
  },
];

export function getV26_6e_svt(): Subject {
  return makeSubject("svt", "SVT", "Leaf", "green", "6e", "6e", v26_6e_svt_topics);
}

const v26_cm2_mathematiques_topics: TopicData[] = [
  {
    title: "Nombres et operations",
    content: "En 5e année primaire au Gabon, tu travailles avec les nombres et les opérations pour résoudre des situations de la vie quotidienne.\n\nUn nombre entier sert à compter des objets : élèves dans une classe, sacs de riz au marché de Mont-Bouët, arbres dans une cour d'école.\n\nLes quatre opérations sont : addition (+), soustraction (−), multiplication (×), division (÷).\n\nL'addition réunit des quantités. La soustraction compare ou retire. La multiplication répète une addition. La division partage en parts égales.",
    example: "Dans une classe de Libreville, il y a 28 élèves le matin et 4 arrivent l'après-midi. Total : 28 + 4 = 32 élèves.",
    keyPoints: ["Nombre entier", "Addition", "Soustraction", "Multiplication", "Division"],
    exercise: { q: "Calcule : 145 + 67.", opts: ["212", "0", "Impossible", "Aucune de ces réponses"], ans: 0, exp: "145 + 67 = 212. On additionne les unités puis les dizaines puis les centaines.", method: "145 + 67 = 212. On additionne les unités puis les dizaines puis les centaines." },
    quiz: [
      { q: "Quelle opération utilise-t-on pour partager équitablement ?", opts: ["Addition", "Soustraction", "Multiplication", "Division"], ans: 3, exp: "La division sert à partager en parts égales." },
      { q: "25 + 17 = ?", opts: ["32", "42", "52", "41"], ans: 1, exp: "25 + 17 = 42." },
      { q: "6 × 7 = ?", opts: ["42", "36", "48", "40"], ans: 0, exp: "6 × 7 = 42." },
    ],
  },
  {
    title: "Resolution de problemes",
    content: "Résoudre un problème, c'est comprendre une situation, choisir la bonne opération, calculer et vérifier.\n\nOn lit l'énoncé attentivement et on repère les données utiles.\n\nOn se demande : est-ce que je réunis, je retire, je multiplie ou je partage ?\n\nOn calcule, puis on vérifie si la réponse a un sens dans la situation.",
    example: "Un bus transporte 45 élèves vers Oyem. 12 descendent à Ntoum. Combien restent dans le bus ? → 45 − 12 = 33.",
    keyPoints: ["Données", "Question", "Opération", "Vérification"],
    exercise: { q: "Une cantine prépare 80 repas. 55 sont servis le midi. Combien reste-t-il ?", opts: ["25", "0", "Impossible", "Aucune de ces réponses"], ans: 0, exp: "80 − 55 = 25 repas restants.", method: "80 − 55 = 25 repas restants." },
    quiz: [
      { q: "Pour trouver ce qui reste après un retrait, on utilise :", opts: ["Addition", "Soustraction", "Multiplication", "Division"], ans: 1, exp: "Retirer = soustraction." },
      { q: "Première étape d'un problème :", opts: ["Calculer vite", "Lire et comprendre l'énoncé", "Deviner", "Ignorer les données"], ans: 1, exp: "Il faut d'abord comprendre la situation." },
    ],
  },
  {
    title: "La Geometrie",
    content: "La géométrie étudie les formes : carrés, rectangles, triangles, cercles que l'on rencontre autour de soi.\n\nUne figure plane est tracée sur une surface plate (feuille, tableau).\n\nLe carré a 4 côtés égaux et 4 angles droits. Le rectangle a 4 angles droits et des côtés opposés égaux.\n\nLe triangle a 3 côtés. Le cercle est l'ensemble des points à égale distance d'un centre.",
    example: "Le tableau de la classe est souvent un rectangle. Une fenêtre peut être un rectangle. Une roue de vélo rappelle un cercle.",
    keyPoints: ["Carré", "Rectangle", "Triangle", "Cercle", "Côté", "Sommet", "Angle droit"],
    exercise: { q: "Combien de côtés a un triangle ?", opts: ["3", "0", "Impossible", "Aucune de ces réponses"], ans: 0, exp: "Un triangle a 3 côtés et 3 sommets.", method: "Un triangle a 3 côtés et 3 sommets." },
    quiz: [
      { q: "Combien d'angles droits a un rectangle ?", opts: ["2", "3", "4", "0"], ans: 2, exp: "Un rectangle a 4 angles droits." },
      { q: "Figure à 3 côtés :", opts: ["Carré", "Rectangle", "Triangle", "Cercle"], ans: 2, exp: "Le triangle a 3 côtés." },
    ],
  },
  {
    title: "La Mesure",
    content: "Mesurer, c'est comparer une grandeur à une unité : longueur, masse, capacité, durée.\n\nLongueur : mètre (m), centimètre (cm). Masse : kilogramme (kg), gramme (g). Capacité : litre (L).\n\n1 m = 100 cm. 1 kg = 1000 g. 1 L = 1000 mL.\n\nOn choisit l'unité adaptée : on ne mesure pas la hauteur d'un élève en kilomètres.",
    example: "Un cahier mesure environ 20 cm de long. Un sachet de sucre au marché peut peser 1 kg.",
    keyPoints: ["Mètre", "Centimètre", "Kilogramme", "Litre", "Conversion"],
    exercise: { q: "Convertis 2 m en cm.", opts: ["200 cm", "0", "Impossible", "Aucune de ces réponses"], ans: 0, exp: "1 m = 100 cm, donc 2 m = 200 cm.", method: "1 m = 100 cm, donc 2 m = 200 cm." },
    quiz: [
      { q: "1 m = ? cm", opts: ["10", "100", "1000", "50"], ans: 1, exp: "1 mètre = 100 centimètres." },
    ],
  },
];

export function getV26_cm2_mathematiques(): Subject {
  return makeSubject("mathematiques", "Math\u00e9matiques", "Calculator", "blue", "cm2", "cm2", v26_cm2_mathematiques_topics);
}

const v26_premiere_philosophie_topics: TopicData[] = [
  {
    title: "Mythe et Philosophie - Genese et grands courants philosophiques",
    content: "Mythe et philosophie : genèse et grands courants philosophiques.\n\nLe mythe raconte et explique le monde par des récits symboliques.\n\nLa philosophie interroge, argumente et cherche des raisons.\n\nLes grands courants proposent des réponses différentes aux questions fondamentales.",
    example: "Passer d'un récit mythique à une question du type : « Qu'est-ce que le vrai ? »",
    keyPoints: ["Mythe", "Philosophie", "Courant philosophique", "Raison"],
    exercise: { q: "En quoi une question philosophique diffère-t-elle d'un simple récit ?", opts: ["Elle exige justification / argumentation, pas seulement narration", "Autre réponse (incorrecte)", "Réponse non appropriée", "Aucune de ces réponses"], ans: 0, exp: "La philosophie demande des raisons.", method: "La philosophie demande des raisons." },
    quiz: [
      { q: "La philosophie se caractérise surtout par :", opts: ["La seule mémorisation de dates", "L'interrogation et l'argumentation", "Le sport collectif", "Le dessin technique"], ans: 1, exp: "Démarche philosophique." },
    ],
  },
  {
    title: "Savoir et Opinion",
    content: "Savoir et opinion : croyance, expérience, et autres formes de rapport au réel.\n\nL'opinion est une affirmation non pleinement justifiée.\n\nLe savoir vise une justification plus solide (preuves, raisons).\n\nCroyance, expérience, rêve, pratiques traditionnelles (évoquées dans la progression) interrogent les limites du savoir.",
    example: "« Il va pleuvoir » peut être une opinion ; une mesure météo argumentée se rapproche davantage d'un savoir.",
    keyPoints: ["Savoir", "Opinion", "Croyance", "Expérience"],
    exercise: { q: "Donne un exemple d'opinion et un exemple de savoir dans la vie scolaire.", opts: ["Ex. opinion : « ce cours est facile » ; savoir : un théorème démontré", "Autre réponse (incorrecte)", "Réponse non appropriée", "Aucune de ces réponses"], ans: 0, exp: "Critère = justification.", method: "Critère = justification." },
    quiz: [
      { q: "Une opinion est en général :", opts: ["Toujours démontrée", "Une affirmation peu ou pas pleinement justifiée", "Une loi de la physique", "Un diplôme"], ans: 1, exp: "Distinction classique." },
    ],
  },
  {
    title: "Methodologie",
    content: "Méthodologie philosophique : sujet question, sujet citation, sujet texte.\n\nSujet-question : on analyse la question, on définit les termes, on problematise, on argumente.\n\nSujet-citation : on explique la citation, on discute sa portée.\n\nSujet-texte : on explique le texte puis on le discute.",
    example: "Avant de rédiger, reformuler la question avec ses propres mots.",
    keyPoints: ["Problématisation", "Argumentation", "Sujet-question", "Sujet-citation", "Sujet-texte"],
    exercise: { q: "Quelles sont les trois étapes minimales face à un sujet-question ?", opts: ["Comprendre/définir, problématiser, argumenter (et conclure)", "Autre réponse (incorrecte)", "Réponse non appropriée", "Aucune de ces réponses"], ans: 0, exp: "Méthode de la dissertation / sujet question.", method: "Méthode de la dissertation / sujet question." },
    quiz: [
      { q: "Face à un sujet philosophique, la première chose est de :", opts: ["Écrire n'importe quoi", "Comprendre et analyser le sujet", "Copier un ami", "Changer de matière"], ans: 1, exp: "Méthodologie." },
    ],
  },
  {
    title: "Etude integrale d une oeuvre et controle de lecture",
    content: "Étude intégrale d'une œuvre et contrôle de lecture.\n\nL'étude d'une œuvre permet de suivre un raisonnement suivi, pas seulement des citations isolées.\n\nLe contrôle de lecture vérifie la compréhension globale.",
    example: "Repérer le problème posé par l'auteur et sa réponse principale.",
    keyPoints: ["Œuvre", "Thèse", "Contrôle de lecture"],
    exercise: { q: "Pourquoi faut-il lire l'œuvre et pas seulement des citations ?", opts: ["Pour comprendre le raisonnement d'ensemble", "Autre réponse (incorrecte)", "Réponse non appropriée", "Aucune de ces réponses"], ans: 0, exp: "Les citations isolées peuvent tromper.", method: "Les citations isolées peuvent tromper." },
    quiz: [
      { q: "Un contrôle de lecture vise surtout à vérifier :", opts: ["La vitesse de course", "La compréhension de l'œuvre", "Le dessin de couverture", "Le prix du livre"], ans: 1, exp: "Objectif pédagogique." },
    ],
  },
  {
    title: "Etre et Pensee",
    content: "Être et pensée : nature, matière et corps, âme et esprit, l'homme.\n\nLa philosophie interroge ce qu'est l'être et ce qu'est penser.\n\nNature, matière, corps, âme/esprit, homme : autant de concepts à définir et discuter.",
    example: "Se demander si l'homme se réduit à son corps ou s'il faut aussi penser l'esprit / la conscience.",
    keyPoints: ["Être", "Pensée", "Nature", "Matière", "Corps", "Esprit", "Homme"],
    exercise: { q: "Propose une définition provisoire de « nature ».", opts: ["Réponse libre argumentée", "Autre réponse (incorrecte)", "Réponse non appropriée", "Aucune de ces réponses"], ans: 0, exp: "Plusieurs définitions possibles ; l'important est la clarté et la justification.", method: "Plusieurs définitions possibles ; l'important est la clarté et la justification." },
    quiz: [
      { q: "Avant de discuter un concept en philosophie, il faut surtout :", opts: ["Le crier", "Le définir", "L'ignorer", "Le dessiner seulement"], ans: 1, exp: "Rigueur conceptuelle." },
    ],
  },
  {
    title: "Le Monde et les Valeurs",
    content: "Le monde et les valeurs.\n\nLes valeurs orientent les jugements (juste, beau, bien…).\n\nLa philosophie interroge leur origine, leur universalité ou leur relativité.",
    example: "Discuter ce que signifie « bien agir » dans la vie scolaire et sociale.",
    keyPoints: ["Valeur", "Monde", "Jugement", "Éthique"],
    exercise: { q: "Cite une valeur importante pour la vie en société et justifie en deux phrases.", opts: ["Ex. respect, justice… + justification", "Autre réponse (incorrecte)", "Réponse non appropriée", "Aucune de ces réponses"], ans: 0, exp: "L'essentiel est l'argumentation.", method: "L'essentiel est l'argumentation." },
    quiz: [
      { q: "En philosophie, une valeur est surtout :", opts: ["Un prix en FCFA uniquement", "Un repère pour juger et agir", "Une matière scolaire de sport", "Un outil de géométrie"], ans: 1, exp: "Sens philosophique." },
    ],
  },
];

export function getV26_premiere_philosophie(): Subject {
  return makeSubject("philosophie", "Philosophie", "BookOpen", "purple", "premiere", "premiere", v26_premiere_philosophie_topics);
}

const v26_seconde_svt_topics: TopicData[] = [
  {
    title: "Chapitre 2 : Exploitation du manganese ou de l uranium et risques environnementaux",
    content: "Exploitation du manganèse ou de l'uranium et risques environnementaux.\n\nLe Gabon est un producteur important de manganèse.\n\nL'extraction minière peut modifier les paysages, les sols et les eaux si elle est mal gérée.\n\nIl faut connaître les risques pour mieux les prévenir.",
    example: "La région de Moanda est historiquement liée à l'exploitation du manganèse.",
    keyPoints: ["Manganèse", "Uranium", "Exploitation", "Risque environnemental"],
    exercise: { q: "Cite un risque environnemental possible lié à une mine.", opts: ["Ex. pollution des eaux, dégradation des sols, perte de biodiversité…", "Autre réponse (incorrecte)", "Réponse non appropriée", "Aucune de ces réponses"], ans: 0, exp: "Plusieurs risques possibles selon le site.", method: "Plusieurs risques possibles selon le site." },
    quiz: [
      { q: "Le manganèse est :", opts: ["Un fruit", "Une ressource minière", "Un gaz noble uniquement", "Une discipline sportive"], ans: 1, exp: "Contexte gabonais." },
    ],
  },
  {
    title: "Chapitre 3 : Gestion des ressources en eau dans l environnement",
    content: "Gestion des ressources en eau dans l'environnement.\n\nL'eau est indispensable à la vie et aux activités humaines.\n\nPollution, gaspillage et mauvaise gestion menacent la ressource.",
    example: "Protéger les sources et les cours d'eau limite les risques sanitaires.",
    keyPoints: ["Ressource en eau", "Gestion", "Pollution"],
    exercise: { q: "Propose une action pour économiser l'eau à la maison.", opts: ["Ex. fermer le robinet, réparer les fuites…", "Autre réponse (incorrecte)", "Réponse non appropriée", "Aucune de ces réponses"], ans: 0, exp: "Tout geste d'économie est pertinent.", method: "Tout geste d'économie est pertinent." },
    quiz: [
      { q: "La pollution d'une rivière menace surtout :", opts: ["Uniquement les nuages", "La qualité de l'eau et les êtres vivants", "Les coefficients du BAC", "Les manuels de philo"], ans: 1, exp: "Impact direct." },
    ],
  },
  {
    title: "Chapitre 4 : Relations et styles de vie",
    content: "Éducation à la santé sexuelle et de la reproduction (ESSR) : relations et styles de vie.\n\nLes relations interpersonnelles reposent sur le respect et le consentement.\n\nLes styles de vie (hygiène, prévention) influencent la santé.",
    example: "Discuter avec un professionnel de santé pour des informations fiables.",
    keyPoints: ["ESSR", "Relations", "Respect", "Prévention"],
    exercise: { q: "Pourquoi le respect est-il important dans une relation ?", opts: ["Il protège la dignité et la sécurité de chacun", "Autre réponse (incorrecte)", "Réponse non appropriée", "Aucune de ces réponses"], ans: 0, exp: "Base d'une relation saine.", method: "Base d'une relation saine." },
    quiz: [
      { q: "Une information de santé fiable provient plutôt :", opts: ["D'une rumeur non vérifiée", "D'un professionnel / structure de santé", "D'un message anonyme alarmiste", "Du hasard"], ans: 1, exp: "Sources fiables." },
    ],
  },
];

export function getV26_seconde_svt(): Subject {
  return makeSubject("svt", "SVT", "Leaf", "green", "seconde", "seconde", v26_seconde_svt_topics);
}

/**
 * Français collège — Source : Ministère de l'Éducation Nationale du Gabon,
 * Institut Pédagogique National (IPN), Département de Français.
 * "Proposition de progressions APC 6e-5e-4e-3e 2025-2026" (nzassy.com).
 * Une leçon par séquence officielle (thème + objectif d'écriture réels).
 * Contenu pédagogique rédigé par EduProf, non recopié du document source.
 */
const v26_6e_francais_topics: TopicData[] = [
  {
    title: "Produire un texte narratif (Séquence 1 : la vie en société)",
    content: "Un texte narratif raconte une histoire qui progresse selon le schéma narratif : la situation initiale (les personnages, le lieu, le temps), l'élément perturbateur (ce qui vient bousculer la situation), les péripéties (les événements qui suivent), le dénouement (la résolution) et la situation finale.\n\nCette séquence porte sur la vie en société : la famille, l'amitié, l'égalité entre filles et garçons, la vie au collège. On veille aussi à bien utiliser les types de phrases (déclarative, interrogative, exclamative) pour varier le récit.",
    example: "Situation initiale : Un élève arrive dans un nouveau collège. Élément perturbateur : personne ne lui parle. Péripéties : il propose son aide à un camarade en difficulté. Dénouement : il se fait des amis. Situation finale : il se sent intégré.",
    keyPoints: ["Situation initiale", "Élément perturbateur", "Péripéties", "Dénouement et situation finale", "Varier les types de phrases"],
    exercise: {
      q: "Dans le schéma narratif, l'élément perturbateur sert à :",
      opts: ["Décrire le décor", "Lancer l'histoire en bousculant la situation initiale", "Conclure le récit", "Présenter uniquement les personnages"],
      ans: 1,
      exp: "L'élément perturbateur rompt l'équilibre de départ et déclenche les péripéties.",
      method: "Demande-toi : qu'est-ce qui change par rapport au début de l'histoire ?",
    },
    quiz: [
      { q: "Quelle est la dernière étape du schéma narratif ?", opts: ["L'élément perturbateur", "Les péripéties", "La situation finale", "Le titre"], ans: 2, exp: "La situation finale montre l'état des personnages après la résolution." },
    ],
  },
  {
    title: "Produire un dialogue (Séquence 2 : la responsabilité du citoyen)",
    content: "Un dialogue rapporte les paroles de personnages qui parlent entre eux. À l'écrit, chaque prise de parole commence par un tiret, et les guillemets encadrent l'échange. On utilise des verbes introducteurs de parole (dire, répondre, s'exclamer, demander...) pour indiquer qui parle et sur quel ton.\n\nCette séquence porte sur la responsabilité du citoyen : les valeurs, les devoirs et les droits du citoyen, l'autonomisation.",
    example: "« Connais-tu tes droits en tant qu'élève ? » demanda le délégué de classe.\n— Pas vraiment, avoua Paul.\n— Alors je vais te les expliquer, répondit-il.",
    keyPoints: ["Le tiret pour chaque changement de locuteur", "Les guillemets encadrent le dialogue", "Les verbes introducteurs de parole", "Un dialogue peut être inséré dans un récit"],
    exercise: {
      q: "À quoi sert un verbe introducteur de parole comme « s'exclamer » ?",
      opts: ["À décrire un lieu", "À indiquer qui parle et avec quelle intonation", "À remplacer la ponctuation", "À terminer le texte"],
      ans: 1,
      exp: "Il précise l'auteur de la réplique et donne une indication de ton.",
      method: "Repère le verbe juste après ou avant une réplique entre guillemets.",
    },
    quiz: [
      { q: "Dans un dialogue écrit, un changement de locuteur est marqué par :", opts: ["Un point d'exclamation", "Un tiret", "Une majuscule seule", "Rien du tout"], ans: 1, exp: "Le tiret signale que la parole passe à un autre personnage." },
    ],
  },
  {
    title: "Produire un texte poétique (Séquence 3 : patriotisme et environnement)",
    content: "Un texte poétique joue sur le rythme, les sonorités et les images. Il s'organise en vers regroupés en strophes, et peut utiliser des rimes (des sons qui se répètent en fin de vers).\n\nCette séquence relie la poésie au patriotisme et à la protection de l'environnement : le respect des valeurs nationales, le réchauffement climatique.",
    example: "La forêt du Gabon respire encore,\nSes arbres verts gardent notre trésor.\n(deux vers qui riment en « -ore »)",
    keyPoints: ["Le vers, unité de base du poème", "La strophe regroupe plusieurs vers", "La rime : répétition d'un son en fin de vers", "Le rythme donne une musicalité au texte"],
    exercise: {
      q: "Que forment plusieurs vers regroupés ensemble dans un poème ?",
      opts: ["Une phrase", "Une strophe", "Un paragraphe", "Un dialogue"],
      ans: 1,
      exp: "Une strophe est un groupe de vers séparé des autres par un espace.",
      method: "Compte les lignes qui vont ensemble avant un saut de ligne.",
    },
    quiz: [
      { q: "Une rime est :", opts: ["Un titre de poème", "La répétition d'un son en fin de vers", "Le nombre de strophes", "Un signe de ponctuation"], ans: 1, exp: "Deux vers riment quand ils se terminent par un son semblable." },
    ],
  },
  {
    title: "Produire un texte informatif (Séquence 4 : le bon usage des TIC)",
    content: "Un texte informatif a pour but de faire connaître des faits de façon claire et objective, sans donner d'opinion personnelle. Il est structuré : une introduction qui annonce le sujet, un développement organisé, une conclusion qui résume.\n\nCette séquence porte sur les technologies de l'information et de la communication : le téléphone, l'ordinateur, l'Internet.",
    example: "« L'Internet permet d'accéder à des millions de documents. Il est utilisé pour communiquer, apprendre et se divertir. Il doit cependant être utilisé avec prudence. » — ce texte informe sans prendre parti.",
    keyPoints: ["Objectivité : pas d'opinion personnelle", "Structure claire : introduction, développement, conclusion", "Vocabulaire précis et technique si besoin", "But : faire connaître, pas convaincre"],
    exercise: {
      q: "Quelle est la principale différence entre un texte informatif et un texte argumentatif ?",
      opts: ["Le texte informatif est plus long", "Le texte informatif ne défend pas de thèse, contrairement à l'argumentatif", "Le texte informatif n'a pas de titre", "Il n'y a aucune différence"],
      ans: 1,
      exp: "Le texte informatif transmet des faits ; le texte argumentatif défend un point de vue.",
      method: "Cherche si le texte essaie de te convaincre de quelque chose : si oui, ce n'est pas purement informatif.",
    },
    quiz: [
      { q: "Un texte informatif vise avant tout à :", opts: ["Convaincre le lecteur", "Faire rire le lecteur", "Faire connaître des faits objectivement", "Raconter une aventure"], ans: 2, exp: "Informer, c'est transmettre des faits sans les déformer par une opinion." },
    ],
  },
  {
    title: "Initiation au texte argumentatif (Séquence 5 : valeurs républicaines et diversité culturelle)",
    content: "Un texte argumentatif défend une thèse (une opinion) à l'aide d'arguments (des raisons) et d'exemples (des illustrations concrètes). Des connecteurs logiques (d'abord, ensuite, en effet, donc) relient les idées entre elles.\n\nCette séquence relie l'argumentation aux valeurs républicaines, au mariage coutumier, à la diversité des langues et aux mets du terroir.",
    example: "Thèse : « Il faut préserver les langues nationales. » Argument : « Elles portent l'histoire et la culture d'un peuple. » Exemple : « Un conte traditionnel perd du sens une fois traduit. »",
    keyPoints: ["La thèse : l'opinion défendue", "Les arguments soutiennent la thèse", "Les exemples illustrent les arguments", "Les connecteurs logiques organisent le texte"],
    exercise: {
      q: "Que fait un connecteur logique comme « donc » dans un texte argumentatif ?",
      opts: ["Il introduit une conséquence", "Il termine automatiquement le texte", "Il remplace la thèse", "Il n'a aucun rôle"],
      ans: 0,
      exp: "« Donc » introduit une conséquence logique tirée de ce qui précède.",
      method: "Regarde ce qui vient juste avant « donc » : c'est la cause de ce qui suit.",
    },
    quiz: [
      { q: "Dans un texte argumentatif, un exemple sert à :", opts: ["Remplacer la thèse", "Illustrer concrètement un argument", "Conclure le texte obligatoirement", "Poser une question"], ans: 1, exp: "L'exemple rend l'argument plus concret et convaincant." },
    ],
  },
  {
    title: "Produire des textes variés (Séquence 6 : sport et loisirs)",
    content: "Cette séquence de fin d'année réunit plusieurs types de textes déjà vus (narratif, informatif, poétique) autour du sport et des loisirs : le bien-être par le sport, les jeux olympiques, les jeux de société, le slam.\n\nSavoir choisir le bon type de texte selon la situation est une compétence clé pour la suite de la scolarité.",
    example: "Raconter un match (texte narratif), présenter les règles d'un jeu (texte informatif), écrire un couplet de slam sur le sport (texte poétique) : trois types de texte pour un même thème.",
    keyPoints: ["Reconnaître le type de texte demandé", "Adapter son écriture à l'objectif (raconter, informer, faire ressentir)", "Réinvestir le vocabulaire du sport et des loisirs", "Réviser le schéma narratif et les caractéristiques du texte informatif"],
    exercise: {
      q: "Pour présenter les règles d'un jeu de société, quel type de texte est le plus adapté ?",
      opts: ["Un texte poétique", "Un texte informatif", "Un texte uniquement dialogué", "Peu importe"],
      ans: 1,
      exp: "Présenter des règles, c'est transmettre une information claire et objective.",
      method: "Demande-toi : est-ce que je raconte une histoire, ou est-ce que j'explique quelque chose ?",
    },
    quiz: [
      { q: "Raconter le déroulement d'un match est un exemple de texte :", opts: ["Informatif", "Narratif", "Poétique", "Argumentatif"], ans: 1, exp: "Raconter des événements qui s'enchaînent, c'est un texte narratif." },
    ],
  },
];

export function getV26_6e_francais(): Subject {
  return makeSubject("francais", "Français", "BookOpen", "amber", "6e", "6e", v26_6e_francais_topics);
}

const v26_5e_francais_topics: TopicData[] = [
  {
    title: "Produire une lettre officielle (Séquence 1 : le vivre ensemble)",
    content: "La lettre officielle s'adresse à une autorité ou une administration (le principal, un service public). Elle suit une structure précise : lieu et date, formule d'appel respectueuse (« Monsieur le Principal »), corps du texte clair et poli, formule de politesse finale, signature. Elle se distingue de la lettre amicale, plus libre et personnelle.\n\nCette séquence porte sur le vivre ensemble : l'amitié, l'entraide, les relations sociales, le mariage coutumier.",
    example: "« Monsieur le Principal, j'ai l'honneur de solliciter... Veuillez agréer, Monsieur le Principal, l'expression de mon profond respect. »",
    keyPoints: ["Lieu, date et formule d'appel respectueuse", "Un objet clair énoncé dès le début", "Un langage soutenu et poli", "Une formule de politesse finale adaptée"],
    exercise: {
      q: "Quelle formule convient pour s'adresser à un principal de collège dans une lettre officielle ?",
      opts: ["Salut mon pote,", "Monsieur le Principal,", "Coucou,", "À plus,"],
      ans: 1,
      exp: "La lettre officielle exige une formule de politesse respectueuse et adaptée au destinataire.",
      method: "Pense à qui tu écris : une autorité demande un registre soutenu.",
    },
    quiz: [
      { q: "La lettre officielle se distingue de la lettre amicale par :", opts: ["Sa longueur uniquement", "Son registre soutenu et sa structure formelle", "L'absence de signature", "L'usage exclusif du dialogue"], ans: 1, exp: "Le registre de langue et la structure formelle sont propres à la lettre officielle." },
    ],
  },
  {
    title: "Défendre et réfuter un point de vue (Séquence 2 : autonomisation et responsabilité du citoyen)",
    content: "Dans un texte argumentatif, défendre un point de vue consiste à apporter des arguments qui soutiennent une thèse. Réfuter un point de vue, c'est au contraire montrer les limites ou les faiblesses d'une thèse adverse, souvent avec des connecteurs d'opposition (mais, cependant, pourtant).\n\nCette séquence porte sur l'autonomisation et la responsabilité du citoyen : la dénonciation des abus en milieu scolaire, le respect du bien public.",
    example: "Défendre : « Le respect du bien public profite à tous. » Réfuter une objection : « Certains pensent que ce n'est pas leur rôle, pourtant chaque élève est responsable de son établissement. »",
    keyPoints: ["Défendre : apporter des arguments pour une thèse", "Réfuter : montrer les limites d'une thèse adverse", "Connecteurs d'opposition : mais, cependant, pourtant", "Rester poli même en contestant un avis"],
    exercise: {
      q: "Quel connecteur logique est utile pour réfuter un point de vue ?",
      opts: ["Ensuite", "Cependant", "Premièrement", "Enfin"],
      ans: 1,
      exp: "« Cependant » introduit une opposition, utile pour nuancer ou contredire un argument.",
      method: "Cherche un mot qui introduit un contraste avec ce qui précède.",
    },
    quiz: [
      { q: "Réfuter un point de vue, c'est :", opts: ["Le répéter", "Montrer ses limites ou ses faiblesses", "L'ignorer complètement", "Le recopier"], ans: 1, exp: "Réfuter consiste à démontrer qu'un argument adverse est fragile ou incomplet." },
    ],
  },
  {
    title: "Structurer un texte informatif (Séquence 3 : intégration et environnement)",
    content: "Un texte informatif bien structuré présente d'abord le sujet, puis développe les informations de façon organisée (par exemple du général au particulier), avant de conclure. Il reste objectif : il ne mélange pas les faits et les opinions personnelles.\n\nCette séquence porte sur l'intégration dans son milieu de vie et la préservation de l'environnement : la gestion des ordures ménagères, le climat.",
    example: "« Le Gabon connaît deux grandes saisons : une saison sèche et une saison des pluies. Cette alternance influence l'agriculture et la vie quotidienne. »",
    keyPoints: ["Présenter le sujet dès le début", "Organiser les informations de façon logique", "Rester objectif, sans opinion personnelle", "Utiliser un vocabulaire précis"],
    exercise: {
      q: "Pourquoi un texte informatif doit-il rester objectif ?",
      opts: ["Pour être plus long", "Pour transmettre des faits fiables, sans les déformer", "Parce que c'est obligatoire à l'oral seulement", "Cela n'a pas d'importance"],
      ans: 1,
      exp: "L'objectivité garantit que l'information transmise n'est pas déformée par une opinion.",
      method: "Vérifie si le texte contient des mots qui expriment un avis personnel (je pense que...).",
    },
    quiz: [
      { q: "Un texte informatif organisé « du général au particulier » commence par :", opts: ["Un détail précis", "Une idée générale", "La conclusion", "Un dialogue"], ans: 1, exp: "On part d'une idée générale avant d'entrer dans les détails." },
    ],
  },
  {
    title: "Produire un poème libre (Séquence 4 : le bon usage des TIC)",
    content: "Le poème libre n'obéit pas à des règles fixes de rimes ou de nombre de syllabes : il joue surtout sur le rythme, les images et les sensations. C'est une forme plus souple que le poème à forme fixe.\n\nCette séquence relie l'écriture poétique au bon usage des réseaux sociaux et à la découverte de l'intelligence artificielle.",
    example: "Un poème libre sur Internet pourrait juxtaposer des images sans rimes imposées : « Des fils invisibles relient le monde / une photo, une pensée, un instant partagé ».",
    keyPoints: ["Pas de rime obligatoire", "Le rythme et les images priment", "Plus de liberté que le poème à forme fixe", "Toujours organisé en vers"],
    exercise: {
      q: "Ce qui caractérise surtout le poème libre est :",
      opts: ["L'absence totale de vers", "L'absence de rimes obligatoires", "L'obligation de rimer à chaque ligne", "Un nombre fixe de strophes"],
      ans: 1,
      exp: "Le poème libre s'affranchit des rimes imposées, contrairement au poème à forme fixe.",
      method: "Compare avec un poème classique : que manque-t-il ici ?",
    },
    quiz: [
      { q: "Le poème libre reste tout de même organisé en :", opts: ["Paragraphes", "Vers", "Articles", "Dialogues"], ans: 1, exp: "Même sans rimes fixes, un poème reste composé de vers." },
    ],
  },
  {
    title: "Produire un texte explicatif (Séquence 5 : valeurs nationales et diversité culturelle)",
    content: "Un texte explicatif répond à la question « pourquoi » ou « comment » : il éclaire un phénomène par un enchaînement logique de cause à conséquence, sans chercher à convaincre comme le ferait un texte argumentatif.\n\nCette séquence porte sur les valeurs nationales et la diversité culturelle : le sens de la levée des couleurs, les armoiries du Gabon.",
    example: "« Le drapeau du Gabon comporte trois bandes de couleur : le vert représente les forêts, le jaune l'équateur, le bleu l'océan Atlantique. »",
    keyPoints: ["Répond à « pourquoi » ou « comment »", "Enchaînement logique cause → conséquence", "Pas de thèse à défendre, contrairement à l'argumentatif", "Vocabulaire clair et précis"],
    exercise: {
      q: "Quelle est la différence principale entre texte explicatif et texte argumentatif ?",
      opts: ["Le texte explicatif éclaire un fait, il ne défend pas une opinion", "Le texte explicatif est toujours plus court", "Il n'y a pas de différence", "Le texte explicatif utilise uniquement le dialogue"],
      ans: 0,
      exp: "Expliquer, c'est faire comprendre un fait ; argumenter, c'est défendre une opinion.",
      method: "Cherche si le texte prend parti pour une opinion : si non, il est plutôt explicatif.",
    },
    quiz: [
      { q: "Un texte explicatif répond typiquement à la question :", opts: ["Qui gagnera ?", "Pourquoi ou comment ?", "Combien ça coûte ?", "Quand partir ?"], ans: 1, exp: "Le texte explicatif éclaire les causes ou le fonctionnement d'un phénomène." },
    ],
  },
  {
    title: "Produire un dialogue théâtral (Séquence 6 : sport et loisirs)",
    content: "Le dialogue théâtral se distingue du dialogue de récit : il comporte des répliques (les paroles des personnages) et des didascalies (indications de mise en scène, souvent en italique ou entre parenthèses). Une tirade est une longue réplique ; un monologue est un discours d'un personnage seul.\n\nCette séquence relie le théâtre au sport et aux loisirs : les arts martiaux, les clubs de lecture.",
    example: "KOUMBA (fièrement). — J'ai gagné mon combat de judo !\n(Il lève les bras en signe de victoire.)",
    keyPoints: ["La réplique : parole d'un personnage", "La didascalie : indication de mise en scène", "La tirade : longue réplique d'un personnage", "Le monologue : un personnage parle seul"],
    exercise: {
      q: "Qu'est-ce qu'une didascalie dans un texte théâtral ?",
      opts: ["Le nom du personnage", "Une indication de mise en scène", "La réplique la plus longue", "Le titre de la pièce"],
      ans: 1,
      exp: "La didascalie précise un geste, un ton ou un déplacement, souvent entre parenthèses.",
      method: "Cherche le texte qui n'est pas dit à voix haute par un personnage.",
    },
    quiz: [
      { q: "Un personnage qui parle seul sur scène fait :", opts: ["Un dialogue", "Un monologue", "Une didascalie", "Une rime"], ans: 1, exp: "Le monologue est la prise de parole d'un personnage seul." },
    ],
  },
];

export function getV26_5e_francais(): Subject {
  return makeSubject("francais", "Français", "BookOpen", "amber", "5e", "5e", v26_5e_francais_topics);
}

const v26_4e_francais_topics: TopicData[] = [
  {
    title: "Écrire un portrait (Séquence 1 : le vivre ensemble)",
    content: "Un portrait décrit une personne physiquement (taille, visage, vêtements) et moralement (caractère, qualités, défauts). On utilise des adjectifs qualificatifs précis et parfois des comparaisons pour rendre le portrait vivant.\n\nCette séquence porte sur le vivre ensemble : le respect d'autrui, les formes de violence, l'empathie.",
    example: "« Grand et mince, il avait un regard doux qui inspirait confiance. Toujours prêt à écouter, il faisait preuve d'une grande patience avec ses camarades. »",
    keyPoints: ["Portrait physique : apparence", "Portrait moral : caractère", "Adjectifs qualificatifs précis", "Comparaisons pour enrichir la description"],
    exercise: {
      q: "Un portrait moral décrit :",
      opts: ["L'apparence physique uniquement", "Le caractère et la personnalité", "Le lieu où vit la personne", "Sa date de naissance"],
      ans: 1,
      exp: "Le portrait moral s'attache aux traits de caractère, aux qualités et aux défauts.",
      method: "Distingue ce qui se voit (physique) de ce qui se ressent (caractère).",
    },
    quiz: [
      { q: "Pour rendre un portrait plus vivant, on utilise souvent :", opts: ["Des chiffres uniquement", "Des comparaisons et adjectifs précis", "Des formules mathématiques", "Des dialogues uniquement"], ans: 1, exp: "Les comparaisons et adjectifs précisent et animent la description." },
    ],
  },
  {
    title: "Produire un texte injonctif (Séquence 2 : autonomisation et responsabilité du citoyen)",
    content: "Le texte injonctif donne des ordres, des conseils ou des consignes : c'est le texte des règlements, notices et recettes. Il utilise souvent l'impératif (« Fais attention ») ou l'infinitif à valeur de consigne (« Respecter le silence »).\n\nCette séquence porte sur le rôle du délégué de classe et la maturité citoyenne.",
    example: "« Respecte les décisions prises en conseil de classe. Écoute tes camarades avant de répondre. Ne coupe pas la parole. »",
    keyPoints: ["But : donner des ordres, conseils ou consignes", "Souvent à l'impératif ou à l'infinitif", "Phrases courtes et claires", "Utilisé pour règlements, notices, recettes"],
    exercise: {
      q: "Quel mode verbal est le plus utilisé dans un texte injonctif ?",
      opts: ["Le conditionnel", "L'impératif", "Le plus-que-parfait", "Le passé simple"],
      ans: 1,
      exp: "L'impératif exprime directement l'ordre ou le conseil : « Fais », « Respecte ».",
      method: "Repère les verbes sans sujet exprimé placés en tête de phrase.",
    },
    quiz: [
      { q: "Un règlement intérieur est un exemple typique de texte :", opts: ["Poétique", "Injonctif", "Narratif", "Explicatif"], ans: 1, exp: "Un règlement donne des consignes à suivre : c'est un texte injonctif." },
    ],
  },
  {
    title: "Construire un plan argumentatif (Séquence 3 : intégration et environnement)",
    content: "Un texte argumentatif développé suit un plan : le plan thématique présente plusieurs arguments organisés par thèmes, avec une introduction qui pose la thèse et une conclusion qui la rappelle. Chaque paragraphe développe un argument illustré d'exemples.\n\nCette séquence porte sur l'intégration dans son milieu de vie et la préservation de l'environnement : le recyclage des ordures, les coopératives scolaires.",
    example: "Plan thématique sur le recyclage : § 1 l'argument écologique, § 2 l'argument économique, § 3 l'argument éducatif — chacun avec un exemple concret.",
    keyPoints: ["Introduction : présenter la thèse", "Développement organisé en paragraphes thématiques", "Chaque paragraphe : un argument + un exemple", "Conclusion : rappeler la thèse"],
    exercise: {
      q: "Dans un plan thématique, chaque paragraphe correspond en général à :",
      opts: ["Un seul mot", "Un argument développé et illustré", "Une nouvelle histoire sans lien", "Une simple liste de mots"],
      ans: 1,
      exp: "Chaque paragraphe développe un argument distinct, appuyé par un exemple.",
      method: "Vérifie que chaque paragraphe défend une idée claire, différente des autres.",
    },
    quiz: [
      { q: "Le rôle de la conclusion dans un texte argumentatif est de :", opts: ["Introduire un nouvel argument", "Rappeler la thèse défendue", "Poser une question ouverte uniquement", "Décrire un lieu"], ans: 1, exp: "La conclusion synthétise et rappelle la position défendue." },
    ],
  },
  {
    title: "Écrire une lettre administrative (Séquence 4 : le bon usage des TIC)",
    content: "La lettre administrative ressemble à la lettre officielle mais s'adresse à une institution précise, avec des références (objet, éventuellement numéro de dossier) et des formules consacrées encore plus strictes. Elle sert par exemple à faire une demande écrite à une administration.\n\nCette séquence porte sur la gestion de l'information en ligne et la création d'un blog.",
    example: "« Objet : demande de duplicata de bulletin scolaire. Monsieur le Directeur, j'ai l'honneur de vous demander... »",
    keyPoints: ["Un objet clairement énoncé", "Des formules consacrées très strictes", "S'adresse à une institution précise", "Langage soutenu, sans familiarité"],
    exercise: {
      q: "Que doit contenir en général une lettre administrative dès le début ?",
      opts: ["Une blague", "Un objet clair de la demande", "Un poème", "Un dialogue"],
      ans: 1,
      exp: "L'objet permet au destinataire de comprendre immédiatement le motif de la lettre.",
      method: "Pense à ce qu'un service administratif a besoin de savoir en priorité.",
    },
    quiz: [
      { q: "La lettre administrative se caractérise surtout par :", opts: ["Un ton familier", "Des formules très strictes et un objet précis", "L'absence de formule de politesse", "Un style poétique"], ans: 1, exp: "La rigueur formelle est essentielle dans une lettre administrative." },
    ],
  },
  {
    title: "Écrire un dialogue argumentatif (Séquence 5 : valeurs nationales et diversité culturelle)",
    content: "Le dialogue argumentatif combine les codes du dialogue (répliques, verbes introducteurs) et ceux de l'argumentation : chaque personnage défend un point de vue différent, avec ses propres arguments et exemples.\n\nCette séquence porte sur les valeurs nationales et la diversité culturelle : les langues nationales, les mets du terroir.",
    example: "— Il faut enseigner les langues nationales à l'école, affirma Aïcha.\n— Mais le français reste indispensable pour tous les Gabonais, répondit Marc.",
    keyPoints: ["Chaque personnage défend une thèse différente", "Les répliques contiennent des arguments", "On garde les codes du dialogue (tirets, verbes de parole)", "Le débat peut rester ouvert sans trancher"],
    exercise: {
      q: "Dans un dialogue argumentatif, chaque personnage doit surtout :",
      opts: ["Répéter la même idée que l'autre", "Défendre un point de vue avec des arguments", "Ne jamais répondre à l'autre", "Parler uniquement de lui-même"],
      ans: 1,
      exp: "L'intérêt du dialogue argumentatif est la confrontation de points de vue différents.",
      method: "Vérifie que les deux personnages ne défendent pas la même thèse.",
    },
    quiz: [
      { q: "Le dialogue argumentatif combine les codes :", opts: ["Du poème et de la lettre", "Du dialogue et de l'argumentation", "De la notice et du roman", "Aucun des deux"], ans: 1, exp: "Il mélange forme dialoguée et contenu argumentatif." },
    ],
  },
  {
    title: "Composer un poème versifié (Séquence 6 : sport et loisirs)",
    content: "Un poème versifié respecte des règles de versification : un compte de syllabes régulier par vers, et des rimes organisées (rimes plates AABB, croisées ABAB, ou embrassées ABBA).\n\nCette séquence relie la poésie au cinéma et aux championnats interclasses.",
    example: "Rimes plates (AABB) : « Sur le terrain, les joueurs s'élancent (A) / Dans un ballet où les corps se lancent (A) / La foule crie, le stade s'enflamme (B) / Chaque but efface un peu plus le blâme (B) »",
    keyPoints: ["Compte régulier de syllabes par vers", "Rimes plates (AABB)", "Rimes croisées (ABAB)", "Rimes embrassées (ABBA)"],
    exercise: {
      q: "Des rimes disposées en ABAB sont appelées :",
      opts: ["Rimes plates", "Rimes croisées", "Rimes embrassées", "Rimes libres"],
      ans: 1,
      exp: "ABAB correspond aux rimes croisées, qui alternent deux sons de rime.",
      method: "Note la lettre de chaque son de fin de vers et regarde l'ordre obtenu.",
    },
    quiz: [
      { q: "Une disposition de rimes ABBA est dite :", opts: ["Plate", "Croisée", "Embrassée", "Absente"], ans: 2, exp: "ABBA correspond aux rimes embrassées, où deux rimes encadrent les deux autres." },
    ],
  },
];

export function getV26_4e_francais(): Subject {
  return makeSubject("francais", "Français", "BookOpen", "amber", "4e", "4e", v26_4e_francais_topics);
}

const v26_3e_francais_topics: TopicData[] = [
  {
    title: "Changer de point de vue dans un récit (Séquence 3 : intégration et environnement)",
    content: "Réécrire un passage en changeant de point de vue narratif consiste à raconter les mêmes événements à travers le regard d'un autre personnage, ou en passant de la première à la troisième personne. Cela demande d'adapter les pronoms, parfois les temps, et surtout les informations connues du narrateur.\n\nCette séquence porte sur l'intégration dans son milieu de vie et la préservation de l'environnement.",
    example: "Point de vue initial : « Je marchais seul dans la rue. » Après changement de point de vue : « Il marchait seul dans la rue, sans savoir qu'on l'observait. » (le narrateur externe sait des choses que le personnage ignore).",
    keyPoints: ["Adapter les pronoms (je → il/elle)", "Adapter ce que le narrateur peut savoir", "Garder la cohérence des événements racontés", "Un narrateur externe peut en savoir plus qu'un personnage"],
    exercise: {
      q: "Que faut-il vérifier en priorité en changeant le point de vue d'un récit ?",
      opts: ["La couleur du livre", "La cohérence des informations connues par le narrateur", "Le nombre de pages", "Le titre du chapitre"],
      ans: 1,
      exp: "Un narrateur externe ne doit pas connaître des pensées qu'il ne pourrait pas connaître dans le récit d'origine, sauf choix volontaire de l'auteur.",
      method: "Demande-toi : qui raconte, et que peut-il légitimement savoir ?",
    },
    quiz: [
      { q: "Passer du « je » au « il » dans un récit change surtout :", opts: ["L'orthographe du titre", "Le point de vue narratif", "Le genre du texte", "La langue du texte"], ans: 1, exp: "C'est un changement de narrateur, donc de point de vue." },
    ],
  },
  {
    title: "La lettre personnelle et la lettre officielle : bien choisir son registre",
    content: "Au BEPC, il faut savoir distinguer clairement la lettre personnelle (registre familier ou courant, destinataire proche) de la lettre officielle (registre soutenu, destinataire institutionnel). Le choix du registre, des formules d'appel et de politesse dépend entièrement du destinataire.\n\nCette distinction, vue dès la 5e, est reprise et approfondie en 3e en vue de l'examen.",
    example: "Lettre personnelle : « Salut Paul, comment vas-tu ? » Lettre officielle : « Monsieur le Censeur, j'ai l'honneur de porter à votre connaissance... »",
    keyPoints: ["Registre familier/courant pour la lettre personnelle", "Registre soutenu pour la lettre officielle", "Adapter la formule d'appel au destinataire", "Adapter la formule de politesse finale"],
    exercise: {
      q: "Avant de choisir le registre d'une lettre, il faut d'abord se demander :",
      opts: ["Combien de pages écrire", "Qui est le destinataire", "Quelle couleur de stylo utiliser", "La date du jour"],
      ans: 1,
      exp: "Le destinataire détermine le registre de langue et les formules à employer.",
      method: "Identifie si le destinataire est un proche ou une autorité/institution.",
    },
    quiz: [
      { q: "« J'ai l'honneur de vous demander » appartient à un registre :", opts: ["Familier", "Soutenu", "Argotique", "Poétique"], ans: 1, exp: "Cette formule appartient au registre soutenu, propre à la lettre officielle." },
    ],
  },
  {
    title: "Écrire un article de presse (Séquence 4 : le bon usage des TIC)",
    content: "Un article de presse informe sur un fait d'actualité. Il comporte un titre accrocheur, parfois un chapeau (court résumé sous le titre), puis un corps qui répond aux questions essentielles : qui, quoi, où, quand, comment, pourquoi. Le ton reste généralement objectif.\n\nCette séquence porte sur les avantages et les inconvénients des réseaux sociaux et sur la cybercriminalité.",
    example: "Titre : « Cybercriminalité : les collégiens sensibilisés ». Chapeau : « Une campagne d'information a eu lieu cette semaine dans plusieurs établissements. » Corps : qui, quoi, où, quand...",
    keyPoints: ["Titre accrocheur", "Chapeau : résumé bref", "Répondre à qui, quoi, où, quand, comment, pourquoi", "Ton globalement objectif"],
    exercise: {
      q: "À quoi sert le chapeau d'un article de presse ?",
      opts: ["À conclure l'article", "À résumer brièvement l'information sous le titre", "À citer une source uniquement", "À remplacer le titre"],
      ans: 1,
      exp: "Le chapeau donne rapidement l'essentiel de l'information avant le développement.",
      method: "Cherche le court paragraphe placé juste après le titre, avant le corps de l'article.",
    },
    quiz: [
      { q: "Un bon article de presse répond notamment à la question :", opts: ["Combien coûte le journal ?", "Qui, quoi, où, quand ?", "Quelle est la couleur du logo ?", "Qui a imprimé le papier ?"], ans: 1, exp: "Ces questions structurent l'information essentielle d'un article." },
    ],
  },
  {
    title: "Réussir un texte explicatif au BEPC",
    content: "Le texte explicatif fait comprendre un fait ou un phénomène par un enchaînement logique (cause, conséquence, exemple), sans chercher à convaincre comme l'argumentatif. Au BEPC, il faut soigner l'organisation en paragraphes et les connecteurs logiques (parce que, c'est pourquoi, ainsi).\n\nCette compétence, travaillée depuis la 5e, est réinvestie en 3e sur des sujets de société (hygiène, environnement, comportement).",
    example: "« Le tri des déchets réduit la pollution. En effet, séparer le plastique du reste permet son recyclage. C'est pourquoi de plus en plus d'écoles s'y engagent. »",
    keyPoints: ["Enchaînement logique cause → conséquence", "Connecteurs : parce que, c'est pourquoi, ainsi", "Pas d'opinion personnelle défendue", "Paragraphes bien organisés"],
    exercise: {
      q: "Quel connecteur introduit typiquement une cause dans un texte explicatif ?",
      opts: ["Cependant", "Parce que", "Malgré", "Enfin"],
      ans: 1,
      exp: "« Parce que » introduit la cause d'un fait déjà énoncé.",
      method: "Cherche le mot qui répond à la question « pourquoi ? » posée par la phrase précédente.",
    },
    quiz: [
      { q: "Le texte explicatif se distingue de l'argumentatif car il :", opts: ["Ne défend pas une opinion, il fait comprendre un fait", "Est toujours plus court", "N'utilise jamais de connecteurs", "Est réservé à la poésie"], ans: 0, exp: "Expliquer, c'est éclairer un fait ; argumenter, c'est défendre une thèse." },
    ],
  },
  {
    title: "Méthode : le texte injonctif et l'argumentation au BEPC",
    content: "Au BEPC, les sujets de rédaction combinent parfois plusieurs compétences : donner des conseils (texte injonctif, souvent à l'impératif) tout en justifiant ces conseils par des arguments. Il faut alors alterner consignes claires et raisons qui les justifient.\n\nCette séquence reprend les objectifs des séquences 1 et 2 de 3e (vivre ensemble, autonomisation et responsabilité du citoyen) en vue de l'examen.",
    example: "« Respecte les horaires de ton établissement (conseil à l'impératif), car la ponctualité te prépare à la vie active (argument qui justifie le conseil). »",
    keyPoints: ["Alterner conseils (impératif) et arguments (justification)", "Rester clair et concis", "Utiliser des connecteurs logiques pour relier conseil et raison", "Adapter le ton au destinataire visé par le sujet"],
    exercise: {
      q: "Dans un sujet qui demande de « donner des conseils justifiés », il faut combiner :",
      opts: ["Poésie et dialogue", "Texte injonctif et argumentation", "Lettre et article de presse uniquement", "Aucune combinaison n'est nécessaire"],
      ans: 1,
      exp: "Le conseil (injonctif) doit être appuyé par une raison (argumentation).",
      method: "Repère dans le sujet s'il demande à la fois de conseiller ET de justifier.",
    },
    quiz: [
      { q: "Un conseil suivi de sa justification correspond à l'association de :", opts: ["Narratif et poétique", "Injonctif et argumentatif", "Informatif et théâtral", "Aucun lien entre les deux"], ans: 1, exp: "Le conseil relève de l'injonctif, sa justification de l'argumentatif." },
    ],
  },
  {
    title: "Méthode générale de la production écrite au BEPC",
    content: "Pour réussir l'épreuve de production écrite au BEPC, il faut : lire attentivement le sujet et repérer le type de texte demandé, respecter la consigne de longueur, organiser sa réponse en paragraphes visibles (alinéas), se relire pour corriger l'orthographe et la ponctuation.\n\nCette séquence de consolidation reprend l'ensemble des types de textes travaillés depuis la 6e : narratif, dialogue, poétique, informatif, argumentatif, explicatif, injonctif, lettre, article de presse.",
    example: "Avant de rédiger : souligner dans le sujet le type de texte demandé et les mots-clés du thème, pour ne pas répondre à côté.",
    keyPoints: ["Repérer le type de texte demandé dans le sujet", "Respecter la longueur demandée", "Organiser le texte en paragraphes", "Se relire pour corriger les erreurs"],
    exercise: {
      q: "Avant de commencer à rédiger le jour de l'examen, la première chose à faire est de :",
      opts: ["Écrire le plus vite possible", "Lire attentivement le sujet et repérer ce qui est demandé", "Recopier un texte déjà appris par cœur", "Ignorer la consigne de longueur"],
      ans: 1,
      exp: "Comprendre précisément la consigne évite de rédiger un texte hors sujet.",
      method: "Repère les verbes de consigne (raconte, explique, décris, convaincs...) : ils indiquent le type de texte attendu.",
    },
    quiz: [
      { q: "Se relire à la fin d'une rédaction sert surtout à :", opts: ["Rallonger le texte", "Corriger l'orthographe et la ponctuation", "Changer le sujet", "Effacer la conclusion"], ans: 1, exp: "La relecture permet de repérer et corriger les erreurs avant de rendre sa copie." },
    ],
  },
];

export function getV26_3e_francais(): Subject {
  return makeSubject("francais", "Français", "BookOpen", "amber", "3e", "3e", v26_3e_francais_topics);
}

/**
 * Histoire & Géographie collège — Source : Ministère de l'Éducation Nationale du Gabon,
 * Institut Pédagogique National (IPN), curriculum 2024-2025 (nzassy.com).
 * Une leçon par palier de compétence officiel. Contenu rédigé par EduProf, non recopié du document source.
 */
const v26_6e_histoire_topics: TopicData[] = [
  {
    title: "La notion de l'Histoire (Palier 1)",
    content: "L'Histoire est la science qui étudie le passé des sociétés humaines. Elle remplit plusieurs fonctions : civique (former des citoyens éclairés), critique (développer l'esprit d'analyse) et identitaire (comprendre d'où l'on vient). On distingue de grandes périodes : la Préhistoire (Paléolithique et Néolithique), puis l'Histoire proprement dite (Antiquité, Moyen Âge, Temps modernes, Époque contemporaine).",
    example: "Une frise chronologique permet de visualiser ces grandes périodes dans l'ordre, de la Préhistoire jusqu'à aujourd'hui.",
    keyPoints: ["L'Histoire étudie le passé des sociétés", "Fonctions civique, critique, identitaire", "Préhistoire : Paléolithique et Néolithique", "Histoire : Antiquité à Époque contemporaine"],
    exercise: { q: "Quelles sont les deux grandes phases de la Préhistoire ?", opts: ["Antiquité et Moyen Âge", "Paléolithique et Néolithique", "Moderne et contemporaine", "Aucune de ces réponses"], ans: 1, exp: "La Préhistoire se divise en Paléolithique (âge de la pierre taillée) et Néolithique (âge de la pierre polie).", method: "Repère les deux noms se terminant par « -lithique » (du grec lithos, la pierre)." },
    quiz: [{ q: "L'Histoire a notamment une fonction :", opts: ["Culinaire", "Civique", "Météorologique", "Sportive"], ans: 1, exp: "La fonction civique aide à former des citoyens conscients de leur passé commun." }],
  },
  {
    title: "Origines de l'Homme et sites préhistoriques (Palier 2)",
    content: "L'Afrique est considérée comme le berceau de l'humanité : c'est là qu'apparaissent les premiers représentants du genre Homo, de l'Australopithèque à l'Homo Habilis. Ces premiers hommes ont ensuite migré vers les autres continents, notamment par l'isthme de Suez et le détroit de Gibraltar.",
    example: "Des sites préhistoriques ont été retrouvés en Afrique australe, orientale, septentrionale et centrale, avec des vestiges témoignant de ces premiers modes de vie.",
    keyPoints: ["L'Afrique, berceau de l'humanité", "De l'Australopithèque à l'Homo Habilis", "Migration par Suez et Gibraltar", "Sites préhistoriques répartis sur tout le continent"],
    exercise: { q: "Par où les premiers hommes préhistoriques ont-ils notamment migré hors d'Afrique ?", opts: ["Par bateau uniquement", "Par l'isthme de Suez et le détroit de Gibraltar", "Par avion", "Ils ne sont jamais sortis d'Afrique"], ans: 1, exp: "Ces deux passages terrestres reliaient l'Afrique à l'Asie et à l'Europe.", method: "Pense à la géographie : quels points relient l'Afrique aux autres continents par voie de terre ?" },
    quiz: [{ q: "L'Afrique est considérée comme :", opts: ["Le berceau de l'humanité", "Un continent sans passé", "Une ile isolée", "Une région jamais peuplée"], ans: 0, exp: "Les plus anciens fossiles du genre Homo ont été trouvés en Afrique." }],
  },
  {
    title: "Sites et activités des Hommes préhistoriques au Gabon (Palier 3)",
    content: "Le Gabon possède plusieurs sites préhistoriques, comme Lopé et Ngolo pour le Paléolithique, ou Cap Estérias et Lalala pour le Néolithique. Les activités des hommes préhistoriques gabonais comprenaient la chasse, la pêche et la cueillette au Paléolithique, puis l'agriculture, l'élevage et l'art au Néolithique.",
    example: "Au Néolithique, les hommes préhistoriques du Gabon ont commencé à pratiquer l'agriculture en plus de la chasse et de la pêche, un tournant important dans leur mode de vie.",
    keyPoints: ["Sites paléolithiques : Lopé, Ngolo", "Sites néolithiques : Cap Estérias, Lalala", "Paléolithique : chasse, pêche, cueillette", "Néolithique : agriculture, élevage, art"],
    exercise: { q: "Quelle activité nouvelle apparaît au Néolithique par rapport au Paléolithique ?", opts: ["La chasse", "L'agriculture", "La pêche", "La cueillette"], ans: 1, exp: "L'agriculture marque une évolution majeure du mode de vie humain au Néolithique.", method: "Cherche l'activité qui suppose de rester au même endroit pour cultiver." },
    quiz: [{ q: "Lopé et Ngolo sont des sites gabonais du :", opts: ["Néolithique", "Paléolithique", "Moyen Âge", "XXe siècle"], ans: 1, exp: "Ce sont des sites préhistoriques du Paléolithique gabonais." }],
  },
  {
    title: "Le travail du fer au Gabon (Palier 4)",
    content: "La métallurgie du fer s'est diffusée en Afrique et au Gabon par les migrations et les échanges. Elle comprend plusieurs étapes : la recherche et l'extraction du minerai, puis sa fonte au haut fourneau ou dans des foyers, pour obtenir le métal utilisable.",
    example: "Les sites métallurgiques gabonais témoignent de cette maîtrise du fer, une compétence technique importante pour l'époque.",
    keyPoints: ["Diffusion du fer par migrations et échanges", "Extraction du minerai de fer", "Fonte par haut fourneau ou foyers", "Sites métallurgiques en Afrique centrale et au Gabon"],
    exercise: { q: "Quelle est la première étape pour obtenir du fer utilisable ?", opts: ["La fonte directe sans préparation", "La recherche et l'extraction du minerai", "La vente du minerai", "Le tissage"], ans: 1, exp: "Il faut d'abord trouver et extraire le minerai avant de pouvoir le transformer.", method: "Réfléchis à l'ordre logique : peut-on fondre un minerai qu'on n'a pas encore extrait ?" },
    quiz: [{ q: "La fonte du minerai de fer se faisait notamment grâce à :", opts: ["Un four à pain", "Un haut fourneau", "Un réfrigérateur", "Un moulin à eau"], ans: 1, exp: "Le haut fourneau permettait d'atteindre la température nécessaire à la fonte du fer." }],
  },
  {
    title: "Les conséquences du travail du fer (Palier 5)",
    content: "La maîtrise du fer a eu des conséquences politiques et militaires (rayonnement des royaumes, armées mieux équipées, expansion territoriale) mais aussi économiques et sociales (développement de l'agriculture, apparition de la monnaie en fer, naissance d'une classe de forgerons, sédentarisation des populations).",
    example: "La fabrication d'outils et d'armes en fer a permis à certains royaumes africains d'étendre leur territoire et leur influence.",
    keyPoints: ["Conséquences politiques : rayonnement, expansion", "Conséquences militaires : armées mieux équipées", "Conséquences économiques : agriculture, monnaie en fer", "Conséquences sociales : classe de forgerons, sédentarisation"],
    exercise: { q: "Quelle conséquence sociale est directement liée à la maîtrise du fer ?", opts: ["La disparition de l'agriculture", "La naissance d'une classe de forgerons", "L'abandon des villages", "La fin du commerce"], ans: 1, exp: "Les forgerons, maîtrisant une technique rare et précieuse, ont formé un groupe social à part.", method: "Cherche le métier directement créé par cette nouvelle compétence technique." },
    quiz: [{ q: "La maîtrise du fer a notamment permis :", opts: ["Une expansion territoriale grâce à de meilleures armes", "La disparition des royaumes", "L'arrêt de l'agriculture", "Rien de particulier"], ans: 0, exp: "De meilleures armes et outils ont favorisé l'expansion de certains royaumes." }],
  },
  {
    title: "La civilisation égyptienne (Palier 6)",
    content: "L'Égypte antique est l'une des premières grandes civilisations d'Afrique, organisée en plusieurs grandes périodes (Ancien Empire, Moyen Empire, Nouvel Empire, Basse Époque). Une dynastie noire, issue du royaume de Kush, a marqué son histoire (Piânkhy, Chabaka). Cette civilisation a rayonné scientifiquement (mathématiques, médecine, astronomie) et culturellement (religion, architecture, art).",
    example: "Les pyramides et les temples témoignent encore aujourd'hui du rayonnement architectural et scientifique de l'Égypte antique.",
    keyPoints: ["Grandes périodes de l'Égypte antique", "La dynastie noire issue de Kush", "Rayonnement scientifique : mathématiques, médecine", "Rayonnement culturel : religion, architecture, art"],
    exercise: { q: "D'où est issue la dynastie noire qui a marqué l'Égypte antique ?", opts: ["Du royaume de Kush", "De la Grèce antique", "De Rome", "De la Chine"], ans: 0, exp: "Le royaume de Kush, en Nubie, est à l'origine de cette dynastie noire d'Égypte.", method: "Ce royaume se situait au sud de l'Égypte, en Nubie." },
    quiz: [{ q: "L'Égypte antique a notamment rayonné dans le domaine :", opts: ["De l'informatique", "Des mathématiques", "De l'aviation", "Du cinéma"], ans: 1, exp: "Les mathématiques égyptiennes ont marqué durablement les sciences antiques." }],
  },
];
export function getV26_6e_histoire(): Subject {
  return makeSubject("histoire", "Histoire", "Landmark", "orange", "6e", "6e", v26_6e_histoire_topics);
}

const v26_5e_histoire_topics: TopicData[] = [
  {
    title: "Les peuples autochtones du Gabon (Palier 1)",
    content: "Les peuples autochtones du Gabon (Baka, Bakoya, Babongo…) étaient organisés en familles, clans, lignages et tribus, dirigés par un patriarche assisté d'un conseil des anciens. Leur économie reposait sur la cueillette, la chasse, la pêche et le troc, avec une riche organisation culturelle faite de rites, de croyances et de pharmacopée traditionnelle.",
    example: "Le conseil des anciens jouait un rôle central dans les décisions importantes de la communauté, sous l'autorité du patriarche.",
    keyPoints: ["Peuples autochtones : Baka, Bakoya, Babongo…", "Organisation : famille, clan, lignage, tribu", "Économie : cueillette, chasse, pêche, troc", "Pharmacopée et rites traditionnels"],
    exercise: { q: "Qui dirigeait traditionnellement une communauté autochtone, assisté du conseil des anciens ?", opts: ["Le patriarche", "Un roi élu", "Un gouverneur colonial", "Personne"], ans: 0, exp: "Le patriarche exerçait l'autorité, en s'appuyant sur les anciens pour les décisions importantes.", method: "Cherche le mot qui désigne le chef de famille ou de clan le plus âgé." },
    quiz: [{ q: "L'économie des peuples autochtones du Gabon reposait notamment sur :", opts: ["L'industrie lourde", "La cueillette, la chasse et le troc", "Le commerce maritime international", "L'agriculture intensive mécanisée"], ans: 1, exp: "Ces activités traditionnelles formaient la base de leur subsistance." }],
  },
  {
    title: "Les migrations et l'organisation Bantu (Palier 2)",
    content: "Les migrations bantu vers le territoire de l'actuel Gabon ont eu des causes naturelles, économiques et sociales, suivant des itinéraires depuis le lac Tchad. Les sociétés bantu étaient hiérarchisées (hommes libres, hommes de condition intermédiaire, esclaves) et organisées en royaumes, villages-états ou confédérations, avec une économie mêlant agriculture, artisanat, élevage et troc.",
    example: "Les migrations bantu ont suivi plusieurs itinéraires, notamment vers l'Ivindo puis vers l'Ogooué, à partir du lac Tchad.",
    keyPoints: ["Causes des migrations : naturelles, économiques, sociales", "Itinéraires depuis le lac Tchad", "Société hiérarchisée : hommes libres, condition intermédiaire, esclaves", "Organisation en royaumes, villages-états, confédérations"],
    exercise: { q: "D'où sont parties les migrations bantu vers le Gabon actuel ?", opts: ["Du lac Tchad", "De l'Égypte", "De l'Europe", "De l'océan Atlantique"], ans: 0, exp: "Les Bantu sont partis de la région du lac Tchad avant de migrer vers l'Afrique centrale.", method: "Le point de départ commun aux grandes migrations bantu se situe en Afrique centrale, près d'un grand lac." },
    quiz: [{ q: "La société bantu traditionnelle était :", opts: ["Totalement égalitaire", "Hiérarchisée", "Sans aucune organisation", "Dirigée uniquement par des étrangers"], ans: 1, exp: "Elle distinguait hommes libres, condition intermédiaire et esclaves." }],
  },
  {
    title: "La cohabitation entre peuples autochtones et Bantu (Palier 3)",
    content: "Autochtones et Bantu ont partagé les ressources naturelles (forêt, cours d'eau) et certaines valeurs communes comme l'hospitalité, la solidarité et le respect de l'environnement et des rites. Cette cohabitation, bien que parfois marquée par des tensions, a favorisé des échanges culturels durables.",
    example: "Le partage des produits de la chasse, de la pêche et de la cueillette illustre cette gestion commune des ressources naturelles entre les deux groupes.",
    keyPoints: ["Partage de la forêt et des cours d'eau", "Valeurs communes : hospitalité, solidarité", "Respect des rites et pratiques culturelles", "Échanges culturels entre les deux groupes"],
    exercise: { q: "Quelle valeur commune est mise en avant dans la cohabitation autochtones-Bantu ?", opts: ["L'hospitalité", "L'isolement total", "Le refus de tout échange", "La guerre permanente"], ans: 0, exp: "L'hospitalité et la solidarité faisaient partie des valeurs partagées entre les deux groupes.", method: "Pense aux valeurs qui favorisent une bonne cohabitation entre communautés voisines." },
    quiz: [{ q: "Les autochtones et les Bantu partageaient notamment :", opts: ["La technologie moderne", "Les ressources de la forêt et des cours d'eau", "Une monnaie unique mondiale", "Aucune ressource"], ans: 1, exp: "La gestion commune de la forêt et de l'eau était centrale dans leur cohabitation." }],
  },
  {
    title: "Les conséquences de la cohabitation (Palier 4)",
    content: "Cette cohabitation a eu des conséquences sociales et politiques (brassage des populations, mais aussi assimilation et désorganisation de la structure sociale des peuples autochtones) ainsi que culturelles et cultuelles (perte progressive de certains éléments de l'identité autochtone, tout en conservant des cultes ancestraux communs).",
    example: "Le brassage entre populations a favorisé des échanges, mais a aussi parfois entraîné une désorganisation des structures sociales autochtones traditionnelles.",
    keyPoints: ["Brassage des populations", "Assimilation des peuples autochtones", "Désorganisation partielle des structures sociales", "Perte progressive de certains traits culturels autochtones"],
    exercise: { q: "Quelle conséquence sociale a pu résulter de cette cohabitation ?", opts: ["Le renforcement total des structures autochtones", "L'assimilation des peuples autochtones", "La disparition des Bantu", "Aucune conséquence"], ans: 1, exp: "L'assimilation a progressivement modifié l'organisation sociale des peuples autochtones.", method: "Cherche le processus par lequel un groupe adopte progressivement la culture d'un autre." },
    quiz: [{ q: "Le brassage entre autochtones et Bantu a notamment entraîné :", opts: ["Une désorganisation sociale chez les autochtones", "Aucun changement", "La disparition immédiate des deux groupes", "Un isolement total"], ans: 0, exp: "Le contact prolongé a modifié l'organisation sociale traditionnelle des autochtones." }],
  },
  {
    title: "Les royaumes de Loango et Téké (Palier 5)",
    content: "Les royaumes de Loango et Téké étaient organisés politiquement (mode de succession, administration), économiquement (troc, agriculture, artisanat, élevage) et culturellement (rites et croyances). Ils illustrent la richesse de l'organisation politique précoloniale en Afrique centrale.",
    example: "Le royaume de Loango disposait d'une administration structurée avec un mode de succession bien défini pour désigner ses dirigeants.",
    keyPoints: ["Royaume de Loango : organisation sociale, politique, économique", "Royaume Téké : structure comparable", "Économie basée sur troc, agriculture, artisanat", "Organisation culturelle : rites et croyances"],
    exercise: { q: "Que désigne le mode de succession dans un royaume comme Loango ?", opts: ["La manière de choisir le prochain dirigeant", "Le type de vêtement porté", "La langue parlée", "Le climat de la région"], ans: 0, exp: "Le mode de succession détermine comment le pouvoir se transmet d'un dirigeant à l'autre.", method: "Le mot « succession » évoque ce qui vient après, donc la transmission du pouvoir." },
    quiz: [{ q: "Les royaumes de Loango et Téké se situaient en :", opts: ["Afrique centrale", "Amérique du Sud", "Europe de l'Est", "Asie du Sud-Est"], ans: 0, exp: "Ces royaumes précoloniaux se trouvaient dans la région de l'actuelle Afrique centrale." }],
  },
  {
    title: "Le Christianisme et l'Islam (Palier 6)",
    content: "Le Christianisme et l'Islam sont deux religions monothéistes nées au Proche-Orient avant de se diffuser en Afrique, en Europe, en Amérique et en Asie. Toutes deux promeuvent des valeurs comme l'amour et la tolérance, tout en ayant chacune leurs propres fondements et leur propre histoire de diffusion.",
    example: "L'expansion de l'Islam et du Christianisme en Afrique s'est faite par différentes voies : commerce, migrations, et parfois conquêtes.",
    keyPoints: ["Deux religions monothéistes", "Naissance au Proche-Orient", "Diffusion en Afrique, Europe, Amérique, Asie", "Valeurs communes : amour, tolérance"],
    exercise: { q: "Que signifie le terme « monothéiste » appliqué au Christianisme et à l'Islam ?", opts: ["La croyance en plusieurs dieux", "La croyance en un seul dieu", "L'absence de croyance religieuse", "La croyance aux esprits de la nature uniquement"], ans: 1, exp: "Mono- signifie « un seul » : ces religions croient en un dieu unique.", method: "Décompose le mot : « mono » (un) + « théiste » (relatif à dieu)." },
    quiz: [{ q: "Le Christianisme et l'Islam se sont diffusés notamment en :", opts: ["Afrique", "Nulle part ailleurs qu'au Proche-Orient", "Uniquement en Antarctique", "Sur la Lune"], ans: 0, exp: "Ces deux religions se sont largement répandues en Afrique, entre autres continents." }],
  },
];
export function getV26_5e_histoire(): Subject {
  return makeSubject("histoire", "Histoire", "Landmark", "orange", "5e", "5e", v26_5e_histoire_topics);
}

const v26_4e_histoire_topics: TopicData[] = [
  {
    title: "La présence européenne au Gabon du XVe au XIXe siècle (Palier 1)",
    content: "Les voyages d'exploration européens au Gabon ont eu des causes scientifiques, politico-économiques et humanitaires, menés notamment par des navigateurs portugais. Par la suite, les Européens se sont installés grâce à des traités d'occupation du territoire (dans l'estuaire du Como puis à l'intérieur du pays) et au développement du commerce (établissements côtiers, factoreries).",
    example: "Les traités d'occupation signés dans l'estuaire du Como ont marqué une étape clé de l'installation européenne sur le territoire gabonais.",
    keyPoints: ["Causes des voyages d'exploration : scientifiques, économiques, humanitaires", "Navigateurs portugais parmi les premiers explorateurs", "Traités d'occupation du territoire", "Développement du commerce européen (factoreries)"],
    exercise: { q: "Quel type de document a permis aux Européens de s'installer sur le territoire gabonais ?", opts: ["Un traité d'occupation", "Un simple courrier", "Une carte postale", "Aucun document n'était nécessaire"], ans: 0, exp: "Les traités d'occupation formalisaient l'installation européenne avec les autorités locales.", method: "Cherche le type d'accord officiel signé entre deux parties pour un territoire." },
    quiz: [{ q: "Les premiers navigateurs européens à explorer le Gabon étaient notamment :", opts: ["Portugais", "Russes", "Japonais", "Australiens"], ans: 0, exp: "Les navigateurs portugais comptent parmi les premiers explorateurs européens de la côte gabonaise." }],
  },
  {
    title: "La traite des Noirs (Palier 2)",
    content: "La traite négrière avait des causes politiques et économiques, et se déroulait notamment via la traite atlantique (Europe-Afrique-Amérique). Elle a eu de lourdes conséquences sociales et économiques dans le monde et au Gabon. Des résistances se sont organisées (comme celle de Gaspar Yanga), menant progressivement à son abolition par des décrets successifs (notamment 1833 et 1848).",
    example: "Le décret d'avril 1848 a marqué l'abolition de l'esclavage dans les colonies françaises, après des décennies de luttes et de résistances.",
    keyPoints: ["Causes politiques et économiques de la traite", "La traite atlantique : Europe-Afrique-Amérique", "Résistances à l'esclavage (ex. Gaspar Yanga)", "Abolition par décrets (1833, 1848)"],
    exercise: { q: "Que représente le décret d'avril 1848 ?", opts: ["Le début de la traite négrière", "L'abolition de l'esclavage dans les colonies françaises", "La construction d'un port", "Un traité de paix européen"], ans: 1, exp: "Ce décret a aboli l'esclavage dans les colonies françaises.", method: "Associe la date 1848 à un grand tournant historique dans la lutte contre l'esclavage." },
    quiz: [{ q: "La traite atlantique reliait principalement :", opts: ["L'Europe, l'Afrique et l'Amérique", "L'Asie et l'Australie", "Le Gabon et la Chine uniquement", "Aucun continent en particulier"], ans: 0, exp: "Ce triangle commercial reliait ces trois continents autour du commerce des esclaves." }],
  },
  {
    title: "La formation de la colonie du Gabon (Palier 3)",
    content: "L'administration coloniale gabonaise s'est mise en place progressivement, d'abord par délégation de pouvoir et administration militaire, puis intégrée dans le vaste ensemble « Gabon-Congo » (1888) et l'Afrique Équatoriale Française (1910), le Gabon obtenant ensuite une autonomie administrative au sein de l'AEF. L'organisation territoriale s'est structurée autour de centres administratifs sur l'Ogooué et le Como.",
    example: "L'Afrique Équatoriale Française (AEF), créée en 1910, regroupait plusieurs colonies dont le Gabon sous une administration commune.",
    keyPoints: ["Administration militaire puis civile", "Ensemble « Gabon-Congo » (1888)", "Afrique Équatoriale Française (1910)", "Organisation territoriale autour de l'Ogooué et du Como"],
    exercise: { q: "Que signifie le sigle AEF ?", opts: ["Afrique Équatoriale Française", "Association des États Francophones", "Alliance Économique Française", "Aucune de ces réponses"], ans: 0, exp: "L'AEF regroupait plusieurs colonies françaises d'Afrique centrale, dont le Gabon.", method: "Décompose le sigle lettre par lettre : Afrique, Équatoriale, Française." },
    quiz: [{ q: "L'ensemble « Gabon-Congo » a été créé par un décret de :", opts: ["1888", "1960", "1789", "2000"], ans: 0, exp: "Le décret du 11 décembre 1888 a créé cet ensemble colonial." }],
  },
  {
    title: "Les conditions de vie sous le système de l'indigénat (Palier 4)",
    content: "Le système de l'indigénat imposait aux populations locales un code strict (règles et sanctions) qui a détérioré leurs conditions de vie. Il a eu des conséquences sociales (suppression de la chefferie traditionnelle) et économiques (renforcement de l'emprise économique coloniale, sociétés monopolistes, régime concessionnaire).",
    example: "La suppression de la chefferie traditionnelle a profondément modifié l'organisation sociale des populations locales sous l'indigénat.",
    keyPoints: ["Code de l'indigénat : règles et sanctions", "Suppression de la chefferie traditionnelle", "Sociétés monopolistes et régime concessionnaire", "Détérioration des conditions de vie locales"],
    exercise: { q: "Quelle conséquence sociale directe a eu le système de l'indigénat ?", opts: ["Le renforcement de la chefferie traditionnelle", "La suppression de la chefferie traditionnelle", "L'enrichissement des populations locales", "Aucune conséquence"], ans: 1, exp: "L'indigénat a affaibli puis supprimé l'autorité traditionnelle des chefferies locales.", method: "Cherche ce qui a été retiré aux populations locales par ce système colonial." },
    quiz: [{ q: "Le régime concessionnaire faisait partie de l'impact :", opts: ["Économique de l'indigénat", "Sportif de l'indigénat", "Culinaire de l'indigénat", "Musical de l'indigénat"], ans: 0, exp: "Le régime concessionnaire renforçait l'emprise économique coloniale sur le territoire." }],
  },
  {
    title: "Les débuts du refus de la domination coloniale au Gabon (Palier 5)",
    content: "Dès 1839, des populations gabonaises se sont opposées aux traités coloniaux (notamment en pays mpongwè, orungu et enenga) par la négociation, la prise d'otages, puis des résistances armées. Le soulèvement de 1879-1880 contre la cherté des marchandises a marqué une étape importante avant l'apaisement progressif par la négociation.",
    example: "Le soulèvement de 1879-1880 contre la cherté des marchandises illustre la contestation directe de l'autorité coloniale par la population.",
    keyPoints: ["Opposition aux traités coloniaux dès 1839", "Stratégies : négociation, prise d'otages, résistance armée", "Soulèvement de 1879-1880", "Apaisement progressif par la négociation"],
    exercise: { q: "Contre quoi s'est notamment révoltée la population lors du soulèvement de 1879-1880 ?", opts: ["La cherté des marchandises", "Un manque de pluie", "Une épidémie", "Un conflit entre villages voisins"], ans: 0, exp: "La cherté des marchandises imposées par les colons a déclenché ce soulèvement.", method: "Le mot « cherté » indique un problème lié aux prix." },
    quiz: [{ q: "Les premières formes de résistance gabonaise incluaient notamment :", opts: ["La négociation et la prise d'otages", "L'acceptation immédiate sans contestation", "Le silence total", "L'émigration collective"], ans: 0, exp: "Ces stratégies ont été utilisées pour contester la domination coloniale naissante." }],
  },
  {
    title: "L'indépendance du Gabon et les droits (Palier 6)",
    content: "Le Gabon devient indépendant le 17 août 1960. Cette date marque la souveraineté de l'État gabonais après la période coloniale. L'indépendance s'inscrit dans la décolonisation de l'Afrique. Les droits de la personne et les institutions républicaines (Constitution, lois, justice) structurent la vie civique. Connaître cette histoire aide l'élève gabonais à comprendre son pays et ses symboles (drapeau, hymne La Concorde, fête nationale).",
    example: "Le 17 août, fête nationale : on célèbre l'indépendance et l'unité du Gabon.",
    keyPoints: ["17 août 1960", "Souveraineté", "Décolonisation", "Institutions", "Fête nationale"],
    exercise: { q: "Date de l'indépendance du Gabon ?", opts: ["14 juillet 1789", "17 août 1960", "1er janvier 2000", "11 novembre 1918"], ans: 1, exp: "17 août 1960.", method: "Fête nationale gabonaise." },
    quiz: [
      { q: "Capitale du Gabon :", opts: ["Port-Gentil", "Libreville", "Oyem", "Franceville"], ans: 1, exp: "Libreville." },
      { q: "L'indépendance du Gabon s'inscrit dans :", opts: ["la Préhistoire", "la décolonisation africaine", "uniquement l'histoire de l'Asie", "l'Empire romain"], ans: 1, exp: "Années 1960 en Afrique." }],
  },
];
export function getV26_4e_histoire(): Subject {
  return makeSubject("histoire", "Histoire", "Landmark", "orange", "4e", "4e", v26_4e_histoire_topics);
}

const v26_3e_histoire_topics: TopicData[] = [
  {
    title: "Les mouvements de résistance du peuple gabonais (Palier 1)",
    content: "Dès le XIXe siècle, plusieurs régions du Gabon ont résisté à la domination coloniale (Estuaire, Woleu-Ntem, Moyen-Ogooué, Ngounié, Nyanga, Haut-Ogooué). Dans l'entre-deux-guerres, la lutte politique s'est structurée avec des organisations affiliées à la métropole puis des organisations clandestines, comme le rassemblement des chefs de l'Estuaire autour de Léon Mba en 1931.",
    example: "Léon Mba a rassemblé les chefs de l'Estuaire en 1931 au sein d'une organisation politique qui s'opposait discrètement à l'administration coloniale.",
    keyPoints: ["Résistances régionales dès le XIXe siècle", "Organisations politiques affiliées à la métropole", "Organisations politiques clandestines", "Léon Mba et le rassemblement des chefs de l'Estuaire (1931)"],
    exercise: { q: "Qui a rassemblé les chefs de l'Estuaire autour d'une organisation politique en 1931 ?", opts: ["Léon Mba", "Omar Bongo", "Un gouverneur français", "Personne"], ans: 0, exp: "Léon Mba a joué un rôle clé dans cette organisation politique clandestine.", method: "Cette figure deviendra plus tard le premier président du Gabon indépendant." },
    quiz: [{ q: "Les résistances gabonaises du XIXe-XXe siècle se sont produites notamment dans :", opts: ["Le Woleu-Ntem et la Ngounié", "Uniquement à Paris", "Sur la lune", "En Amérique du Sud"], ans: 0, exp: "Plusieurs régions gabonaises ont connu des mouvements de résistance à la colonisation." }],
  },
  {
    title: "Le Gabon dans la Grande Guerre (Palier 2)",
    content: "La Première Guerre mondiale (1914-1918) a eu des causes multiples et un lourd bilan humain, politique et économique. Le Gabon y a contribué par une mobilisation humaine et économique, avec des opérations militaires liées au traité d'Algésiras et au coup d'Agadir, entraînant des conséquences humaines, économiques et politiques sur le territoire.",
    example: "La mobilisation économique du Gabon durant la Première Guerre mondiale a mis à contribution les ressources locales pour l'effort de guerre métropolitain.",
    keyPoints: ["Première Guerre mondiale : 1914-1918", "Mobilisation humaine et économique du Gabon", "Lien avec le traité d'Algésiras et le coup d'Agadir", "Conséquences humaines, économiques, politiques"],
    exercise: { q: "Quelles années couvre la Première Guerre mondiale ?", opts: ["1914-1918", "1939-1945", "1900-1910", "1960-1968"], ans: 0, exp: "La Première Guerre mondiale s'est déroulée de 1914 à 1918.", method: "C'est la guerre qui précède la Seconde Guerre mondiale (1939-1945)." },
    quiz: [{ q: "Le Gabon a contribué à la Première Guerre mondiale par :", opts: ["Une mobilisation humaine et économique", "Aucune participation", "L'envoi de vaisseaux spatiaux", "Un refus total de coopérer"], ans: 0, exp: "Le Gabon, colonie française, a été mobilisé humainement et économiquement pour l'effort de guerre." }],
  },
  {
    title: "Le Gabon dans la Seconde Guerre mondiale (Palier 3)",
    content: "La Seconde Guerre mondiale (1939-1945) a également mobilisé le Gabon humainement et économiquement, marqué par la rivalité entre Pétainistes et Gaullistes et des opérations militaires sur le territoire gabonais, avec des conséquences humaines, économiques et politiques importantes.",
    example: "La rivalité entre partisans de Pétain et partisans de De Gaulle a entraîné de véritables opérations militaires sur le sol gabonais durant cette période.",
    keyPoints: ["Seconde Guerre mondiale : 1939-1945", "Mobilisation humaine et économique du Gabon", "Rivalité Pétainistes / Gaullistes", "Opérations militaires sur le territoire gabonais"],
    exercise: { q: "Quelle rivalité politico-militaire a touché le Gabon durant la Seconde Guerre mondiale ?", opts: ["Pétainistes contre Gaullistes", "Romains contre Grecs", "Nord contre Sud américain", "Aucune rivalité"], ans: 0, exp: "Cette rivalité a entraîné des affrontements sur le territoire gabonais même.", method: "Pense aux deux camps français qui s'opposaient pendant l'Occupation." },
    quiz: [{ q: "La Seconde Guerre mondiale s'est déroulée de :", opts: ["1939 à 1945", "1914 à 1918", "1960 à 1968", "1789 à 1799"], ans: 0, exp: "Ces dates marquent le début et la fin de la Seconde Guerre mondiale." }],
  },
  {
    title: "Le processus d'émancipation des peuples en Afrique noire (Palier 4)",
    content: "À partir de 1940, un réveil des consciences et des mouvements nationalistes se développent en Afrique noire, soutenus par le rôle de l'ONU et de l'OUA. Au Gabon, ce processus passe par la conférence de Brazzaville (1944), le passage de l'Union française à la Communauté française, jusqu'à la marche vers l'indépendance.",
    example: "La conférence de Brazzaville de janvier 1944 a marqué une étape importante vers l'évolution du statut politique des colonies françaises d'Afrique.",
    keyPoints: ["Réveil des consciences dès 1940", "Rôle de l'ONU et de l'OUA", "Conférence de Brazzaville (1944)", "Marche vers l'indépendance du Gabon"],
    exercise: { q: "Quelle conférence de 1944 a marqué une étape vers l'émancipation des colonies ?", opts: ["La conférence de Brazzaville", "La conférence de Yalta", "La conférence de Berlin", "Aucune conférence"], ans: 0, exp: "La conférence de Brazzaville a initié une évolution du statut des colonies françaises.", method: "Cette conférence porte le nom de la capitale d'un pays d'Afrique centrale." },
    quiz: [{ q: "Quelles organisations ont joué un rôle dans l'émancipation des peuples africains ?", opts: ["L'ONU et l'OUA", "Aucune organisation", "Uniquement des entreprises privées", "Des clubs sportifs"], ans: 0, exp: "L'ONU et l'Organisation de l'Unité Africaine ont soutenu ce processus." }],
  },
  {
    title: "Le Gabon de 1960 à 1968 (Palier 5)",
    content: "La Ière République gabonaise (1960-1961) se caractérise par l'adoption d'une Constitution, un système multipartite et une politique économique naissante, avant de rencontrer des difficultés menant à sa fin. La IIe République (1961-1968) présente ses propres caractéristiques politiques et économiques, avec ses propres difficultés et sa fin.",
    example: "L'adoption de la Constitution du Gabon indépendant a marqué le début de la Ière République en 1960.",
    keyPoints: ["Ière République (1960-1961) : Constitution, multipartisme", "Difficultés et fin de la Ière République", "IIe République (1961-1968)", "Caractéristiques politiques et économiques propres"],
    exercise: { q: "Que marque l'année 1960 dans l'histoire du Gabon ?", opts: ["Le début de la Ière République (indépendance)", "La fin de la colonisation portugaise", "Le début de la Seconde Guerre mondiale", "Aucun événement particulier"], ans: 0, exp: "1960 marque l'indépendance du Gabon et le début de la Ière République.", method: "C'est l'année où le Gabon devient un État indépendant." },
    quiz: [{ q: "La Ière République gabonaise s'étend de :", opts: ["1960 à 1961", "1789 à 1799", "1914 à 1918", "2000 à 2010"], ans: 0, exp: "La Ière République est une période courte, de 1960 à 1961." }],
  },
  {
    title: "Le Gabon de 1968 à 2024 (Palier 6)",
    content: "La IIIe République (1968-1991) se caractérise par la centralisation du pouvoir et le monopartisme, avant de connaître des difficultés menant à la conférence nationale de 1990. La IVe République (1991-2024) présente ses propres caractéristiques politiques et économiques, avec ses crises et son évolution jusqu'à 2024.",
    example: "La conférence nationale de 1990 a marqué un tournant important, ouvrant la voie à une nouvelle étape politique pour le Gabon.",
    keyPoints: ["IIIe République (1968-1991) : centralisation, monopartisme", "Conférence nationale de 1990", "IVe République (1991-2024)", "Crises politiques, économiques et sociales"],
    exercise: { q: "Quel événement de 1990 a marqué la fin de la IIIe République gabonaise ?", opts: ["La conférence nationale", "Une guerre mondiale", "Un traité européen", "Aucun événement"], ans: 0, exp: "La conférence nationale de 1990 a marqué un tournant politique majeur pour le Gabon.", method: "Cherche l'événement politique national qui a précédé le passage à la IVe République." },
    quiz: [{ q: "La IIIe République gabonaise se caractérise notamment par :", opts: ["Le monopartisme", "Le multipartisme intégral dès le début", "L'absence totale de pouvoir central", "Une monarchie"], ans: 0, exp: "Le monopartisme et la centralisation du pouvoir caractérisent cette période." }],
  },
];
export function getV26_3e_histoire(): Subject {
  return makeSubject("histoire", "Histoire", "Landmark", "orange", "3e", "3e", v26_3e_histoire_topics);
}

const v26_6e_geographie_topics: TopicData[] = [
  {
    title: "Introduction à la notion de Géographie (Palier 1)",
    content: "La Géographie comprend plusieurs branches : la géographie physique, la géographie humaine et économique, et la géographie régionale. Le géographe utilise des outils (cartes, globe, boussole, GPS, photographies aériennes, données statistiques) et suit une démarche précise : localisation, observation, description, explication, comparaison.",
    example: "Un géographe qui étudie une ville commence par la localiser sur une carte, puis observe et décrit son organisation avant d'en expliquer les caractéristiques.",
    keyPoints: ["Branches : physique, humaine, régionale", "Outils : carte, GPS, boussole, données statistiques", "Démarche : localiser, observer, décrire, expliquer, comparer", "Fonctions civique et sociétale de la géographie"],
    exercise: { q: "Quelle est la première étape de la démarche du géographe ?", opts: ["La comparaison", "La localisation", "L'explication", "La conclusion"], ans: 1, exp: "On localise d'abord un lieu avant de pouvoir l'observer et l'étudier.", method: "Sans savoir où se trouve un lieu, peut-on l'observer précisément ?" },
    quiz: [{ q: "Le GPS est un exemple d'outil utilisé en :", opts: ["Géographie", "Cuisine", "Musique", "Sport uniquement"], ans: 0, exp: "Le GPS permet de se localiser précisément, un outil essentiel du géographe." }],
  },
  {
    title: "La Terre dans le système solaire (Palier 2)",
    content: "La Terre est une planète du système solaire, caractérisée par son rayon, son diamètre et sa circonférence. Elle peut être représentée de façon sphérique (globe) ou plane (carte, planisphère). Les coordonnées géographiques (longitude et latitude) permettent de localiser précisément un point à sa surface.",
    example: "Grâce aux longitudes et latitudes, on peut donner la position exacte de n'importe quelle ville sur Terre, comme Libreville.",
    keyPoints: ["La Terre : une planète du système solaire", "Représentations : globe (sphérique) et carte (plane)", "Longitude et latitude : coordonnées géographiques", "Calcul de distances grâce aux parallèles et méridiens"],
    exercise: { q: "Quelles coordonnées permettent de localiser un point précis sur Terre ?", opts: ["La longitude et la latitude", "La couleur et la taille", "Le poids et la vitesse", "Aucune coordonnée n'est nécessaire"], ans: 0, exp: "Longitude et latitude forment les coordonnées géographiques d'un point.", method: "Ce sont les deux valeurs données par un GPS pour indiquer une position." },
    quiz: [{ q: "Une représentation sphérique de la Terre est appelée :", opts: ["Un globe", "Une carte plane", "Un planisphère uniquement", "Un atlas"], ans: 0, exp: "Le globe représente la Terre sous sa forme sphérique réelle." }],
  },
  {
    title: "Les mouvements de la Terre et leurs conséquences (Palier 3)",
    content: "La Terre effectue un mouvement de rotation sur elle-même (24h), à l'origine de la succession du jour et de la nuit, et un mouvement de révolution autour du Soleil (environ 365 jours), à l'origine de la succession des saisons, des équinoxes et des solstices.",
    example: "C'est grâce à la rotation de la Terre que le jour succède à la nuit, tandis que sa révolution autour du Soleil explique le changement des saisons.",
    keyPoints: ["Rotation : jour/nuit", "Révolution : saisons", "Équinoxes et solstices liés à la révolution", "Rythme de nos activités quotidiennes lié à ces mouvements"],
    exercise: { q: "Quel mouvement de la Terre explique la succession du jour et de la nuit ?", opts: ["La rotation", "La révolution", "Aucun mouvement", "Le vent"], ans: 0, exp: "La rotation de la Terre sur elle-même, en 24 heures, provoque l'alternance jour/nuit.", method: "Pense au mouvement qui se produit en une seule journée." },
    quiz: [{ q: "La succession des saisons est due au mouvement de :", opts: ["Révolution", "Rotation uniquement", "Aucun mouvement", "La Lune"], ans: 0, exp: "La révolution de la Terre autour du Soleil, en un an, explique les saisons." }],
  },
  {
    title: "Les grands ensembles orohydrographiques du Gabon (Palier 4)",
    content: "Le relief du Gabon comprend des massifs montagneux, des plateaux et des plaines. Son réseau hydrographique est riche : fleuves, rivières, lacs et lagunes qui influencent fortement le mode de vie des populations et l'organisation du territoire.",
    example: "L'Ogooué, principal fleuve du Gabon, structure une grande partie de l'organisation du territoire et des activités humaines dans le pays.",
    keyPoints: ["Relief : massifs montagneux, plateaux, plaines", "Hydrographie : fleuves, rivières, lacs, lagunes", "Lien entre relief/hydrographie et milieu de vie", "Importance pour l'organisation du territoire"],
    exercise: { q: "Quels éléments composent le réseau hydrographique du Gabon ?", opts: ["Fleuves, rivières, lacs et lagunes", "Uniquement des déserts", "Des volcans en activité", "Aucun cours d'eau"], ans: 0, exp: "Le Gabon possède un réseau hydrographique dense et varié.", method: "Le préfixe « hydro » renvoie à l'eau : cherche les éléments liés à l'eau." },
    quiz: [{ q: "Le relief du Gabon comprend notamment :", opts: ["Des plateaux et des plaines", "Uniquement des déserts de sable", "Des glaciers", "Aucun relief particulier"], ans: 0, exp: "Massifs montagneux, plateaux et plaines composent le relief gabonais." }],
  },
  {
    title: "Les grands ensembles bioclimatiques du Gabon (Palier 5)",
    content: "Le Gabon connaît plusieurs régions climatiques (climat équatorial pur, équatorial de transition, tropical) associées à différents types de végétation (forêt ombrophile, savanes, mangrove) et de sols (argileux, ferralitiques, sablonneux), qui influencent directement le milieu de vie des populations.",
    example: "La forêt ombrophile, caractéristique du climat équatorial, couvre une grande partie du territoire gabonais et abrite une biodiversité exceptionnelle.",
    keyPoints: ["Climats : équatorial pur, transition, tropical", "Végétation : forêt ombrophile, savanes, mangrove", "Sols : argileux, ferralitiques, sablonneux", "Lien avec le milieu de vie des populations"],
    exercise: { q: "Quel type de végétation domine dans le climat équatorial gabonais ?", opts: ["La forêt ombrophile", "Le désert de sable", "La toundra", "Les glaciers"], ans: 0, exp: "La forêt ombrophile (forêt dense humide) est typique du climat équatorial.", method: "« Ombrophile » signifie qui aime l'ombre et l'humidité, comme en climat équatorial." },
    quiz: [{ q: "Parmi les types de sols du Gabon, on trouve notamment les sols :", opts: ["Ferralitiques", "Volcaniques glacés", "De lave uniquement", "Aucun sol particulier"], ans: 0, exp: "Les sols ferralitiques font partie des sols caractéristiques du Gabon." }],
  },
  {
    title: "Les ressources naturelles du Gabon (Palier 6)",
    content: "Le Gabon dispose de ressources du sol (bois, produits ligneux et non ligneux), du sous-sol (manganèse, fer, or) et énergétiques (pétrole, gaz), ainsi que de ressources marines (poissons, fruits de mer, ressources minérales). Ces ressources sont essentielles au développement économique du pays.",
    example: "Le manganèse, extrait du sous-sol gabonais, constitue l'une des principales ressources minières exportées par le pays.",
    keyPoints: ["Ressources du sol : bois et produits ligneux", "Ressources du sous-sol : manganèse, fer, or", "Ressources énergétiques : pétrole, gaz", "Ressources marines : poissons, fruits de mer"],
    exercise: { q: "Quelle ressource minière est particulièrement associée au sous-sol gabonais ?", opts: ["Le manganèse", "Le charbon uniquement", "Le diamant uniquement", "Aucune ressource minière"], ans: 0, exp: "Le manganèse est l'une des ressources minières majeures du Gabon.", method: "C'est un métal gris souvent cité parmi les exportations minières du pays." },
    quiz: [{ q: "Le pétrole et le gaz font partie des ressources :", opts: ["Énergétiques", "Marines uniquement", "Culturelles", "Alimentaires uniquement"], ans: 0, exp: "Le pétrole et le gaz sont des ressources énergétiques importantes du sous-sol gabonais." }],
  },
];
export function getV26_6e_geographie(): Subject {
  return makeSubject("geographie", "Géographie", "Map", "teal", "6e", "6e", v26_6e_geographie_topics);
}

const v26_5e_geographie_topics: TopicData[] = [
  {
    title: "La population gabonaise (Palier 1)",
    content: "La population gabonaise est inégalement répartie sur le territoire, selon des facteurs naturels, historiques et économiques. Son dynamisme démographique se mesure par des indicateurs comme le taux de natalité, le taux de mortalité, le solde naturel et le solde migratoire, ainsi que par les mouvements de population (migrations nationales et internationales).",
    example: "Les régions côtières et urbaines du Gabon sont généralement plus densément peuplées que certaines zones rurales de l'intérieur du pays.",
    keyPoints: ["Répartition inégale de la population", "Facteurs : naturels, historiques, économiques", "Indicateurs démographiques : natalité, mortalité, solde naturel", "Migrations nationales et internationales"],
    exercise: { q: "Quel indicateur démographique mesure la différence entre naissances et décès ?", opts: ["Le solde naturel", "Le solde migratoire", "Le PIB", "La superficie"], ans: 0, exp: "Le solde naturel correspond à la différence entre le nombre de naissances et de décès.", method: "Le mot « naturel » ici s'oppose à « migratoire » : pense aux naissances et décès, pas aux déplacements." },
    quiz: [{ q: "La répartition de la population gabonaise sur le territoire est :", opts: ["Inégale", "Parfaitement égale partout", "Impossible à mesurer", "Sans aucun facteur explicatif"], ans: 0, exp: "Certaines régions sont plus peuplées que d'autres, pour diverses raisons." }],
  },
  {
    title: "L'organisation de l'espace rural (Palier 2)",
    content: "En milieu rural gabonais, on distingue différentes formes d'habitat (linéaire dispersé ou groupé) et différents types d'habitations (huttes, cabanes, cases, habitat moderne). Les activités y sont à la fois sociales (cérémonies, rites) et économiques (élevage, agriculture, artisanat, pêche, commerce).",
    example: "Les cérémonies traditionnelles comme les rites initiatiques ou les funérailles occupent une place importante dans la vie sociale des villages gabonais.",
    keyPoints: ["Formes d'habitat : linéaire dispersé, linéaire groupé", "Types d'habitat : huttes, cases, habitat moderne", "Activités sociales : cérémonies, rites", "Activités économiques : agriculture, élevage, artisanat"],
    exercise: { q: "Quelle activité économique est typique du milieu rural gabonais ?", opts: ["L'agriculture", "La finance internationale", "L'aérospatiale", "Le tourisme spatial"], ans: 0, exp: "L'agriculture, avec l'élevage et l'artisanat, est une activité centrale en milieu rural.", method: "Pense aux activités traditionnelles liées à la terre et à la subsistance." },
    quiz: [{ q: "L'habitat linéaire peut être :", opts: ["Dispersé ou groupé", "Uniquement souterrain", "Toujours en hauteur", "Interdit au Gabon"], ans: 0, exp: "On distingue l'habitat linéaire dispersé et l'habitat linéaire groupé." }],
  },
  {
    title: "Les problèmes du milieu rural (Palier 3)",
    content: "Le milieu rural gabonais fait face à des problèmes structurels (insuffisance de routes, écoles, dispensaires, eau, électricité) et à des problèmes conjoncturels (pénuries alimentaires ou de médicaments, conflits homme-faune, exode rural), qui fragilisent son développement.",
    example: "Le manque de routes praticables complique l'accès de certains villages aux écoles et aux centres de santé, un problème structurel majeur.",
    keyPoints: ["Problèmes structurels : infrastructures insuffisantes", "Problèmes conjoncturels : pénuries, conflits homme-faune", "Exode rural vers les villes", "Impact sur le développement du milieu rural"],
    exercise: { q: "L'insuffisance de routes et d'écoles est un problème :", opts: ["Structurel", "Conjoncturel", "Climatique uniquement", "Sans importance"], ans: 0, exp: "Les infrastructures de base relèvent des problèmes structurels du milieu rural.", method: "« Structurel » renvoie à ce qui est durable et lié aux infrastructures de base." },
    quiz: [{ q: "L'exode rural désigne :", opts: ["Le départ des habitants des campagnes vers les villes", "L'arrivée de nouveaux habitants dans les villages", "Une fête traditionnelle", "Un type de culture agricole"], ans: 0, exp: "L'exode rural est le déplacement des populations des campagnes vers les villes." }],
  },
  {
    title: "L'organisation de l'espace urbain (Palier 4)",
    content: "La ville gabonaise se caractérise par différents types d'habitat (quartier résidentiel, bidonville) et différents plans (damier, circulaire), remplissant des fonctions politique, administrative, économique et culturelle. On y trouve des activités sociales (coopératives, loisirs) et économiques (commerce, agriculture périurbaine, industrie, services).",
    example: "Libreville, en tant que capitale, cumule des fonctions politique, administrative et économique importantes pour tout le pays.",
    keyPoints: ["Types d'habitat urbain : résidentiel, bidonville", "Plans de ville : damier, circulaire", "Fonctions : politique, administrative, économique, culturelle", "Activités économiques urbaines : commerce, industrie, services"],
    exercise: { q: "Quelle fonction urbaine concerne le gouvernement et les institutions d'un pays ?", opts: ["La fonction politique", "La fonction sportive", "La fonction agricole", "Aucune fonction particulière"], ans: 0, exp: "La fonction politique concerne le pouvoir et les institutions gouvernementales.", method: "Pense au rôle joué par une capitale abritant le gouvernement." },
    quiz: [{ q: "Un plan de ville organisé en carrés réguliers est appelé plan :", opts: ["Damier", "Circulaire", "Aucun de ces plans", "Triangulaire uniquement"], ans: 0, exp: "Le plan en damier organise les rues selon une grille régulière, comme un jeu de dames." }],
  },
  {
    title: "Les problèmes du milieu urbain (Palier 5)",
    content: "Les villes gabonaises connaissent des problèmes structurels (logements, transport, électricité, eau, structures sanitaires) et conjoncturels (insécurité, chômage, gestion des ordures ménagères), ainsi que des problèmes spécifiques au littoral (pollution, érosion, tensions entre écologistes et industriels).",
    example: "La gestion des ordures ménagères reste un défi majeur pour de nombreuses villes gabonaises en pleine croissance.",
    keyPoints: ["Problèmes structurels urbains : logement, transport", "Problèmes conjoncturels : insécurité, chômage", "Problèmes du littoral : pollution, érosion", "Tensions entre écologistes et industriels"],
    exercise: { q: "La pollution et l'érosion sont des problèmes particulièrement liés :", opts: ["Au littoral", "Aux zones montagneuses uniquement", "Au désert", "À aucune région précise"], ans: 0, exp: "Les zones littorales, très fréquentées et industrialisées, sont particulièrement exposées à ces problèmes.", method: "Pense à la proximité de la mer et des activités portuaires/industrielles." },
    quiz: [{ q: "La gestion des ordures ménagères relève d'un problème :", opts: ["Conjoncturel urbain", "Historique uniquement", "Scientifique sans lien avec la ville", "Inexistant au Gabon"], ans: 0, exp: "C'est un défi quotidien de gestion urbaine, classé parmi les problèmes conjoncturels." }],
  },
  {
    title: "L'organisation administrative du Gabon (Palier 6)",
    content: "Le Gabon est organisé en provinces, départements et districts, chacun avec ses fonctions et enjeux d'aménagement du territoire. Les collectivités locales comprennent les conseils communaux (communes, arrondissements, quartiers) et les conseils départementaux (cantons, regroupements, villages).",
    example: "Chaque province du Gabon possède un chef-lieu qui centralise l'administration régionale, avant la subdivision en départements puis en districts.",
    keyPoints: ["Provinces, départements, districts", "Chefs-lieux à chaque niveau administratif", "Conseil communal : commune, arrondissements, quartiers", "Conseil départemental : cantons, villages"],
    exercise: { q: "Quel est le plus grand découpage administratif du Gabon parmi les suivants ?", opts: ["La province", "Le district", "Le quartier", "Le village"], ans: 0, exp: "La province est le plus grand échelon administratif, avant département et district.", method: "Range les niveaux du plus grand au plus petit : province > département > district." },
    quiz: [{ q: "Le conseil communal gère notamment :", opts: ["Les communes, arrondissements et quartiers", "Uniquement les frontières internationales", "L'armée nationale", "Les relations diplomatiques"], ans: 0, exp: "Le conseil communal s'occupe de l'organisation locale à l'échelle de la ville." }],
  },
];
export function getV26_5e_geographie(): Subject {
  return makeSubject("geographie", "Géographie", "Map", "teal", "5e", "5e", v26_5e_geographie_topics);
}

const v26_4e_geographie_topics: TopicData[] = [
  {
    title: "Le Gabon dans la CEEAC (Palier 1)",
    content: "La Communauté Économique des États de l'Afrique Centrale (CEEAC) s'est construite en plusieurs étapes, avec des institutions et un bilan d'activités propres. Le Gabon y coopère à travers des accords économiques et sociaux, qui présentent cependant certaines limites.",
    example: "Les accords économiques entre le Gabon et les autres pays de la CEEAC visent à renforcer la coopération et le développement régional en Afrique centrale.",
    keyPoints: ["CEEAC : Communauté Économique des États de l'Afrique Centrale", "Étapes de construction et missions", "Accords économiques et sociaux du Gabon avec la CEEAC", "Limites de cette coopération régionale"],
    exercise: { q: "Que signifie le sigle CEEAC ?", opts: ["Communauté Économique des États de l'Afrique Centrale", "Conseil Européen des Affaires Culturelles", "Comité d'Étude sur l'Environnement en Afrique", "Aucune de ces réponses"], ans: 0, exp: "La CEEAC regroupe les pays d'Afrique centrale autour d'objectifs économiques communs.", method: "Décompose le sigle : Communauté, Économique, États, Afrique Centrale." },
    quiz: [{ q: "La coopération du Gabon avec la CEEAC vise notamment à :", opts: ["Favoriser le développement régional", "Isoler le pays de ses voisins", "Empêcher tout commerce régional", "Aucun objectif particulier"], ans: 0, exp: "La coopération régionale vise le développement économique commun." }],
  },
  {
    title: "Le Gabon dans la CEMAC (Palier 2)",
    content: "La Communauté Économique et Monétaire de l'Afrique Centrale (CEMAC) rassemble plusieurs pays autour d'une monnaie et d'objectifs économiques communs. Le Gabon y coopère économiquement et socialement, malgré certaines limites à cette coopération.",
    example: "La monnaie commune utilisée dans la zone CEMAC (le franc CFA) facilite les échanges économiques entre le Gabon et ses voisins.",
    keyPoints: ["CEMAC : Communauté Économique et Monétaire de l'Afrique Centrale", "Étapes de construction et institutions", "Coopération économique et sociale du Gabon", "Limites économiques et sociales de la coopération"],
    exercise: { q: "Que signifie le M dans le sigle CEMAC ?", opts: ["Monétaire", "Militaire", "Maritime", "Mondiale"], ans: 0, exp: "Le M de CEMAC renvoie à l'aspect monétaire, la zone partageant une monnaie commune.", method: "Pense à ce qui distingue la CEMAC de la simple CEEAC : la dimension monétaire." },
    quiz: [{ q: "La CEMAC concerne notamment la coopération :", opts: ["Économique et monétaire", "Uniquement militaire", "Uniquement sportive", "Uniquement culturelle"], ans: 0, exp: "La CEMAC porte avant tout sur la coopération économique et monétaire régionale." }],
  },
  {
    title: "Le Gabon dans l'Union africaine (Palier 3)",
    content: "L'Union africaine (UA) s'est construite en plusieurs étapes, avec des institutions et un bilan d'activités. Le Gabon y coopère sur les plans diplomatique, sécuritaire, économique, environnemental, social et culturel.",
    example: "La coopération diplomatique entre le Gabon et l'Union africaine permet de coordonner des positions communes sur des enjeux continentaux.",
    keyPoints: ["Union africaine : étapes de construction, institutions", "Coopération diplomatique et sécuritaire", "Coopération économique, environnementale, sociale, culturelle", "Renforcement de la coopération sous-régionale"],
    exercise: { q: "L'Union africaine regroupe :", opts: ["Des pays du continent africain", "Uniquement des pays d'Europe", "Uniquement des pays d'Asie", "Aucun pays en particulier"], ans: 0, exp: "L'UA rassemble les États du continent africain autour d'objectifs communs.", method: "Le nom de l'organisation indique directement le continent concerné." },
    quiz: [{ q: "La coopération Gabon-UA concerne notamment le domaine :", opts: ["Diplomatique et sécuritaire", "Uniquement culinaire", "Uniquement musical", "Aucun domaine"], ans: 0, exp: "La coopération diplomatique et sécuritaire fait partie des axes de cette coopération." }],
  },
  {
    title: "La coopération Gabon-Union européenne (Palier 4)",
    content: "Le Gabon coopère avec l'Union européenne sur les plans politique et environnemental (accords politiques et environnementaux) ainsi qu'économique et social (accords économiques et sociaux), même si cette coopération présente certaines limites de part et d'autre.",
    example: "Des accords environnementaux entre le Gabon et l'Union européenne portent notamment sur la préservation de la forêt équatoriale gabonaise.",
    keyPoints: ["Accords politiques et environnementaux Gabon-UE", "Accords économiques et sociaux", "Limites de cette coopération", "Objectif d'une coopération équilibrée"],
    exercise: { q: "La préservation de la forêt gabonaise relève d'accords :", opts: ["Environnementaux", "Sportifs", "Musicaux", "Aucun accord particulier"], ans: 0, exp: "Ces accords environnementaux concernent la protection des ressources naturelles.", method: "Pense au domaine qui concerne la nature et l'écologie." },
    quiz: [{ q: "La coopération Gabon-Union européenne vise notamment une relation :", opts: ["Équilibrée (gagnant-gagnant)", "Totalement à sens unique", "Sans aucun accord", "Uniquement militaire"], ans: 0, exp: "L'objectif affiché est une coopération équilibrée entre les deux parties." }],
  },
  {
    title: "La coopération Gabon-ALENA/ACEUM (Palier 5)",
    content: "Le Gabon entretient également une coopération politique, environnementale, économique et sociale avec les pays de l'ALENA/ACEUM (Accord de libre-échange nord-américain), là aussi marquée par certaines limites, avec pour objectif une coopération équilibrée entre les parties.",
    example: "Des échanges économiques existent entre le Gabon et les pays nord-américains regroupés au sein de cet accord de libre-échange.",
    keyPoints: ["ALENA/ACEUM : accord de libre-échange nord-américain", "Coopération politique et environnementale", "Coopération économique et sociale", "Recherche d'une coopération équilibrée"],
    exercise: { q: "L'ALENA/ACEUM regroupe des pays de quelle région ?", opts: ["Amérique du Nord", "Afrique de l'Ouest", "Asie du Sud-Est", "Europe de l'Est"], ans: 0, exp: "L'ALENA/ACEUM est un accord de libre-échange entre pays nord-américains.", method: "Le nom de l'accord mentionne directement « nord-américain »." },
    quiz: [{ q: "La coopération Gabon-ALENA concerne notamment :", opts: ["Les domaines économique et social", "Uniquement le sport", "Uniquement la musique", "Aucun domaine"], ans: 0, exp: "Cette coopération couvre notamment les aspects économiques et sociaux." }],
  },
  {
    title: "La coopération Gabon-BRICS (Palier 6)",
    content: "Le Gabon coopère aussi avec les BRICS (Brésil, Russie, Inde, Chine, Afrique du Sud) sur les plans politique, environnemental, économique et social, dans une recherche de coopération équilibrée malgré certaines limites.",
    example: "La coopération économique entre le Gabon et la Chine, membre des BRICS, illustre ce type de partenariat international.",
    keyPoints: ["BRICS : Brésil, Russie, Inde, Chine, Afrique du Sud", "Coopération politique et environnementale", "Coopération économique et sociale", "Recherche d'un partenariat équilibré"],
    exercise: { q: "Quels pays composent les BRICS ?", opts: ["Brésil, Russie, Inde, Chine, Afrique du Sud", "France, Allemagne, Italie, Espagne, Portugal", "USA, Canada, Mexique", "Aucun pays précis"], ans: 0, exp: "Les BRICS regroupent ces cinq grandes puissances émergentes.", method: "Chaque lettre du sigle BRICS correspond à l'initiale d'un pays." },
    quiz: [{ q: "La coopération Gabon-BRICS vise notamment une relation :", opts: ["Équilibrée entre les parties", "Totalement à sens unique", "Interdite par la loi", "Sans aucun accord"], ans: 0, exp: "L'objectif recherché est un partenariat gagnant-gagnant." }],
  },
];
export function getV26_4e_geographie(): Subject {
  return makeSubject("geographie", "Géographie", "Map", "teal", "4e", "4e", v26_4e_geographie_topics);
}

const v26_3e_geographie_topics: TopicData[] = [
  {
    title: "Le secteur primaire : le pétrole et le bois (Palier 1)",
    content: "Le secteur pétrolier gabonais comprend une production on-shore et off-shore, avec des apports économiques, financiers et sociaux importants, mais aussi des difficultés (dépendance, épuisement des réserves) et des perspectives d'avenir. Le secteur forestier, avec ses propres zones d'exploitation et producteurs, présente également des apports et des défis comparables.",
    example: "La production pétrolière gabonaise se répartit entre sites on-shore (sur terre) et off-shore (en mer), chacun ayant ses propres enjeux d'exploitation.",
    keyPoints: ["Production pétrolière : on-shore et off-shore", "Apports économiques, financiers et sociaux du pétrole", "Secteur forestier : zones d'exploitation, producteurs", "Difficultés et perspectives des deux secteurs"],
    exercise: { q: "Que signifie une production pétrolière « off-shore » ?", opts: ["Une production en mer", "Une production uniquement sur terre", "Une production interdite", "Une production agricole"], ans: 0, exp: "« Off-shore » désigne l'exploitation pétrolière réalisée en mer, au large des côtes.", method: "« Shore » signifie « côte » en anglais ; « off-shore » signifie donc « au large »." },
    quiz: [{ q: "Le secteur forestier gabonais fait partie du secteur :", opts: ["Primaire", "Tertiaire uniquement", "Quaternaire", "Aucun secteur particulier"], ans: 0, exp: "L'exploitation du bois, comme celle du pétrole, relève du secteur primaire." }],
  },
  {
    title: "Le secteur primaire : les mines (Palier 2)",
    content: "Le Gabon est un important producteur de manganèse, avec des sites et des producteurs spécifiques, apportant des retombées économiques, financières et sociales significatives. D'autres minerais, abondants et variés, complètent ce secteur minier, chacun avec ses propres apports et défis.",
    example: "L'exploitation du manganèse constitue l'une des principales richesses minières du Gabon, générant d'importantes recettes à l'exportation.",
    keyPoints: ["Manganèse : sites, producteurs, apports économiques", "Autres minerais abondants et variés", "Apports économiques, financiers et sociaux du secteur minier", "Difficultés et perspectives de ce secteur"],
    exercise: { q: "Quel minerai est particulièrement associé à l'exploitation minière gabonaise ?", opts: ["Le manganèse", "Le charbon", "Le sel uniquement", "Aucun minerai particulier"], ans: 0, exp: "Le manganèse est l'une des ressources minières majeures et emblématiques du Gabon.", method: "C'est un métal gris souvent cité en tête des exportations minières gabonaises." },
    quiz: [{ q: "L'exploitation minière au Gabon apporte notamment des retombées :", opts: ["Économiques et sociales", "Aucune retombée", "Uniquement négatives", "Uniquement culturelles"], ans: 0, exp: "Elle génère des revenus économiques et des effets sociaux, positifs comme négatifs." }],
  },
  {
    title: "Le secteur primaire : agriculture, pêche et élevage (Palier 3)",
    content: "L'agriculture gabonaise se divise entre agriculture vivrière/maraîchère et agriculture de rente/agro-industrielle, chacune avec ses apports économiques et sociaux. La pêche et l'élevage complètent ce secteur, avec leurs propres types d'activités, apports et défis, dans une perspective d'autosuffisance alimentaire.",
    example: "L'agriculture vivrière permet aux familles gabonaises de subvenir directement à leurs besoins alimentaires quotidiens.",
    keyPoints: ["Agriculture vivrière/maraîchère et de rente/agro-industrielle", "Types de pêche et d'élevage", "Apports économiques et sociaux de ces activités", "Objectif d'autosuffisance alimentaire"],
    exercise: { q: "Quel type d'agriculture vise directement à nourrir la famille ou la communauté locale ?", opts: ["L'agriculture vivrière", "L'agriculture de rente", "L'agro-industrie exportatrice", "Aucune de ces réponses"], ans: 0, exp: "L'agriculture vivrière est destinée à la consommation locale, contrairement à l'agriculture de rente tournée vers la vente.", method: "« Vivrière » vient de « vivre » : elle sert à nourrir directement les populations." },
    quiz: [{ q: "L'objectif recherché à travers agriculture, pêche et élevage est notamment :", opts: ["L'autosuffisance alimentaire", "La disparition de ces secteurs", "L'importation exclusive de nourriture", "Aucun objectif particulier"], ans: 0, exp: "Développer ces secteurs vise à réduire la dépendance aux importations alimentaires." }],
  },
  {
    title: "Les secteurs secondaire et innovant (Palier 4)",
    content: "Le secteur secondaire gabonais comprend les industries de transformation liées aux secteurs pétrolier, forestier, minier et agricole. L'économie numérique, avec ses domaines d'activité, sa couverture et ses acteurs, représente un secteur innovant en plein essor, avec ses propres apports, difficultés et perspectives.",
    example: "La transformation locale du bois brut en produits finis (meubles, panneaux) illustre le développement du secteur secondaire gabonais.",
    keyPoints: ["Industries de transformation : pétrole, forêt, mines, agriculture", "Économie numérique : domaines, couverture, acteurs", "Apports économiques et sociaux de ces secteurs", "Perspectives de diversification économique"],
    exercise: { q: "Que fait le secteur secondaire par rapport aux matières premières du secteur primaire ?", opts: ["Il les transforme", "Il les ignore complètement", "Il les détruit", "Il les exporte sans y toucher"], ans: 0, exp: "Le secteur secondaire transforme les matières premières en produits élaborés.", method: "Pense à la différence entre extraire une ressource (primaire) et la transformer (secondaire)." },
    quiz: [{ q: "L'économie numérique est considérée comme un secteur :", opts: ["Innovant", "Traditionnel uniquement", "En voie de disparition", "Sans lien avec l'économie"], ans: 0, exp: "L'économie numérique représente un secteur innovant à fort potentiel pour le Gabon." }],
  },
  {
    title: "Le secteur touristique et le développement durable (Palier 5)",
    content: "Le tourisme gabonais (tourisme d'affaires, balnéaire, écotourisme) a des impacts positifs (socio-économiques, environnementaux) mais aussi négatifs (acculturation, précarité de l'emploi, pollution, destruction de la biodiversité), nécessitant des solutions comme le choix des types de tourisme et la sensibilisation.",
    example: "L'écotourisme, en valorisant les parcs nationaux gabonais, peut générer des revenus tout en préservant la biodiversité, contrairement à certaines formes de tourisme plus destructrices.",
    keyPoints: ["Types de tourisme : affaires, balnéaire, écotourisme", "Impacts positifs : socio-économiques, environnementaux", "Impacts négatifs : acculturation, pollution, biodiversité", "Solutions : choix du tourisme, sensibilisation"],
    exercise: { q: "Quel type de tourisme met l'accent sur la préservation de la nature ?", opts: ["L'écotourisme", "Le tourisme d'affaires", "Le tourisme industriel", "Aucun type de tourisme"], ans: 0, exp: "L'écotourisme cherche à valoriser et préserver les milieux naturels visités.", method: "Le préfixe « éco » renvoie à l'écologie et à l'environnement." },
    quiz: [{ q: "Un impact négatif possible du tourisme est :", opts: ["La destruction de la biodiversité", "La création d'emplois stables uniquement", "Aucun impact négatif", "L'amélioration automatique de l'environnement"], ans: 0, exp: "Un tourisme mal maîtrisé peut nuire à l'environnement et à la biodiversité locale." }],
  },
  {
    title: "Les problèmes de l'économie gabonaise (Palier 6)",
    content: "L'économie gabonaise fait face à des problèmes internes (dépendance aux ressources extractives, mauvaise gouvernance, infrastructures dégradées, dette intérieure) et externes (aléas de la conjoncture internationale, poids de la dette extérieure), avec des conséquences économiques et sociales qui appellent des perspectives d'amélioration.",
    example: "La forte dépendance du Gabon vis-à-vis du pétrole rend son économie sensible aux variations des cours mondiaux de cette matière première.",
    keyPoints: ["Problèmes internes : dépendance extractive, gouvernance", "Problèmes externes : conjoncture internationale, dette extérieure", "Conséquences économiques et sociales", "Perspectives : bonne gouvernance, réduction de la dépendance"],
    exercise: { q: "La forte dépendance au pétrole est un problème :", opts: ["Interne à l'économie gabonaise", "Uniquement climatique", "Sans rapport avec l'économie", "Un avantage sans inconvénient"], ans: 0, exp: "Cette dépendance structurelle est un problème interne majeur de l'économie gabonaise.", method: "Pense à ce qui vient de l'intérieur même de la structure économique du pays." },
    quiz: [{ q: "Un problème externe de l'économie gabonaise peut être :", opts: ["Les aléas de la conjoncture internationale", "La météo locale uniquement", "Un problème purement culturel", "Aucun problème externe n'existe"], ans: 0, exp: "Les variations économiques mondiales affectent directement l'économie gabonaise." }],
  },
];
export function getV26_3e_geographie(): Subject {
  return makeSubject("geographie", "Géographie", "Map", "teal", "3e", "3e", v26_3e_geographie_topics);
}

/** Merge helper: subjects generated from V2.6 pack for a given levelId */
export function getV26SubjectsForLevel(levelId: string): Subject[] {
  const out: Subject[] = [];
  if (levelId === "3e") out.push(getV26_3e_physique_chimie());
  if (levelId === "4e") out.push(getV26_4e_physique_chimie());
  if (levelId === "5e") out.push(getV26_5e_mathematiques());
  if (levelId === "6e") out.push(getV26_6e_mathematiques());
  if (levelId === "6e") out.push(getV26_6e_physique_chimie());
  if (levelId === "6e") out.push(getV26_6e_svt());
  if (levelId === "6e") out.push(getV26_6e_francais());
  if (levelId === "5e") out.push(getV26_5e_francais());
  if (levelId === "4e") out.push(getV26_4e_francais());
  if (levelId === "3e") out.push(getV26_3e_francais());
  if (levelId === "6e") out.push(getV26_6e_histoire());
  if (levelId === "5e") out.push(getV26_5e_histoire());
  if (levelId === "4e") out.push(getV26_4e_histoire());
  if (levelId === "3e") out.push(getV26_3e_histoire());
  if (levelId === "6e") out.push(getV26_6e_geographie());
  if (levelId === "5e") out.push(getV26_5e_geographie());
  if (levelId === "4e") out.push(getV26_4e_geographie());
  if (levelId === "3e") out.push(getV26_3e_geographie());
  if (levelId === "cm2") out.push(getV26_cm2_mathematiques());
  if (levelId === "premiere") out.push(getV26_premiere_philosophie());
  if (levelId === "seconde") out.push(getV26_seconde_svt());
  return out;
}

export function getAllV26Subjects(): Subject[] {
  const levels = ["cm2","6e","5e","4e","3e","seconde","premiere"];
  return levels.flatMap(getV26SubjectsForLevel);
}