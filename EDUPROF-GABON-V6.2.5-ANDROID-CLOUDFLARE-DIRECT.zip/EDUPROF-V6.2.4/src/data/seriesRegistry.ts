/**
 * Registre des séries lycée — structure cible + compatibilité ancien modèle (A/C/D).
 * Aucune invention de contenu : seul le routage / libellés / aliases.
 */

export type SeriesContentGroup =
  | 'seconde-common'
  | 'literary' // ancien A — non subdivisé A1/A2/B dans les données
  | 'scientific-c'
  | 'scientific-d'
  | 'unknown';

export interface CanonicalSeriesDef {
  /** ID stable stocké / utilisé */
  id: string;
  /** Libellé UI */
  label: string;
  /** Groupe de contenu pédagogique (réutilise les packs existants) */
  contentGroup: SeriesContentGroup;
  /** Anciennes valeurs profil / API encore acceptées */
  legacyIds: string[];
  /**
   * true si A1/A2/B pointent vers le pack littéraire unique faute de subdivision
   * dans les données — à confirmer plus tard, pas une invention de programme.
   */
  classificationPending?: boolean;
}

/** Séries affichées / sélectionnables par niveau lycée */
export const CANONICAL_SERIES: Record<'seconde' | 'premiere' | 'terminale', CanonicalSeriesDef[]> = {
  seconde: [
    {
      id: 'serie-le',
      label: 'Seconde LE',
      contentGroup: 'seconde-common',
      legacyIds: ['le', 'LE', 'serie-le', 'seconde-le'],
    },
    {
      id: 'serie-s',
      label: 'Seconde S',
      contentGroup: 'seconde-common',
      legacyIds: ['s', 'S', 'serie-s', 'seconde-s'],
    },
  ],
  premiere: [
    {
      id: 'serie-a1',
      label: 'Première A1',
      contentGroup: 'literary',
      legacyIds: ['a1', 'A1', 'serie-a1'],
      classificationPending: true,
    },
    {
      id: 'serie-a2',
      label: 'Première A2',
      contentGroup: 'literary',
      legacyIds: ['a2', 'A2', 'serie-a2'],
      classificationPending: true,
    },
    {
      id: 'serie-b',
      label: 'Première B',
      contentGroup: 'literary',
      legacyIds: ['b', 'B', 'serie-b'],
      classificationPending: true,
    },
    {
      id: 'serie-s',
      label: 'Première S',
      contentGroup: 'scientific-c',
      legacyIds: ['s', 'S', 'serie-s', 'premiere-s'],
    },
    // Compatibilité ancien modèle (toujours résolvables)
    {
      id: 'serie-a',
      label: 'Série A (ancien modèle)',
      contentGroup: 'literary',
      legacyIds: ['a', 'A', 'serie-a', 'premiere-a'],
    },
    {
      id: 'serie-c',
      label: 'Série C (ancien modèle)',
      contentGroup: 'scientific-c',
      legacyIds: ['c', 'C', 'serie-c', 'premiere-c'],
    },
    {
      id: 'serie-d',
      label: 'Série D (ancien modèle)',
      contentGroup: 'scientific-d',
      legacyIds: ['d', 'D', 'serie-d', 'premiere-d'],
    },
  ],
  terminale: [
    {
      id: 'serie-a1',
      label: 'Terminale A1',
      contentGroup: 'literary',
      legacyIds: ['a1', 'A1', 'serie-a1'],
      classificationPending: true,
    },
    {
      id: 'serie-a2',
      label: 'Terminale A2',
      contentGroup: 'literary',
      legacyIds: ['a2', 'A2', 'serie-a2'],
      classificationPending: true,
    },
    {
      id: 'serie-b',
      label: 'Terminale B',
      contentGroup: 'literary',
      legacyIds: ['b', 'B', 'serie-b'],
      classificationPending: true,
    },
    {
      id: 'serie-c',
      label: 'Terminale C',
      contentGroup: 'scientific-c',
      legacyIds: ['c', 'C', 'serie-c', 'terminale-c'],
    },
    {
      id: 'serie-d',
      label: 'Terminale D',
      contentGroup: 'scientific-d',
      legacyIds: ['d', 'D', 'serie-d', 'terminale-d'],
    },
    {
      id: 'serie-a',
      label: 'Série A (ancien modèle)',
      contentGroup: 'literary',
      legacyIds: ['a', 'A', 'serie-a', 'terminale-a'],
    },
  ],
};

/** Séries proposées en UI (sans les entrées « ancien modèle » en double d’affichage) */
export function seriesChoicesForLevel(levelId: string): CanonicalSeriesDef[] {
  if (levelId === 'seconde') return CANONICAL_SERIES.seconde;
  if (levelId === 'premiere') {
    return CANONICAL_SERIES.premiere.filter((s) =>
      ['serie-a1', 'serie-a2', 'serie-b', 'serie-s'].includes(s.id)
    );
  }
  if (levelId === 'terminale') {
    return CANONICAL_SERIES.terminale.filter((s) =>
      ['serie-a1', 'serie-a2', 'serie-b', 'serie-c', 'serie-d'].includes(s.id)
    );
  }
  return [];
}

/**
 * Normalise une valeur profil / URL vers un ID de série canonique du niveau.
 * Ne détruit jamais la valeur d’origine côté stockage : renvoie null si inconnu.
 */
export function normalizeSeriesId(
  levelId: string,
  raw: string | null | undefined
): string | null {
  if (!raw || !String(raw).trim()) return null;
  const v = String(raw).trim();
  const list =
    levelId === 'seconde' || levelId === 'premiere' || levelId === 'terminale'
      ? CANONICAL_SERIES[levelId]
      : [];
  for (const s of list) {
    if (s.id === v || s.legacyIds.includes(v)) return s.id;
    if (s.label.toLowerCase() === v.toLowerCase()) return s.id;
  }
  // Recherche souple
  const lower = v.toLowerCase();
  for (const s of list) {
    if (s.legacyIds.some((id) => id.toLowerCase() === lower)) return s.id;
  }
  return null;
}

export function contentGroupForSeries(
  levelId: string,
  seriesId: string | null | undefined
): SeriesContentGroup {
  if (!seriesId) return 'unknown';
  const normalized = normalizeSeriesId(levelId, seriesId) || seriesId;
  const list =
    levelId === 'seconde' || levelId === 'premiere' || levelId === 'terminale'
      ? CANONICAL_SERIES[levelId]
      : [];
  const found = list.find((s) => s.id === normalized);
  return found?.contentGroup ?? 'unknown';
}

/** true si le niveau lycée exige une série pour un parcours complet */
export function levelRequiresSeries(levelId: string): boolean {
  return levelId === 'seconde' || levelId === 'premiere' || levelId === 'terminale';
}
