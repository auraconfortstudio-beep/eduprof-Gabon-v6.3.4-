/**
 * Packs pédagogiques par série — Gabon.
 * Orientations vérifiées (sources secondaires sur le BAC général gabonais) :
 * - A1 : français, philosophie, mathématiques
 * - A2 : français, langues étrangères
 * - B  : économie / SES
 * - C  : maths, physique
 * - D  : maths, physique, SVT
 * - Seconde LE vs S : tronc commun + initiation éco (LE) / sciences renforcées (S)
 *
 * Contenu d'entraînement EduProf (non copie d'examens officiels).
 * IDs préfixés par série pour individualiser progression.
 */
import { makeSubject, type Subject, type TopicData, type TopicExercise } from './types';

function ex(
  q: string,
  opts: string[],
  ans: number,
  exp: string,
  method: string,
  difficulty: 'facile' | 'intermediaire' | 'difficile' = 'intermediaire'
): TopicExercise {
  return { q, opts, ans, exp, method, difficulty };
}
function qz(q: string, opts: string[], ans: number, exp: string) {
  return { q, opts, ans, exp };
}

// ─── Unités thématiques ───────────────────────────────────────────

const philoA1: TopicData[] = [
  {
    title: 'La conscience et la personne',
    content:
      "La conscience permet de se connaître et de juger ses actes. En philosophie de terminale (série A1 notamment), on relie conscience, liberté et responsabilité.\nAu Gabon : être citoyen responsable (école, famille, vie publique) suppose de réfléchir avant d'agir.\nDistinction : conscience psychologique (se sentir soi) / conscience morale (bien et mal).",
    example: "Choisir de signaler un harcèlement à l'école est un acte de conscience morale.",
    keyPoints: ['Conscience de soi', 'Conscience morale', 'Responsabilité', 'Lien citoyenneté gabonaise'],
    exercise: ex('La conscience morale sert surtout à :', ['mesurer une longueur', 'juger le bien et le mal', 'calculer un prix', 'dessiner une carte'], 1, 'Jugement moral.', 'Philo.', 'facile'),
    exercises: [
      ex('Conscience morale :', ['longueur', 'bien et mal', 'prix', 'carte'], 1, 'Morale.', 'Déf.', 'facile'),
      ex('Agir librement implique souvent :', ['aucune réflexion', 'responsabilité de ses actes', 'ignorer autrui', 'refuser toute règle'], 1, 'Liberté/responsabilité.', 'Lien.', 'intermediaire'),
      ex('Exemple de conscience citoyenne au Gabon :', ['polluer un parc', 'respecter le règlement scolaire et signaler une injustice', 'tricher au BAC', 'ignorer la loi'], 1, 'Civisme.', 'Exemple.', 'intermediaire'),
      ex('Se connaître soi-même relève plutôt de :', ['la conscience psychologique', 'la géologie', 'la comptabilité', 'la météo'], 0, 'Psychologie.', 'Distinctions.', 'difficile'),
      ex('Sans responsabilité, la liberté devient :', ['plus claire', 'arbitraire / dangereuse pour autrui', 'une matière scolaire', 'un fleuve'], 1, 'Critique.', 'Réflexion.', 'difficile'),
    ],
    quiz: [
      qz('A1 met souvent l’accent sur :', ['philo + français', 'uniquement le sport', 'uniquement la chimie organique', 'la plomberie'], 0, 'Orientation A1.'),
      qz('Responsabilité signifie :', ['répondre de ses actes', 'ne jamais choisir', 'oublier l’école', 'refuser d’apprendre'], 0, 'Déf.'),
    ],
  },
];

const francaisA1: TopicData[] = [
  {
    title: 'Dissertation : méthode et enjeux gabonais',
    content:
      "En A1, le français et l’argumentation sont centraux. La dissertation : analyser le sujet, problematiser, plan dialectique ou thématique, exemples.\nExemples d’ancrage : forêt gabonaise, école, vivre ensemble, mémoire de l’indépendance (17 août).\nProcédé → effet → sens dans le commentaire ; thèse → arguments → exemples dans la dissertation.",
    example: "Sujet : « Pourquoi lire les contes de son pays ? » → identité, oralité, valeurs.",
    keyPoints: ['Problématique', 'Plan', 'Exemples locaux', 'Conclusion'],
    exercise: ex('La problématique d’une dissertation est :', ['un titre de film', 'la question essentielle que pose le sujet', 'une date', 'un calcul'], 1, 'Cœur du sujet.', 'Méthode.', 'facile'),
    exercises: [
      ex('Problématique :', ['film', 'question essentielle du sujet', 'date', 'calcul'], 1, 'Méthode.', 'Fr.', 'facile'),
      ex('Un exemple gabonais pertinent :', ['uniquement la banquise', 'forêt, école, 17 août, oralité', 'météo martienne', 'code de la route seul'], 1, 'Ancrage.', 'Ex.', 'facile'),
      ex('Plan dialectique typique :', ['thèse / antithèse / synthèse', 'seulement une liste de courses', 'un seul mot', 'un numéro de téléphone'], 0, 'Structure.', 'Méthode.', 'intermediaire'),
      ex('Conclusion efficace :', ['ouvre sans lien', 'répond à la problématique et ouvre modestement', 'insulte le lecteur', 'recopie l’intro entière sans sens'], 1, 'Clôture.', 'Rédaction.', 'intermediaire'),
      ex('En A1, le français est :', ['marginal', 'discipline fondamentale', 'interdite', 'uniquement orale'], 1, 'Orientation.', 'Série.', 'difficile'),
    ],
    quiz: [
      qz('Dissertation ≠ ', ['récit purement narratif sans argumentation', 'texte argumenté sur un sujet', 'exercice de réflexion', 'travail scolaire'], 0, 'Genre.'),
      qz('Oralité gabonaise peut servir d’exemple pour :', ['identité et transmission', 'uniquement la chimie', 'les intégrales', 'le pH'], 0, 'Culture.'),
    ],
  },
];

const languesA2: TopicData[] = [
  {
    title: 'Langues et communication internationale',
    content:
      "La série A2 valorise les langues vivantes (anglais, espagnol…). Objectifs : comprendre, s’exprimer, découvrir d’autres cultures.\nAu Gabon : anglais utile pour les études, le tourisme, les échanges en Afrique centrale et au-delà.\nTravailler : vocabulaire thématique (école, ville, environnement), structures, oral.",
    example: "Present Libreville or a national park in English in 8–10 lines.",
    keyPoints: ['Compréhension', 'Expression', 'Vocabulaire', 'Culture'],
    exercise: ex('A2 met l’accent surtout sur :', ['uniquement la soudure', 'les langues étrangères', 'uniquement le pétrole brut', 'la plomberie'], 1, 'Orientation A2.', 'Série.', 'facile'),
    exercises: [
      ex('Orientation A2 :', ['soudure', 'langues étrangères', 'pétrole seul', 'plomberie'], 1, 'A2.', 'Série.', 'facile'),
      ex('« There is a market in Libreville » illustre :', ['there is/are', 'un temps du conditionnel latin', 'une intégrale', 'un ion OH-'], 0, 'Anglais.', 'Grammaire.', 'facile'),
      ex('Parler d’un parc national en anglais développe :', ['vocabulaire environnemental et culturel', 'uniquement la géométrie', 'le silence', 'la chimie organique seule'], 0, 'Thème.', 'Production.', 'intermediaire'),
      ex('Une langue vivante sert à :', ['communiquer et ouvrir des horizons', 'remplacer toute science', 'interdire le français', 'supprimer l’école'], 0, 'Finalité.', 'Compétence.', 'intermediaire'),
      ex('Au BAC, l’épreuve de langue évalue surtout :', ['compréhension et expression', 'uniquement le dessin technique', 'la course de fond', 'la cuisine'], 0, 'Évaluation.', 'Exam.', 'difficile'),
    ],
    quiz: [
      qz('Espagnol ou anglais en A2 :', ['langues vivantes', 'matières interdites', 'uniquement du latin obligatoire partout', 'sports'], 0, 'LV.'),
      qz('Tourisme au Gabon + anglais :', ['opportunité de communication', 'sans aucun lien', 'remplace les maths C', 'interdit'], 0, 'Contexte.'),
    ],
  },
];

const sesB: TopicData[] = [
  {
    title: 'Économie gabonaise et choix collectifs',
    content:
      "La série B oriente vers l’économie et les sciences sociales.\nNotions : agents économiques (ménages, entreprises, État), marché, emploi, inflation (sens simple), commerce extérieur.\nAncrage Gabon : pétrole, diversification, urbanisation de Libreville et Port-Gentil, emploi des jeunes, rôle de l’école dans le capital humain.",
    example: "Expliquer pourquoi dépendre d’une seule ressource (pétrole) est un risque.",
    keyPoints: ['Agents', 'État', 'Emploi', 'Diversification', 'Gabon'],
    exercise: ex('La série B est surtout orientée vers :', ['uniquement la poésie latine', 'l’économie / SES', 'uniquement la mécanique quantique', 'la natation'], 1, 'Orientation B.', 'Série.', 'facile'),
    exercises: [
      ex('Orientation B :', ['poésie latine seule', 'économie / SES', 'mécanique quantique seule', 'natation'], 1, 'B.', 'Série.', 'facile'),
      ex('Un ménage dans l’économie :', ['consomme, travaille, épargne…', 'est une province', 'est un parc', 'est un ion'], 0, 'Acteur.', 'SES.', 'facile'),
      ex('Exportation majeure historique du Gabon :', ['banquise', 'pétrole', 'neige', 'blé polaire'], 1, 'Ressource.', 'Gabon.', 'facile'),
      ex('Diversifier l’économie vise à :', ['dépendre d’une seule ressource', 'développer plusieurs secteurs', 'fermer les écoles', 'interdire le commerce'], 1, 'Stratégie.', 'Développement.', 'intermediaire'),
      ex('Capital humain renvoie surtout à :', ['formation et compétences des personnes', 'uniquement le pétrole en baril', 'un drapeau', 'un fleuve'], 0, 'Notion.', 'SES.', 'difficile'),
    ],
    quiz: [
      qz('Port-Gentil est lié à :', ['activités portuaires / pétrole', 'uniquement l’Antarctique', 'un glacier', 'Rome antique'], 0, 'Géo-éco.'),
      qz('L’État peut agir via :', ['éducation, santé, infrastructures', 'uniquement le silence', 'suppression de toute école', 'interdiction d’apprendre'], 0, 'Politiques.'),
    ],
  },
];

const mathsS: TopicData[] = [
  {
    title: 'Suites et raisonnement (orientation scientifique)',
    content:
      "En Première / Terminale scientifiques (S, C, D), les suites et le raisonnement sont centraux.\nSuite arithmétique : u_{n+1} = u_n + r.\nSuite géométrique : u_{n+1} = q · u_n.\nAncrage : modéliser une évolution simple (population d’une ville, production) — sans données inventées non sourcées : on reste sur la méthode.",
    example: "u_0 = 2, r = 3 → u_1 = 5, u_2 = 8 (arithmétique).",
    keyPoints: ['Arithmétique', 'Géométrique', 'Formule explicite', 'Raisonnement'],
    exercise: ex('Suite arithmétique de raison 4, u_0 = 1. u_1 = ?', ['4', '5', '1', '0'], 1, '1+4=5.', 'Suite.', 'facile'),
    exercises: [
      ex('u_0=1, r=4, u_1=?', ['4', '5', '1', '0'], 1, '5.', 'Arith.', 'facile'),
      ex('Suite géométrique : chaque terme est obtenu en :', ['ajoutant toujours 0', 'multipliant par une raison q', 'divisant par π toujours', 'ignorant n'], 1, 'Déf.', 'Géo.', 'facile'),
      ex('La raison d’une suite arithmétique est :', ['la différence constante entre termes', 'toujours 0', 'un pays', 'un verbe'], 0, 'Déf.', 'Maths.', 'intermediaire'),
      ex('Orientation S/C : les maths sont :', ['marginales', 'fondamentales', 'interdites', 'uniquement orales'], 1, 'Série.', 'Parcours.', 'intermediaire'),
      ex('Modéliser une évolution régulière peut utiliser :', ['une suite', 'uniquement un proverbe', 'un drapeau', 'un hymne'], 0, 'Modèle.', 'Application.', 'difficile'),
    ],
    quiz: [
      qz('u_n = 2n + 1 pour n=0 donne :', ['1', '2', '0', '3'], 0, 'Calcul.'),
      qz('Série C met l’accent sur :', ['maths et physique', 'uniquement le dessin', 'uniquement la cuisine', 'le football seul'], 0, 'C.'),
    ],
  },
];

const pcC: TopicData[] = [
  {
    title: 'Énergie et conversions (physique)',
    content:
      "En série C, physique et maths dominent.\nÉnergie : formes (cinétique, potentielle, thermique…), conservation, conversions.\nAu quotidien au Gabon : électricité, transport, cuisson — discuter des conversions sans chiffres non sourcés.",
    example: "Énergie électrique → énergie lumineuse et thermique dans une lampe.",
    keyPoints: ['Formes d’énergie', 'Conversion', 'Conservation', 'Sécurité'],
    exercise: ex('Une lampe convertit surtout l’énergie électrique en :', ['uniquement du son de mer', 'lumière (et chaleur)', 'pétrole brut', 'forêt'], 1, 'Conversion.', 'PC.', 'facile'),
    exercises: [
      ex('Lampe : électrique →', ['son de mer', 'lumière/chaleur', 'pétrole', 'forêt'], 1, 'Conversion.', 'PC.', 'facile'),
      ex('Principe de conservation de l’énergie :', ['l’énergie disparaît toujours', 'l’énergie se transforme mais le bilan se conserve dans un système isolé', 'l’énergie est un pays', 'l’énergie est un verbe'], 1, 'Principe.', 'Physique.', 'intermediaire'),
      ex('Série C : physique est :', ['fondamentale', 'absente', 'interdite', 'uniquement littéraire'], 0, 'Orientation.', 'C.', 'facile'),
      ex('Sécurité électrique à la maison :', ['toucher les fils dénudés', 'éviter les installations défectueuses', 'ignorer les fusibles', 'mélanger eau et prises volontairement'], 1, 'Sécurité.', 'Vie courante.', 'intermediaire'),
      ex('Énergie thermique liée à :', ['agitation microscopique / chaleur', 'uniquement la grammaire', 'un drapeau', 'un hymne'], 0, 'Notion.', 'Physique.', 'difficile'),
    ],
    quiz: [
      qz('Conversion d’énergie :', ['changement de forme', 'disparition totale obligatoire', 'création d’un continent', 'une conjugaison'], 0, 'Déf.'),
      qz('Maths + physique caractérisent surtout :', ['série C', 'uniquement A2 langues seules', 'EPS seule', 'musique seule'], 0, 'C.'),
    ],
  },
];

const svtD: TopicData[] = [
  {
    title: 'Biodiversité et forêt gabonaise (SVT)',
    content:
      "La série D articule maths, physique et SVT.\nForêt dense gabonaise : biodiversité, chaînes alimentaires, enjeux de conservation (parcs nationaux).\nSanté : hygiène, prévention (rappels).\nLien développement durable : exploiter sans détruire le patrimoine pour les générations futures.",
    example: "Producteurs (plantes) → herbivores → prédateurs ; décomposeurs recyclent la matière.",
    keyPoints: ['Biodiversité', 'Chaînes alimentaires', 'Parcs', 'DD', 'Santé'],
    exercise: ex('Les plantes vertes sont des :', ['consommateurs tertiaires seulement', 'producteurs', 'décomposeurs exclusifs', 'prédateurs'], 1, 'Photosynthèse.', 'SVT.', 'facile'),
    exercises: [
      ex('Plantes = ', ['consommateurs tertiaires', 'producteurs', 'décomposeurs seuls', 'prédateurs'], 1, 'Producteurs.', 'SVT.', 'facile'),
      ex('Série D inclut fortement :', ['SVT', 'uniquement la plomberie', 'uniquement le latin', 'le silence'], 0, 'Orientation.', 'D.', 'facile'),
      ex('Parc national vise à :', ['protéger milieux et espèces', 'augmenter le braconnage', 'supprimer la pluie', 'fermer les écoles'], 0, 'Conservation.', 'Environnement.', 'intermediaire'),
      ex('Décomposeurs :', ['recyclent la matière organique', 'produisent la lumière solaire', 'sont des provinces', 'sont des drapeaux'], 0, 'Écosystème.', 'SVT.', 'intermediaire'),
      ex('Développement durable :', ['besoins présents sans compromettre l’avenir', 'tout extraire sans limite', 'interdire toute étude', 'ignorer la forêt'], 0, 'DD.', 'Citoyenneté.', 'difficile'),
    ],
    quiz: [
      qz('D = orientation :', ['maths + sciences de la vie', 'uniquement langues A2', 'uniquement philo A1', 'EPS seule'], 0, 'D.'),
      qz('Forêt gabonaise :', ['grande biodiversité', 'désért absolu', 'banquise', 'absence d’arbres'], 0, 'Géo-SVT.'),
    ],
  },
];

const ecoSecondeLE: TopicData[] = [
  {
    title: 'Initiation économique (Seconde LE)',
    content:
      "En Seconde LE (littéraire / économique), l’initiation économique a un poids important.\nNotions de base : besoin, bien, service, production, consommation, échange.\nAncrage : marché de Libreville, métiers, rôle de l’État, importance de l’école pour l’emploi futur.",
    example: "Acheter du pain = consommation ; le boulanger produit un bien.",
    keyPoints: ['Besoin', 'Production', 'Consommation', 'Échange', 'État'],
    exercise: ex('Consommer signifie surtout :', ['produire une usine', 'utiliser un bien ou un service pour satisfaire un besoin', 'écrire une intégrale', 'ignorer le marché'], 1, 'Déf.', 'Éco.', 'facile'),
    exercises: [
      ex('Consommation :', ['usine seule', 'usage d’un bien/service', 'intégrale', 'ignorer le marché'], 1, 'Déf.', 'Éco.', 'facile'),
      ex('Seconde LE met l’accent relatif sur :', ['initiation économique / lettres', 'uniquement la physique C', 'uniquement la SVT D', 'la plomberie'], 0, 'LE.', 'Orientation.', 'facile'),
      ex('Un service exemple :', ['une coupe de cheveux', 'un caillou non travaillé', 'un ion libre', 'une suite géométrique'], 0, 'Service.', 'Éco.', 'intermediaire'),
      ex('L’école comme investissement en capital humain :', ['formation pour demain', 'aucun lien avec l’emploi', 'interdit au Gabon', 'remplace la nourriture'], 0, 'Lien.', 'SES.', 'intermediaire'),
      ex('Échanger sur un marché :', ['acheter/vendre des biens ou services', 'uniquement dormir', 'refuser toute règle', 'fermer les écoles'], 0, 'Marché.', 'Éco.', 'difficile'),
    ],
    quiz: [
      qz('LE = ', ['littéraire / économique', 'uniquement C physique', 'uniquement D SVT', 'technique plomberie'], 0, 'Seconde.'),
      qz('Production :', ['création de biens/services', 'uniquement la destruction', 'un hymne', 'un drapeau'], 0, 'Déf.'),
    ],
  },
];

const sciencesSecondeS: TopicData[] = [
  {
    title: 'Méthode scientifique (Seconde S)',
    content:
      "La Seconde S prépare aux séries scientifiques.\nDémarche : observer, formuler une hypothèse, expérimenter / raisonner, conclure.\nMaths et sciences expérimentales (PC, SVT) y sont structurantes.\nExemple local : qualité de l’eau, observation d’un écosystème forestier (sans inventer de mesures non sourcées).",
    example: "Hypothèse → test → conclusion provisoire révisable.",
    keyPoints: ['Hypothèse', 'Expérience', 'Rigueur', 'Sciences'],
    exercise: ex('Une hypothèse scientifique est :', ['une conclusion définitive interdite de révision', 'une proposition testable', 'un drapeau', 'un hymne'], 1, 'Déf.', 'Méthode.', 'facile'),
    exercises: [
      ex('Hypothèse :', ['conclusion figée', 'proposition testable', 'drapeau', 'hymne'], 1, 'Méthode.', 'S.', 'facile'),
      ex('Seconde S prépare surtout vers :', ['parcours scientifiques', 'uniquement A2 langues seules', 'uniquement B éco sans science', 'interdiction des maths'], 0, 'Orientation.', 'S.', 'facile'),
      ex('Observer un milieu (forêt, littoral) relève de :', ['démarche scientifique de terrain', 'uniquement la grammaire', 'uniquement la poésie', 'le refus d’apprendre'], 0, 'SVT/Géo.', 'Méthode.', 'intermediaire'),
      ex('La rigueur en sciences impose :', ['distinguer faits et opinions', 'confondre tout', 'ignorer les mesures', 'refuser les définitions'], 0, 'Esprit critique.', 'Science.', 'intermediaire'),
      ex('Maths en Seconde S :', ['outil de modélisation', 'matière interdite', 'uniquement optionnelle partout', 'remplacée par le sport'], 0, 'Rôle.', 'S.', 'difficile'),
    ],
    quiz: [
      qz('S scientifique :', ['maths et sciences renforcées', 'uniquement philo A1', 'uniquement langues A2', 'uniquement SES B'], 0, 'S.'),
      qz('Conclusion scientifique est :', ['provisoire et révisable si nouvelles preuves', 'jamais discutable', 'un chant', 'un drapeau'], 0, 'Épistémologie simple.'),
    ],
  },
];

/** Sujets spécifiques par clé de série (levelId prefix pour IDs uniques) */
export function getSeriesSpecificSubjects(
  level: 'seconde' | 'premiere' | 'terminale',
  seriesId: string
): Subject[] {
  if (level === 'seconde') {
    if (seriesId === 'serie-le') {
      return [
        makeSubject('initiation-eco', 'Initiation économique', 'TrendingUp', 'emerald', 'seconde-le', 'Seconde LE', ecoSecondeLE),
        makeSubject('francais', 'Français (LE)', 'BookOpen', 'amber', 'seconde-le', 'Seconde LE', francaisA1.slice(0, 1)),
      ];
    }
    if (seriesId === 'serie-s') {
      return [
        makeSubject('methode-sciences', 'Méthode scientifique', 'Atom', 'indigo', 'seconde-s', 'Seconde S', sciencesSecondeS),
        makeSubject('mathematiques', 'Mathématiques (S)', 'Calculator', 'blue', 'seconde-s', 'Seconde S', mathsS.slice(0, 1)),
      ];
    }
  }

  if (level === 'premiere') {
    if (seriesId === 'serie-a1') {
      return [
        makeSubject('francais', 'Français', 'BookOpen', 'amber', 'premiere-a1', 'Première A1', francaisA1),
        makeSubject('philosophie', 'Philosophie', 'Lightbulb', 'violet', 'premiere-a1', 'Première A1', philoA1),
        makeSubject('mathematiques', 'Mathématiques', 'Calculator', 'blue', 'premiere-a1', 'Première A1', mathsS.slice(0, 1)),
      ];
    }
    if (seriesId === 'serie-a2') {
      return [
        makeSubject('francais', 'Français', 'BookOpen', 'amber', 'premiere-a2', 'Première A2', francaisA1.slice(0, 1)),
        makeSubject('anglais', 'Anglais / LV', 'Languages', 'red', 'premiere-a2', 'Première A2', languesA2),
      ];
    }
    if (seriesId === 'serie-b') {
      return [
        makeSubject('ses', 'SES / Économie', 'TrendingUp', 'emerald', 'premiere-b', 'Première B', sesB),
        makeSubject('mathematiques', 'Mathématiques appliquées', 'Calculator', 'blue', 'premiere-b', 'Première B', mathsS.slice(0, 1)),
      ];
    }
    if (seriesId === 'serie-s') {
      return [
        makeSubject('mathematiques', 'Mathématiques', 'Calculator', 'blue', 'premiere-s', 'Première S', mathsS),
        makeSubject('physique-chimie', 'Physique-Chimie', 'Atom', 'indigo', 'premiere-s', 'Première S', pcC),
      ];
    }
  }

  if (level === 'terminale') {
    if (seriesId === 'serie-a1') {
      return [
        makeSubject('philosophie', 'Philosophie', 'Lightbulb', 'violet', 'terminale-a1', 'Terminale A1', philoA1),
        makeSubject('francais', 'Français', 'BookOpen', 'amber', 'terminale-a1', 'Terminale A1', francaisA1),
      ];
    }
    if (seriesId === 'serie-a2') {
      return [
        makeSubject('anglais', 'Anglais / LV', 'Languages', 'red', 'terminale-a2', 'Terminale A2', languesA2),
        makeSubject('francais', 'Français', 'BookOpen', 'amber', 'terminale-a2', 'Terminale A2', francaisA1.slice(0, 1)),
      ];
    }
    if (seriesId === 'serie-b') {
      return [
        makeSubject('ses', 'SES / Économie', 'TrendingUp', 'emerald', 'terminale-b', 'Terminale B', sesB),
      ];
    }
    if (seriesId === 'serie-c') {
      return [
        makeSubject('physique-chimie', 'Physique-Chimie (C)', 'Atom', 'indigo', 'terminale-c-plus', 'Terminale C', pcC),
        makeSubject('mathematiques', 'Mathématiques (C)', 'Calculator', 'blue', 'terminale-c-plus', 'Terminale C', mathsS),
      ];
    }
    if (seriesId === 'serie-d') {
      return [
        makeSubject('svt', 'SVT (D)', 'Leaf', 'green', 'terminale-d-plus', 'Terminale D', svtD),
        makeSubject('mathematiques', 'Mathématiques (D)', 'Calculator', 'blue', 'terminale-d-plus', 'Terminale D', mathsS.slice(0, 1)),
      ];
    }
  }

  return [];
}

/** Métadonnées de couverture pour rapport / IA */
export type CoverageStatus = 'VERIFIE' | 'PARTAGE' | 'A_CONFIRMER' | 'MANQUANT';

export interface CoverageRow {
  level: string;
  seriesId: string;
  seriesLabel: string;
  subjectName: string;
  status: CoverageStatus;
  source: string;
  notes?: string;
}

export function buildCoverageMatrix(): CoverageRow[] {
  const rows: CoverageRow[] = [];
  const add = (level: string, seriesId: string, label: string, subjectName: string, status: CoverageStatus, source: string, notes?: string) => {
    rows.push({ level, seriesId, seriesLabel: label, subjectName, status, source, notes });
  };

  // Seconde
  add('seconde', 'serie-le', 'Seconde LE', 'Tronc commun (maths, fr, …)', 'PARTAGE', 'getSecondeSubjects+V26+extra', 'Tronc commun légitime');
  add('seconde', 'serie-le', 'Seconde LE', 'Initiation économique', 'VERIFIE', 'seriesPedagogy', 'Orientation LE documentée');
  add('seconde', 'serie-s', 'Seconde S', 'Tronc commun', 'PARTAGE', 'getSecondeSubjects+…', 'Tronc commun légitime');
  add('seconde', 'serie-s', 'Seconde S', 'Méthode scientifique / Maths S', 'VERIFIE', 'seriesPedagogy', 'Orientation S');

  // Première
  add('premiere', 'serie-a1', 'Première A1', 'Français, Philosophie, Maths', 'VERIFIE', 'seriesPedagogy', 'A1 : fr/philo/maths');
  add('premiere', 'serie-a2', 'Première A2', 'Français, Langues', 'VERIFIE', 'seriesPedagogy', 'A2 : langues');
  add('premiere', 'serie-b', 'Première B', 'SES, Maths appliquées', 'VERIFIE', 'seriesPedagogy', 'B : économie');
  add('premiere', 'serie-s', 'Première S', 'Maths, PC', 'VERIFIE', 'seriesPedagogy+legacy C', 'S scientifique');
  add('premiere', 'serie-a', 'Série A legacy', 'Pack littéraire historique', 'A_CONFIRMER', 'lycee-universite serie-a', 'Non subdivisé A1/A2/B dans l’ancien pack');
  add('premiere', 'serie-c', 'Série C legacy', 'Pack scientifique C', 'VERIFIE', 'lycee-universite serie-c', 'Conservé');
  add('premiere', 'serie-d', 'Série D legacy', 'Pack scientifique D', 'VERIFIE', 'lycee-universite serie-d', 'Conservé');

  // Terminale
  add('terminale', 'serie-a1', 'Terminale A1', 'Philosophie, Français', 'VERIFIE', 'seriesPedagogy', 'A1 lettres/philo');
  add('terminale', 'serie-a2', 'Terminale A2', 'Langues, Français', 'VERIFIE', 'seriesPedagogy', 'A2 langues');
  add('terminale', 'serie-b', 'Terminale B', 'SES', 'VERIFIE', 'seriesPedagogy', 'B éco');
  add('terminale', 'serie-c', 'Terminale C', 'Maths, PC (+ legacy C)', 'VERIFIE', 'lycee+seriesPedagogy', 'C');
  add('terminale', 'serie-d', 'Terminale D', 'SVT, Maths (+ legacy D)', 'VERIFIE', 'lycee+seriesPedagogy', 'D');

  // Manques explicites (pas inventés)
  add('premiere', 'serie-a1', 'Première A1', 'Programme officiel exhaustif toutes matières', 'MANQUANT', '—', 'Pas de reproduction du programme officiel complet');
  add('premiere', 'serie-a2', 'Première A2', 'Espagnol (LV2) complet', 'MANQUANT', '—', 'Pack LV concentré anglais ; espagnol à enrichir');
  add('terminale', 'serie-a1', 'Terminale A1', 'Histoire-Géo coefficient complet', 'MANQUANT', '—', 'HG série-spécifique non détaillé ici');
  add('seconde', 'serie-le', 'Seconde LE', 'Grille horaire officielle complète', 'MANQUANT', '—', 'Référence pédagogique, pas fac-similé officiel');

  return rows;
}
