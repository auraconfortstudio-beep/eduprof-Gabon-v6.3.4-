import {
  Calculator, BookOpen, Globe, Landmark, Map, Languages, Activity,
  Leaf, Atom, Cog, Palette, Music, Brain, TrendingUp, Scale,
  Database, Code, HeartPulse, BarChart3, GraduationCap, BookMarked,
  Award, School, type LucideIcon,
} from 'lucide-react';

const iconMap: Record<string, LucideIcon> = {
  Calculator, BookOpen, Globe, Landmark, Map, Languages, Activity,
  Leaf, Atom, Cog, Palette, Music, Brain, TrendingUp, Scale,
  Database, Code, HeartPulse, BarChart3, GraduationCap, BookMarked,
  Award, School,
};

export function getIcon(name: string): LucideIcon {
  return iconMap[name] ?? BookOpen;
}
