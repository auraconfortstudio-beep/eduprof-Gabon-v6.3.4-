/** Toast UI natif léger — inspiration react-hot-toast, sans dépendance */
export type ToastKind = 'success' | 'error' | 'info' | 'loading';

export interface ToastItem {
  id: string;
  kind: ToastKind;
  message: string;
  createdAt: number;
}

type Listener = (items: ToastItem[]) => void;

let items: ToastItem[] = [];
const listeners = new Set<Listener>();

function emit() {
  for (const l of listeners) l([...items]);
}

export function subscribeToasts(fn: Listener): () => void {
  listeners.add(fn);
  fn([...items]);
  return () => listeners.delete(fn);
}

export function showToast(message: string, kind: ToastKind = 'info', ms = 3200): string {
  const id = `t-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
  items = [...items, { id, kind, message, createdAt: Date.now() }].slice(-5);
  emit();
  if (kind !== 'loading' && ms > 0) {
    setTimeout(() => dismissToast(id), ms);
  }
  return id;
}

export function dismissToast(id: string) {
  items = items.filter((t) => t.id !== id);
  emit();
}
