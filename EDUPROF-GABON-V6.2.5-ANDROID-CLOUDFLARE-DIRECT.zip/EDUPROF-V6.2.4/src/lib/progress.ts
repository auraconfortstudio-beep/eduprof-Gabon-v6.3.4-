import { api } from './api';

/** Ancienne clé globale (≤ V3.5.2) — ne plus écrire dedans (partageait les leçons entre comptes). */
const LEGACY_GLOBAL_KEY = 'eduprof_completed_lessons';

function storageKey(userId?: string | null): string {
  if (userId && String(userId).trim()) return `eduprof_completed_lessons:uid:${userId}`;
  return 'eduprof_completed_lessons:guest';
}

function readLocalLessons(userId?: string | null): string[] {
  try {
    const raw = localStorage.getItem(storageKey(userId));
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed.filter((x) => typeof x === 'string') : [];
  } catch {
    return [];
  }
}

function writeLocalLessons(userId: string | null | undefined, ids: string[]) {
  try {
    localStorage.setItem(storageKey(userId), JSON.stringify([...new Set(ids)]));
  } catch {
    /* quota / private mode */
  }
}

/**
 * True si la leçon est marquée complète **pour ce compte** (ou invité).
 * Isolation stricte par userId — plus de clé globale partagée.
 */
export function isLessonCompletedLocally(lessonId: string, userId?: string | null): boolean {
  return readLocalLessons(userId).includes(lessonId);
}

export function markLessonCompletedLocally(lessonId: string, userId?: string | null) {
  const ids = readLocalLessons(userId);
  if (!ids.includes(lessonId)) {
    ids.push(lessonId);
    writeLocalLessons(userId, ids);
  }
}

export function getLocalCompletedLessons(userId?: string | null): string[] {
  return readLocalLessons(userId);
}

/** Nettoie l’ancienne clé globale (sans migrer vers un compte — évite de polluer un autre user). */
export function clearLegacyGlobalLessonProgress() {
  try {
    localStorage.removeItem(LEGACY_GLOBAL_KEY);
  } catch {
    /* ignore */
  }
}

function isGuestUser(userId?: string | null): boolean {
  return !userId || !String(userId).trim();
}

export type CompleteLessonResult = {
  completed: boolean;
  xpAwarded: boolean;
  xpGain: number;
  localOnly?: boolean;
  error?: string;
};

/**
 * Marque une leçon comme terminée.
 *
 * - Invité : persistance locale uniquement (pas de serveur).
 * - Compte connecté : le serveur est la source de vérité.
 *   Le cache local n’est écrit qu’après confirmation.
 *   En cas d’échec : completed=false, pas d’écriture locale, error renseignée.
 */
export async function completeLesson(
  lessonId: string,
  userId?: string | null
): Promise<CompleteLessonResult> {
  if (isGuestUser(userId)) {
    markLessonCompletedLocally(lessonId, userId);
    return {
      completed: true,
      xpAwarded: false,
      xpGain: 0,
      localOnly: true,
    };
  }

  try {
    const res = await api.completeLesson(lessonId);
    const completed = res.completed === true;
    if (completed) {
      markLessonCompletedLocally(lessonId, userId);
    }
    return {
      completed,
      xpAwarded: res.xpAwarded === true,
      xpGain: typeof res.xpGain === 'number' ? res.xpGain : 0,
    };
  } catch (e: unknown) {
    const message = e instanceof Error ? e.message : String(e);
    return {
      completed: false,
      xpAwarded: false,
      xpGain: 0,
      error: message,
    };
  }
}

export async function completeExercise(exerciseId: string, selectedAnswer: number) {
  try {
    const res = await api.completeExercise(exerciseId, selectedAnswer);
    return {
      recorded: res.recorded,
      xpAwarded: res.xpAwarded,
      xpGain: res.xpGain,
      wasCorrect: res.wasCorrect,
    };
  } catch (e: unknown) {
    const message = e instanceof Error ? e.message : String(e);
    return {
      recorded: false,
      xpAwarded: false,
      xpGain: 0,
      wasCorrect: false,
      error: message,
    };
  }
}

export async function submitQuiz(subjectId: string, quizId: string, answers: number[]) {
  try {
    const res = await api.submitQuiz({ quizId, subjectId, answers });
    return {
      recorded: res.recorded,
      xpAwarded: res.xpAwarded,
      xpAmount: res.xpAmount,
      score: res.score,
      totalQuestions: res.totalQuestions,
    };
  } catch (e: unknown) {
    const message = e instanceof Error ? e.message : String(e);
    return {
      recorded: false,
      xpAwarded: false,
      xpAmount: 0,
      score: 0,
      totalQuestions: 0,
      error: message,
    };
  }
}

export async function getProgress() {
  try {
    return await api.getProgress();
  } catch (e) {
    console.error('getProgress failed:', e);
    return null;
  }
}
