/** Numéro officiel paiement / support EduProf Gabon */
export const WHATSAPP_NUMBER = '065607226';
export const WHATSAPP_DISPLAY = '+241 065 607 226';
export const PREMIUM_DAILY = 500;
export const PREMIUM_MONTHLY = 4000;

/** XP centralisés — doivent correspondre au serveur */
export const XP_LESSON = 10;
export const XP_EXERCISE = 15;
export const XP_QUIZ_MAX = 50;

export function whatsappLink(message: string): string {
  const encoded = encodeURIComponent(message);
  return `https://wa.me/241${WHATSAPP_NUMBER}?text=${encoded}`;
}

export const PREMIUM_PAYMENT_MESSAGE =
  'Bonjour EduProf Gabon, je viens d\'effectuer mon paiement Premium. Voici mes informations et ma preuve de paiement.';

export const SUPPORT_MESSAGE =
  'Bonjour EduProf Gabon, j\'ai besoin d\'aide concernant l\'application.';
