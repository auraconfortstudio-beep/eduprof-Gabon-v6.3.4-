import { api } from './api';

export interface TutorAttachmentRef {
  id: string;
  fileName: string;
  mimeType: string;
  size: number;
}

export interface TutorRequest {
  level?: string;
  className?: string;
  series?: string | null;
  filiere?: string | null;
  subject?: string | null;
  subjectId?: string | null;
  subjectName?: string | null;
  chapterId?: string | null;
  chapterName?: string | null;
  lesson?: string | null;
  lessonId?: string | null;
  lessonTitle?: string | null;
  question: string;
  history?: { role: string; content: string }[];
  conversationId?: string | null;
  /** IDs des pièces jointes déjà uploadées (stockage serveur isolé). */
  attachmentIds?: string[];
  /** Métadonnées pour affichage / historique local. */
  attachments?: TutorAttachmentRef[];
}

export async function askTutor(
  req: TutorRequest
): Promise<{ content: string; provider?: string; conversationId?: string | null }> {
  const messages = [
    ...(req.history || []),
    {
      role: 'user',
      content: req.question,
      ...(req.attachments && req.attachments.length
        ? { attachments: req.attachments }
        : {}),
    },
  ];
  const context: Record<string, string> = {};
  if (req.level) context.level = req.level;
  if (req.subjectName || req.subject) context.subjectName = (req.subjectName || req.subject)!;
  if (req.subjectId) context.subjectId = req.subjectId;
  if (req.chapterId) context.chapterId = req.chapterId;
  if (req.chapterName) context.chapterName = req.chapterName;
  if (req.lessonId) context.lessonId = req.lessonId;
  if (req.lessonTitle || req.lesson) context.lessonTitle = (req.lessonTitle || req.lesson)!;
  if (req.series) context.series = req.series;
  if (req.filiere) context.filiere = req.filiere;

  const res = await api.aiTutor(
    messages,
    context,
    req.conversationId,
    req.attachmentIds
  );
  return { content: res.reply, provider: res.provider, conversationId: res.conversationId };
}
