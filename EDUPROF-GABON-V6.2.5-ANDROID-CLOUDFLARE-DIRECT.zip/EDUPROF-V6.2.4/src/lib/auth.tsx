import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import { api, setToken } from './api';
import { errorMessage } from './errors';
import type { EduProfUser } from '@/types/user';
import { clearLegacyGlobalLessonProgress } from './progress';

function toProfile(u: EduProfUser): Profile {
  return {
    id: u.id,
    displayName: u.displayName,
    email: u.email,
    educationLevel: u.educationLevel || 'cm2',
    educationSeries: u.educationSeries ?? null,
    educationFiliere: u.educationFiliere ?? null,
    role: u.role,
    isPremium: !!u.isPremium,
    premiumUntil: u.premiumUntil ?? null,
    xp: u.xp ?? 0,
    streak: u.streak ?? 0,
    lastActivityDate: u.lastActivityDate ?? null,
    createdAt: u.createdAt,
    isDemo: u.isDemo,
  };
}


export interface Profile {
  id: string;
  displayName: string;
  email?: string;
  educationLevel: string;
  educationSeries: string | null;
  educationFiliere: string | null;
  role?: string;
  isPremium: boolean;
  premiumUntil: string | null;
  xp: number;
  streak: number;
  lastActivityDate?: string | null;
  createdAt?: string;
  isDemo?: boolean;
}

interface AuthContextType {
  user: Profile | null;
  profile: Profile | null;
  isAdmin: boolean;
  isOwner: boolean;
  loading: boolean;
  signUp: (
    email: string,
    password: string,
    displayName: string,
    educationLevel?: string,
    educationSeries?: string | null,
    educationFiliere?: string | null
  ) => Promise<{ error: string | null }>;
  signIn: (email: string, password: string) => Promise<{ error: string | null }>;
  startDemo: () => Promise<{ error: string | null }>;
  signOut: () => Promise<void>;
  updateProfile: (updates: {
    displayName?: string;
    educationLevel?: string;
    educationSeries?: string | null;
    educationFiliere?: string | null;
  }) => Promise<{ error: string | null }>;
  refreshProfile: () => Promise<void>;
  getAllProfiles: () => Promise<{ data: Profile[] | null; error: string | null }>;
  setUserPremium: (targetUserId: string, isPremium: boolean, days: number) => Promise<{ error: string | null }>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  async function loadMe() {
    try {
      const { user: u } = await api.me();
      setUser(toProfile(u));
    } catch {
      setToken(null);
      setUser(null);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    const token = localStorage.getItem('eduprof_token');
    if (token) loadMe();
    else setLoading(false);
  }, []);

  const signUp = async (
    email: string,
    password: string,
    displayName: string,
    educationLevel?: string,
    educationSeries?: string | null,
    educationFiliere?: string | null
  ) => {
    try {
      const { token, user: u } = await api.signup({
        email,
        password,
        displayName,
        educationLevel,
        educationSeries,
        educationFiliere,
      });
      if (!token) return { error: 'Inscription OK mais jeton manquant. Réessaie.' };
      setToken(token);
      setUser(toProfile(u));
      clearLegacyGlobalLessonProgress();
      return { error: null };
    } catch (e: unknown) {
      return { error: errorMessage(e, 'Erreur inscription') };
    }
  };

  const signIn = async (email: string, password: string) => {
    try {
      const { token, user: u } = await api.login(email, password);
      if (!token) return { error: 'Connexion OK mais jeton manquant. Réessaie.' };
      setToken(token);
      setUser(toProfile(u));
      // Ne pas hériter des leçons locales de l’ancienne clé globale partagée
      clearLegacyGlobalLessonProgress();
      return { error: null };
    } catch (e: unknown) {
      return { error: errorMessage(e, 'Erreur connexion') };
    }
  };

  const startDemo = async () => {
    try {
      const { token, user: u } = await api.startDemo();
      if (!token) return { error: 'Démo indisponible. Réessaie.' };
      setToken(token);
      setUser(toProfile(u));
      clearLegacyGlobalLessonProgress();
      return { error: null };
    } catch (e: unknown) {
      return { error: errorMessage(e, 'Erreur démo') };
    }
  };

  const signOut = async () => {
    setToken(null);
    setUser(null);
    clearLegacyGlobalLessonProgress();
  };

  const updateProfile = async (updates: Record<string, unknown>) => {
    try {
      const { user: u } = await api.updateProfile(updates);
      setUser(toProfile(u));
      return { error: null };
    } catch (e: unknown) {
      return { error: errorMessage(e) };
    }
  };

  const refreshProfile = async () => {
    await loadMe();
  };

  const getAllProfiles = async () => {
    try {
      const { users } = await api.adminUsers();
      return { data: users, error: null };
    } catch (e: unknown) {
      return { data: null, error: errorMessage(e) };
    }
  };

  const setUserPremium = async (targetUserId: string, isPremium: boolean, days: number) => {
    try {
      await api.setPremium(targetUserId, isPremium, days);
      return { error: null };
    } catch (e: unknown) {
      return { error: errorMessage(e) };
    }
  };

  const isAdmin = !!user && (user.role === 'ADMIN' || user.role === 'OWNER');
  const isOwner = !!user && user.role === 'OWNER';

  return (
    <AuthContext.Provider
      value={{
        user,
        profile: user,
        isAdmin,
        isOwner,
        loading,
        signUp,
        signIn,
        startDemo,
        signOut,
        updateProfile,
        refreshProfile,
        getAllProfiles,
        setUserPremium,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
