import { ApiError } from './errors';
import type { EduProfUser, AuthTokenResponse } from '@/types/user';

const API_BASE = '/api';

const TOKEN_KEY = 'eduprof_token';

function getToken(): string | null {
  try {
    const t = localStorage.getItem(TOKEN_KEY);
    if (t && t.trim()) return t.trim();
  } catch {
    /* private mode */
  }
  return null;
}

export function setToken(token: string | null) {
  try {
    if (token && token.trim()) {
      localStorage.setItem(TOKEN_KEY, token.trim());
    } else {
      localStorage.removeItem(TOKEN_KEY);
    }
  } catch {
    /* ignore */
  }
}

/** Headers d'auth pour toutes les requêtes API (Bearer + secours X-EduProf). */
export function authHeaders(): Record<string, string> {
  const token = getToken();
  if (!token) return {};
  return {
    Authorization: `Bearer ${token}`,
    'X-EduProf-Authorization': `Bearer ${token}`,
  };
}

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...authHeaders(),
    ...(options.headers as Record<string, string>),
  };

  const res = await fetch(`${API_BASE}${path}`, { ...options, headers });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    if (res.status === 404) {
      throw new ApiError(
        'Erreur 404 — API introuvable. En local lancez « npm run dev » (plugin API Worker). En production le Worker Cloudflare sert /api/*.',
        { status: 404, code: 'not_found' }
      );
    }
    if (res.status === 401) {
      throw new ApiError(
        (data as { error?: string }).error || 'Session expirée ou non authentifié.',
        { status: 401, code: 'unauthorized' }
      );
    }
    throw new ApiError(
      (data as { error?: string }).error || `Erreur ${res.status}`,
      { status: res.status }
    );
  }
  return data as T;
}

export const api = {
  signup: (body: {
    email: string;
    password: string;
    displayName: string;
    educationLevel?: string;
    educationSeries?: string | null;
    educationFiliere?: string | null;
  }) => request<AuthTokenResponse>('/auth/signup', { method: 'POST', body: JSON.stringify(body) }),

  login: (email: string, password: string) =>
    request<AuthTokenResponse>('/auth/login', { method: 'POST', body: JSON.stringify({ email, password }) }),

  startDemo: () =>
    request<AuthTokenResponse>('/auth/demo', { method: 'POST', body: JSON.stringify({}) }),

  me: () => request<{ user: EduProfUser }>('/auth/me'),

  updateProfile: (updates: Record<string, unknown>) =>
    request<{ user: EduProfUser }>('/profile', { method: 'PUT', body: JSON.stringify(updates) }),

  leaderboard: (level?: string) =>
    request<{
      leaderboard: Array<{
        id: string;
        displayName: string;
        educationLevel?: string;
        xp: number;
        isPremium?: boolean;
        rank?: number;
      }>;
      myRank?: { rank: number; xp: number; displayName: string } | null;
    }>(`/leaderboard${level ? `?level=${level}` : ''}`),

  getProgress: () =>
    request<{
      progress: {
        userId?: string;
        lessons?: Array<{ lessonId: string; completedAt?: string }>;
        exercises?: unknown[];
        quizzes?: Array<{ quizId: string; score: number; totalQuestions: number }>;
        xpHistory?: Array<{ amount: number; reason: string; at?: string }>;
      };
      profile: {
        id: string;
        displayName: string;
        xp: number;
        streak: number;
        [key: string]: unknown;
      };
    }>('/progress'),

  completeLesson: (lessonId: string) =>
    request<{ completed: boolean; xpAwarded: boolean; xp: number; xpGain?: number }>('/progress/lesson', {
      method: 'POST',
      body: JSON.stringify({ lessonId }),
    }),

  completeExercise: (exerciseId: string, selectedAnswer: number) =>
    request<{
      recorded: boolean;
      xpAwarded: boolean;
      xp: number;
      xpGain: number;
      wasCorrect: boolean;
    }>('/progress/exercise', {
      method: 'POST',
      body: JSON.stringify({ exerciseId, selectedAnswer }),
    }),

  submitQuiz: (payload: {
    quizId: string;
    subjectId: string;
    answers: number[];
  }) =>
    request<{
      recorded: boolean;
      xpAwarded: boolean;
      xp: number;
      xpAmount: number;
      score: number;
      totalQuestions: number;
    }>('/progress/quiz', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  requestPremium: (plan: 'daily' | 'monthly', proof: string) =>
    request<{ request: any }>('/premium/request', { method: 'POST', body: JSON.stringify({ plan, proof }) }),

  getPremiumRequests: () => request<{ requests: any[] }>('/premium/requests'),

  processPremium: (requestId: string, action: 'approve' | 'reject') =>
    request<{ ok: boolean }>('/premium/process', { method: 'POST', body: JSON.stringify({ requestId, action }) }),


  getAnnales: (params?: { exam?: string; year?: string; subject?: string }) => {
    const q = new URLSearchParams();
    if (params?.exam) q.set('exam', params.exam);
    if (params?.year) q.set('year', params.year);
    if (params?.subject) q.set('subject', params.subject);
    const qs = q.toString();
    return request<{ annales: any[] }>(`/annales${qs ? `?${qs}` : ''}`);
  },

  adminUsers: () => request<{ users: any[] }>('/admin/users'),

  setPremium: (targetUserId: string, isPremium: boolean, days?: number) =>
    request<{ user: EduProfUser }>('/admin/set-premium', {
      method: 'POST',
      body: JSON.stringify({ targetUserId, isPremium, days }),
    }),

  setRole: (targetUserId: string, role: 'ADMIN' | 'USER') =>
    request<{ user: EduProfUser }>('/admin/set-role', { method: 'POST', body: JSON.stringify({ targetUserId, role }) }),

  deleteUser: (targetUserId: string) =>
    request<{ ok: boolean }>('/admin/delete-user', { method: 'POST', body: JSON.stringify({ targetUserId }) }),

  adminLogs: () => request<{ logs: any[] }>('/admin/logs'),

  listInstitutions: () => request<{ establishments: unknown[] }>('/institutions'),
  createInstitution: (body: { name: string; code: string; type?: string }) =>
    request<{ establishment: unknown }>('/institutions', { method: 'POST', body: JSON.stringify(body) }),
  institutionalDashboard: () =>
    request<{
      establishments: number;
      activations: number;
      active: number;
      expired: number;
      expiringSoon: number;
      recentAudit: unknown[];
    }>('/institutional/dashboard'),
  listActivations: (establishmentId?: string) =>
    request<{ activations: unknown[] }>(
      `/activations${establishmentId ? `?establishmentId=${encodeURIComponent(establishmentId)}` : ''}`
    ),
  activateStudent: (targetUserId: string, establishmentId: string, days: number) =>
    request<{ activation: unknown }>('/activations/activate', {
      method: 'POST',
      body: JSON.stringify({ targetUserId, establishmentId, days }),
    }),
  deactivateStudent: (targetUserId: string, establishmentId: string) =>
    request<{ ok: boolean }>('/activations/deactivate', {
      method: 'POST',
      body: JSON.stringify({ targetUserId, establishmentId }),
    }),
  bulkActivate: (userIds: string[], establishmentId: string, days: number) =>
    request<{ success: string[]; failed: { userId: string; reason: string }[] }>('/activations/bulk', {
      method: 'POST',
      body: JSON.stringify({ userIds, establishmentId, days }),
    }),
  previewCsvImport: (csv: string) =>
    request<{ ok: boolean; rows: unknown[]; errors: unknown[] }>('/import/csv/preview', {
      method: 'POST',
      body: JSON.stringify({ csv }),
    }),
  confirmCsvImport: (csv: string) =>
    request<{ created: string[]; failed: unknown[]; createdCount: number; failedCount: number }>(
      '/import/csv/confirm',
      { method: 'POST', body: JSON.stringify({ csv }) }
    ),
  analyticsOverview: (period?: string, establishmentId?: string) => {
    const q = new URLSearchParams();
    if (period) q.set('period', period);
    if (establishmentId) q.set('establishmentId', establishmentId);
    const qs = q.toString();
    return request<{ analytics: Record<string, unknown> }>(`/analytics/overview${qs ? `?${qs}` : ''}`);
  },
  analyticsAudit: (params?: Record<string, string>) => {
    const q = new URLSearchParams(params || {});
    const qs = q.toString();
    return request<{ items: unknown[]; total: number; page: number; pageSize: number }>(
      `/analytics/audit${qs ? `?${qs}` : ''}`
    );
  },
  accessStatus: () =>
    request<{
      allowed: boolean;
      status: string;
      reason: string | null;
      establishmentId: string | null;
      expiresAt: string | null;
    }>('/access/status'),
  listSupportTickets: () => request<{ tickets: unknown[] }>('/support/tickets'),
  createSupportTicket: (body: { subject: string; message: string; category?: string }) =>
    request<{ ticket: unknown }>('/support/tickets', { method: 'POST', body: JSON.stringify(body) }),
  getSupportTicket: (id: string) =>
    request<{ ticket: unknown }>(`/support/tickets/get?id=${encodeURIComponent(id)}`),
  replySupportTicket: (id: string, message: string) =>
    request<{ ticket: unknown }>('/support/tickets/reply', {
      method: 'POST',
      body: JSON.stringify({ id, message }),
    }),
  listNotifications: (page?: number) =>
    request<{ items: unknown[]; unread: number; total: number }>(
      `/notifications${page ? `?page=${page}` : ''}`
    ),
  markNotificationRead: (id: string) =>
    request<{ ok: boolean }>('/notifications/read', { method: 'POST', body: JSON.stringify({ id }) }),
  markAllNotificationsRead: () =>
    request<{ count: number }>('/notifications/read-all', { method: 'POST', body: '{}' }),
  studentProgress: (userId?: string) =>
    request<{ summary: Record<string, unknown> }>(
      `/student/progress${userId ? `?userId=${encodeURIComponent(userId)}` : ''}`
    ),
  institutionalAudit: () => request<{ logs: unknown[] }>('/institutional/audit'),

  /**
   * Professeur IA — passe par /api/ai-tutor (Vite dev + Cloudflare Worker prod).
   * Timeout 25s pour ne jamais laisser l'UI bloquée sur « réfléchit… ».
   */
  aiTutor: async (
    messages: { role: string; content: string; attachments?: { id: string; fileName: string; mimeType: string; size: number }[] }[],
    context?: Record<string, string>,
    conversationId?: string | null,
    attachmentIds?: string[]
  ): Promise<{ reply: string; provider: string; conversationId?: string | null }> => {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 25_000);
    try {
      const token = getToken();
      if (!token) {
        throw new Error('Connexion requise pour utiliser le Professeur IA.');
      }
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
        ...authHeaders(),
      };

      const res = await fetch(`${API_BASE}/ai-tutor`, {
        method: 'POST',
        headers,
        // token aussi dans le body : secours si Authorization est retiré par un proxy/rewrite
        body: JSON.stringify({
          messages,
          context,
          token,
          conversationId: conversationId || undefined,
          attachmentIds: attachmentIds && attachmentIds.length ? attachmentIds : undefined,
        }),
        signal: controller.signal,
      });

      const data = await res.json().catch(() => ({} as { error?: string; reply?: string; provider?: string }));

      if (!res.ok) {
        if (res.status === 401) {
          throw new Error(
            (data as { error?: string }).error ||
              'Connexion requise pour utiliser le Professeur IA.'
          );
        }
        if (res.status === 404) {
          throw new Error(
            'Service IA introuvable. Vérifie le déploiement ou réessaie plus tard.'
          );
        }
        throw new Error((data as { error?: string }).error || `Erreur IA (${res.status})`);
      }

      return {
        reply: (data as { reply: string }).reply,
        provider: (data as { provider?: string }).provider || 'unknown',
        conversationId: (data as { conversationId?: string | null }).conversationId ?? null,
      };
    } catch (err: unknown) {
      if (err instanceof Error && err.name === 'AbortError') {
        throw new Error(
          "Délai dépassé. Le Professeur IA ne répond pas pour le moment. Réessaie."
        );
      }
      throw err;
    } finally {
      clearTimeout(timeoutId);
    }
  },

  listConversations: () =>
    request<{ conversations: any[] }>('/conversations'),

  getConversation: (id: string) =>
    request<{ conversation: any }>(`/conversations/get?id=${encodeURIComponent(id)}`),

  createConversation: (opts: {
    lessonId?: string | null;
    levelId?: string | null;
    seriesId?: string | null;
    subjectId?: string | null;
    subjectName?: string | null;
    chapterId?: string | null;
    lessonTitle?: string | null;
  }) => request<{ conversation: any }>('/conversations', { method: 'POST', body: JSON.stringify(opts) }),

  deleteConversation: (id: string) =>
    request<{ ok: boolean }>('/conversations/delete', { method: 'POST', body: JSON.stringify({ id }) }),

  uploadAttachment: (opts: {
    fileName: string;
    mimeType: string;
    size: number;
    data: string;
    conversationId?: string | null;
    lessonId?: string | null;
  }) =>
    request<{
      attachment: { id: string; fileName: string; mimeType: string; size: number; createdAt: string };
    }>('/attachments/upload', { method: 'POST', body: JSON.stringify(opts) }),

  deleteAttachment: (id: string) =>
    request<{ ok: boolean }>('/attachments/delete', { method: 'POST', body: JSON.stringify({ id }) }),
};
