/** Classes Tailwind complètes (JIT) — ne pas construire via template strings. */
export type ThemeColor =
  | 'blue' | 'cyan' | 'teal' | 'green' | 'emerald' | 'lime'
  | 'amber' | 'orange' | 'red' | 'rose' | 'pink'
  | 'purple' | 'violet' | 'indigo' | 'fuchsia' | 'gray';

export interface ColorClasses {
  gradientFrom: string;
  gradientTo: string;
  bg50: string;
  bg100: string;
  bg600: string;
  bg700: string;
  text600: string;
  text700: string;
  border100: string;
  border500: string;
  borderHover: string;
}

const MAP: Record<string, ColorClasses> = {
  blue: {
    gradientFrom: 'from-blue-600', gradientTo: 'to-blue-700',
    bg50: 'bg-blue-50', bg100: 'bg-blue-100', bg600: 'bg-blue-600', bg700: 'bg-blue-700',
    text600: 'text-blue-600', text700: 'text-blue-700',
    border100: 'border-blue-100', border500: 'border-blue-500', borderHover: 'hover:bg-blue-100',
  },
  cyan: {
    gradientFrom: 'from-cyan-600', gradientTo: 'to-cyan-700',
    bg50: 'bg-cyan-50', bg100: 'bg-cyan-100', bg600: 'bg-cyan-600', bg700: 'bg-cyan-700',
    text600: 'text-cyan-600', text700: 'text-cyan-700',
    border100: 'border-cyan-100', border500: 'border-cyan-500', borderHover: 'hover:bg-cyan-100',
  },
  teal: {
    gradientFrom: 'from-teal-600', gradientTo: 'to-teal-700',
    bg50: 'bg-teal-50', bg100: 'bg-teal-100', bg600: 'bg-teal-600', bg700: 'bg-teal-700',
    text600: 'text-teal-600', text700: 'text-teal-700',
    border100: 'border-teal-100', border500: 'border-teal-500', borderHover: 'hover:bg-teal-100',
  },
  green: {
    gradientFrom: 'from-green-600', gradientTo: 'to-green-700',
    bg50: 'bg-green-50', bg100: 'bg-green-100', bg600: 'bg-green-600', bg700: 'bg-green-700',
    text600: 'text-green-600', text700: 'text-green-700',
    border100: 'border-green-100', border500: 'border-green-500', borderHover: 'hover:bg-green-100',
  },
  emerald: {
    gradientFrom: 'from-emerald-600', gradientTo: 'to-emerald-700',
    bg50: 'bg-emerald-50', bg100: 'bg-emerald-100', bg600: 'bg-emerald-600', bg700: 'bg-emerald-700',
    text600: 'text-emerald-600', text700: 'text-emerald-700',
    border100: 'border-emerald-100', border500: 'border-emerald-500', borderHover: 'hover:bg-emerald-100',
  },
  lime: {
    gradientFrom: 'from-lime-600', gradientTo: 'to-lime-700',
    bg50: 'bg-lime-50', bg100: 'bg-lime-100', bg600: 'bg-lime-600', bg700: 'bg-lime-700',
    text600: 'text-lime-600', text700: 'text-lime-700',
    border100: 'border-lime-100', border500: 'border-lime-500', borderHover: 'hover:bg-lime-100',
  },
  amber: {
    gradientFrom: 'from-amber-600', gradientTo: 'to-amber-700',
    bg50: 'bg-amber-50', bg100: 'bg-amber-100', bg600: 'bg-amber-600', bg700: 'bg-amber-700',
    text600: 'text-amber-600', text700: 'text-amber-700',
    border100: 'border-amber-100', border500: 'border-amber-500', borderHover: 'hover:bg-amber-100',
  },
  orange: {
    gradientFrom: 'from-orange-600', gradientTo: 'to-orange-700',
    bg50: 'bg-orange-50', bg100: 'bg-orange-100', bg600: 'bg-orange-600', bg700: 'bg-orange-700',
    text600: 'text-orange-600', text700: 'text-orange-700',
    border100: 'border-orange-100', border500: 'border-orange-500', borderHover: 'hover:bg-orange-100',
  },
  red: {
    gradientFrom: 'from-red-600', gradientTo: 'to-red-700',
    bg50: 'bg-red-50', bg100: 'bg-red-100', bg600: 'bg-red-600', bg700: 'bg-red-700',
    text600: 'text-red-600', text700: 'text-red-700',
    border100: 'border-red-100', border500: 'border-red-500', borderHover: 'hover:bg-red-100',
  },
  rose: {
    gradientFrom: 'from-rose-600', gradientTo: 'to-rose-700',
    bg50: 'bg-rose-50', bg100: 'bg-rose-100', bg600: 'bg-rose-600', bg700: 'bg-rose-700',
    text600: 'text-rose-600', text700: 'text-rose-700',
    border100: 'border-rose-100', border500: 'border-rose-500', borderHover: 'hover:bg-rose-100',
  },
  pink: {
    gradientFrom: 'from-pink-600', gradientTo: 'to-pink-700',
    bg50: 'bg-pink-50', bg100: 'bg-pink-100', bg600: 'bg-pink-600', bg700: 'bg-pink-700',
    text600: 'text-pink-600', text700: 'text-pink-700',
    border100: 'border-pink-100', border500: 'border-pink-500', borderHover: 'hover:bg-pink-100',
  },
  purple: {
    gradientFrom: 'from-purple-600', gradientTo: 'to-purple-700',
    bg50: 'bg-purple-50', bg100: 'bg-purple-100', bg600: 'bg-purple-600', bg700: 'bg-purple-700',
    text600: 'text-purple-600', text700: 'text-purple-700',
    border100: 'border-purple-100', border500: 'border-purple-500', borderHover: 'hover:bg-purple-100',
  },
  violet: {
    gradientFrom: 'from-violet-600', gradientTo: 'to-violet-700',
    bg50: 'bg-violet-50', bg100: 'bg-violet-100', bg600: 'bg-violet-600', bg700: 'bg-violet-700',
    text600: 'text-violet-600', text700: 'text-violet-700',
    border100: 'border-violet-100', border500: 'border-violet-500', borderHover: 'hover:bg-violet-100',
  },
  indigo: {
    gradientFrom: 'from-indigo-600', gradientTo: 'to-indigo-700',
    bg50: 'bg-indigo-50', bg100: 'bg-indigo-100', bg600: 'bg-indigo-600', bg700: 'bg-indigo-700',
    text600: 'text-indigo-600', text700: 'text-indigo-700',
    border100: 'border-indigo-100', border500: 'border-indigo-500', borderHover: 'hover:bg-indigo-100',
  },
  fuchsia: {
    gradientFrom: 'from-fuchsia-600', gradientTo: 'to-fuchsia-700',
    bg50: 'bg-fuchsia-50', bg100: 'bg-fuchsia-100', bg600: 'bg-fuchsia-600', bg700: 'bg-fuchsia-700',
    text600: 'text-fuchsia-600', text700: 'text-fuchsia-700',
    border100: 'border-fuchsia-100', border500: 'border-fuchsia-500', borderHover: 'hover:bg-fuchsia-100',
  },
  gray: {
    gradientFrom: 'from-gray-600', gradientTo: 'to-gray-700',
    bg50: 'bg-gray-50', bg100: 'bg-gray-100', bg600: 'bg-gray-600', bg700: 'bg-gray-700',
    text600: 'text-gray-600', text700: 'text-gray-700',
    border100: 'border-gray-100', border500: 'border-gray-500', borderHover: 'hover:bg-gray-100',
  },
};

export function theme(color: string | undefined): ColorClasses {
  return MAP[color || ''] || MAP.blue;
}
