/**
 * Erreurs API / réseau — messages sûrs pour l'élève (pas de stack / secrets).
 */
export class ApiError extends Error {
  readonly status?: number;
  readonly code?: string;

  constructor(message: string, opts?: { status?: number; code?: string }) {
    super(message);
    this.name = 'ApiError';
    this.status = opts?.status;
    this.code = opts?.code;
  }
}

export function errorMessage(err: unknown, fallback = 'Une erreur est survenue. Réessaie.'): string {
  if (err instanceof ApiError) return err.message || fallback;
  if (err instanceof Error && err.message) {
    const m = err.message.trim();
    if (/secret|jwt|password|api[_-]?key/i.test(m) && m.length > 120) {
      return fallback;
    }
    return m;
  }
  if (typeof err === 'string' && err.trim()) return err.trim();
  return fallback;
}
