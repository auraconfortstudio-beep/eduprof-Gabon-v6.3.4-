/**
 * Rôles EduProf — socle V4.
 * RBAC complet (établissements, enseignants) = blocs futurs.
 */
export type Role =
  | 'OWNER'
  | 'ADMIN'
  | 'USER'
  | 'ESTABLISHMENT_ADMIN'
  | 'TEACHER'
  | 'STUDENT';

/** Rôles réellement utilisables aujourd'hui (JWT / store). */
export type ActiveRole = 'OWNER' | 'ADMIN' | 'USER';

export function isActiveRole(r: string | undefined | null): r is ActiveRole {
  return r === 'OWNER' || r === 'ADMIN' || r === 'USER';
}

export function isAdminRole(r: string | undefined | null): boolean {
  return r === 'ADMIN' || r === 'OWNER';
}

export function isOwnerRole(r: string | undefined | null): boolean {
  return r === 'OWNER';
}
