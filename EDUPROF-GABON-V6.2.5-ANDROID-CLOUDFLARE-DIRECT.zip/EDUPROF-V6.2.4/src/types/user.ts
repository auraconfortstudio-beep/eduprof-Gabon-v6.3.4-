import type { ActiveRole } from './roles';

/** Profil utilisateur côté client (aligné sur le backend / auth.tsx Profile). */
export interface EduProfUser {
  id: string;
  email: string;
  displayName: string;
  role: ActiveRole | string;
  educationLevel?: string | null;
  educationSeries?: string | null;
  educationFiliere?: string | null;
  isPremium?: boolean;
  premiumUntil?: string | null;
  xp?: number;
  streak?: number;
  lastActivityDate?: string | null;
  isDemo?: boolean;
  createdAt?: string;
}

export interface AuthTokenResponse {
  token: string;
  user: EduProfUser;
}
