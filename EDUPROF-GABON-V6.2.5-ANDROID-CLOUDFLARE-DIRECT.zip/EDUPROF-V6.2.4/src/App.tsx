import { ToastHost } from '@/components/ToastHost';
import { OfflineBanner } from '@/components/OfflineBanner';
import { PWAUpdatePrompt } from '@/components/PWAUpdatePrompt';
import { NotificationsPage } from '@/components/NotificationsPage';
import { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from '@/lib/auth';
import { HomePage } from '@/components/HomePage';
import { LevelPage } from '@/components/LevelPage';
import { SubjectPage } from '@/components/SubjectPage';
import { AITutorPage } from '@/components/AITutorPage';
import { AnnalesPage } from '@/components/AnnalesPage';
import { ProgressPage } from '@/components/ProgressPage';
import { PremiumPage } from '@/components/PremiumPage';
import { AuthPage } from '@/components/AuthPage';
import { AdminPage } from '@/components/AdminPage';
import { InfoPage } from '@/components/InfoPage';
import { SearchModal } from '@/components/SearchModal';
import { GraduationCap, Home, User, Award, Sparkles, ShieldCheck } from 'lucide-react';

type Page = 'home' | 'level' | 'subject' | 'ai-tutor' | 'annales' | 'progress' | 'premium' | 'auth' | 'admin' | 'info' | 'notifications';

function AppContent() {
  const [page, setPage] = useState<Page>('home');
  const [params, setParams] = useState<Record<string, string>>({});
  const [showSearch, setShowSearch] = useState(false);
  const { user, isAdmin, loading: authLoading } = useAuth();

  function navigate(newPage: string, newParams?: Record<string, string>) {
    if (newPage === 'search') {
      setShowSearch(true);
      return;
    }
    setShowSearch(false);
    setPage(newPage as Page);
    setParams(newParams ?? {});
    window.scrollTo(0, 0);
  }

  // Rediriger vers auth seulement après la fin du chargement auth (évite flash)
  useEffect(() => {
    if (authLoading) return;
    if (!user && page === 'progress') {
      setPage('auth');
    }
  }, [user, page, authLoading]);

  let content;
  if (authLoading && (page === 'progress' || page === 'auth')) {
    // Placeholder stable pendant la restauration de session — pas de bascule Auth ↔ Profil
    content = (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <p className="text-sm text-gray-400">Chargement…</p>
      </div>
    );
  } else if (page === 'auth' && !user) {
    content = <AuthPage onNavigate={navigate} />;
  } else {
    switch (page) {
      case 'home':
        content = <HomePage onNavigate={navigate} />;
        break;
      case 'level':
        content = <LevelPage levelId={params.levelId ?? ''} seriesId={params.seriesId} onNavigate={navigate} />;
        break;
      case 'subject':
        content = <SubjectPage levelId={params.levelId ?? ''} subjectId={params.subjectId ?? ''} seriesId={params.seriesId} onNavigate={navigate} />;
        break;
      case 'ai-tutor':
        content = (
          <AITutorPage
            onNavigate={navigate}
            tutorContext={{
              level: params.levelId || params.level,
              subjectId: params.subjectId,
              subjectName: params.subjectName,
              chapterId: params.chapterId,
              chapterName: params.chapterName,
              lessonId: params.lessonId,
              lessonTitle: params.lessonTitle,
              series: params.seriesId || params.series,
              filiere: params.filiere,
            }}
            prefillQuestion={params.prefillQuestion}
          />
        );
        break;
      case 'annales':
        content = (
          <AnnalesPage
            onNavigate={navigate}
            initialExam={params.exam || params.initialExam}
            initialAnnaleId={params.annaleId}
          />
        );
        break;
      case 'progress':
        content = user ? <ProgressPage onNavigate={navigate} /> : <AuthPage onNavigate={navigate} />;
        break;
      case 'premium':
        content = <PremiumPage onNavigate={navigate} />;
        break;
      case 'auth':
        content = user ? <ProgressPage onNavigate={navigate} /> : <AuthPage onNavigate={navigate} />;
        break;
      case 'admin':
        // UI masquée pour USER ; la vraie protection est côté Cloudflare Worker
        content = isAdmin ? (
          <AdminPage onNavigate={navigate} />
        ) : (
          <div className="min-h-screen flex flex-col items-center justify-center gap-3 p-4">
            <p className="text-gray-600 text-sm">Accès réservé aux administrateurs.</p>
            <button
              type="button"
              onClick={() => navigate('home')}
              className="text-blue-600 text-sm font-medium underline"
            >
              Retour à l&apos;accueil
            </button>
          </div>
        );
        break;
      case 'info':
        content = <InfoPage onNavigate={navigate} section={params.section} />;
        break;
      case 'notifications':
        content = <NotificationsPage onNavigate={navigate} />;
        break;
      default:
        content = <HomePage onNavigate={navigate} />;
    }
  }

  const showBottomNav = true;

  return (
    <div className="min-h-screen bg-gray-50">
      <OfflineBanner />
      <PWAUpdatePrompt />
      <ToastHost />
      {showSearch && <SearchModal onNavigate={navigate} />}
      {content}
      {showBottomNav && (
        <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-40 safe-area-pb">
          <div className="max-w-4xl mx-auto flex items-center justify-around px-1 py-1.5">
            <NavButton icon={Home} label="Accueil" active={page === 'home'} onClick={() => navigate('home')} />
            <NavButton icon={Sparkles} label="IA" active={page === 'ai-tutor'} onClick={() => navigate('ai-tutor')} />
            <NavButton icon={Award} label="Annales" active={page === 'annales'} onClick={() => navigate('annales')} />
            <NavButton icon={User} label="Notif" active={page === 'notifications'} onClick={() => navigate('notifications')} />
            {user ? (
              <NavButton icon={GraduationCap} label="Profil" active={page === 'progress'} onClick={() => navigate('progress')} />
            ) : (
              <NavButton icon={User} label="Compte" active={page === 'auth'} onClick={() => navigate('auth')} />
            )}
            {isAdmin && (
              <NavButton icon={ShieldCheck} label="Admin" active={page === 'admin'} onClick={() => navigate('admin')} />
            )}
          </div>
        </nav>
      )}
      {showBottomNav && <div className="h-16" />}
    </div>
  );
}

function NavButton({ icon: Icon, label, active, onClick }: { icon: typeof Home; label: string; active: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={`flex flex-col items-center gap-0.5 px-2 py-1.5 rounded-lg transition-colors ${active ? 'text-blue-600' : 'text-gray-400 hover:text-gray-600'}`}
    >
      <Icon className="w-5 h-5" />
      <span className="text-xs font-medium">{label}</span>
    </button>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
