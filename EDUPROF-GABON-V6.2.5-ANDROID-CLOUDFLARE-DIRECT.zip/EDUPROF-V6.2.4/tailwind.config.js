/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {},
  },
  plugins: [],
  safelist: [
    'bg-emerald-100', 'text-emerald-600', 'bg-emerald-50', 'from-emerald-600', 'to-emerald-700', 'text-emerald-700', 'border-emerald-500',
    'bg-blue-100', 'text-blue-600', 'bg-blue-50', 'from-blue-600', 'to-blue-700', 'text-blue-700', 'border-blue-500',
    'bg-cyan-100', 'text-cyan-600', 'bg-cyan-50', 'from-cyan-600', 'to-cyan-700', 'text-cyan-700', 'border-cyan-500',
    'bg-teal-100', 'text-teal-600', 'bg-teal-50', 'from-teal-600', 'to-teal-700', 'text-teal-700', 'border-teal-500',
    'bg-indigo-100', 'text-indigo-600', 'bg-indigo-50', 'from-indigo-600', 'to-indigo-700', 'text-indigo-700', 'border-indigo-500',
    'bg-violet-100', 'text-violet-600', 'bg-violet-50', 'from-violet-600', 'to-violet-700', 'text-violet-700', 'border-violet-500',
    'bg-purple-100', 'text-purple-600', 'bg-purple-50', 'from-purple-600', 'to-purple-700', 'text-purple-700', 'border-purple-500',
    'bg-fuchsia-100', 'text-fuchsia-600', 'bg-fuchsia-50', 'from-fuchsia-600', 'to-fuchsia-700', 'text-fuchsia-700', 'border-fuchsia-500',
    'bg-rose-100', 'text-rose-600', 'bg-rose-50', 'from-rose-600', 'to-rose-700', 'text-rose-700', 'border-rose-500',
    'bg-amber-100', 'text-amber-600', 'bg-amber-50', 'from-amber-600', 'to-amber-700', 'text-amber-700', 'border-amber-500',
    'bg-orange-100', 'text-orange-600', 'bg-orange-50', 'from-orange-600', 'to-orange-700', 'text-orange-700', 'border-orange-500',
    'bg-green-100', 'text-green-600', 'bg-green-50', 'from-green-600', 'to-green-700', 'text-green-700', 'border-green-500',
    'bg-red-100', 'text-red-600', 'bg-red-50', 'from-red-600', 'to-red-700', 'text-red-700', 'border-red-500',
    'bg-lime-100', 'text-lime-600', 'bg-lime-50', 'from-lime-600', 'to-lime-700', 'text-lime-700', 'border-lime-500',
    'bg-slate-100', 'text-slate-600', 'bg-slate-50', 'from-slate-600', 'to-slate-700', 'text-slate-700', 'border-slate-500',
    'bg-pink-100', 'text-pink-600', 'bg-pink-50', 'from-pink-600', 'to-pink-700', 'text-pink-700', 'border-pink-500',
  ],
};
