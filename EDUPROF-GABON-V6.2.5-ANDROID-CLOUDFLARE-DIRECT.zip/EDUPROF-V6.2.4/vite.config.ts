import { defineConfig, type Plugin } from 'vite';
import react from '@vitejs/plugin-react';
import { fileURLToPath, URL } from 'node:url';
import type { IncomingMessage, ServerResponse } from 'node:http';
import { runWithEnv, createDevEnv } from './workers/platform/env.ts';

/**
 * Dev-only: route /api/* vers workers/api.ts
 * Évite wrangler + Deno Edge (incompatible Termux aarch64).
 * Production: Cloudflare Workers.
 */
function workersApiDevPlugin(): Plugin {
  return {
    name: 'eduprof-workers-api-dev',
    configureServer(server) {
      server.middlewares.use(async (req: IncomingMessage, res: ServerResponse, next: () => void) => {
        const url = req.url || '';
        if (!url.startsWith('/api')) {
          next();
          return;
        }
        try {
          // /api/ai-tutor → workers/ai-tutor.ts
          // /api/*         → workers/api.ts
          const pathOnly = url.split('?')[0];
          const isAiTutor =
            pathOnly === '/api/ai-tutor' || pathOnly === '/api/ai-tutor/';
          const modulePath = isAiTutor
            ? '/workers/ai-tutor.ts'
            : '/workers/api.ts';

          const mod = await server.ssrLoadModule(modulePath);
          const handler = mod.default as (request: Request, context: unknown) => Promise<Response>;
          if (typeof handler !== 'function') {
            res.statusCode = 500;
            res.setHeader('Content-Type', 'application/json');
            res.end(JSON.stringify({ error: 'Handler API introuvable' }));
            return;
          }
          const host = req.headers.host || 'localhost';
          const fullUrl = `http://${host}${url}`;
          const chunks: Buffer[] = [];
          await new Promise<void>((resolve) => {
            req.on('data', (c) => chunks.push(Buffer.from(c)));
            req.on('end', () => resolve());
          });
          const bodyBuf = Buffer.concat(chunks);
          const method = (req.method || 'GET').toUpperCase();
          const headers = new Headers();
          for (const [k, v] of Object.entries(req.headers)) {
            if (v == null) continue;
            headers.set(k, Array.isArray(v) ? v.join(',') : String(v));
          }
          const requestInit: RequestInit = { method, headers };
          if (method !== 'GET' && method !== 'HEAD' && bodyBuf.length) {
            requestInit.body = bodyBuf;
          }
          const request = new Request(fullUrl, requestInit);
          const response = await runWithEnv(createDevEnv(), () => handler(request, createDevEnv()));
          res.statusCode = response.status;
          response.headers.forEach((value, key) => {
            if (key.toLowerCase() === 'transfer-encoding') return;
            res.setHeader(key, value);
          });
          const ab = await response.arrayBuffer();
          res.end(Buffer.from(ab));
        } catch (err: unknown) {
          const message = err instanceof Error ? err.message : String(err);
          console.error('[eduprof-api-dev]', message);
          res.statusCode = 500;
          res.setHeader('Content-Type', 'application/json');
          res.end(JSON.stringify({ error: message || 'Erreur API locale' }));
        }
      });
    },
  };
}

export default defineConfig({
  plugins: [react(), workersApiDevPlugin()],
  resolve: {
    alias: {
      '@': fileURLToPath(new URL('./src', import.meta.url)),
    },
  },
  optimizeDeps: {
    exclude: ['lucide-react'],
  },
  server: {
    host: '0.0.0.0',
    port: 8080,
    strictPort: true,
  },
  preview: {
    host: '0.0.0.0',
    port: 8081,
    strictPort: true,
  },
});
