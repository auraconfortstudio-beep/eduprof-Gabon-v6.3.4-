import type { EduprofEnv } from './platform/env.ts';
import { runInstitutionalMaintenance } from './_shared/institutional/maintenance.ts';

export async function runScheduledMaintenance(_env?: EduprofEnv) {
  const summary = await runInstitutionalMaintenance({
    recordAudit: true,
    actorUserId: 'system:cron',
  });
  return { ok: true, summary };
}
