/**
 * Analytics institutionnels + pédagogiques — données réelles uniquement.
 */
import type { UserRecord } from '../types.ts';
import {
  listEstablishments,
  listActivations,
  listInstitutionalAudit,
  syncExpiredActivations,
} from '../institutional/index.ts';
import { listAllUsers } from '../store.ts';

export type AnalyticsPeriod = '7d' | '30d' | '90d' | 'all';

function periodStart(period: AnalyticsPeriod): number | null {
  if (period === 'all') return null;
  const days = period === '7d' ? 7 : period === '30d' ? 30 : 90;
  return Date.now() - days * 86400000;
}

function inPeriod(iso: string | null | undefined, start: number | null): boolean {
  if (start == null) return true;
  if (!iso) return false;
  return new Date(iso).getTime() >= start;
}

export async function computeOwnerAnalytics(period: AnalyticsPeriod = 'all') {
  syncExpiredActivations();
  const start = periodStart(period);
  const ests = await listEstablishments();
  const acts = await listActivations();
  const users = await listAllUsers();
  const students = users.filter((u) => u.role === 'STUDENT' || u.role === 'USER');
  const activeActs = acts.filter((a) => a.status === 'active');
  const expiredActs = acts.filter((a) => a.status === 'expired');
  const logs = await listInstitutionalAudit({ limit: 500 });
  const renewals = logs.filter((l) => l.action === 'STUDENT_RENEWED' && inPeriod(l.timestamp, start)).length;
  const revocations = logs.filter((l) => l.action === 'STUDENT_REVOKED' && inPeriod(l.timestamp, start)).length;
  const activations = logs.filter((l) => l.action === 'STUDENT_ACTIVATED' && inPeriod(l.timestamp, start)).length;
  const soon = activeActs.filter((a) => {
    if (!a.expiresAt) return false;
    const ms = new Date(a.expiresAt).getTime() - Date.now();
    return ms > 0 && ms < 7 * 86400000;
  }).length;
  const totalXp = students.reduce((s, u) => s + (u.xp || 0), 0);
  return {
    scope: 'global' as const,
    period,
    establishments: ests.length,
    establishmentsActive: ests.filter((e) => e.status === 'active').length,
    establishmentsSuspended: ests.filter((e) => e.status === 'suspended').length,
    students: students.length,
    studentsActiveAccess: activeActs.length,
    studentsExpiredAccess: expiredActs.length,
    activationsInPeriod: activations,
    renewalsInPeriod: renewals,
    revocationsInPeriod: revocations,
    expiringSoon: soon,
    totalXpDistributed: totalXp,
    note: start
      ? 'Les métriques d’audit filtrées par période reposent sur les logs institutionnels en mémoire (non historiques persistants).'
      : 'Store mémoire : pas d’historique long terme.',
  };
}

export async function computeEstablishmentAnalytics(
  establishmentId: string,
  period: AnalyticsPeriod = 'all'
) {
  syncExpiredActivations();
  const start = periodStart(period);
  const acts = await listActivations({ establishmentId });
  const users = await listAllUsers();
  const students = users.filter(
    (u) => u.establishmentId === establishmentId && (u.role === 'STUDENT' || u.role === 'USER')
  );
  const logs = await listInstitutionalAudit({ establishmentId, limit: 500 });
  const renewals = logs.filter((l) => l.action === 'STUDENT_RENEWED' && inPeriod(l.timestamp, start)).length;
  const revocations = logs.filter((l) => l.action === 'STUDENT_REVOKED' && inPeriod(l.timestamp, start)).length;
  const activations = logs.filter((l) => l.action === 'STUDENT_ACTIVATED' && inPeriod(l.timestamp, start)).length;
  const soon = acts.filter((a) => {
    if (a.status !== 'active' || !a.expiresAt) return false;
    const ms = new Date(a.expiresAt).getTime() - Date.now();
    return ms > 0 && ms < 7 * 86400000;
  }).length;
  const totalXp = students.reduce((s, u) => s + (u.xp || 0), 0);
  const avgXp = students.length ? totalXp / students.length : 0;
  return {
    scope: 'establishment' as const,
    establishmentId,
    period,
    students: students.length,
    active: acts.filter((a) => a.status === 'active').length,
    expired: acts.filter((a) => a.status === 'expired').length,
    activationsInPeriod: activations,
    renewalsInPeriod: renewals,
    revocationsInPeriod: revocations,
    expiringSoon: soon,
    totalXp,
    averageXp: Math.round(avgXp * 10) / 10,
    note: 'Analytics établissement basés sur store mémoire + users.',
  };
}
