/**
 * Audit avancé — filtres + pagination sur audit institutionnel existant.
 */
import type { InstitutionalAuditLog } from '../types.ts';
import { listInstitutionalAudit } from '../institutional/store.ts';

export interface AuditQuery {
  establishmentId?: string;
  actorUserId?: string;
  action?: string;
  targetUserId?: string;
  from?: string;
  to?: string;
  page?: number;
  pageSize?: number;
}

export async function queryAudit(q: AuditQuery): Promise<{
  items: InstitutionalAuditLog[];
  total: number;
  page: number;
  pageSize: number;
}> {
  const page = Math.max(1, q.page || 1);
  const pageSize = Math.min(100, Math.max(1, q.pageSize || 20));
  let all = await listInstitutionalAudit({
    establishmentId: q.establishmentId,
    limit: 500,
  });
  if (q.actorUserId) all = all.filter((l) => l.actorUserId === q.actorUserId);
  if (q.action) all = all.filter((l) => l.action === q.action);
  if (q.targetUserId) all = all.filter((l) => l.targetUserId === q.targetUserId);
  if (q.from) {
    const t = new Date(q.from).getTime();
    all = all.filter((l) => new Date(l.timestamp).getTime() >= t);
  }
  if (q.to) {
    const t = new Date(q.to).getTime();
    all = all.filter((l) => new Date(l.timestamp).getTime() <= t);
  }
  const total = all.length;
  const start = (page - 1) * pageSize;
  return { items: all.slice(start, start + pageSize), total, page, pageSize };
}

/** Sanitize metadata — strip secrets */
export function sanitizeAuditForClient(log: InstitutionalAuditLog): InstitutionalAuditLog {
  const meta = { ...(log.metadata || {}) };
  for (const k of Object.keys(meta)) {
    if (/password|token|jwt|secret|api[_-]?key/i.test(k)) delete meta[k];
  }
  return { ...log, metadata: meta };
}
