/**
 * Store utilisateurs / progress / annales — V6.1
 * Production : D1 | Tests : mémoire isolée
 * Aucun Netlify. Aucune filesystem.
 */
import type { UserRecord, UserProgress, PremiumRequest, AdminLog, AnnaleRecord } from './types';
import { getDb } from '../platform/db.ts';

const memUsers = new Map<string, UserRecord>();
const memEmailIndex = new Map<string, string>();
const memProgress = new Map<string, UserProgress>();
let memPremium: PremiumRequest[] = [];
let memAdminLogs: AdminLog[] = [];
let memAnnales: AnnaleRecord[] = [];

function rowToUser(r: Record<string, unknown>): UserRecord {
  return {
    id: String(r.id),
    email: String(r.email),
    passwordHash: String(r.password_hash || ''),
    displayName: String(r.display_name || r.email),
    role: (r.role as UserRecord['role']) || 'USER',
    educationLevel: (r.education_level as UserRecord['educationLevel']) ?? null,
    educationSeries: (r.education_series as UserRecord['educationSeries']) ?? null,
    educationFiliere: (r.education_filiere as UserRecord['educationFiliere']) ?? null,
    isPremium: !!r.is_premium,
    premiumUntil: (r.premium_until as string) || null,
    xp: Number(r.xp || 0),
    streak: Number(r.streak || 0),
    lastActivityDate: (r.last_activity_date as string) || null,
    establishmentId: (r.establishment_id as string) || null,
    accessStatus: (r.access_status as UserRecord['accessStatus']) || undefined,
    accessExpiresAt: (r.access_expires_at as string) || null,
    isDemo: !!r.is_demo,
    createdAt: String(r.created_at),
    updatedAt: String(r.updated_at),
  };
}

export async function getUserById(id: string): Promise<UserRecord | null> {
  const db = getDb();
  if (db) {
    const r = await db.prepare('SELECT * FROM users WHERE id = ?').bind(id).first();
    return r ? rowToUser(r as Record<string, unknown>) : null;
  }
  return memUsers.get(id) || null;
}

export async function getUserByEmail(email: string): Promise<UserRecord | null> {
  const key = email.trim().toLowerCase();
  const db = getDb();
  if (db) {
    const r = await db.prepare('SELECT * FROM users WHERE email = ? COLLATE NOCASE').bind(key).first();
    return r ? rowToUser(r as Record<string, unknown>) : null;
  }
  const id = memEmailIndex.get(key);
  return id ? memUsers.get(id) || null : null;
}

export async function saveUser(user: UserRecord): Promise<void> {
  const db = getDb();
  if (db) {
    await db
      .prepare(
        `INSERT INTO users (id,email,password_hash,display_name,role,education_level,education_series,education_filiere,
          is_premium,premium_until,xp,streak,last_activity_date,establishment_id,access_status,access_expires_at,is_demo,created_at,updated_at)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
         ON CONFLICT(id) DO UPDATE SET
           email=excluded.email,password_hash=excluded.password_hash,display_name=excluded.display_name,role=excluded.role,
           education_level=excluded.education_level,education_series=excluded.education_series,education_filiere=excluded.education_filiere,
           is_premium=excluded.is_premium,premium_until=excluded.premium_until,xp=excluded.xp,streak=excluded.streak,
           last_activity_date=excluded.last_activity_date,establishment_id=excluded.establishment_id,
           access_status=excluded.access_status,access_expires_at=excluded.access_expires_at,is_demo=excluded.is_demo,updated_at=excluded.updated_at`
      )
      .bind(
        user.id, user.email.toLowerCase(), user.passwordHash, user.displayName, user.role,
        user.educationLevel, user.educationSeries, user.educationFiliere,
        user.isPremium ? 1 : 0, user.premiumUntil, user.xp, user.streak, user.lastActivityDate,
        user.establishmentId, user.accessStatus ?? null, user.accessExpiresAt ?? null,
        user.isDemo ? 1 : 0, user.createdAt, user.updatedAt
      )
      .run();
    return;
  }
  memUsers.set(user.id, user);
  memEmailIndex.set(user.email.toLowerCase(), user.id);
}

export async function deleteUser(id: string): Promise<void> {
  const db = getDb();
  if (db) {
    await db.prepare('DELETE FROM users WHERE id = ?').bind(id).run();
    return;
  }
  const u = memUsers.get(id);
  if (u) memEmailIndex.delete(u.email.toLowerCase());
  memUsers.delete(id);
}

export async function listAllUsers(): Promise<UserRecord[]> {
  const db = getDb();
  if (db) {
    const { results } = await db.prepare('SELECT * FROM users').all();
    return (results || []).map((r) => rowToUser(r as Record<string, unknown>));
  }
  return [...memUsers.values()];
}

export async function getProgress(userId: string): Promise<UserProgress> {
  const empty: UserProgress = { userId, lessons: [], exercises: [], quizzes: [], xpHistory: [] };
  const db = getDb();
  if (db) {
    const row = await db.prepare('SELECT data_json FROM user_progress WHERE user_id = ?').bind(userId).first<{ data_json: string }>();
    if (!row) return empty;
    try {
      return JSON.parse(row.data_json) as UserProgress;
    } catch {
      return empty;
    }
  }
  return memProgress.get(userId) || empty;
}

export async function saveProgress(progress: UserProgress): Promise<void> {
  const db = getDb();
  if (db) {
    const now = new Date().toISOString();
    await db
      .prepare(
        `INSERT INTO user_progress (user_id, data_json, updated_at) VALUES (?, ?, ?)
         ON CONFLICT(user_id) DO UPDATE SET data_json=excluded.data_json, updated_at=excluded.updated_at`
      )
      .bind(progress.userId, JSON.stringify(progress), now)
      .run();
    return;
  }
  memProgress.set(progress.userId, progress);
}

export async function getPremiumRequests(): Promise<PremiumRequest[]> {
  const db = getDb();
  if (db) {
    const { results } = await db.prepare('SELECT data_json FROM premium_requests').all<{ data_json: string }>();
    return (results || []).map((r) => JSON.parse(r.data_json) as PremiumRequest);
  }
  return [...memPremium];
}

export async function savePremiumRequests(reqs: PremiumRequest[]): Promise<void> {
  const db = getDb();
  if (db) {
    await db.prepare('DELETE FROM premium_requests').run();
    for (const req of reqs) {
      await db
        .prepare('INSERT INTO premium_requests (id, data_json, created_at) VALUES (?, ?, ?)')
        .bind(req.id, JSON.stringify(req), req.createdAt || new Date().toISOString())
        .run();
    }
    return;
  }
  memPremium = [...reqs];
}

export async function getAdminLogs(): Promise<AdminLog[]> {
  const db = getDb();
  if (db) {
    const { results } = await db.prepare('SELECT data_json FROM admin_logs ORDER BY created_at DESC LIMIT 500').all<{ data_json: string }>();
    return (results || []).map((r) => JSON.parse(r.data_json) as AdminLog);
  }
  return [...memAdminLogs];
}

export async function appendAdminLog(log: AdminLog): Promise<void> {
  const db = getDb();
  if (db) {
    const id = (log as { id?: string }).id || crypto.randomUUID();
    await db
      .prepare('INSERT INTO admin_logs (id, data_json, created_at) VALUES (?, ?, ?)')
      .bind(id, JSON.stringify(log), (log as { createdAt?: string }).createdAt || new Date().toISOString())
      .run();
    return;
  }
  memAdminLogs.push(log);
}

export async function getAnnales(): Promise<AnnaleRecord[]> {
  const db = getDb();
  if (db) {
    const row = await db.prepare('SELECT data_json FROM annales_store WHERE id = ?').bind('main').first<{ data_json: string }>();
    if (!row) return [];
    try {
      return JSON.parse(row.data_json) as AnnaleRecord[];
    } catch {
      return [];
    }
  }
  return [...memAnnales];
}

export async function saveAnnales(items: AnnaleRecord[]): Promise<void> {
  const db = getDb();
  if (db) {
    await db
      .prepare(
        `INSERT INTO annales_store (id, data_json, updated_at) VALUES ('main', ?, ?)
         ON CONFLICT(id) DO UPDATE SET data_json=excluded.data_json, updated_at=excluded.updated_at`
      )
      .bind(JSON.stringify(items), new Date().toISOString())
      .run();
    return;
  }
  memAnnales = [...items];
}

/** Tests uniquement — reset mémoire */
export function __resetStoreForTests(): void {
  memUsers.clear();
  memEmailIndex.clear();
  memProgress.clear();
  memPremium = [];
  memAdminLogs = [];
  memAnnales = [];
}
