/**
 * Helpers de limitation mémoire pour les stores in-memory.
 */
export function trimMap<K, V>(map: Map<K, V>, max: number): number {
  if (map.size <= max) return 0;
  const excess = map.size - max;
  const keys = map.keys();
  let n = 0;
  for (const k of keys) {
    map.delete(k);
    n++;
    if (n >= excess) break;
  }
  return n;
}

export function trimArray<T>(arr: T[], max: number): number {
  if (arr.length <= max) return 0;
  const excess = arr.length - max;
  arr.splice(0, excess);
  return excess;
}
