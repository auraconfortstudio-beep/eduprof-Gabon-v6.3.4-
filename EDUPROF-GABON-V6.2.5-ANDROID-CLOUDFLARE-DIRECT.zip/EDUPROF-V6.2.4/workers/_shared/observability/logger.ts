/**
 * Logger structuré léger — inspiration pino/winston (MIT) sans dépendance.
 * Jamais de secrets dans les logs.
 */
export type LogLevel = 'INFO' | 'WARN' | 'ERROR';

export interface LogEntry {
  level: LogLevel;
  msg: string;
  ts: string;
  requestId?: string;
  route?: string;
  userId?: string;
  durationMs?: number;
  code?: string;
  meta?: Record<string, string | number | boolean | null>;
}

const SENSITIVE = /password|passwd|token|jwt|secret|authorization|api[_-]?key|bearer\s+[a-z0-9._-]+/i;

export function sanitizeLogValue(v: unknown): string | number | boolean | null {
  if (v == null) return null;
  if (typeof v === 'number' || typeof v === 'boolean') return v;
  const s = String(v);
  if (SENSITIVE.test(s)) return '[REDACTED]';
  if (/\/home\/|\/tmp\/|node_modules|stack/i.test(s)) return '[REDACTED_PATH]';
  return s.slice(0, 300);
}

export function sanitizeMeta(
  meta?: Record<string, unknown>
): Record<string, string | number | boolean | null> | undefined {
  if (!meta) return undefined;
  const out: Record<string, string | number | boolean | null> = {};
  for (const [k, v] of Object.entries(meta)) {
    if (SENSITIVE.test(k)) {
      out[k] = '[REDACTED]';
      continue;
    }
    out[k] = sanitizeLogValue(v);
  }
  return out;
}

function emit(entry: LogEntry): void {
  const line = JSON.stringify({
    ...entry,
    meta: entry.meta ? sanitizeMeta(entry.meta as Record<string, unknown>) : undefined,
  });
  if (entry.level === 'ERROR') console.error(line);
  else if (entry.level === 'WARN') console.warn(line);
  else console.log(line);
}

export function logInfo(msg: string, extra?: Partial<Omit<LogEntry, 'level' | 'msg' | 'ts'>>): void {
  emit({ level: 'INFO', msg, ts: new Date().toISOString(), ...extra });
}

export function logWarn(msg: string, extra?: Partial<Omit<LogEntry, 'level' | 'msg' | 'ts'>>): void {
  emit({ level: 'WARN', msg, ts: new Date().toISOString(), ...extra });
}

export function logError(msg: string, extra?: Partial<Omit<LogEntry, 'level' | 'msg' | 'ts'>>): void {
  emit({
    level: 'ERROR',
    msg: String(sanitizeLogValue(msg)),
    ts: new Date().toISOString(),
    ...extra,
  });
}
