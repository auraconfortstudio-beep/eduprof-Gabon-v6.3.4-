import { getMetricsSnapshot } from './metrics.ts';
import { InstitutionalRepository } from '../institutional/repository.ts';

export function buildHealthReport(): {
  status: 'ok' | 'degraded';
  version: string;
  uptimeSec: number;
  stores: { institutional: string };
  metrics: ReturnType<typeof getMetricsSnapshot>;
  ts: string;
} {
  const metrics = getMetricsSnapshot();
  const errorRate = metrics.totalRequests ? metrics.totalErrors / metrics.totalRequests : 0;
  return {
    status: errorRate > 0.5 && metrics.totalRequests > 10 ? 'degraded' : 'ok',
    version: '6.2.0',
    uptimeSec: Math.floor(process.uptime()),
    stores: { institutional: InstitutionalRepository.backend },
    metrics,
    ts: new Date().toISOString(),
  };
}
