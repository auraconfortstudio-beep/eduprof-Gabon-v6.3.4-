/**
 * Métriques process-local (non distribuées entre isolates Worker).
 * Ring buffer borné pour limiter la mémoire.
 */
export interface RequestMetric {
  route: string;
  status: number;
  durationMs: number;
  ts: number;
  error?: boolean;
}

const MAX = 200;
const buffer: RequestMetric[] = [];
let totalRequests = 0;
let totalErrors = 0;
let totalDurationMs = 0;

export function recordRequest(m: RequestMetric): void {
  totalRequests += 1;
  totalDurationMs += m.durationMs;
  if (m.error || m.status >= 500) totalErrors += 1;
  buffer.push(m);
  if (buffer.length > MAX) buffer.shift();
}

export function getMetricsSnapshot(): {
  totalRequests: number;
  totalErrors: number;
  avgDurationMs: number;
  recent: RequestMetric[];
  bufferSize: number;
  bufferCap: number;
} {
  return {
    totalRequests,
    totalErrors,
    avgDurationMs: totalRequests ? Math.round(totalDurationMs / totalRequests) : 0,
    recent: buffer.slice(-20),
    bufferSize: buffer.length,
    bufferCap: MAX,
  };
}

export function resetMetrics(): void {
  buffer.length = 0;
  totalRequests = 0;
  totalErrors = 0;
  totalDurationMs = 0;
}
