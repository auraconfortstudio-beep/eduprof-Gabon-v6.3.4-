import { randomUUID } from 'crypto';

const HDR = 'x-request-id';

export function getOrCreateRequestId(headers: Headers | Record<string, string | undefined>): string {
  const read = (k: string): string | null => {
    if (headers && typeof (headers as Headers).get === 'function') {
      return (headers as Headers).get(k);
    }
    const h = headers as Record<string, string | undefined>;
    return h[k] || h[k.toLowerCase()] || null;
  };
  const incoming = read(HDR) || read('X-Request-Id');
  if (incoming && /^[a-zA-Z0-9_-]{8,64}$/.test(incoming)) return incoming;
  return randomUUID();
}

export function requestIdHeader(id: string): Record<string, string> {
  return { 'X-Request-Id': id };
}
