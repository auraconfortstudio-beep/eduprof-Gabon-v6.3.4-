/**
 * Memberships V6.2 — D1 production / mémoire tests.
 */
import { randomUUID } from 'crypto';
import type { Membership, Role } from '../types.ts';
import { getDb } from '../../platform/db.ts';

const mem = new Map<string, Membership>();

function rowMem(r: Record<string, unknown>): Membership {
  return {
    id: String(r.id),
    userId: String(r.user_id),
    establishmentId: String(r.establishment_id),
    role: (r.role as Role) || 'STUDENT',
    status: (r.status as Membership['status']) || 'ACTIVE',
    createdAt: String(r.created_at),
    updatedAt: String(r.updated_at),
    createdBy: String(r.user_id),
  };
}

export function resetMemberships(): void {
  mem.clear();
}

export async function listMemberships(filter?: {
  userId?: string;
  establishmentId?: string;
  status?: Membership['status'];
}): Promise<Membership[]> {
  const db = getDb();
  if (db) {
    let sql = 'SELECT * FROM memberships WHERE 1=1';
    const binds: unknown[] = [];
    if (filter?.userId) { sql += ' AND user_id = ?'; binds.push(filter.userId); }
    if (filter?.establishmentId) { sql += ' AND establishment_id = ?'; binds.push(filter.establishmentId); }
    if (filter?.status) { sql += ' AND status = ?'; binds.push(filter.status); }
    let stmt = db.prepare(sql);
    if (binds.length) stmt = stmt.bind(...binds);
    const { results } = await stmt.all();
    return (results || []).map((r) => rowMem(r as Record<string, unknown>));
  }
  let all = [...mem.values()];
  if (filter?.userId) all = all.filter((m) => m.userId === filter.userId);
  if (filter?.establishmentId) all = all.filter((m) => m.establishmentId === filter.establishmentId);
  if (filter?.status) all = all.filter((m) => m.status === filter.status);
  return all;
}

export async function getMembership(userId: string, establishmentId: string): Promise<Membership | undefined> {
  const list = await listMemberships({ userId, establishmentId });
  return list[0];
}

export async function upsertMembership(input: {
  userId: string;
  establishmentId: string;
  role: Role;
  status?: Membership['status'];
}): Promise<Membership> {
  const existing = await getMembership(input.userId, input.establishmentId);
  const now = new Date().toISOString();
  const m: Membership = {
    id: existing?.id || randomUUID(),
    userId: input.userId,
    establishmentId: input.establishmentId,
    role: input.role,
    status: input.status || 'ACTIVE',
    createdAt: existing?.createdAt || now,
    updatedAt: now,
    createdBy: existing?.createdBy || input.userId,
  };
  const db = getDb();
  if (db) {
    await db.prepare(
      `INSERT INTO memberships (id, user_id, establishment_id, role, status, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?)
       ON CONFLICT(user_id, establishment_id) DO UPDATE SET role=excluded.role, status=excluded.status, updated_at=excluded.updated_at`
    ).bind(m.id, m.userId, m.establishmentId, m.role, m.status, m.createdAt, m.updatedAt).run();
    return m;
  }
  mem.set(m.id, m);
  return m;
}

export async function revokeMembership(userId: string, establishmentId: string): Promise<boolean> {
  const m = await getMembership(userId, establishmentId);
  if (!m) return false;
  await upsertMembership({ userId, establishmentId, role: m.role, status: 'REVOKED' });
  return true;
}


/** Sync-friendly check using mémoire/D1 via async wrapper for context — uses listMemberships sync path via mem when no DB. */
export async function hasActiveMembership(user: { id: string }, establishmentId: string): Promise<boolean> {
  const m = await getMembership(user.id, establishmentId);
  return !!m && m.status === 'ACTIVE';
}
