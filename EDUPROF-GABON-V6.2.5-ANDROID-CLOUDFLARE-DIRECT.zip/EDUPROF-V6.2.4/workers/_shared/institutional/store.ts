/**
 * Stockage institutionnel V6.2 — D1 source de vérité production.
 * Mémoire uniquement si getDb() === null (tests isolés).
 */
import { randomUUID } from 'crypto';
import type {
  Establishment,
  EstablishmentStatus,
  StudentActivation,
  AccessStatus,
  InstitutionalAuditLog,
  InstitutionalAuditAction,
  UserRecord,
} from '../types.ts';
import { getDb } from '../../platform/db.ts';

const memEst = new Map<string, Establishment>();
const memAct = new Map<string, StudentActivation>();
const memAudit: InstitutionalAuditLog[] = [];

function rowEst(r: Record<string, unknown>): Establishment {
  let type = 'lycee';
  try {
    const meta = r.meta_json ? JSON.parse(String(r.meta_json)) : {};
    if (meta && typeof meta.type === 'string') type = meta.type;
  } catch { /* ignore */ }
  return {
    id: String(r.id),
    name: String(r.name),
    code: String(r.code),
    type,
    status: (r.status as EstablishmentStatus) || 'active',
    createdAt: String(r.created_at),
    updatedAt: String(r.updated_at),
  };
}

function rowAct(r: Record<string, unknown>): StudentActivation {
  let activatedBy: string | null = null;
  try {
    const meta = r.meta_json ? JSON.parse(String(r.meta_json)) : {};
    if (meta && meta.activatedBy) activatedBy = String(meta.activatedBy);
  } catch { /* ignore */ }
  return {
    id: String(r.id),
    userId: String(r.user_id),
    establishmentId: String(r.establishment_id),
    status: (r.status as AccessStatus) || 'pending',
    activatedAt: (r.starts_at as string) || null,
    expiresAt: (r.expires_at as string) || null,
    activatedBy,
    createdAt: String(r.created_at),
    updatedAt: String(r.updated_at),
  };
}

export function resetInstitutionalStore(): void {
  memEst.clear();
  memAct.clear();
  memAudit.length = 0;
}

export async function listEstablishments(): Promise<Establishment[]> {
  const db = getDb();
  if (db) {
    const { results } = await db.prepare('SELECT * FROM establishments ORDER BY name').all();
    return (results || []).map((r) => rowEst(r as Record<string, unknown>));
  }
  return [...memEst.values()].sort((a, b) => a.name.localeCompare(b.name, 'fr'));
}

export async function getEstablishment(id: string): Promise<Establishment | undefined> {
  const db = getDb();
  if (db) {
    const r = await db.prepare('SELECT * FROM establishments WHERE id = ?').bind(id).first();
    return r ? rowEst(r as Record<string, unknown>) : undefined;
  }
  return memEst.get(id);
}

export async function getEstablishmentByCode(code: string): Promise<Establishment | undefined> {
  const c = code.trim().toUpperCase();
  const db = getDb();
  if (db) {
    const r = await db.prepare('SELECT * FROM establishments WHERE code = ?').bind(c).first();
    return r ? rowEst(r as Record<string, unknown>) : undefined;
  }
  return [...memEst.values()].find((e) => e.code === c);
}

export async function createEstablishment(input: {
  name: string;
  code: string;
  type?: string;
  status?: EstablishmentStatus;
}): Promise<Establishment> {
  const code = input.code.trim().toUpperCase();
  if (await getEstablishmentByCode(code)) throw new Error('Code établissement déjà utilisé');
  const now = new Date().toISOString();
  const est: Establishment = {
    id: randomUUID(),
    name: input.name.trim(),
    code,
    type: (input.type || 'lycee').trim(),
    status: input.status || 'active',
    createdAt: now,
    updatedAt: now,
  };
  const db = getDb();
  if (db) {
    await db.prepare(
      `INSERT INTO establishments (id, name, code, status, created_at, updated_at, meta_json) VALUES (?, ?, ?, ?, ?, ?, ?)`
    ).bind(est.id, est.name, est.code, est.status, est.createdAt, est.updatedAt, JSON.stringify({ type: est.type })).run();
    return est;
  }
  memEst.set(est.id, est);
  return est;
}

export async function updateEstablishment(
  id: string,
  patch: Partial<Pick<Establishment, 'name' | 'type' | 'status'>>
): Promise<Establishment | null> {
  const cur = await getEstablishment(id);
  if (!cur) return null;
  const next: Establishment = {
    ...cur,
    ...patch,
    name: patch.name?.trim() || cur.name,
    type: patch.type?.trim() || cur.type,
    updatedAt: new Date().toISOString(),
  };
  const db = getDb();
  if (db) {
    await db.prepare(
      `UPDATE establishments SET name = ?, status = ?, updated_at = ?, meta_json = ? WHERE id = ?`
    ).bind(next.name, next.status, next.updatedAt, JSON.stringify({ type: next.type }), id).run();
    return next;
  }
  memEst.set(id, next);
  return next;
}

export async function listActivations(filter?: {
  establishmentId?: string;
  userId?: string;
  status?: AccessStatus;
}): Promise<StudentActivation[]> {
  const db = getDb();
  if (db) {
    let sql = 'SELECT * FROM activations WHERE 1=1';
    const binds: unknown[] = [];
    if (filter?.establishmentId) { sql += ' AND establishment_id = ?'; binds.push(filter.establishmentId); }
    if (filter?.userId) { sql += ' AND user_id = ?'; binds.push(filter.userId); }
    if (filter?.status) { sql += ' AND status = ?'; binds.push(filter.status); }
    let stmt = db.prepare(sql);
    if (binds.length) stmt = stmt.bind(...binds);
    const { results } = await stmt.all();
    return (results || []).map((r) => rowAct(r as Record<string, unknown>));
  }
  let all = [...memAct.values()];
  if (filter?.establishmentId) all = all.filter((a) => a.establishmentId === filter.establishmentId);
  if (filter?.userId) all = all.filter((a) => a.userId === filter.userId);
  if (filter?.status) all = all.filter((a) => a.status === filter.status);
  return all;
}

export async function getActivation(id: string): Promise<StudentActivation | undefined> {
  const db = getDb();
  if (db) {
    const r = await db.prepare('SELECT * FROM activations WHERE id = ?').bind(id).first();
    return r ? rowAct(r as Record<string, unknown>) : undefined;
  }
  return memAct.get(id);
}

export async function getActivationForUser(userId: string, establishmentId?: string): Promise<StudentActivation | undefined> {
  const list = await listActivations({ userId, establishmentId });
  return list[0];
}

export async function upsertActivation(input: {
  userId: string;
  establishmentId: string;
  status: AccessStatus;
  expiresAt?: string | null;
  activatedAt?: string | null;
  activatedBy?: string | null;
  id?: string;
}): Promise<StudentActivation> {
  const existing = await getActivationForUser(input.userId, input.establishmentId);
  const now = new Date().toISOString();
  const act: StudentActivation = {
    id: existing?.id || input.id || randomUUID(),
    userId: input.userId,
    establishmentId: input.establishmentId,
    status: input.status,
    activatedAt: input.activatedAt ?? existing?.activatedAt ?? now,
    expiresAt: input.expiresAt !== undefined ? input.expiresAt : existing?.expiresAt ?? null,
    activatedBy: input.activatedBy ?? existing?.activatedBy ?? null,
    createdAt: existing?.createdAt || now,
    updatedAt: now,
  };
  const db = getDb();
  if (db) {
    await db.prepare(
      `INSERT INTO activations (id, user_id, establishment_id, status, starts_at, expires_at, created_at, updated_at, meta_json)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
       ON CONFLICT(id) DO UPDATE SET status=excluded.status, starts_at=excluded.starts_at, expires_at=excluded.expires_at,
         updated_at=excluded.updated_at, meta_json=excluded.meta_json`
    ).bind(act.id, act.userId, act.establishmentId, act.status, act.activatedAt, act.expiresAt, act.createdAt, act.updatedAt, JSON.stringify({ activatedBy: act.activatedBy })).run();
    return act;
  }
  memAct.set(act.id, act);
  return act;
}

export async function refreshActivationStatus(act: StudentActivation): Promise<StudentActivation> {
  if (act.status === 'active' && act.expiresAt && new Date(act.expiresAt).getTime() < Date.now()) {
    return upsertActivation({
      userId: act.userId,
      establishmentId: act.establishmentId,
      status: 'expired',
      expiresAt: act.expiresAt,
      activatedAt: act.activatedAt,
      activatedBy: act.activatedBy,
      id: act.id,
    });
  }
  return act;
}

export async function appendInstitutionalAudit(entry: {
  actorUserId: string;
  actorEmail?: string;
  action: InstitutionalAuditAction | string;
  targetUserId?: string | null;
  targetEstablishmentId?: string | null;
  metadata?: Record<string, string | number | boolean | null>;
}): Promise<InstitutionalAuditLog> {
  const log: InstitutionalAuditLog = {
    id: randomUUID(),
    actorUserId: entry.actorUserId,
    actorEmail: entry.actorEmail,
    action: entry.action,
    targetUserId: entry.targetUserId,
    targetEstablishmentId: entry.targetEstablishmentId,
    timestamp: new Date().toISOString(),
    metadata: entry.metadata,
  };
  const db = getDb();
  if (db) {
    await db.prepare(
      `INSERT INTO audit_logs (id, establishment_id, actor_user_id, action, target_type, target_id, details_json, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    ).bind(log.id, log.targetEstablishmentId || null, log.actorUserId, log.action, log.targetUserId ? 'user' : 'establishment', log.targetUserId || log.targetEstablishmentId || null, JSON.stringify({ email: log.actorEmail, metadata: log.metadata }), log.timestamp).run();
    return log;
  }
  memAudit.push(log);
  return log;
}

export async function listInstitutionalAudit(filter?: {
  establishmentId?: string;
  limit?: number;
}): Promise<InstitutionalAuditLog[]> {
  const limit = filter?.limit ?? 100;
  const db = getDb();
  if (db) {
    let sql = 'SELECT * FROM audit_logs';
    const binds: unknown[] = [];
    if (filter?.establishmentId) { sql += ' WHERE establishment_id = ?'; binds.push(filter.establishmentId); }
    sql += ' ORDER BY created_at DESC LIMIT ?';
    binds.push(limit);
    const { results } = await db.prepare(sql).bind(...binds).all();
    return (results || []).map((r) => {
      const row = r as Record<string, unknown>;
      let details: Record<string, unknown> = {};
      try { details = JSON.parse(String(row.details_json || '{}')); } catch { /* */ }
      return {
        id: String(row.id),
        actorUserId: String(row.actor_user_id || ''),
        actorEmail: details.email as string | undefined,
        action: String(row.action),
        targetUserId: row.target_type === 'user' ? String(row.target_id) : null,
        targetEstablishmentId: (row.establishment_id as string) || null,
        timestamp: String(row.created_at),
        metadata: details.metadata as InstitutionalAuditLog['metadata'],
      };
    });
  }
  let all = [...memAudit];
  if (filter?.establishmentId) all = all.filter((a) => a.targetEstablishmentId === filter.establishmentId);
  return all.slice(-limit).reverse();
}

export async function isAccessActive(user: UserRecord): Promise<boolean> {
  if (!user.establishmentId) return true;
  const act = await getActivationForUser(user.id, user.establishmentId);
  if (!act) return user.accessStatus === 'active';
  const refreshed = await refreshActivationStatus(act);
  return refreshed.status === 'active';
}
