/**
 * Import CSV élèves — validation + prévisualisation, pas de création silencieuse.
 * Colonnes attendues : studentId,firstName,lastName,level,establishmentCode
 * (email optionnel en colonne supplémentaire)
 */

export interface CsvStudentRow {
  line: number;
  studentId: string;
  firstName: string;
  lastName: string;
  level: string;
  establishmentCode: string;
  email?: string;
}

export interface CsvRowError {
  line: number;
  reason: string;
  raw?: string;
}

export interface CsvParseResult {
  ok: boolean;
  rows: CsvStudentRow[];
  errors: CsvRowError[];
  duplicatesInFile: string[];
}

const KNOWN_LEVELS = new Set([
  'cm2', '6e', '5e', '4e', '3e', 'seconde', '2nde', 'premiere', '1ere', 'terminale', 'tle',
]);

function normalizeLevel(l: string): string {
  const x = l.trim().toLowerCase().replace('è', 'e').replace('é', 'e');
  if (x === '2nde') return 'seconde';
  if (x === '1ere') return 'premiere';
  if (x === 'tle') return 'terminale';
  return x;
}

export function parseStudentsCsv(text: string): CsvParseResult {
  const errors: CsvRowError[] = [];
  const rows: CsvStudentRow[] = [];
  if (!text || !text.trim()) {
    return { ok: false, rows: [], errors: [{ line: 0, reason: 'CSV vide' }], duplicatesInFile: [] };
  }
  const lines = text.replace(/^\uFEFF/, '').split(/\r?\n/).filter((l) => l.trim().length > 0);
  if (lines.length < 2) {
    return {
      ok: false,
      rows: [],
      errors: [{ line: 1, reason: 'En-tête ou données manquants' }],
      duplicatesInFile: [],
    };
  }
  const header = lines[0].split(/[,;]/).map((h) => h.trim().toLowerCase());
  const idx = (name: string) => header.indexOf(name);
  const required = ['studentid', 'firstname', 'lastname', 'level', 'establishmentcode'];
  for (const r of required) {
    if (idx(r) < 0) {
      return {
        ok: false,
        rows: [],
        errors: [{ line: 1, reason: `Colonne manquante : ${r}` }],
        duplicatesInFile: [],
      };
    }
  }
  const seen = new Set<string>();
  const duplicatesInFile: string[] = [];
  for (let i = 1; i < lines.length; i++) {
    const lineNo = i + 1;
    const cols = lines[i].split(/[,;]/).map((c) => c.trim());
    if (cols.every((c) => !c)) continue;
    const studentId = cols[idx('studentid')] || '';
    const firstName = cols[idx('firstname')] || '';
    const lastName = cols[idx('lastname')] || '';
    const levelRaw = cols[idx('level')] || '';
    const establishmentCode = (cols[idx('establishmentcode')] || '').toUpperCase();
    const email = idx('email') >= 0 ? cols[idx('email')] : undefined;

    if (!studentId || !firstName || !lastName || !levelRaw || !establishmentCode) {
      errors.push({ line: lineNo, reason: 'Champs obligatoires manquants', raw: lines[i] });
      continue;
    }
    const level = normalizeLevel(levelRaw);
    if (!KNOWN_LEVELS.has(level)) {
      errors.push({ line: lineNo, reason: `Niveau inconnu : ${levelRaw}`, raw: lines[i] });
      continue;
    }
    if (seen.has(studentId)) {
      duplicatesInFile.push(studentId);
      errors.push({ line: lineNo, reason: `Doublon dans le fichier : ${studentId}` });
      continue;
    }
    seen.add(studentId);
    rows.push({
      line: lineNo,
      studentId,
      firstName,
      lastName,
      level,
      establishmentCode,
      email: email || undefined,
    });
  }
  return {
    ok: errors.length === 0 && rows.length > 0,
    rows,
    errors,
    duplicatesInFile,
  };
}
