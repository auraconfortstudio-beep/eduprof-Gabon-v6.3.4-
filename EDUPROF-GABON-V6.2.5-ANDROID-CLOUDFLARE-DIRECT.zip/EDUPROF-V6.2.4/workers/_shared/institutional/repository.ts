/**
 * Repository institutionnel V6.2 — façade D1 / mémoire tests.
 */
import {
  listEstablishments,
  getEstablishment,
  createEstablishment,
  updateEstablishment,
  listActivations,
  listInstitutionalAudit,
} from './store.ts';
import { listMemberships } from './memberships.ts';
import { getDb } from '../../platform/db.ts';

export const InstitutionalRepository = {
  establishments: {
    list: listEstablishments,
    get: getEstablishment,
    create: createEstablishment,
    update: updateEstablishment,
  },
  activations: {
    list: listActivations,
  },
  memberships: {
    list: listMemberships,
  },
  audit: {
    list: listInstitutionalAudit,
  },
  get backend(): 'd1' | 'memory' {
    return getDb() ? 'd1' : 'memory';
  },
  futureBackend: 'cloudflare-d1' as const,
};

export type InstitutionalRepositoryType = typeof InstitutionalRepository;
