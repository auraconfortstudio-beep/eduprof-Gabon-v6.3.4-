/**
 * RBAC institutionnel EduProf — réimplémentation native.
 * Inspiration conceptuelle : RBAC-dashboard (MIT), RBACStack (Apache-2.0).
 */
import type { Role, UserRecord } from '../types.ts';

export type Permission =
  | 'users.read'
  | 'users.create'
  | 'users.update'
  | 'users.disable'
  | 'students.read'
  | 'students.create'
  | 'students.update'
  | 'students.activate'
  | 'students.deactivate'
  | 'establishments.read'
  | 'establishments.create'
  | 'establishments.update'
  | 'establishments.disable'
  | 'activations.read'
  | 'activations.create'
  | 'activations.cancel'
  | 'activations.renew'
  | 'roles.read'
  | 'roles.manage'
  | 'audit.read'
  | 'csv.import';

const ALL: Permission[] = [
  'users.read', 'users.create', 'users.update', 'users.disable',
  'students.read', 'students.create', 'students.update', 'students.activate', 'students.deactivate',
  'establishments.read', 'establishments.create', 'establishments.update', 'establishments.disable',
  'activations.read', 'activations.create', 'activations.cancel', 'activations.renew',
  'roles.read', 'roles.manage', 'audit.read', 'csv.import',
];

const ROLE_PERMS: Record<Role, Permission[]> = {
  OWNER: [...ALL],
  ADMIN: ALL.filter((p) => p !== 'roles.manage'),
  ESTABLISHMENT_ADMIN: [
    'students.read', 'students.create', 'students.update', 'students.activate', 'students.deactivate',
    'establishments.read',
    'activations.read', 'activations.create', 'activations.cancel', 'activations.renew',
    'audit.read', 'csv.import',
  ],
  TEACHER: ['students.read', 'activations.read'],
  STUDENT: [],
  USER: [], // legacy élève
};

export function permissionsFor(role: Role): Permission[] {
  return ROLE_PERMS[role] || [];
}

export function hasPermission(user: UserRecord | null | undefined, perm: Permission): boolean {
  if (!user) return false;
  if (user.role === 'OWNER') return true;
  return permissionsFor(user.role).includes(perm);
}

/** Isolation établissement : OWNER/ADMIN global ; ESTABLISHMENT_ADMIN limité */
export function canAccessEstablishment(
  user: UserRecord,
  establishmentId: string | null | undefined
): boolean {
  if (!user) return false;
  if (user.role === 'OWNER' || user.role === 'ADMIN') return true;
  if (!establishmentId) return false;
  return user.establishmentId === establishmentId;
}

export function assertEstablishmentAccess(
  user: UserRecord,
  establishmentId: string | null | undefined
): { ok: true } | { ok: false; error: string; status: number } {
  if (canAccessEstablishment(user, establishmentId)) return { ok: true };
  return { ok: false, error: 'Accès refusé à cet établissement', status: 403 };
}
