/**
 * Gate d'accès commercial institutionnel.
 * PAS de paiement Premium individuel dans l'app élève.
 * Accès institutionnel = activation établissement active et non expirée.
 * Compatibilité : USER/STUDENT sans establishmentId conserve l'accès libre (legacy).
 */
import type { UserRecord } from '../types.ts';
import { listActivations, refreshActivationStatus } from './store.ts';

export interface AccessGateResult {
  allowed: boolean;
  reason?: string;
  status?: string;
  establishmentId?: string | null;
  expiresAt?: string | null;
}

export async function checkInstitutionalAccess(user: UserRecord | null | undefined): Promise<AccessGateResult> {
  if (!user) {
    return { allowed: false, reason: 'Non authentifié', status: 'anonymous' };
  }
  if (
    user.role === 'OWNER' ||
    user.role === 'ADMIN' ||
    user.role === 'ESTABLISHMENT_ADMIN' ||
    user.role === 'TEACHER'
  ) {
    return {
      allowed: true,
      status: 'staff',
      establishmentId: user.establishmentId ?? null,
    };
  }
  if (!user.establishmentId) {
    return { allowed: true, status: 'legacy_open', establishmentId: null };
  }
  const acts = await listActivations({ userId: user.id, establishmentId: user.establishmentId });
  for (const a of acts) {
    const r = await refreshActivationStatus(a);
    if (r.status === 'active') {
      return {
        allowed: true,
        status: 'active',
        establishmentId: r.establishmentId,
        expiresAt: r.expiresAt,
      };
    }
  }
  const status = user.accessStatus || 'pending';
  if (status === 'active') {
    if (user.accessExpiresAt && new Date(user.accessExpiresAt).getTime() < Date.now()) {
      return {
        allowed: false,
        reason: 'Accès expiré — contactez votre établissement pour renouveler',
        status: 'expired',
        establishmentId: user.establishmentId,
        expiresAt: user.accessExpiresAt,
      };
    }
    return {
      allowed: true,
      status: 'active',
      establishmentId: user.establishmentId,
      expiresAt: user.accessExpiresAt ?? null,
    };
  }
  return {
    allowed: false,
    reason:
      status === 'expired'
        ? 'Accès expiré — contactez votre établissement'
        : status === 'revoked'
          ? 'Accès révoqué'
          : status === 'suspended'
            ? 'Compte suspendu'
            : "Compte en attente d'activation par votre établissement",
    status,
    establishmentId: user.establishmentId,
    expiresAt: user.accessExpiresAt ?? null,
  };
}
