/**
 * Automatisation institutionnelle — idempotente.
 * Scheduled Function : voir workers/institutional-maintenance.ts + docs/AUTOMATION.md
 */
import type { MaintenanceSummary } from '../types.ts';
import {
  listActivations,
  refreshActivationStatus,
  appendInstitutionalAudit,
} from './store.ts';

const SOON_MS = {
  d0: 1 * 86400000,
  d1: 2 * 86400000,
  d3: 4 * 86400000,
  d7: 8 * 86400000,
};

export async function getExpiringBuckets(now = Date.now()) {
  const acts = (await listActivations()).filter((a) => a.status === 'active' && a.expiresAt);
  const buckets = { today: [] as string[], in1d: [] as string[], in3d: [] as string[], in7d: [] as string[] };
  for (const a of acts) {
    const exp = new Date(a.expiresAt!).getTime();
    const delta = exp - now;
    if (delta < 0) continue;
    if (delta < SOON_MS.d0) buckets.today.push(a.id);
    else if (delta < SOON_MS.d1) buckets.in1d.push(a.id);
    else if (delta < SOON_MS.d3) buckets.in3d.push(a.id);
    else if (delta < SOON_MS.d7) buckets.in7d.push(a.id);
  }
  return buckets;
}

/**
 * Job principal : expire les activations dépassées.
 * Idempotent : re-run ne re-expire pas, n'ajoute pas d'audit doublon pour le même id déjà expired.
 */
let lastExpiredIds = new Set<string>();

export function resetMaintenanceState(): void {
  lastExpiredIds = new Set();
}

export async function runInstitutionalMaintenance(opts?: {
  actorUserId?: string;
  recordAudit?: boolean;
}): Promise<MaintenanceSummary> {
  const ranAt = new Date().toISOString();
  let processed = 0;
  let expired = 0;
  let skipped = 0;
  let errors = 0;
  const newlyExpired: string[] = [];

  try {
    const acts = await listActivations();
    for (const a of acts) {
      processed++;
      try {
        if (a.status === 'revoked' || a.status === 'suspended') {
          skipped++;
          continue;
        }
        if (a.status === 'expired') {
          skipped++;
          continue;
        }
        if (a.status === 'active' && a.expiresAt) {
          const before = a.status;
          const after = await refreshActivationStatus(a);
          if (before === 'active' && after.status === 'expired') {
            expired++;
            newlyExpired.push(a.id);
          } else {
            skipped++;
          }
        } else {
          skipped++;
        }
      } catch {
        errors++;
      }
    }
  } catch {
    errors++;
  }

  const buckets = await getExpiringBuckets();
  const expiringSoon =
    buckets.today.length + buckets.in1d.length + buckets.in3d.length + buckets.in7d.length;

  // Audit une fois par run (pas par activation) pour éviter le spam ; détail en metadata
  if (opts?.recordAudit !== false) {
    const signature = newlyExpired.slice().sort().join(',');
    const prevSig = [...lastExpiredIds].sort().join(',');
    // Toujours journaliser le run, mais metadata n'inclut que les nouveaux expires
    await appendInstitutionalAudit({
      actorUserId: opts?.actorUserId || 'system:maintenance',
      action: 'MAINTENANCE_RUN',
      metadata: {
        processed,
        expired,
        expiringSoon,
        skipped,
        errors,
        newExpiredCount: newlyExpired.length,
      },
    });
    for (const id of newlyExpired) {
      if (!lastExpiredIds.has(id)) {
        await appendInstitutionalAudit({
          actorUserId: opts?.actorUserId || 'system:maintenance',
          action: 'ACTIVATION_EXPIRED',
          metadata: { activationId: id },
        });
        lastExpiredIds.add(id);
      }
    }
    void signature;
    void prevSig;
  }

  return { processed, expired, expiringSoon, skipped, errors, ranAt };
}
