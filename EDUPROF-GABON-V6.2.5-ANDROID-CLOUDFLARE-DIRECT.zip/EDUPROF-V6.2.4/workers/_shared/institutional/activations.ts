/**
 * Cycle de vie activations V6.2 — async, persistant via store D1.
 */
import type { UserRecord, AccessStatus } from '../types.ts';
import {
  upsertActivation,
  refreshActivationStatus,
  listActivations,
  getActivationForUser,
  appendInstitutionalAudit,
} from './store.ts';

export function computeExpiry(days: number): string {
  const d = new Date();
  d.setUTCDate(d.getUTCDate() + Math.max(1, Math.floor(days)));
  return d.toISOString();
}

export async function activateStudent(opts: {
  user: UserRecord;
  establishmentId: string;
  days: number;
  actor: UserRecord;
}): Promise<{ ok: true; activation: Awaited<ReturnType<typeof upsertActivation>> } | { ok: false; error: string }> {
  const days = Math.max(1, Math.floor(opts.days || 30));
  const expiresAt = computeExpiry(days);
  const now = new Date().toISOString();
  opts.user.establishmentId = opts.establishmentId;
  opts.user.accessStatus = 'active';
  opts.user.accessExpiresAt = expiresAt;
  opts.user.accessActivatedAt = now;
  opts.user.updatedAt = now;
  const activation = await upsertActivation({
    userId: opts.user.id,
    establishmentId: opts.establishmentId,
    status: 'active',
    expiresAt,
    activatedAt: now,
    activatedBy: opts.actor.id,
  });
  await appendInstitutionalAudit({
    actorUserId: opts.actor.id,
    actorEmail: opts.actor.email,
    action: 'STUDENT_ACTIVATED',
    targetUserId: opts.user.id,
    targetEstablishmentId: opts.establishmentId,
    metadata: { days },
  });
  return { ok: true, activation };
}

export async function deactivateStudent(opts: {
  user: UserRecord;
  establishmentId: string;
  actor: UserRecord;
  status?: 'revoked' | 'suspended';
}): Promise<{ ok: true } | { ok: false; error: string }> {
  const status: AccessStatus = opts.status || 'revoked';
  opts.user.accessStatus = status;
  opts.user.updatedAt = new Date().toISOString();
  await upsertActivation({
    userId: opts.user.id,
    establishmentId: opts.establishmentId,
    status,
  });
  await appendInstitutionalAudit({
    actorUserId: opts.actor.id,
    actorEmail: opts.actor.email,
    action: status === 'revoked' ? 'STUDENT_REVOKED' : 'STUDENT_DEACTIVATED',
    targetUserId: opts.user.id,
    targetEstablishmentId: opts.establishmentId,
  });
  return { ok: true };
}

export async function renewStudent(opts: {
  user: UserRecord;
  establishmentId: string;
  days: number;
  actor: UserRecord;
}): Promise<{ ok: true; activation: Awaited<ReturnType<typeof upsertActivation>> } | { ok: false; error: string }> {
  const r = await activateStudent(opts);
  if (r.ok) {
    await appendInstitutionalAudit({
      actorUserId: opts.actor.id,
      actorEmail: opts.actor.email,
      action: 'STUDENT_RENEWED',
      targetUserId: opts.user.id,
      targetEstablishmentId: opts.establishmentId,
      metadata: { days: opts.days },
    });
  }
  return r;
}

export async function bulkActivate(opts: {
  users: UserRecord[];
  establishmentId: string;
  days: number;
  actor: UserRecord;
}): Promise<{ success: string[]; failed: { userId: string; reason: string }[] }> {
  const success: string[] = [];
  const failed: { userId: string; reason: string }[] = [];
  for (const u of opts.users) {
    try {
      if (u.establishmentId && u.establishmentId !== opts.establishmentId) {
        failed.push({ userId: u.id, reason: 'Élève rattaché à un autre établissement' });
        continue;
      }
      const r = await activateStudent({
        user: u,
        establishmentId: opts.establishmentId,
        days: opts.days,
        actor: opts.actor,
      });
      if (r.ok) success.push(u.id);
      else failed.push({ userId: u.id, reason: r.error });
    } catch (e) {
      failed.push({ userId: u.id, reason: e instanceof Error ? e.message : 'Erreur' });
    }
  }
  await appendInstitutionalAudit({
    actorUserId: opts.actor.id,
    actorEmail: opts.actor.email,
    action: 'BULK_ACTIVATION',
    targetEstablishmentId: opts.establishmentId,
    metadata: { success: success.length, failed: failed.length, days: opts.days },
  });
  return { success, failed };
}

export async function syncExpiredActivations(): Promise<number> {
  let n = 0;
  for (const a of await listActivations()) {
    const before = a.status;
    const after = await refreshActivationStatus(a);
    if (before === 'active' && after.status === 'expired') n++;
  }
  return n;
}

export async function getEffectiveAccess(user: UserRecord): Promise<AccessStatus | 'open'> {
  const act = await getActivationForUser(user.id, user.establishmentId || undefined);
  if (act) return (await refreshActivationStatus(act)).status;
  return user.accessStatus || 'open';
}
