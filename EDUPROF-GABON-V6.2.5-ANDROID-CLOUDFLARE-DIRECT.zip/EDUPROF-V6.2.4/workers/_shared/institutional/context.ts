/**
 * Résolution du contexte établissement côté serveur (async V6.2).
 */
import type { UserRecord, Establishment } from '../types.ts';
import { getEstablishment, listEstablishments } from './store.ts';
import { hasActiveMembership } from './memberships.ts';
import { canAccessEstablishment } from './permissions.ts';

export interface EstablishmentContext {
  actor: UserRecord;
  establishmentId: string | null;
  establishment: Establishment | null;
  isGlobal: boolean;
}

export async function resolveEstablishmentContext(
  actor: UserRecord,
  requestedId?: string | null
): Promise<{ ok: true; ctx: EstablishmentContext } | { ok: false; error: string; status: number }> {
  const isGlobal = actor.role === 'OWNER' || actor.role === 'ADMIN';

  if (!isGlobal) {
    const forced = actor.establishmentId || null;
    if (!forced) {
      return { ok: false, error: 'Aucun établissement rattaché à ce compte', status: 403 };
    }
    if (requestedId && requestedId !== forced) {
      return { ok: false, error: 'Accès refusé à cet établissement', status: 403 };
    }
    const membershipOk = await hasActiveMembership(actor, forced);
    if (!membershipOk && !canAccessEstablishment(actor, forced)) {
      return { ok: false, error: 'Membership inactif ou accès refusé', status: 403 };
    }
    const est = (await getEstablishment(forced)) || null;
    return {
      ok: true,
      ctx: { actor, establishmentId: forced, establishment: est, isGlobal: false },
    };
  }

  if (requestedId) {
    const est = await getEstablishment(requestedId);
    if (!est) return { ok: false, error: 'Établissement introuvable', status: 404 };
    return {
      ok: true,
      ctx: { actor, establishmentId: requestedId, establishment: est, isGlobal: true },
    };
  }

  return {
    ok: true,
    ctx: { actor, establishmentId: null, establishment: null, isGlobal: true },
  };
}

export async function assertTenantWrite(
  actor: UserRecord,
  targetEstablishmentId: string
): Promise<{ ok: true } | { ok: false; error: string; status: number }> {
  const r = await resolveEstablishmentContext(actor, targetEstablishmentId);
  if (!r.ok) return r;
  if (!r.ctx.establishmentId) {
    return { ok: false, error: 'Établissement requis', status: 400 };
  }
  const est = r.ctx.establishment;
  if (est && est.status === 'suspended' && actor.role !== 'OWNER' && actor.role !== 'ADMIN') {
    return { ok: false, error: 'Établissement suspendu', status: 403 };
  }
  return { ok: true };
}

export async function listVisibleEstablishments(actor: UserRecord): Promise<Establishment[]> {
  if (actor.role === 'OWNER' || actor.role === 'ADMIN') {
    return listEstablishments();
  }
  if (actor.establishmentId) {
    const e = await getEstablishment(actor.establishmentId);
    return e ? [e] : [];
  }
  return [];
}
