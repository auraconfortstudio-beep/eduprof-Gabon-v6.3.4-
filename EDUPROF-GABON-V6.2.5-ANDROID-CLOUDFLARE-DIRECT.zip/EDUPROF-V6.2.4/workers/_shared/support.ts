/**
 * Support tickets — tenant-aware, isolation user/admin.
 */
import { randomUUID } from 'crypto';
import { createNotification } from './notifications.ts';

export type TicketCategory =
  | 'ACCOUNT'
  | 'ACCESS'
  | 'COURSE'
  | 'QUIZ'
  | 'AI'
  | 'ATTACHMENT'
  | 'TECHNICAL'
  | 'OTHER';

export type TicketStatus = 'OPEN' | 'IN_PROGRESS' | 'WAITING_USER' | 'RESOLVED' | 'CLOSED';
export type TicketPriority = 'low' | 'normal' | 'high';

export interface SupportTicket {
  id: string;
  userId: string;
  establishmentId?: string | null;
  subject: string;
  message: string;
  category: TicketCategory;
  priority: TicketPriority;
  status: TicketStatus;
  createdAt: string;
  updatedAt: string;
  assignedTo?: string | null;
  replies?: { id: string; authorId: string; body: string; createdAt: string }[];
}

const tickets = new Map<string, SupportTicket>();

export function resetSupportTickets(): void {
  tickets.clear();
}

export function createTicket(input: {
  userId: string;
  establishmentId?: string | null;
  subject: string;
  message: string;
  category?: TicketCategory;
  priority?: TicketPriority;
}): SupportTicket {
  const now = new Date().toISOString();
  const t: SupportTicket = {
    id: randomUUID(),
    userId: input.userId,
    establishmentId: input.establishmentId ?? null,
    subject: input.subject.trim().slice(0, 120),
    message: input.message.trim().slice(0, 2000),
    category: input.category || 'OTHER',
    priority: input.priority || 'normal',
    status: 'OPEN',
    createdAt: now,
    updatedAt: now,
    assignedTo: null,
    replies: [],
  };
  tickets.set(t.id, t);
  createNotification({
    userId: input.userId,
    establishmentId: input.establishmentId,
    type: 'SUPPORT',
    title: 'Ticket créé',
    message: `Votre demande « ${t.subject} » a été enregistrée.`,
    metadata: { ticketId: t.id },
  });
  return t;
}

export function getTicket(id: string): SupportTicket | undefined {
  return tickets.get(id);
}

export function listTicketsForUser(userId: string): SupportTicket[] {
  return [...tickets.values()]
    .filter((t) => t.userId === userId)
    .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
}

export function listTicketsForEstablishment(establishmentId: string): SupportTicket[] {
  return [...tickets.values()]
    .filter((t) => t.establishmentId === establishmentId)
    .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
}

export function listAllTickets(): SupportTicket[] {
  return [...tickets.values()].sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
}

export function updateTicketStatus(
  id: string,
  status: TicketStatus,
  actorId: string
): SupportTicket | null {
  const t = tickets.get(id);
  if (!t) return null;
  t.status = status;
  t.updatedAt = new Date().toISOString();
  if (status === 'RESOLVED' || status === 'CLOSED') {
    createNotification({
      userId: t.userId,
      establishmentId: t.establishmentId,
      type: 'SUPPORT',
      title: status === 'RESOLVED' ? 'Ticket résolu' : 'Ticket fermé',
      message: `Votre ticket « ${t.subject} » est maintenant ${status}.`,
      metadata: { ticketId: t.id, actorId },
    });
  }
  return t;
}

export function replyToTicket(
  id: string,
  authorId: string,
  body: string
): SupportTicket | null {
  const t = tickets.get(id);
  if (!t) return null;
  const reply = {
    id: randomUUID(),
    authorId,
    body: body.trim().slice(0, 2000),
    createdAt: new Date().toISOString(),
  };
  t.replies = [...(t.replies || []), reply];
  t.updatedAt = reply.createdAt;
  if (t.status === 'OPEN') t.status = 'IN_PROGRESS';
  // Notify the other party
  const notifyUserId = authorId === t.userId ? t.assignedTo || t.userId : t.userId;
  if (notifyUserId && notifyUserId !== authorId) {
    createNotification({
      userId: notifyUserId,
      establishmentId: t.establishmentId,
      type: 'SUPPORT',
      title: 'Nouvelle réponse support',
      message: `Réponse sur « ${t.subject} ».`,
      metadata: { ticketId: t.id },
    });
  }
  return t;
}

export function assignTicket(id: string, assigneeId: string): SupportTicket | null {
  const t = tickets.get(id);
  if (!t) return null;
  t.assignedTo = assigneeId;
  t.updatedAt = new Date().toISOString();
  if (t.status === 'OPEN') t.status = 'IN_PROGRESS';
  createNotification({
    userId: assigneeId,
    establishmentId: t.establishmentId,
    type: 'SUPPORT',
    title: 'Ticket assigné',
    message: `Ticket « ${t.subject} » vous a été assigné.`,
    metadata: { ticketId: t.id },
  });
  return t;
}

/** Accès lecture ticket : propriétaire ou admin même tenant / global */
export function canAccessTicket(
  ticket: SupportTicket,
  actor: { id: string; role: string; establishmentId?: string | null }
): boolean {
  if (ticket.userId === actor.id) return true;
  if (actor.role === 'OWNER' || actor.role === 'ADMIN') return true;
  if (
    (actor.role === 'ESTABLISHMENT_ADMIN' || actor.role === 'TEACHER') &&
    actor.establishmentId &&
    ticket.establishmentId === actor.establishmentId
  ) {
    return true;
  }
  return false;
}
