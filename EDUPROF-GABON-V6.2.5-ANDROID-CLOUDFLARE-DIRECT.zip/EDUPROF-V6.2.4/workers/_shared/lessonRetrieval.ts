import lessonCatalogJson from './lesson-catalog.json';
/**
 * Retrieval pédagogique serveur — lesson-catalog.json (généré depuis getLevels()).
 * Isolation stricte des séries, sauf contenus explicitement PARTAGE / allowedSeries.
 */

export interface CatalogExercise {
  id?: string;
  question: string;
  difficulty?: string;
}

export interface CatalogQuiz {
  id?: string;
  question: string;
}

export interface LessonCatalogEntry {
  lessonId: string;
  levelId: string;
  seriesId: string | null;
  allowedSeries?: string[];
  subjectId: string;
  subjectName: string;
  chapterId: string;
  chapterTitle: string;
  title: string;
  objective: string;
  content: string;
  example: string;
  keyPoints: string[];
  exercises: CatalogExercise[];
  quiz: CatalogQuiz[];
  status: string;
  source: string;
  legacy?: boolean;
  shared?: boolean;
}

export type RetrievalResult =
  | { ok: true; lesson: LessonCatalogEntry; isolationOk: true }
  | {
      ok: false;
      reason: 'not_found' | 'series_mismatch' | 'catalog_missing';
      message: string;
    };

type CatalogFile = {
  lessons: Record<string, LessonCatalogEntry>;
  byChapter?: Record<string, string>;
  stats?: Record<string, unknown>;
};

let cached: CatalogFile | null = null;

function loadCatalog(): CatalogFile {
  if (cached) return cached;
  try {
    cached = lessonCatalogJson as CatalogFile;
  } catch {
    cached = { lessons: {} };
  }
  return cached!;
}

export function normSeries(raw?: string | null): string {
  if (!raw) return '';
  const v = String(raw).trim().toLowerCase();
  const map: Record<string, string> = {
    a: 'serie-a',
    a1: 'serie-a1',
    a2: 'serie-a2',
    b: 'serie-b',
    c: 'serie-c',
    d: 'serie-d',
    s: 'serie-s',
    le: 'serie-le',
    'serie-a': 'serie-a',
    'serie-a1': 'serie-a1',
    'serie-a2': 'serie-a2',
    'serie-b': 'serie-b',
    'serie-c': 'serie-c',
    'serie-d': 'serie-d',
    'serie-s': 'serie-s',
    'serie-le': 'serie-le',
  };
  if (map[v]) return map[v];
  if (v.startsWith('serie-')) return v;
  return v ? `serie-${v}` : '';
}

function seriesAllows(lesson: LessonCatalogEntry, requestedRaw: string | null | undefined): boolean {
  if (!requestedRaw) return true; // pas de contrainte série côté client
  const requested = normSeries(requestedRaw);
  if (!requested) return true;

  const allowed = (lesson.allowedSeries || [])
    .map(normSeries)
    .filter(Boolean);
  if (allowed.length > 0) {
    return allowed.includes(requested);
  }

  // Fallback : seriesId unique
  const actual = normSeries(lesson.seriesId);
  if (!actual) {
    // Contenu sans série (collège, CM2, univ) : OK pour tout profil
    return true;
  }
  return actual === requested;
}

export function retrieveLesson(params: {
  lessonId?: string | null;
  seriesId?: string | null;
  subjectId?: string | null;
  levelId?: string | null;
  chapterId?: string | null;
}): RetrievalResult {
  const catalog = loadCatalog();
  if (!catalog.lessons || Object.keys(catalog.lessons).length === 0) {
    return {
      ok: false,
      reason: 'catalog_missing',
      message: 'Catalogue de leçons indisponible sur le serveur.',
    };
  }

  let lessonId = (params.lessonId || '').trim();
  if (!lessonId && params.chapterId) {
    const mapped = catalog.byChapter?.[params.chapterId];
    if (mapped) lessonId = mapped;
  }

  let lesson = lessonId ? catalog.lessons[lessonId] : undefined;

  if (!lesson && params.subjectId) {
    const candidates = Object.values(catalog.lessons).filter((l) => {
      if (l.subjectId !== params.subjectId && !l.subjectId.endsWith(`-${params.subjectId}`)) {
        return false;
      }
      if (params.levelId && l.levelId !== params.levelId) return false;
      return seriesAllows(l, params.seriesId);
    });
    lesson = candidates[0];
  }

  if (!lesson) {
    return {
      ok: false,
      reason: 'not_found',
      message:
        'Leçon introuvable dans le catalogue EduProf. Le professeur n’inventera pas le cours.',
    };
  }

  if (!seriesAllows(lesson, params.seriesId)) {
    return {
      ok: false,
      reason: 'series_mismatch',
      message: `Cette leçon n’est pas autorisée pour la série ${params.seriesId} (série du contenu : ${lesson.seriesId || 'n/a'}).`,
    };
  }

  return { ok: true, lesson, isolationOk: true };
}

export function formatLessonContextForPrompt(
  lesson: LessonCatalogEntry,
  maxChars = 3500
): string {
  const parts: string[] = [
    '=== CONTENU EDUPROF (source de référence pour cette leçon) ===',
    `Niveau : ${lesson.levelId}`,
    lesson.seriesId ? `Série : ${lesson.seriesId}` : null,
    lesson.status ? `Statut contenu : ${lesson.status}` : null,
    `Matière : ${lesson.subjectName} (${lesson.subjectId})`,
    lesson.chapterTitle ? `Chapitre : ${lesson.chapterTitle}` : null,
    `Leçon : ${lesson.title}`,
  ].filter(Boolean) as string[];

  if (lesson.objective) parts.push(`Objectif : ${lesson.objective}`);
  if (lesson.content) {
    const c =
      lesson.content.length > 2200
        ? lesson.content.slice(0, 2200) + '…'
        : lesson.content;
    parts.push(`Cours :\n${c}`);
  }
  if (lesson.example) parts.push(`Exemple : ${lesson.example}`);
  if (lesson.keyPoints?.length) {
    parts.push('Points clés :\n- ' + lesson.keyPoints.join('\n- '));
  }
  if (lesson.exercises?.length) {
    parts.push(
      'Exercices associés (énoncés — guide l’élève, ne donne pas la réponse d’emblée) :'
    );
    lesson.exercises.slice(0, 5).forEach((ex, i) => {
      parts.push(
        `${i + 1}. ${ex.question}${ex.difficulty ? ` [${ex.difficulty}]` : ''}`
      );
    });
  }
  if (lesson.quiz?.length) {
    parts.push('Questions de révision possibles :');
    lesson.quiz.slice(0, 4).forEach((q, i) => {
      parts.push(`${i + 1}. ${q.question}`);
    });
  }
  parts.push(
    '=== FIN CONTENU EDUPROF ===',
    'Si une information demandée n’apparaît pas ci-dessus, dis-le clairement. Ne l’invente pas comme provenant du cours EduProf.'
  );
  let out = parts.join('\n');
  if (out.length > maxChars) out = out.slice(0, maxChars) + '\n…[contexte tronqué]';
  return out;
}

export function catalogStats(): Record<string, unknown> | null {
  return loadCatalog().stats || null;
}

export function _resetCatalogCache() {
  cached = null;
}
