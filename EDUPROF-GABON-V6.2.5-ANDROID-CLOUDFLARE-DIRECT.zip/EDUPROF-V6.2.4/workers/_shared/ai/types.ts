/**
 * Generic AI provider contract — no vendor names in the orchestrator.
 */

export type ProviderHealth =
  | 'available'
  | 'temporarily_unavailable'
  | 'quota_exceeded'
  | 'invalid_key';

export type AIMessageRole = 'user' | 'assistant' | 'system';

export interface AIMessage {
  role: AIMessageRole;
  content: string;
}

export interface AIGenerateRequest {
  /** System / pedagogical instructions */
  systemPrompt: string;
  /** Conversation turns (user + assistant). System goes in systemPrompt. */
  messages: AIMessage[];
  maxTokens?: number;
  temperature?: number;
}

export interface AIGenerateResponse {
  content: string;
  /** Optional usage metadata from a provider */
  usage?: {
    promptTokens?: number;
    completionTokens?: number;
  };
}

export interface AIProvider {
  /** Stable identifier, e.g. "provider-a" — injected, not hardcoded in orchestrator */
  readonly id: string;
  generate(request: AIGenerateRequest): Promise<AIGenerateResponse>;
}

/** Client → Edge Function payload */
export interface AITutorClientRequest {
  level: string;
  className?: string;
  series?: string | null;
  filiere?: string | null;
  subject?: string | null;
  subjectId?: string | null;
  subjectName?: string | null;
  chapterId?: string | null;
  chapterName?: string | null;
  lesson?: string | null;
  lessonId?: string | null;
  lessonTitle?: string | null;
  exerciseId?: string | null;
  quizId?: string | null;
  question: string;
  history?: AIMessage[];
}

export interface AITutorClientResponse {
  content: string;
  providerId?: string;
  source: 'backend' | 'local-fallback';
  error?: string;
}

/** Classification of failures for fallback decisions */
export type AIErrorKind =
  | 'invalid_request'
  | 'timeout'
  | 'network'
  | 'quota'
  | 'unavailable'
  | 'invalid_key'
  | 'server'
  | 'unknown';

export interface OrchestratorResult {
  content: string;
  providerId: string;
  attempts: { providerId: string; ok: boolean; errorKind?: AIErrorKind }[];
}

export interface OrchestratorOptions {
  /** Per-attempt timeout in ms */
  timeoutMs?: number;
  /** Default cooldown after temporary failure (ms) */
  cooldownMs?: number;
  /** Cooldown after quota exceeded (ms) */
  quotaCooldownMs?: number;
  /** Enable in-flight request deduplication */
  dedupe?: boolean;
}


/** Contexte scolaire transmis à Maël */
export interface TutorContext {
  level?: string;
  series?: string | null;
  filiere?: string | null;
  subjectId?: string;
  subjectName?: string;
  chapterId?: string;
  chapterName?: string;
  lessonId?: string;
  lessonTitle?: string;
  exerciseId?: string;
  quizId?: string;
}
