import type {
  AIGenerateRequest,
  AIGenerateResponse,
  AIProvider,
  AIErrorKind,
  OrchestratorOptions,
  OrchestratorResult,
  ProviderHealth,
} from './types.ts';
import {
  AIError,
  AllProvidersFailedError,
  classifyThrown,
  isNonRetryableKind,
} from './errors.ts';

interface ProviderRuntimeState {
  health: ProviderHealth;
  cooldownUntil: number;
}

const DEFAULT_TIMEOUT_MS = 12_000;
const DEFAULT_COOLDOWN_MS = 30_000;
const DEFAULT_QUOTA_COOLDOWN_MS = 60_000;

/**
 * Multi-provider relay orchestrator.
 * Providers are injected in priority order (index 0 = highest priority).
 * After cooldown expires, a secondary provider yields back to higher-priority ones.
 */
export class AIOrchestrator {
  private readonly providers: AIProvider[];
  private readonly state = new Map<string, ProviderRuntimeState>();
  private readonly timeoutMs: number;
  private readonly cooldownMs: number;
  private readonly quotaCooldownMs: number;
  private readonly dedupe: boolean;
  private readonly inFlight = new Map<string, Promise<OrchestratorResult>>();
  /** Injectable clock for tests */
  private nowFn: () => number = () => Date.now();

  constructor(providers: AIProvider[], options: OrchestratorOptions = {}) {
    if (!providers.length) {
      throw new Error('AIOrchestrator requires at least one provider');
    }
    this.providers = [...providers];
    for (const p of this.providers) {
      this.state.set(p.id, { health: 'available', cooldownUntil: 0 });
    }
    this.timeoutMs = options.timeoutMs ?? DEFAULT_TIMEOUT_MS;
    this.cooldownMs = options.cooldownMs ?? DEFAULT_COOLDOWN_MS;
    this.quotaCooldownMs = options.quotaCooldownMs ?? DEFAULT_QUOTA_COOLDOWN_MS;
    this.dedupe = options.dedupe ?? true;
  }

  /** Test helper: override clock */
  setNow(fn: () => number): void {
    this.nowFn = fn;
  }

  getProviderHealth(providerId: string): ProviderHealth {
    this.refreshCooldowns();
    return this.state.get(providerId)?.health ?? 'available';
  }

  getCooldownRemainingMs(providerId: string): number {
    const s = this.state.get(providerId);
    if (!s) return 0;
    return Math.max(0, s.cooldownUntil - this.nowFn());
  }

  /** Force a provider back to available (tests / admin) */
  resetProvider(providerId: string): void {
    this.state.set(providerId, { health: 'available', cooldownUntil: 0 });
  }

  async generate(request: AIGenerateRequest): Promise<OrchestratorResult> {
    this.validateRequest(request);

    const key = this.dedupe ? this.requestKey(request) : null;
    if (key) {
      const existing = this.inFlight.get(key);
      if (existing) return existing;
    }

    const run = this.runGenerate(request);
    if (key) {
      this.inFlight.set(key, run);
      try {
        return await run;
      } finally {
        this.inFlight.delete(key);
      }
    }
    return run;
  }

  private async runGenerate(request: AIGenerateRequest): Promise<OrchestratorResult> {
    this.refreshCooldowns();

    const attempts: OrchestratorResult['attempts'] = [];
    const ordered = this.providersInPriorityOrder();

    for (const provider of ordered) {
      const st = this.state.get(provider.id)!;
      if (st.health !== 'available') {
        attempts.push({
          providerId: provider.id,
          ok: false,
          errorKind: this.healthToKind(st.health),
        });
        continue;
      }

      try {
        const response = await this.withTimeout(provider.generate(request), this.timeoutMs);
        this.markAvailable(provider.id);
        attempts.push({ providerId: provider.id, ok: true });
        return {
          content: response.content,
          providerId: provider.id,
          attempts,
        };
      } catch (err) {
        const aiErr = classifyThrown(err, provider.id);

        if (isNonRetryableKind(aiErr.kind)) {
          // Invalid request — do not try other providers
          attempts.push({ providerId: provider.id, ok: false, errorKind: aiErr.kind });
          throw aiErr;
        }

        this.applyFailure(provider.id, aiErr.kind);
        attempts.push({ providerId: provider.id, ok: false, errorKind: aiErr.kind });
      }
    }

    throw new AllProvidersFailedError(
      attempts.map(a => ({
        providerId: a.providerId,
        errorKind: a.errorKind,
      }))
    );
  }

  private providersInPriorityOrder(): AIProvider[] {
    // Always respect original injection order; cooldown only skips unavailable ones
    return this.providers;
  }

  private validateRequest(request: AIGenerateRequest): void {
    if (!request.systemPrompt || !request.systemPrompt.trim()) {
      throw new AIError('systemPrompt requis', 'invalid_request', { retryable: false });
    }
    if (!request.messages || request.messages.length === 0) {
      throw new AIError('messages requis', 'invalid_request', { retryable: false });
    }
    const lastUser = [...request.messages].reverse().find(m => m.role === 'user');
    if (!lastUser || !lastUser.content.trim()) {
      throw new AIError('Question vide', 'invalid_request', { retryable: false });
    }
    if (lastUser.content.length > 4000) {
      throw new AIError('Question trop longue', 'invalid_request', { retryable: false });
    }
  }

  private applyFailure(providerId: string, kind: AIErrorKind): void {
    const now = this.nowFn();
    let health: ProviderHealth = 'temporarily_unavailable';
    let cooldown = this.cooldownMs;

    if (kind === 'quota') {
      health = 'quota_exceeded';
      cooldown = this.quotaCooldownMs;
    } else if (kind === 'invalid_key') {
      health = 'invalid_key';
      // Long cooldown — key issues need manual fix; still allow eventual retry
      cooldown = this.quotaCooldownMs * 5;
    } else if (kind === 'timeout' || kind === 'network' || kind === 'unavailable' || kind === 'server') {
      health = 'temporarily_unavailable';
      cooldown = this.cooldownMs;
    } else {
      health = 'temporarily_unavailable';
      cooldown = this.cooldownMs;
    }

    this.state.set(providerId, { health, cooldownUntil: now + cooldown });
  }

  private markAvailable(providerId: string): void {
    this.state.set(providerId, { health: 'available', cooldownUntil: 0 });
  }

  private refreshCooldowns(): void {
    const now = this.nowFn();
    for (const [id, st] of this.state) {
      if (st.health !== 'available' && st.cooldownUntil <= now) {
        this.state.set(id, { health: 'available', cooldownUntil: 0 });
      }
    }
  }

  private healthToKind(health: ProviderHealth): AIErrorKind {
    switch (health) {
      case 'quota_exceeded':
        return 'quota';
      case 'invalid_key':
        return 'invalid_key';
      case 'temporarily_unavailable':
        return 'unavailable';
      default:
        return 'unknown';
    }
  }

  private requestKey(request: AIGenerateRequest): string {
    const last = request.messages[request.messages.length - 1]?.content ?? '';
    return `${request.systemPrompt.slice(0, 80)}|${last.slice(0, 200)}|${request.messages.length}`;
  }

  private withTimeout<T>(promise: Promise<T>, ms: number): Promise<T> {
    return new Promise<T>((resolve, reject) => {
      const timer = setTimeout(() => {
        reject(new AIError(`Timeout après ${ms}ms`, 'timeout'));
      }, ms);
      promise
        .then(v => {
          clearTimeout(timer);
          resolve(v);
        })
        .catch(err => {
          clearTimeout(timer);
          reject(err);
        });
    });
  }
}

export type { AIGenerateResponse };
