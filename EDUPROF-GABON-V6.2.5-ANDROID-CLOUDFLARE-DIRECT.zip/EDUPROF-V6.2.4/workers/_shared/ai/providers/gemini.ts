/**
 * GeminiProvider — official Google Generative Language API.
 * Supports optional vision (inline base64 images) when request.images is provided.
 */
import type {
  AIGenerateRequest,
  AIGenerateResponse,
  AIProvider,
} from '../types.ts';
import { AIError } from '../errors.ts';
import { errorFromHttpStatus, networkError } from '../http.ts';

const DEFAULT_MODEL = 'gemini-2.0-flash';
const ENDPOINT_BASE =
  'https://generativelanguage.googleapis.com/v1beta/models';

export interface GeminiProviderOptions {
  apiKey: string;
  model?: string;
  id?: string;
}

/** Extended request with optional inline images (data URLs or raw base64 + mime). */
export interface GeminiVisionRequest extends AIGenerateRequest {
  images?: { mimeType: string; base64: string }[];
}

export function createGeminiProvider(
  opts: GeminiProviderOptions
): AIProvider {
  const id = opts.id ?? 'gemini';
  const model = opts.model || DEFAULT_MODEL;
  const apiKey = opts.apiKey;

  return {
    id,
    async generate(request: AIGenerateRequest): Promise<AIGenerateResponse> {
      const url = `${ENDPOINT_BASE}/${model}:generateContent`;
      const visionReq = request as GeminiVisionRequest;
      const images = visionReq.images || [];

      const contents = request.messages
        .filter(m => m.role === 'user' || m.role === 'assistant')
        .map((m, idx, arr) => {
          const isLastUser =
            m.role === 'user' && idx === arr.map((x) => x.role).lastIndexOf('user');
          const parts: { text?: string; inline_data?: { mime_type: string; data: string } }[] = [
            { text: m.content },
          ];
          // Attach images only on the last user turn
          if (isLastUser && images.length > 0) {
            for (const img of images) {
              let data = img.base64;
              if (data.startsWith('data:')) {
                const comma = data.indexOf(',');
                data = comma >= 0 ? data.slice(comma + 1) : data;
              }
              parts.push({
                inline_data: {
                  mime_type: img.mimeType.startsWith('image/')
                    ? img.mimeType
                    : 'image/jpeg',
                  data,
                },
              });
            }
          }
          return {
            role: m.role === 'assistant' ? 'model' : 'user',
            parts,
          };
        });

      const body: Record<string, unknown> = {
        contents,
        generationConfig: {
          maxOutputTokens: request.maxTokens ?? 2048,
          temperature: request.temperature ?? 0.7,
        },
      };

      if (request.systemPrompt?.trim()) {
        body.systemInstruction = {
          parts: [{ text: request.systemPrompt }],
        };
      }

      let res: Response;
      try {
        res = await fetch(url, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-goog-api-key': apiKey,
          },
          body: JSON.stringify(body),
        });
      } catch (err) {
        throw networkError(id, err);
      }

      const text = await res.text();
      if (!res.ok) {
        throw errorFromHttpStatus(res.status, text, id);
      }

      let data: {
        candidates?: { content?: { parts?: { text?: string }[] } }[];
        usageMetadata?: {
          promptTokenCount?: number;
          candidatesTokenCount?: number;
        };
      };
      try {
        data = JSON.parse(text);
      } catch {
        throw new AIError(`[${id}] réponse JSON invalide`, 'server', {
          providerId: id,
        });
      }

      const content =
        data.candidates?.[0]?.content?.parts
          ?.map(p => p.text ?? '')
          .join('')
          .trim() ?? '';

      if (!content) {
        throw new AIError(`[${id}] réponse vide`, 'unavailable', {
          providerId: id,
        });
      }

      return {
        content,
        usage: {
          promptTokens: data.usageMetadata?.promptTokenCount,
          completionTokens: data.usageMetadata?.candidatesTokenCount,
        },
      };
    },
  };
}

export { DEFAULT_MODEL as GEMINI_DEFAULT_MODEL };
