/**
 * Factory: build the 4 independent brains in priority order.
 * Only providers with a present API key are included.
 * Secrets are read exclusively via the injected getEnv (Cloudflare Worker secrets / currentEnv). Never hardcode API keys.
 */
import type { AIProvider } from '../types.ts';
import { createGeminiProvider, GEMINI_DEFAULT_MODEL } from './gemini.ts';
import { createGroqProvider, GROQ_DEFAULT_MODEL } from './groq.ts';
import { createMistralProvider, MISTRAL_DEFAULT_MODEL } from './mistral.ts';
import {
  createCerebrasProvider,
  CEREBRAS_DEFAULT_MODEL,
} from './cerebras.ts';
import { createMockProvider } from '../mock.ts';

export type EnvGetter = (key: string) => string | undefined;

export interface ConfiguredProvidersResult {
  providers: AIProvider[];
  /** Model IDs actually used (no secrets) */
  models: {
    gemini?: string;
    groq?: string;
    mistral?: string;
    cerebras?: string;
  };
  /** Which brains were activated (ids only) */
  activeIds: string[];
}

/**
 * Priority order (never permanently changed):
 * 1. Gemini  2. Groq  3. Mistral  4. Cerebras
 *
 * Missing key → provider simply omitted (no crash).
 * If zero keys → optional mock fallback for local/dev (includeMocks).
 */
export function createConfiguredProviders(
  getEnv: EnvGetter,
  options?: { includeMocksIfEmpty?: boolean }
): ConfiguredProvidersResult {
  const providers: AIProvider[] = [];
  const models: ConfiguredProvidersResult['models'] = {};
  const activeIds: string[] = [];

  const geminiKey = getEnv('GEMINI_API_KEY')?.trim();
  if (geminiKey) {
    const model = getEnv('GEMINI_MODEL')?.trim() || GEMINI_DEFAULT_MODEL;
    providers.push(createGeminiProvider({ apiKey: geminiKey, model }));
    models.gemini = model;
    activeIds.push('gemini');
  }

  const groqKey = getEnv('GROQ_API_KEY')?.trim();
  if (groqKey) {
    const model = getEnv('GROQ_MODEL')?.trim() || GROQ_DEFAULT_MODEL;
    providers.push(createGroqProvider({ apiKey: groqKey, model }));
    models.groq = model;
    activeIds.push('groq');
  }

  const mistralKey = getEnv('MISTRAL_API_KEY')?.trim();
  if (mistralKey) {
    const model = getEnv('MISTRAL_MODEL')?.trim() || MISTRAL_DEFAULT_MODEL;
    providers.push(createMistralProvider({ apiKey: mistralKey, model }));
    models.mistral = model;
    activeIds.push('mistral');
  }

  const cerebrasKey = getEnv('CEREBRAS_API_KEY')?.trim();
  if (cerebrasKey) {
    const model = getEnv('CEREBRAS_MODEL')?.trim() || CEREBRAS_DEFAULT_MODEL;
    providers.push(createCerebrasProvider({ apiKey: cerebrasKey, model }));
    models.cerebras = model;
    activeIds.push('cerebras');
  }

  if (providers.length === 0 && options?.includeMocksIfEmpty !== false) {
    // Safe offline path: no secrets required
    providers.push(
      createMockProvider({ id: 'mock-primary', behavior: 'success' }),
      createMockProvider({ id: 'mock-secondary', behavior: 'success' }),
      createMockProvider({ id: 'mock-tertiary', behavior: 'success' }),
      createMockProvider({ id: 'mock-quaternary', behavior: 'success' })
    );
    activeIds.push(
      'mock-primary',
      'mock-secondary',
      'mock-tertiary',
      'mock-quaternary'
    );
  }

  return { providers, models, activeIds };
}

export {
  createGeminiProvider,
  createGroqProvider,
  createMistralProvider,
  createCerebrasProvider,
  GEMINI_DEFAULT_MODEL,
  GROQ_DEFAULT_MODEL,
  MISTRAL_DEFAULT_MODEL,
  CEREBRAS_DEFAULT_MODEL,
};
