/**
 * GroqProvider — official Groq OpenAI-compatible API.
 * Independent adapter.
 */
import type {
  AIGenerateRequest,
  AIGenerateResponse,
  AIProvider,
} from '../types.ts';
import { AIError } from '../errors.ts';
import { errorFromHttpStatus, networkError } from '../http.ts';

const DEFAULT_MODEL = 'openai/gpt-oss-120b';
const ENDPOINT = 'https://api.groq.com/openai/v1/chat/completions';

export interface GroqProviderOptions {
  apiKey: string;
  model?: string;
  id?: string;
}

export function createGroqProvider(opts: GroqProviderOptions): AIProvider {
  const id = opts.id ?? 'groq';
  const model = opts.model || DEFAULT_MODEL;
  const apiKey = opts.apiKey;

  return {
    id,
    async generate(request: AIGenerateRequest): Promise<AIGenerateResponse> {
      const messages: { role: string; content: string }[] = [];
      if (request.systemPrompt?.trim()) {
        messages.push({ role: 'system', content: request.systemPrompt });
      }
      for (const m of request.messages) {
        if (m.role === 'system') continue;
        messages.push({
          role: m.role === 'assistant' ? 'assistant' : 'user',
          content: m.content,
        });
      }

      let res: Response;
      try {
        res = await fetch(ENDPOINT, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${apiKey}`,
          },
          body: JSON.stringify({
            model,
            messages,
            max_tokens: request.maxTokens ?? 2048,
            temperature: request.temperature ?? 0.7,
          }),
        });
      } catch (err) {
        throw networkError(id, err);
      }

      const text = await res.text();
      if (!res.ok) {
        throw errorFromHttpStatus(res.status, text, id);
      }

      let data: {
        choices?: { message?: { content?: string } }[];
        usage?: { prompt_tokens?: number; completion_tokens?: number };
      };
      try {
        data = JSON.parse(text);
      } catch {
        throw new AIError(`[${id}] réponse JSON invalide`, 'server', {
          providerId: id,
        });
      }

      const content = data.choices?.[0]?.message?.content?.trim() ?? '';
      if (!content) {
        throw new AIError(`[${id}] réponse vide`, 'unavailable', {
          providerId: id,
        });
      }

      return {
        content,
        usage: {
          promptTokens: data.usage?.prompt_tokens,
          completionTokens: data.usage?.completion_tokens,
        },
      };
    },
  };
}

export { DEFAULT_MODEL as GROQ_DEFAULT_MODEL };
