import { AIError } from './errors.ts';
import type { AIErrorKind } from './types.ts';

/**
 * Map HTTP status (+ optional body text) to AIError for all providers.
 * Shared so Gemini / Groq / Mistral / Cerebras behave identically.
 */
export function errorFromHttpStatus(
  status: number,
  bodyText: string,
  providerId: string
): AIError {
  const snippet = bodyText.slice(0, 200).toLowerCase();

  if (status === 400) {
    // User / request validation — do NOT trigger fallback
    return new AIError(
      `Requête invalide (${providerId})`,
      'invalid_request',
      { retryable: false, providerId }
    );
  }
  if (status === 401 || status === 403) {
    return new AIError(`Authentification (${providerId})`, 'invalid_key', {
      providerId,
    });
  }
  if (status === 408) {
    return new AIError(`Timeout HTTP (${providerId})`, 'timeout', { providerId });
  }
  if (status === 429) {
    return new AIError(`Quota / rate limit (${providerId})`, 'quota', {
      providerId,
    });
  }
  if (status === 502 || status === 503 || status === 504) {
    return new AIError(`Indisponible (${providerId})`, 'unavailable', {
      providerId,
    });
  }
  if (status >= 500) {
    return new AIError(`Erreur serveur (${providerId})`, 'server', {
      providerId,
    });
  }

  // Heuristics on body when status is ambiguous
  if (snippet.includes('resource_exhausted') || snippet.includes('rate limit')) {
    return new AIError(`Quota (${providerId})`, 'quota', { providerId });
  }
  if (snippet.includes('api key') || snippet.includes('unauthorized')) {
    return new AIError(`Clé invalide (${providerId})`, 'invalid_key', {
      providerId,
    });
  }

  return new AIError(`HTTP ${status} (${providerId})`, 'unknown', {
    providerId,
    retryable: true,
  });
}

export function networkError(providerId: string, cause: unknown): AIError {
  const msg = cause instanceof Error ? cause.message : String(cause);
  return new AIError(`Réseau (${providerId}): ${msg}`, 'network', {
    providerId,
    cause,
  });
}

export type { AIErrorKind };
