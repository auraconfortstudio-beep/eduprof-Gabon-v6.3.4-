import type { AIErrorKind } from './types.ts';

export class AIError extends Error {
  readonly kind: AIErrorKind;
  readonly retryable: boolean;
  readonly providerId?: string;

  constructor(
    message: string,
    kind: AIErrorKind,
    opts?: { retryable?: boolean; providerId?: string; cause?: unknown }
  ) {
    super(message);
    this.name = 'AIError';
    this.kind = kind;
    this.retryable =
      opts?.retryable ??
      (kind === 'timeout' ||
        kind === 'network' ||
        kind === 'quota' ||
        kind === 'unavailable' ||
        kind === 'server' ||
        kind === 'invalid_key');
    this.providerId = opts?.providerId;
    if (opts?.cause !== undefined) {
      (this as Error & { cause?: unknown }).cause = opts.cause;
    }
  }
}

export class AllProvidersFailedError extends Error {
  readonly attempts: { providerId: string; errorKind?: AIErrorKind; message?: string }[];

  constructor(
    attempts: { providerId: string; errorKind?: AIErrorKind; message?: string }[]
  ) {
    super(
      attempts.length === 0
        ? 'Aucun fournisseur IA configuré'
        : 'Tous les fournisseurs IA sont indisponibles'
    );
    this.name = 'AllProvidersFailedError';
    this.attempts = attempts;
  }
}

/** Errors that must NOT trigger fallback to the next provider */
export function isNonRetryableKind(kind: AIErrorKind): boolean {
  return kind === 'invalid_request';
}

/**
 * Map unknown thrown values to AIError.
 * Providers should throw AIError when possible.
 */
export function classifyThrown(err: unknown, providerId?: string): AIError {
  if (err instanceof AIError) {
    return err;
  }

  const msg =
    err instanceof Error ? err.message : typeof err === 'string' ? err : 'Erreur inconnue';
  const lower = msg.toLowerCase();

  if (lower.includes('timeout') || lower.includes('timed out') || lower.includes('aborted') ||
    lower.includes('408')) {
    return new AIError(msg, 'timeout', { providerId });
  }
  if (
    lower.includes('quota') ||
    lower.includes('rate limit') ||
    lower.includes('429') ||
    lower.includes('resource_exhausted')
  ) {
    return new AIError(msg, 'quota', { providerId });
  }
  if (
    lower.includes('unauthorized') ||
    lower.includes('invalid api key') ||
    lower.includes('401') ||
    lower.includes('403')
  ) {
    return new AIError(msg, 'invalid_key', { providerId });
  }
  if (
    lower.includes('network') ||
    lower.includes('fetch failed') ||
    lower.includes('econnrefused') ||
    lower.includes('enotfound')
  ) {
    return new AIError(msg, 'network', { providerId });
  }
  if (
    lower.includes('unavailable') ||
    lower.includes('503') ||
    lower.includes('502') ||
    lower.includes('overloaded')
  ) {
    return new AIError(msg, 'unavailable', { providerId });
  }
  if (lower.includes('500') || lower.includes('server')) {
    return new AIError(msg, 'server', { providerId });
  }

  return new AIError(msg, 'unknown', { providerId, retryable: true });
}
