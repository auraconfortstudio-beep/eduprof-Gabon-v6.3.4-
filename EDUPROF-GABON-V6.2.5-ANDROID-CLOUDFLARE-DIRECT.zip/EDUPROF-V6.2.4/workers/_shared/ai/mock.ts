import type { AIGenerateRequest, AIGenerateResponse, AIProvider } from './types.ts';
import { AIError } from './errors.ts';

export type MockBehavior =
  | 'success'
  | 'timeout'
  | 'network'
  | 'quota'
  | 'unavailable'
  | 'invalid_key'
  | 'server'
  | 'invalid_request';

export interface MockProviderOptions {
  id: string;
  behavior?: MockBehavior;
  /** Delay before resolving/rejecting (ms) */
  delayMs?: number;
  /** Custom success content */
  content?: string;
  /** After N successful calls, switch behavior (optional) */
  failAfterSuccesses?: number;
  /** Mutable behavior for tests that flip availability mid-flight */
  getBehavior?: () => MockBehavior;
}

/**
 * Simulated provider for tests and offline development.
 * Never calls a real network API.
 */
export function createMockProvider(opts: MockProviderOptions): AIProvider {
  let successCount = 0;

  return {
    id: opts.id,
    async generate(request: AIGenerateRequest): Promise<AIGenerateResponse> {
      const delay = opts.delayMs ?? 0;
      if (delay > 0) {
        await new Promise(r => setTimeout(r, delay));
      }

      const behavior =
        opts.getBehavior?.() ??
        (opts.failAfterSuccesses !== undefined && successCount >= opts.failAfterSuccesses
          ? 'unavailable'
          : opts.behavior ?? 'success');

      switch (behavior) {
        case 'success': {
          successCount += 1;
          const lastUser = [...request.messages].reverse().find(m => m.role === 'user');
          return {
            content:
              opts.content ??
              `[${opts.id}] Réponse pédagogique simulée pour: "${(lastUser?.content ?? '').slice(0, 120)}"`,
          };
        }
        case 'timeout':
          throw new AIError(`[${opts.id}] timeout simulé`, 'timeout', { providerId: opts.id });
        case 'network':
          throw new AIError(`[${opts.id}] network simulé`, 'network', { providerId: opts.id });
        case 'quota':
          throw new AIError(`[${opts.id}] quota simulé`, 'quota', { providerId: opts.id });
        case 'unavailable':
          throw new AIError(`[${opts.id}] unavailable simulé`, 'unavailable', {
            providerId: opts.id,
          });
        case 'invalid_key':
          throw new AIError(`[${opts.id}] invalid_key simulé`, 'invalid_key', {
            providerId: opts.id,
          });
        case 'server':
          throw new AIError(`[${opts.id}] server simulé`, 'server', { providerId: opts.id });
        case 'invalid_request':
          throw new AIError(`[${opts.id}] invalid_request simulé`, 'invalid_request', {
            providerId: opts.id,
            retryable: false,
          });
        default:
          throw new AIError(`[${opts.id}] comportement inconnu`, 'unknown', {
            providerId: opts.id,
          });
      }
    },
  };
}
