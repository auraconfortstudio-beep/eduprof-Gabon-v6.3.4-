/** Rôles actifs : OWNER | ADMIN | USER. Les autres sont réservés (blocs futurs). */
export type Role = 'OWNER' | 'ADMIN' | 'USER' | 'ESTABLISHMENT_ADMIN' | 'TEACHER' | 'STUDENT';
export type ActiveRole = 'OWNER' | 'ADMIN' | 'USER' | 'ESTABLISHMENT_ADMIN' | 'TEACHER' | 'STUDENT';

export interface UserRecord {
  id: string;
  email: string;
  passwordHash: string;
  displayName: string;
  educationLevel: string;
  educationSeries: string | null;
  educationFiliere: string | null;
  role: Role;
  isPremium: boolean;
  premiumUntil: string | null;
  xp: number;
  streak: number;
  lastActivityDate: string | null;
  createdAt: string;
  updatedAt: string;
  /** Compte de démo éphémère créé via /auth/demo — jamais ADMIN, jamais Premium. */
  isDemo?: boolean;
  /** Établissement rattaché (null = global / OWNER) */
  establishmentId?: string | null;
  /** Cycle de vie d'accès institutionnel */
  accessStatus?: AccessStatus;
  accessExpiresAt?: string | null;
  accessActivatedAt?: string | null;
}

export type AccessStatus = 'pending' | 'active' | 'expired' | 'suspended' | 'revoked';

export type EstablishmentStatus = 'active' | 'inactive' | 'suspended';

export interface Establishment {
  id: string;
  name: string;
  code: string;
  type: string;
  status: EstablishmentStatus;
  createdAt: string;
  updatedAt: string;
}

export interface StudentActivation {
  id: string;
  userId: string;
  establishmentId: string;
  status: AccessStatus;
  activatedAt: string | null;
  expiresAt: string | null;
  activatedBy: string | null;
  createdAt: string;
  updatedAt: string;
}

export type InstitutionalAuditAction =
  | 'ESTABLISHMENT_CREATED'
  | 'ESTABLISHMENT_UPDATED'
  | 'TENANT_CREATED'
  | 'TENANT_UPDATED'
  | 'TENANT_SUSPENDED'
  | 'TENANT_ACTIVATED'
  | 'STUDENT_IMPORTED'
  | 'STUDENT_ACTIVATED'
  | 'STUDENT_DEACTIVATED'
  | 'STUDENT_RENEWED'
  | 'STUDENT_REVOKED'
  | 'ROLE_CHANGED'
  | 'PERMISSION_CHANGED'
  | 'BULK_ACTIVATION'
  | 'MEMBERSHIP_CREATED'
  | 'MEMBERSHIP_REVOKED'
  | 'ACTIVATION_EXPIRED'
  | 'MAINTENANCE_RUN';

export interface InstitutionalAuditLog {
  id: string;
  actorUserId: string;
  actorEmail?: string;
  action: InstitutionalAuditAction | string;
  targetUserId?: string | null;
  targetEstablishmentId?: string | null;
  timestamp: string;
  metadata?: Record<string, string | number | boolean | null>;
}

export interface PublicProfile {
  id: string;
  displayName: string;
  educationLevel: string;
  xp: number;
  isPremium: boolean;
}

export interface LessonProgress {
  lessonId: string;
  completedAt: string;
}

export interface ExerciseProgress {
  exerciseId: string;
  wasCorrect: boolean;
  completedAt: string;
}

export interface QuizResult {
  quizId: string;
  subjectId: string;
  score: number;
  totalQuestions: number;
  completedAt: string;
  xpAwarded: number;
}

export interface XpEvent {
  amount: number;
  reason: string;
  createdAt: string;
}

export interface UserProgress {
  userId: string;
  lessons: LessonProgress[];
  exercises: ExerciseProgress[];
  quizzes: QuizResult[];
  xpHistory: XpEvent[];
}

export interface PremiumRequest {
  id: string;
  userId: string;
  userEmail: string;
  userDisplayName: string;
  plan: 'daily' | 'monthly';
  amount: number;
  proof: string;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
  processedAt: string | null;
  processedBy: string | null;
}

export interface AdminLog {
  id: string;
  actorId: string;
  actorEmail: string;
  action: string;
  targetUserId: string | null;
  details: string;
  createdAt: string;
}

export interface SessionPayload {
  sub: string;
  email: string;
  role: Role;
}

export type AnnaleStatus = 'draft' | 'published';

export interface AnnaleRecord {
  id: string;
  exam: string;
  year: string;
  subject: string;
  level: string;
  series: string | null;
  title: string;
  description: string;
  subjectUrl: string | null;
  correctionUrl: string | null;
  status: AnnaleStatus;
  createdAt: string;
  updatedAt: string;
  createdBy: string;
}


/** Membership utilisateur ↔ établissement (tenant boundary) */
export type MembershipStatus = 'ACTIVE' | 'INACTIVE' | 'REVOKED';

export interface Membership {
  id: string;
  userId: string;
  establishmentId: string;
  role: Role;
  status: MembershipStatus;
  createdAt: string;
  updatedAt: string;
  createdBy?: string;
}

export interface MaintenanceSummary {
  processed: number;
  expired: number;
  expiringSoon: number;
  skipped: number;
  errors: number;
  ranAt: string;
}
