/**
 * Rate limiting — Cloudflare Functions (Blobs / fichier local).
 * Best-effort sur serverless (pas de coordination parfaite entre isolates).
 *
 * Protections spécialisées conservées :
 * - Auth login : lockout progressif (recordFailedLogin / isLoginBlocked)
 * - Auth signup : limite IP dédiée
 * - IA : limites user/min, user/day, IP (env AI_RATE_LIMIT_*)
 *
 * Middleware générique : enforceRateLimit + rateLimitResponse
 * pour homogénéiser les 429 sans dupliquer la logique bucket.
 */
// getStore chargé dynamiquement uniquement en runtime Cloudflare (évite latence locale)

/** True only in Cloudflare Functions runtime (prod / deploy-preview / branch-deploy). */
const isCloudflare = false;
const DATA_DIR = '.data';

type Bucket = { count: number; resetAt: number; blockedUntil?: number };

/** Presets documentés — utilisés explicitement aux points d’appel */
export const RATE_PRESETS = {
  /** Inscription : 10 / heure / IP */
  SIGNUP_IP: { limit: 10, windowMs: 60 * 60 * 1000 },
  /** Écritures API authentifiées (progress, premium request…) : 120 / min / IP */
  API_WRITE_IP: { limit: 120, windowMs: 60 * 1000 },
  /** Lecture API générale : 300 / min / IP */
  API_READ_IP: { limit: 300, windowMs: 60 * 1000 },
  /** Demande Premium : 10 / heure / user */
  PREMIUM_REQUEST_USER: { limit: 10, windowMs: 60 * 60 * 1000 },
  /** Création de compte démo : 5 / heure / IP — évite l'abus du mode démo */
  DEMO_IP: { limit: 5, windowMs: 60 * 60 * 1000 },
  /** Support tickets : 20 / heure / user */
  SUPPORT_USER: { limit: 20, windowMs: 60 * 60 * 1000 },
  /** Upload pièces jointes : 30 / heure / user */
  UPLOAD_USER: { limit: 30, windowMs: 60 * 60 * 1000 },
  /** Login attempts soft (en plus du lockout) : 30 / 15 min / IP */
  LOGIN_IP: { limit: 30, windowMs: 15 * 60 * 1000 },
  /** Admin mutations : 60 / min / user */
  ADMIN_WRITE_USER: { limit: 60, windowMs: 60 * 1000 },
} as const;

const memBuckets = new Map<string, Bucket>();
async function getBucket(key: string): Promise<Bucket | null> { return memBuckets.get(key) || null; }
async function setBucket(key: string, bucket: Bucket): Promise<void> { memBuckets.set(key, bucket); }
export function __resetRateLimitForTests(): void { memBuckets.clear(); }

export function getClientIp(req: Request): string {
  return (
    req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ||
    req.headers.get('x-nf-client-connection-ip') ||
    'unknown'
  );
}

export async function checkRateLimit(
  key: string,
  limit: number,
  windowMs: number
): Promise<{ allowed: boolean; remaining: number; retryAfterSec?: number }> {
  const now = Date.now();
  let bucket = await getBucket(key);
  if (!bucket || bucket.resetAt <= now) {
    bucket = { count: 0, resetAt: now + windowMs };
  }
  if (bucket.blockedUntil && bucket.blockedUntil > now) {
    return {
      allowed: false,
      remaining: 0,
      retryAfterSec: Math.ceil((bucket.blockedUntil - now) / 1000),
    };
  }
  if (bucket.count >= limit) {
    return {
      allowed: false,
      remaining: 0,
      retryAfterSec: Math.ceil((bucket.resetAt - now) / 1000),
    };
  }
  bucket.count += 1;
  await setBucket(key, bucket);
  return { allowed: true, remaining: Math.max(0, limit - bucket.count) };
}

/**
 * Réponse 429 homogène (JSON + Retry-After + CORS basique).
 * N’impose pas de framework middleware Cloudflare Edge.
 */
export function rateLimitResponse(
  message: string,
  retryAfterSec?: number
): Response {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  };
  if (retryAfterSec != null && retryAfterSec > 0) {
    headers['Retry-After'] = String(retryAfterSec);
  }
  return new Response(
    JSON.stringify({
      error: message,
      retryAfterSec: retryAfterSec ?? null,
    }),
    { status: 429, headers }
  );
}

/**
 * Applique une limite et retourne une Response 429 si dépassée, sinon null.
 * À utiliser aux points d’entrée sans remplacer les règles métier existantes.
 */
export async function enforceRateLimit(
  key: string,
  limit: number,
  windowMs: number,
  message = 'Trop de requêtes. Réessayez plus tard.'
): Promise<Response | null> {
  const rl = await checkRateLimit(key, limit, windowMs);
  if (rl.allowed) return null;
  return rateLimitResponse(message, rl.retryAfterSec);
}

/** Progressive lockout after failed logins — inchangé fonctionnellement */
export async function recordFailedLogin(
  emailOrIp: string
): Promise<{ blocked: boolean; retryAfterSec?: number }> {
  const key = `loginfail:${emailOrIp}`;
  const now = Date.now();
  let bucket = await getBucket(key);
  if (!bucket || bucket.resetAt <= now) {
    bucket = { count: 0, resetAt: now + 15 * 60 * 1000 };
  }
  bucket.count += 1;
  // After 5 fails: 1 min, 8 fails: 5 min, 12+: 15 min
  if (bucket.count >= 12) {
    bucket.blockedUntil = now + 15 * 60 * 1000;
  } else if (bucket.count >= 8) {
    bucket.blockedUntil = now + 5 * 60 * 1000;
  } else if (bucket.count >= 5) {
    bucket.blockedUntil = now + 60 * 1000;
  }
  await setBucket(key, bucket);
  if (bucket.blockedUntil && bucket.blockedUntil > now) {
    return {
      blocked: true,
      retryAfterSec: Math.ceil((bucket.blockedUntil - now) / 1000),
    };
  }
  return { blocked: false };
}

export async function clearFailedLogin(emailOrIp: string): Promise<void> {
  await setBucket(`loginfail:${emailOrIp}`, { count: 0, resetAt: Date.now() });
}

export async function isLoginBlocked(
  emailOrIp: string
): Promise<{ blocked: boolean; retryAfterSec?: number }> {
  const bucket = await getBucket(`loginfail:${emailOrIp}`);
  const now = Date.now();
  if (bucket?.blockedUntil && bucket.blockedUntil > now) {
    return {
      blocked: true,
      retryAfterSec: Math.ceil((bucket.blockedUntil - now) / 1000),
    };
  }
  return { blocked: false };
}
