/**
 * Security headers — OWASP ASVS / Cheat Sheet inspiration.
 * Compatible PWA (pas de CSP ultra-stricte qui casse le SW).
 */
export function securityHeaders(): Record<string, string> {
  return {
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'strict-origin-when-cross-origin',
    'X-Frame-Options': 'DENY',
    'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
    // CSP permissive pour Vite assets + self — pas de third-party scripts inline dangereux
    'Content-Security-Policy':
      "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self'; worker-src 'self'; manifest-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'",
  };
}

/** Sanitize error message for public API — jamais de stack/path/secret */
export function publicErrorMessage(err: unknown, fallback = 'Erreur serveur'): string {
  if (!(err instanceof Error)) return fallback;
  const msg = err.message || fallback;
  if (/secret|token|jwt|password|api[_-]?key|stack|\/home\/|\/tmp\/|node_modules/i.test(msg)) {
    return fallback;
  }
  // Truncate long internal messages
  return msg.slice(0, 200) || fallback;
}
