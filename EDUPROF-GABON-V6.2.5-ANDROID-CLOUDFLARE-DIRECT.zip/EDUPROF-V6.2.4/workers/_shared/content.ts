/**
 * Server-side content catalog — source of truth for XP validation.
 * Client claims are never trusted. Compatible Cloudflare Workers (JSON import).
 */
import contentIndex from './content-index.json';

export const XP_LESSON = 10;
export const XP_EXERCISE = 15;
export const XP_QUIZ_MAX = 50;

type LessonMeta = { levelId: string; subjectId: string };
type QuizQ = { id: string; correctAnswer: number };

function loadIndex(): {
  lessons: Record<string, LessonMeta>;
  exercises: Record<string, number>;
  quizzes: Record<string, QuizQ[]>;
  quizQuestions: Record<string, number>;
} {
  const data = contentIndex as {
    lessons?: Record<string, LessonMeta>;
    exercises?: Record<string, number>;
    quizzes?: Record<string, QuizQ[]>;
    quizQuestions?: Record<string, number>;
  };
  return {
    lessons: data.lessons || {},
    exercises: data.exercises || {},
    quizzes: data.quizzes || {},
    quizQuestions: data.quizQuestions || {},
  };
}

const index = loadIndex();
const lessons = index.lessons || {};
const exercises = index.exercises || {};
const quizzes = index.quizzes || {};
const quizQuestions = index.quizQuestions || {};

export function getLesson(lessonId: string): LessonMeta | null {
  if (!lessonId || typeof lessonId !== 'string') return null;
  return lessons[lessonId] || null;
}

export function getExerciseCorrectAnswer(exerciseId: string): number | null {
  if (!exerciseId || typeof exerciseId !== 'string') return null;
  if (exerciseId in exercises) return exercises[exerciseId];
  // Tolérance : même suffixe -exN après fusion de packs (IDs renumérotés)
  const m = exerciseId.match(/-c\d+-(.+)$/);
  if (m) {
    const suffix = m[1];
    for (const [id, ans] of Object.entries(exercises)) {
      if (id.endsWith(suffix) || id.includes(suffix)) return ans as number;
    }
  }
  return null;
}

export function getQuizQuestions(quizId: string): QuizQ[] | null {
  if (!quizId || typeof quizId !== 'string') return null;
  if (quizzes[quizId] && quizzes[quizId].length > 0) return quizzes[quizId];
  if (quizId.endsWith('-quiz')) {
    const alt = quizId.replace(/-quiz$/, '-lecon1');
    if (quizzes[alt]?.length) return quizzes[alt];
  }
  return null;
}

export function getQuizQuestionAnswer(questionId: string): number | null {
  if (!questionId || typeof questionId !== 'string') return null;
  if (!(questionId in quizQuestions)) return null;
  return quizQuestions[questionId];
}

export function listLessonIds(): string[] {
  return Object.keys(lessons);
}
