/**
 * EduProf — système de pièces jointes (métadonnées + stockage isolé par userId).
 * Stockage : R2 Cloudflare (prod) / mémoire locale (dev).
 * Ne jamais exposer d'URL publique permanente.
 */
import { randomUUID } from 'crypto';

export const ATTACHMENT_MAX_SIZE_BYTES = 4 * 1024 * 1024; // 4 Mo
export const ATTACHMENT_MAX_PER_MESSAGE = 3;

export const ALLOWED_MIME_TYPES = [
  'image/jpeg',
  'image/jpg',
  'image/png',
  'image/webp',
  'application/pdf',
] as const;

export type AllowedMime = (typeof ALLOWED_MIME_TYPES)[number];

export interface AttachmentMeta {
  id: string;
  userId: string;
  conversationId?: string | null;
  messageId?: string | null;
  lessonId?: string | null;
  fileName: string;
  mimeType: AllowedMime;
  size: number;
  storageKey: string;
  createdAt: string;
  /** true si le contenu binaire est encore disponible en store */
  hasBinary?: boolean;
}

/** Métadonnées légères embarquées dans un message de conversation */
export interface MessageAttachmentRef {
  id: string;
  fileName: string;
  mimeType: string;
  size: number;
  /** data URL ou base64 court pour aperçu client (optionnel, non persisté côté serveur long terme) */
  previewDataUrl?: string | null;
}

/** Sanitisation noms de fichiers */
export function sanitizeFileName(name: string): string {
  // Nom de base uniquement (pas de chemin), aucune séquence ".."
  const baseName = name.split(/[/\\]/).pop() || name;
  const withoutDots = baseName.replace(/\.\./g, '_');
  const base = withoutDots.replace(/[?%*:|"<>]/g, '_').replace(/\s+/g, '_').slice(0, 120);
  return base || 'fichier';
}

function normalizeMime(mime: string): string {
  const m = (mime || '').toLowerCase().trim();
  if (m === 'image/jpg') return 'image/jpeg';
  return m;
}

export function isAllowedMime(mime: string): mime is AllowedMime {
  const m = normalizeMime(mime);
  return (ALLOWED_MIME_TYPES as readonly string[]).includes(m);
}


const EXT_MIME: Record<string, AllowedMime[]> = {
  '.jpg': ['image/jpeg'],
  '.jpeg': ['image/jpeg'],
  '.png': ['image/png'],
  '.webp': ['image/webp'],
  '.pdf': ['application/pdf'],
};

export function extensionMatchesMime(fileName: string, mime: string): boolean {
  const lower = fileName.toLowerCase();
  const dot = lower.lastIndexOf('.');
  if (dot < 0) return false;
  const ext = lower.slice(dot);
  const allowed = EXT_MIME[ext];
  if (!allowed) return false;
  const m = mime === 'image/jpg' ? 'image/jpeg' : mime;
  return (allowed as string[]).includes(m);
}

export function isDangerousExtension(fileName: string): boolean {
  const lower = fileName.toLowerCase();
  return /\.(exe|bat|cmd|sh|js|mjs|cjs|php|asp|aspx|html|htm|svg|dll|so|apk|msi|ps1|vbs)$/i.test(lower);
}

/** Ex. photo.jpg.php, doc.pdf.exe */
export function hasDoubleDangerousExtension(fileName: string): boolean {
  const lower = (fileName || '').toLowerCase();
  return /\.(jpe?g|png|webp|pdf|txt)\.(exe|php|js|sh|asp|aspx|html|htm|svg)$/i.test(lower);
}

export function validateAttachmentInput(opts: {
  fileName: string;
  mimeType: string;
  size: number;
  base64Data?: string;
}): { ok: true; mime: AllowedMime; fileName: string } | { ok: false; error: string } {
  const fileName = sanitizeFileName(opts.fileName || 'fichier');
  if (isDangerousExtension(opts.fileName || fileName) || hasDoubleDangerousExtension(opts.fileName || fileName)) {
    return { ok: false, error: 'Type de fichier dangereux refusé' };
  }
  const mime = normalizeMime(opts.mimeType) as AllowedMime;
  if (!isAllowedMime(mime)) {
    return { ok: false, error: 'Type de fichier non autorisé. Formats acceptés : JPG, PNG, WEBP, PDF.' };
  }
  if (!extensionMatchesMime(fileName, mime)) {
    return { ok: false, error: 'Extension incompatible avec le type MIME' };
  }
  if (!opts.size || opts.size <= 0) {
    return { ok: false, error: 'Fichier invalide (taille nulle).' };
  }
  if (opts.size > ATTACHMENT_MAX_SIZE_BYTES) {
    return {
      ok: false,
      error: `Fichier trop volumineux (max ${Math.round(ATTACHMENT_MAX_SIZE_BYTES / 1024 / 1024)} Mo).`,
    };
  }
  if (opts.base64Data) {
    // Estimation rough : base64 ~ 4/3 de la taille
    const approx = Math.ceil((opts.base64Data.length * 3) / 4);
    if (approx > ATTACHMENT_MAX_SIZE_BYTES * 1.15) {
      return {
        ok: false,
        error: `Fichier trop volumineux (max ${Math.round(ATTACHMENT_MAX_SIZE_BYTES / 1024 / 1024)} Mo).`,
      };
    }
  }
  return { ok: true, mime, fileName };
}

import { r2Put, r2Get, r2Delete, metaPut, metaGet, metaDelete } from '../platform/r2Attachments.ts';
import { getDb } from '../platform/db.ts';

export async function saveAttachment(opts: {
  userId: string; fileName: string; mimeType: string; base64Data: string; size?: number;
  establishmentId?: string | null; conversationId?: string | null; messageId?: string | null; lessonId?: string | null;
}): Promise<{ ok: true; id: string; meta: Record<string, unknown> } | { ok: false; error: string }> {
  if (!opts.userId || !opts.userId.trim()) return { ok: false, error: 'Utilisateur non authentifié' };
  const sizeBytes = opts.size ?? Math.floor((opts.base64Data.length * 3) / 4);
  const v = validateAttachmentInput({ fileName: opts.fileName, mimeType: opts.mimeType, size: sizeBytes });
  if (!v.ok) return v as { ok: false; error: string };
  const id = randomUUID();
  const key = `${opts.userId}/${id}`;
  const bin = Uint8Array.from(atob(opts.base64Data), (c) => c.charCodeAt(0));
  await r2Put(key, bin, opts.mimeType);
  const meta = {
    id, userId: opts.userId, fileName: sanitizeFileName(opts.fileName), mimeType: opts.mimeType,
    size: bin.byteLength, establishmentId: opts.establishmentId || null,
    conversationId: opts.conversationId || null, messageId: opts.messageId || null, lessonId: opts.lessonId || null,
    createdAt: new Date().toISOString(), r2Key: key, storageKey: key,
  };
  await metaPut(key, JSON.stringify(meta));
  const db = getDb();
  if (db) {
    await db.prepare(
      `INSERT INTO attachment_meta (id, user_id, establishment_id, filename, mime, size, r2_key, conversation_id, message_id, lesson_id, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
       ON CONFLICT(id) DO UPDATE SET filename=excluded.filename, mime=excluded.mime, size=excluded.size, r2_key=excluded.r2_key`
    ).bind(
      id, opts.userId, opts.establishmentId || null, meta.fileName, opts.mimeType, meta.size, key,
      opts.conversationId || null, opts.messageId || null, opts.lessonId || null, meta.createdAt
    ).run();
  }
  return { ok: true, id, meta };
}

export async function getAttachmentMeta(userId: string, attachmentId: string) {
  if (!userId || !attachmentId) return null;
  const raw = await metaGet(`${userId}/${attachmentId}`);
  if (!raw) return null;
  try { const meta = JSON.parse(raw); return meta.userId === userId ? meta : null; } catch { return null; }
}

export async function getAttachmentBinary(userId: string, attachmentId: string) {
  const meta = await getAttachmentMeta(userId, attachmentId);
  if (!meta) return null;
  const key = meta.r2Key || meta.storageKey || `${userId}/${attachmentId}`;
  const buf = await r2Get(key);
  if (!buf) return null;
  const bytes = new Uint8Array(buf);
  let binary = '';
  for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
  return { meta, base64: btoa(binary) };
}

export async function deleteAttachment(userId: string, attachmentId: string): Promise<boolean> {
  const meta = await getAttachmentMeta(userId, attachmentId);
  if (!meta) return false;
  const key = meta.r2Key || meta.storageKey || `${userId}/${attachmentId}`;
  await r2Delete(key); await metaDelete(key); return true;
}

export function toDataUrl(mimeType: string, base64: string): string { return `data:${mimeType};base64,${base64}`; }
export function isImageMime(mime: string): boolean { return (mime || '').startsWith('image/'); }
export function isPdfMime(mime: string): boolean { return (mime || '') === 'application/pdf'; }
