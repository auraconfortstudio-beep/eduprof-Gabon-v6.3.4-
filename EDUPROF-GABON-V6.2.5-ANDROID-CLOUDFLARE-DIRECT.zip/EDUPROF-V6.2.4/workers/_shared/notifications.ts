/**
 * Notifications internes EduProf — in-app, tenant-aware.
 * Push Web : abstraction préparée, désactivée par défaut (pas de VAPID).
 */
import { randomUUID } from 'crypto';

export type NotificationType =
  | 'SYSTEM'
  | 'COURSE'
  | 'QUIZ'
  | 'PROGRESSION'
  | 'ACTIVATION'
  | 'EXPIRATION'
  | 'ADMIN'
  | 'SUPPORT'
  | 'DOCUMENT'
  | 'SECURITY';

export interface AppNotification {
  id: string;
  userId: string;
  establishmentId?: string | null;
  type: NotificationType;
  title: string;
  message: string;
  createdAt: string;
  readAt?: string | null;
  priority?: 'low' | 'normal' | 'high';
  metadata?: Record<string, string | number | boolean | null>;
}

const byUser = new Map<string, AppNotification[]>();

export function resetNotifications(): void {
  byUser.clear();
}

export function createNotification(input: {
  userId: string;
  establishmentId?: string | null;
  type: NotificationType;
  title: string;
  message: string;
  priority?: 'low' | 'normal' | 'high';
  metadata?: Record<string, string | number | boolean | null>;
}): AppNotification {
  // Strip secrets from metadata
  const meta: Record<string, string | number | boolean | null> = {};
  if (input.metadata) {
    for (const [k, v] of Object.entries(input.metadata)) {
      if (/password|token|jwt|secret|api[_-]?key/i.test(k)) continue;
      meta[k] = v;
    }
  }
  const n: AppNotification = {
    id: randomUUID(),
    userId: input.userId,
    establishmentId: input.establishmentId ?? null,
    type: input.type,
    title: input.title.slice(0, 120),
    message: input.message.slice(0, 500),
    createdAt: new Date().toISOString(),
    readAt: null,
    priority: input.priority || 'normal',
    metadata: Object.keys(meta).length ? meta : undefined,
  };
  const list = byUser.get(input.userId) || [];
  list.unshift(n);
  if (list.length > 200) list.length = 200;
  byUser.set(input.userId, list);
  return n;
}

export function listNotifications(
  userId: string,
  opts?: { unreadOnly?: boolean; page?: number; pageSize?: number; establishmentId?: string }
): { items: AppNotification[]; total: number; unread: number; page: number; pageSize: number } {
  let all = byUser.get(userId) || [];
  if (opts?.establishmentId) {
    all = all.filter((n) => !n.establishmentId || n.establishmentId === opts.establishmentId);
  }
  const unread = all.filter((n) => !n.readAt).length;
  if (opts?.unreadOnly) all = all.filter((n) => !n.readAt);
  const page = Math.max(1, opts?.page || 1);
  const pageSize = Math.min(50, Math.max(1, opts?.pageSize || 20));
  const start = (page - 1) * pageSize;
  return {
    items: all.slice(start, start + pageSize),
    total: all.length,
    unread,
    page,
    pageSize,
  };
}

export function markNotificationRead(userId: string, id: string): boolean {
  const list = byUser.get(userId) || [];
  const n = list.find((x) => x.id === id);
  if (!n) return false;
  if (!n.readAt) n.readAt = new Date().toISOString();
  return true;
}

export function markAllNotificationsRead(userId: string): number {
  const list = byUser.get(userId) || [];
  let c = 0;
  const now = new Date().toISOString();
  for (const n of list) {
    if (!n.readAt) {
      n.readAt = now;
      c++;
    }
  }
  return c;
}

export function deleteNotification(userId: string, id: string): boolean {
  const list = byUser.get(userId) || [];
  const i = list.findIndex((x) => x.id === id);
  if (i < 0) return false;
  list.splice(i, 1);
  byUser.set(userId, list);
  return true;
}

/** Push provider stub — disabled without VAPID */
export const PushNotificationProvider = {
  enabled: false as const,
  reason: 'VAPID / push server non configurés — in-app uniquement',
};
