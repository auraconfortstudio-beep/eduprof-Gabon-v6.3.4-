/**
 * XP centralisé — constantes EduProf inchangées.
 * Idempotence : même eventKey ne peut être crédité deux fois dans un historique.
 */
import { XP_LESSON, XP_EXERCISE, XP_QUIZ_MAX } from '../content.ts';
import type { UserProgress, XpEvent } from '../types.ts';

export { XP_LESSON, XP_EXERCISE, XP_QUIZ_MAX };

export function makeEventKey(reason: string, refId: string): string {
  return `${reason}:${refId}`;
}

export function hasXpEvent(progress: UserProgress, eventKey: string): boolean {
  return (progress.xpHistory || []).some((e) => e.reason === eventKey || (e as XpEvent & { eventKey?: string }).eventKey === eventKey);
}

/**
 * Ajoute XP si eventKey absent. Retourne xpGain (0 si déjà crédité).
 */
export function awardXpIdempotent(
  progress: UserProgress,
  amount: number,
  eventKey: string
): { progress: UserProgress; xpGain: number; alreadyAwarded: boolean } {
  if (hasXpEvent(progress, eventKey)) {
    return { progress, xpGain: 0, alreadyAwarded: true };
  }
  const gain = Math.max(0, Math.floor(amount));
  const ev: XpEvent & { eventKey?: string } = {
    amount: gain,
    reason: eventKey,
    createdAt: new Date().toISOString(),
  };
  const xpHistory = [...(progress.xpHistory || []), ev];
  return {
    progress: { ...progress, xpHistory },
    xpGain: gain,
    alreadyAwarded: false,
  };
}

export function sumXpFromHistory(progress: UserProgress): number {
  return (progress.xpHistory || []).reduce((s, e) => s + (e.amount || 0), 0);
}
