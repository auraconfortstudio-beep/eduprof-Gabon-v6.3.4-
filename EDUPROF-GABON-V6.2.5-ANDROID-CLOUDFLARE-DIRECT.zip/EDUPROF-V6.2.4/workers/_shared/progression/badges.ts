/**
 * Badges idempotents — uniquement si données réelles disponibles.
 */
export type BadgeId =
  | 'FIRST_LESSON'
  | 'FIRST_EXERCISE'
  | 'FIRST_QUIZ'
  | 'QUIZ_MASTER'
  | 'STREAK_7'
  | 'STREAK_30'
  | 'XP_100'
  | 'XP_500'
  | 'XP_1000'
  | 'SUBJECT_MASTER';

export interface BadgeDef {
  id: BadgeId;
  name: string;
  description: string;
}

export const BADGE_DEFS: BadgeDef[] = [
  { id: 'FIRST_LESSON', name: 'Première leçon', description: 'A terminé une leçon' },
  { id: 'FIRST_EXERCISE', name: 'Premier exercice', description: 'A réussi un exercice' },
  { id: 'FIRST_QUIZ', name: 'Premier quiz', description: 'A passé un quiz' },
  { id: 'QUIZ_MASTER', name: 'Maître du quiz', description: 'Score parfait à un quiz' },
  { id: 'STREAK_7', name: 'Série 7 jours', description: '7 jours d’activité consécutifs' },
  { id: 'STREAK_30', name: 'Série 30 jours', description: '30 jours d’activité consécutifs' },
  { id: 'XP_100', name: '100 XP', description: 'Atteint 100 XP' },
  { id: 'XP_500', name: '500 XP', description: 'Atteint 500 XP' },
  { id: 'XP_1000', name: '1000 XP', description: 'Atteint 1000 XP' },
  { id: 'SUBJECT_MASTER', name: 'Maîtrise matière', description: 'Au moins 3 notions maîtrisées' },
];

export interface ProgressSnapshot {
  xp: number;
  streak: number;
  lessonsCompleted: number;
  exercisesCorrect: number;
  quizzesTaken: number;
  perfectQuiz: boolean;
  masteredConcepts: number;
}

/** Retourne les badges mérités (idempotent : ensemble, pas de doublon) */
export function evaluateBadges(s: ProgressSnapshot): BadgeId[] {
  const earned = new Set<BadgeId>();
  if (s.lessonsCompleted >= 1) earned.add('FIRST_LESSON');
  if (s.exercisesCorrect >= 1) earned.add('FIRST_EXERCISE');
  if (s.quizzesTaken >= 1) earned.add('FIRST_QUIZ');
  if (s.perfectQuiz) earned.add('QUIZ_MASTER');
  if (s.streak >= 7) earned.add('STREAK_7');
  if (s.streak >= 30) earned.add('STREAK_30');
  if (s.xp >= 100) earned.add('XP_100');
  if (s.xp >= 500) earned.add('XP_500');
  if (s.xp >= 1000) earned.add('XP_1000');
  if (s.masteredConcepts >= 3) earned.add('SUBJECT_MASTER');
  return [...earned];
}
