import type { UserRecord, UserProgress } from '../types.ts';
import { getLevelFromXp, getXpToNextLevel } from './levels.ts';
import { evaluateBadges, type ProgressSnapshot } from './badges.ts';
import { listUserMastery } from '../pedagogy/engine/masteryStore.ts';
import { masteryLabelFromProb } from '../pedagogy/engine/bkt.ts';
import { detectGaps, getNextLearningRecommendation } from '../pedagogy/engine/recommendations.ts';
import { ensureGraphSeeded } from '../pedagogy/engine/knowledgeGraph.ts';

export function buildStudentProgressSummary(user: UserRecord, progress: UserProgress) {
  ensureGraphSeeded();
  const lessonsCompleted = progress.lessons?.length || 0;
  const exercisesCorrect = (progress.exercises || []).filter((e) => e.wasCorrect).length;
  const quizzesTaken = progress.quizzes?.length || 0;
  const perfectQuiz = (progress.quizzes || []).some((q) => q.totalQuestions > 0 && q.score === q.totalQuestions);
  const masteryList = listUserMastery(user.id);
  const masteredConcepts = masteryList.filter((m) => masteryLabelFromProb(m.bkt.probMastery) === 'mastered').length;
  const snap: ProgressSnapshot = {
    xp: user.xp || 0,
    streak: user.streak || 0,
    lessonsCompleted,
    exercisesCorrect,
    quizzesTaken,
    perfectQuiz,
    masteredConcepts,
  };
  const badges = evaluateBadges(snap);
  const levelInfo = getXpToNextLevel(user.xp || 0);
  const gaps = detectGaps(user.id);
  const recommendation = getNextLearningRecommendation(user.id, {
    levelId: user.educationLevel || undefined,
  });
  const byLabel = { mastered: 0, learning: 0, fragile: 0, unknown: 0 };
  for (const m of masteryList) {
    byLabel[masteryLabelFromProb(m.bkt.probMastery)]++;
  }
  return {
    userId: user.id,
    xp: user.xp || 0,
    level: getLevelFromXp(user.xp || 0),
    levelInfo,
    streak: user.streak || 0,
    lastActivityDate: user.lastActivityDate,
    lessonsCompleted,
    exercisesCorrect,
    quizzesTaken,
    successRate:
      (progress.exercises?.length || 0) > 0
        ? exercisesCorrect / progress.exercises.length
        : null,
    badges,
    masteryCounts: byLabel,
    gaps: gaps.slice(0, 5),
    recommendation,
  };
}
