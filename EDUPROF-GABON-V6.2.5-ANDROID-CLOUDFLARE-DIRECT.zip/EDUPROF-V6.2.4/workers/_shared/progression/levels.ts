/**
 * Niveaux XP — formule déterministe documentée.
 * niveau n commence à XP = 50 * n * (n - 1)  (somme 50+100+...+(n-1)*50)
 * n=1 → 0 XP, n=2 → 50, n=3 → 150, n=4 → 300, ...
 */
export function getLevelFromXp(xp: number): number {
  const x = Math.max(0, Math.floor(xp || 0));
  let level = 1;
  let need = 0;
  while (true) {
    const nextNeed = need + 50 * level;
    if (x < nextNeed) return level;
    need = nextNeed;
    level += 1;
    if (level > 1000) return level;
  }
}

export function getXpFloorForLevel(level: number): number {
  const L = Math.max(1, Math.floor(level));
  // sum_{i=1}^{L-1} 50*i = 50 * (L-1)*L/2
  return (50 * (L - 1) * L) / 2;
}

export function getXpToNextLevel(xp: number): { level: number; current: number; nextLevelAt: number; remaining: number; progress01: number } {
  const level = getLevelFromXp(xp);
  const floor = getXpFloorForLevel(level);
  const nextLevelAt = getXpFloorForLevel(level + 1);
  const span = Math.max(1, nextLevelAt - floor);
  const into = Math.max(0, Math.floor(xp || 0) - floor);
  return {
    level,
    current: Math.floor(xp || 0),
    nextLevelAt,
    remaining: Math.max(0, nextLevelAt - Math.floor(xp || 0)),
    progress01: Math.min(1, into / span),
  };
}
