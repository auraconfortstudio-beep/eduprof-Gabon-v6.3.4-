/**
 * Mémoire pédagogique persistante — isolée par userId.
 *
 * Production Cloudflare : KV (binding KV, préfixe pedmem:).
 * Tests / local sans bindings : Map RAM isolée par userId.
 * Dégradation contrôlée si KV indisponible.
 */
import type { PedagogicalMemory, ActivityEvent, MasteryState } from './types.ts';
import { currentEnv } from '../../platform/env.ts';

const MAX_NOTIONS = 80;
const MAX_ACTIVITY = 30;
const MAX_RECS = 10;
const KV_PREFIX = 'pedmem:';

/**
 * Runtime Worker Cloudflare avec KV disponible.
 * Pas d'héritage Netlify CONTEXT — détection via bindings env.
 */
function hasKvBinding(): boolean {
  const env = currentEnv();
  return typeof env.KV !== 'undefined' && env.KV !== null;
}

/** Mémoire locale de développement / tests — isolée par userId (jamais globale). */
const localDevMemory = new Map<string, PedagogicalMemory>();

function emptyMemory(userId: string): PedagogicalMemory {
  return {
    userId,
    updatedAt: new Date().toISOString(),
    notions: [],
    recentActivity: [],
    recommendations: [],
  };
}

export async function loadPedagogicalMemory(
  userId: string
): Promise<PedagogicalMemory> {
  if (!userId) return emptyMemory('anonymous');

  // Chemin local / Vite : RAM uniquement, zéro attente réseau.
  if (!hasKvBinding()) {
    const existing = localDevMemory.get(userId);
    if (existing && existing.userId === userId) {
      // Clone léger pour éviter mutations partagées accidentelles.
      return JSON.parse(JSON.stringify(existing)) as PedagogicalMemory;
    }
    return emptyMemory(userId);
  }

  try {
    const kv = currentEnv().KV;
    if (!kv) return emptyMemory(userId);
    const raw = await kv.get(`${KV_PREFIX}${userId}`);
    if (!raw) return emptyMemory(userId);
    const parsed = JSON.parse(raw) as PedagogicalMemory;
    if (parsed.userId !== userId) return emptyMemory(userId);
    return parsed;
  } catch {
    return emptyMemory(userId);
  }
}

export async function savePedagogicalMemory(
  mem: Partial<PedagogicalMemory> & { userId: string }
): Promise<void> {
  if (!mem.userId || mem.userId === 'anonymous') return;

  mem.updatedAt = new Date().toISOString();
  mem.notions = (mem.notions || []).slice(0, MAX_NOTIONS);
  mem.recentActivity = (mem.recentActivity || []).slice(0, MAX_ACTIVITY);
  mem.recommendations = (mem.recommendations || []).slice(0, MAX_RECS);

  // Chemin local / Vite : persistance session process (Map isolée).
  if (!hasKvBinding()) {
    localDevMemory.set(mem.userId, {
      userId: mem.userId,
      updatedAt: mem.updatedAt,
      levelId: mem.levelId,
      seriesId: mem.seriesId,
      notions: mem.notions || [],
      recentActivity: mem.recentActivity || [],
      recommendations: mem.recommendations || [],
    });
    return;
  }

  try {
    const kv = currentEnv().KV;
    if (!kv) return;
    await kv.put(`${KV_PREFIX}${mem.userId}`, JSON.stringify(mem));
  } catch {
    // Dégradation contrôlée : pas de crash si KV indisponible.
  }
}

function notionKey(subjectName: string | undefined, notion: string) {
  return `${(subjectName || 'matiere').toLowerCase()}|${notion.toLowerCase().slice(0, 80)}`;
}

export function upsertNotion(
  mem: PedagogicalMemory,
  opts: {
    subjectId?: string;
    subjectName?: string;
    notion: string;
    lessonId?: string;
    seriesId?: string | null;
    error?: boolean;
    success?: boolean;
    errorType?: string;
    forceState?: MasteryState;
  }
): PedagogicalMemory {
  const key = notionKey(opts.subjectName, opts.notion);
  let n = mem.notions.find((x) => x.key === key);

  if (!n) {
    n = {
      key,
      subjectId: opts.subjectId,
      subjectName: opts.subjectName,
      notion: opts.notion,
      lessonId: opts.lessonId,
      seriesId: opts.seriesId,
      state: 'learning',
      errorCount: 0,
      successCount: 0,
      lastSeenAt: new Date().toISOString(),
    };
    mem.notions.unshift(n);
  }

  n.lastSeenAt = new Date().toISOString();

  if (opts.lessonId) n.lessonId = opts.lessonId;
  if (opts.seriesId !== undefined) n.seriesId = opts.seriesId;

  if (opts.error) {
    n.errorCount += 1;
    n.lastErrorType = opts.errorType || n.lastErrorType;

    if (n.errorCount >= 2) {
      n.state = 'fragile';
    } else {
      n.state = 'learning';
    }

    n.recommendation = `Revoir « ${n.notion} » avant d'avancer.`;
  }

  if (opts.success) {
    n.successCount += 1;

    if (n.successCount >= 3 && n.errorCount <= 1) {
      n.state = 'mastered';
    } else if (n.state === 'unknown') {
      n.state = 'learning';
    } else if (n.state === 'fragile' && n.successCount >= 2) {
      n.state = 'learning';
    }
  }

  if (opts.forceState) {
    n.state = opts.forceState;
  }

  return mem;
}

export function pushActivity(
  mem: PedagogicalMemory,
  ev: Omit<ActivityEvent, 'at'>
): PedagogicalMemory {
  mem.recentActivity.unshift({
    ...ev,
    at: new Date().toISOString(),
  });

  mem.recentActivity = mem.recentActivity.slice(0, MAX_ACTIVITY);

  return mem;
}

export function buildRecommendations(
  mem: PedagogicalMemory
): string[] {
  const fragile = mem.notions.filter(
    (n) => n.state === 'fragile' || n.state === 'learning'
  );

  fragile.sort((a, b) => b.errorCount - a.errorCount);

  const recs = fragile.slice(0, 5).map((n) => {
    const subj = n.subjectName ? `${n.subjectName} · ` : '';
    return `${subj}${n.notion} (${
      n.state === 'fragile' ? 'fragile' : 'à consolider'
    })`;
  });

  mem.recommendations = recs;

  return recs;
}

/** Résumé court pour injection prompt (pas toute la mémoire). */
export function formatMemoryForPrompt(
  mem: PedagogicalMemory,
  max = 800
): string {
  const fragile = mem.notions
    .filter((n) => n.state === 'fragile')
    .slice(0, 5);

  const mastered = mem.notions
    .filter((n) => n.state === 'mastered')
    .slice(0, 3);

  const lines = ['=== MÉMOIRE PÉDAGOGIQUE (synthèse) ==='];

  if (mem.levelId) {
    lines.push(`Niveau mémorisé : ${mem.levelId}`);
  }

  if (mem.seriesId) {
    lines.push(`Série mémorisée : ${mem.seriesId}`);
  }

  if (fragile.length) {
    lines.push('Notions fragiles:');

    fragile.forEach((n) => {
      lines.push(
        `- ${n.subjectName || ''} ${n.notion} (erreurs: ${n.errorCount})`
      );
    });
  }

  if (mastered.length) {
    lines.push('Notions maîtrisées (aperçu):');

    mastered.forEach((n) => {
      lines.push(`- ${n.notion}`);
    });
  }

  if (mem.recommendations?.length) {
    lines.push(
      'Recommandations: ' +
        mem.recommendations.slice(0, 3).join(' ; ')
    );
  }

  lines.push('=== FIN MÉMOIRE ===');

  let out = lines.join('\n');

  if (out.length > max) {
    out = out.slice(0, max) + '…';
  }

  return out;
}
