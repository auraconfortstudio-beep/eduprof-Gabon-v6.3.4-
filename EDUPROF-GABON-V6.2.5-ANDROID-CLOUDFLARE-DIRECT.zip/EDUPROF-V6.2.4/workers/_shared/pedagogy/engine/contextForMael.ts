/**
 * Construit le contexte pédagogique réel pour Maël.
 * N'invente aucune mastery : uniquement store + graphe.
 */

import type { MaelPedagogyContext } from './types.ts';
import { ensureGraphSeeded, findConceptsForSubject, getConcept } from './knowledgeGraph.ts';
import { getLevelFromXp } from '../../progression/levels.ts';
import { detectGaps, getNextLearningRecommendation } from './recommendations.ts';
import { masteryProb } from './masteryStore.ts';
import { masteryLabelFromProb } from './bkt.ts';

export function buildMaelPedagogyContext(opts: {
  userId: string;
  levelId?: string | null;
  seriesId?: string | null;
  subjectId?: string | null;
  subjectName?: string | null;
  focusConceptId?: string | null;
  question?: string | null;
  xp?: number | null;
  streak?: number | null;
}): MaelPedagogyContext {
  ensureGraphSeeded();
  const userId = opts.userId || '';
  let focusId = opts.focusConceptId || null;

  // Heuristique question : mots-clés maths
  if (!focusId && opts.question) {
    const q = opts.question.toLowerCase();
    if (q.includes('équation') || q.includes('equation')) focusId = 'math-equations';
    else if (q.includes('fraction')) focusId = 'math-fractions';
    else if (q.includes('système') || q.includes('systeme')) focusId = 'math-systemes';
    else if (q.includes('distribut')) focusId = 'math-distributivite';
  }

  if (!focusId) {
    const found = findConceptsForSubject(opts.subjectName, opts.levelId || undefined);
    if (found[0]) focusId = found[0].id;
  }

  const concept = focusId ? getConcept(focusId) : undefined;
  const mastery = concept && userId ? masteryProb(userId, concept.id) : null;
  const label = mastery != null ? masteryLabelFromProb(mastery) : null;
  const gaps = userId ? detectGaps(userId, { levelId: opts.levelId || undefined, subjectId: opts.subjectId || undefined }) : [];
  const recommendation = userId
    ? getNextLearningRecommendation(userId, {
        levelId: opts.levelId || undefined,
        subjectId: opts.subjectId || undefined,
        focusConceptId: focusId || undefined,
      })
    : null;

  const prereqWeak =
    recommendation?.prerequisiteGap != null ? [recommendation.prerequisiteGap] : [];

  const lines: string[] = [];
  if (concept) {
    lines.push(`Concept focal : ${concept.name} (${concept.id})`);
    if (mastery != null) lines.push(`Maîtrise estimée (BKT) : ${(mastery * 100).toFixed(0)} % — ${label}`);
  }
  if (prereqWeak.length) {
    lines.push(
      'Prérequis fragiles : ' +
        prereqWeak.map((g) => `${g.conceptName} (${(g.mastery * 100).toFixed(0)} %)`).join(', ')
    );
  }
  if (recommendation && recommendation.conceptId) {
    lines.push(
      `Recommandation : ${recommendation.conceptName} — ${recommendation.reason} → activité ${recommendation.recommendedActivity}`
    );
  }
  if (opts.xp != null) {
    lines.push(`XP : ${opts.xp} · niveau ${getLevelFromXp(opts.xp)}`);
  }
  if (opts.streak != null) {
    lines.push(`Série d'activité : ${opts.streak} jour(s)`);
  }
  if (!userId) {
    lines.push('Pas d’utilisateur authentifié : pas de mastery personnelle.');
  }

  return {
    userId,
    levelId: opts.levelId,
    seriesId: opts.seriesId,
    subjectId: opts.subjectId,
    subjectName: opts.subjectName,
    conceptId: concept?.id || null,
    conceptName: concept?.name || null,
    mastery,
    masteryLabel: label,
    prerequisitesWeak: prereqWeak,
    gaps: gaps.slice(0, 5),
    recommendation,
    summaryForPrompt: lines.length ? lines.join('\n') : 'Aucun contexte de maîtrise disponible.',
  };
}
