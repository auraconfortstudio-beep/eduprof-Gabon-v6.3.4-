/**
 * Recommandations pédagogiques EduProf.
 * Priorité : prérequis manquants → compétences fragiles → en apprentissage → révision → nouvelle notion.
 * Pas de recommandation forcée si données insuffisantes.
 */

import type { LearningGap, LearningRecommendation, MasteryLabel } from './types.ts';
import {
  ensureGraphSeeded,
  getConcept,
  getDirectPrerequisites,
  listConcepts,
} from './knowledgeGraph.ts';
import { getConceptMastery, masteryProb, labelFor } from './masteryStore.ts';
import { masteryLabelFromProb } from './bkt.ts';

const MASTERY_OK = 0.85;

function gapFor(userId: string, conceptId: string): LearningGap | null {
  const c = getConcept(conceptId);
  if (!c) return null;
  const p = masteryProb(userId, conceptId);
  const label = masteryLabelFromProb(p);
  if (label === 'mastered') return null;
  return {
    conceptId,
    conceptName: c.name,
    mastery: p,
    label,
    reason:
      label === 'unknown'
        ? 'Notion peu ou pas encore travaillée'
        : label === 'learning'
          ? 'Notion en cours d’apprentissage'
          : 'Maîtrise encore fragile',
  };
}

export function detectGaps(
  userId: string,
  opts?: { levelId?: string; subjectId?: string }
): LearningGap[] {
  ensureGraphSeeded();
  if (!userId) return [];
  const concepts = listConcepts({ levelId: opts?.levelId, subjectId: opts?.subjectId });
  const gaps: LearningGap[] = [];
  for (const c of concepts) {
    const g = gapFor(userId, c.id);
    if (g) gaps.push(g);
  }
  gaps.sort((a, b) => a.mastery - b.mastery);
  return gaps;
}

export function getNextLearningRecommendation(
  userId: string,
  opts?: { levelId?: string; subjectId?: string; focusConceptId?: string }
): LearningRecommendation {
  ensureGraphSeeded();
  const empty: LearningRecommendation = {
    conceptId: null,
    conceptName: null,
    reason: 'Données insuffisantes pour recommander.',
    mastery: null,
    label: null,
    prerequisiteGap: null,
    recommendedActivity: 'none',
  };
  if (!userId) return empty;

  const focus = opts?.focusConceptId ? getConcept(opts.focusConceptId) : null;
  const candidates = focus
    ? [focus]
    : listConcepts({ levelId: opts?.levelId, subjectId: opts?.subjectId });

  if (candidates.length === 0) return empty;

  // 1) Prérequis manquants du focus ou des candidats
  for (const c of candidates) {
    const prereqs = getDirectPrerequisites(c.id);
    for (const pre of prereqs) {
      const p = masteryProb(userId, pre.id);
      if (p < MASTERY_OK) {
        const label = masteryLabelFromProb(p);
        return {
          conceptId: pre.id,
          conceptName: pre.name,
          reason: `Prérequis fragile pour « ${c.name} »`,
          mastery: p,
          label,
          prerequisiteGap: {
            conceptId: pre.id,
            conceptName: pre.name,
            mastery: p,
            label,
            reason: `Nécessaire avant « ${c.name} »`,
          },
          recommendedActivity: label === 'unknown' ? 'lesson' : 'revision',
          lessonId: pre.lessonIds?.[0] || null,
        };
      }
    }
  }

  // 2) Compétences fragiles / en apprentissage
  const gaps = detectGaps(userId, opts);
  const fragile = gaps.find((g) => g.label === 'fragile' || g.label === 'learning');
  if (fragile) {
    return {
      conceptId: fragile.conceptId,
      conceptName: fragile.conceptName,
      reason: fragile.reason,
      mastery: fragile.mastery,
      label: fragile.label,
      prerequisiteGap: null,
      recommendedActivity: fragile.label === 'learning' ? 'exercise' : 'revision',
      lessonId: getConcept(fragile.conceptId)?.lessonIds?.[0] || null,
    };
  }

  // 3) Notion encore unknown (nouvelle)
  const unknown = gaps.find((g) => g.label === 'unknown');
  if (unknown) {
    return {
      conceptId: unknown.conceptId,
      conceptName: unknown.conceptName,
      reason: 'Nouvelle notion adaptée au parcours',
      mastery: unknown.mastery,
      label: unknown.label,
      prerequisiteGap: null,
      recommendedActivity: 'lesson',
      lessonId: getConcept(unknown.conceptId)?.lessonIds?.[0] || null,
    };
  }

  // Tout maîtrisé dans le filtre
  if (gaps.length === 0 && candidates.length > 0) {
    return {
      conceptId: candidates[0].id,
      conceptName: candidates[0].name,
      reason: 'Parcours stable sur ce filtre — révision optionnelle.',
      mastery: masteryProb(userId, candidates[0].id),
      label: labelFor(userId, candidates[0].id),
      prerequisiteGap: null,
      recommendedActivity: 'revision',
      lessonId: candidates[0].lessonIds?.[0] || null,
    };
  }

  return empty;
}
