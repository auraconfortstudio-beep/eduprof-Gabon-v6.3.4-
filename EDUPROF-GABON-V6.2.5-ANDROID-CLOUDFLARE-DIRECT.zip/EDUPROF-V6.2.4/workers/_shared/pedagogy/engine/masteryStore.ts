/**
 * Stockage maîtrise par utilisateur (isolation stricte userId).
 * RAM en local ; Blobs en runtime Cloudflare si disponible.
 */

import type { ConceptMastery, BktParams } from './types.ts';
import { createBktParams, updateBkt, masteryLabelFromProb } from './bkt.ts';
import type { MasteryLabel } from './types.ts';

const local = new Map<string, Map<string, ConceptMastery>>();

function userMap(userId: string): Map<string, ConceptMastery> {
  let m = local.get(userId);
  if (!m) {
    m = new Map();
    local.set(userId, m);
  }
  return m;
}

export function resetMasteryStore(): void {
  local.clear();
}

export function getConceptMastery(userId: string, conceptId: string): ConceptMastery | null {
  if (!userId || !conceptId) return null;
  return userMap(userId).get(conceptId) || null;
}

export function getOrInitMastery(
  userId: string,
  conceptId: string,
  bktOverrides?: Partial<BktParams>
): ConceptMastery {
  const existing = getConceptMastery(userId, conceptId);
  if (existing) return { ...existing, bkt: { ...existing.bkt } };
  const created: ConceptMastery = {
    userId,
    conceptId,
    bkt: createBktParams(bktOverrides),
    observations: 0,
    correctCount: 0,
    incorrectCount: 0,
    lastUpdatedAt: new Date().toISOString(),
  };
  userMap(userId).set(conceptId, created);
  return { ...created, bkt: { ...created.bkt } };
}

export function applyObservation(
  userId: string,
  conceptId: string,
  isCorrect: boolean
): ConceptMastery | null {
  if (!userId || !conceptId) return null;
  const cur = getOrInitMastery(userId, conceptId);
  const nextBkt = updateBkt(cur.bkt, isCorrect);
  const updated: ConceptMastery = {
    ...cur,
    bkt: nextBkt,
    observations: cur.observations + 1,
    correctCount: cur.correctCount + (isCorrect ? 1 : 0),
    incorrectCount: cur.incorrectCount + (isCorrect ? 0 : 1),
    lastUpdatedAt: new Date().toISOString(),
  };
  userMap(userId).set(conceptId, updated);
  return { ...updated, bkt: { ...updated.bkt } };
}

export function listUserMastery(userId: string): ConceptMastery[] {
  if (!userId) return [];
  return [...userMap(userId).values()].map((m) => ({ ...m, bkt: { ...m.bkt } }));
}

export function masteryProb(userId: string, conceptId: string): number {
  const m = getConceptMastery(userId, conceptId);
  return m ? m.bkt.probMastery : createBktParams().probMastery;
}

export function labelFor(userId: string, conceptId: string): MasteryLabel {
  return masteryLabelFromProb(masteryProb(userId, conceptId));
}

/** Isolation : user A ne voit jamais les données de B */
export function assertIsolated(userA: string, userB: string): boolean {
  if (!userA || !userB || userA === userB) return true;
  const a = listUserMastery(userA);
  const b = listUserMastery(userB);
  for (const ma of a) {
    if (ma.userId !== userA) return false;
  }
  for (const mb of b) {
    if (mb.userId !== userB) return false;
  }
  return true;
}
