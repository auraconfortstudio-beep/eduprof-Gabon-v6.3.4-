/**
 * Bayesian Knowledge Tracing — réimplémentation TypeScript EduProf.
 *
 * SOURCE inspectée : OATutor `src/models/BKT/BKT-brain.js` (MIT)
 * Formule identique à update(model, isCorrect) d'OATutor.
 *
 * Valeurs par défaut documentées (courantes en ITS) :
 * - probMastery initial 0.1 (élève débutant)
 * - probTransit 0.1
 * - probSlip 0.1
 * - probGuess 0.3
 *
 * Ces défauts sont configurables par concept via createBktParams().
 */

import type { BktParams } from './types.ts';

export const DEFAULT_BKT: Readonly<BktParams> = {
  probMastery: 0.1,
  probTransit: 0.1,
  probSlip: 0.1,
  probGuess: 0.3,
};

export function createBktParams(overrides?: Partial<BktParams>): BktParams {
  const p: BktParams = {
    probMastery: overrides?.probMastery ?? DEFAULT_BKT.probMastery,
    probTransit: overrides?.probTransit ?? DEFAULT_BKT.probTransit,
    probSlip: overrides?.probSlip ?? DEFAULT_BKT.probSlip,
    probGuess: overrides?.probGuess ?? DEFAULT_BKT.probGuess,
  };
  return clampParams(p);
}

function clamp01(x: number): number {
  if (!Number.isFinite(x)) return 0;
  return Math.min(1, Math.max(0, x));
}

function clampParams(p: BktParams): BktParams {
  return {
    probMastery: clamp01(p.probMastery),
    probTransit: clamp01(p.probTransit),
    probSlip: clamp01(p.probSlip),
    probGuess: clamp01(p.probGuess),
  };
}

/**
 * Met à jour les paramètres BKT in-place (comme OATutor) et retourne le modèle.
 * Ne mute pas l'objet d'entrée : retourne une copie mise à jour.
 */
export function updateBkt(model: BktParams, isCorrect: boolean): BktParams {
  const m = clampParams(model);
  let numerator: number;
  let masteryAndGuess: number;
  if (isCorrect) {
    numerator = m.probMastery * (1 - m.probSlip);
    masteryAndGuess = (1 - m.probMastery) * m.probGuess;
  } else {
    numerator = m.probMastery * m.probSlip;
    masteryAndGuess = (1 - m.probMastery) * (1 - m.probGuess);
  }
  const denom = numerator + masteryAndGuess;
  const probMasteryGivenObservation = denom > 0 ? numerator / denom : m.probMastery;
  const next =
    probMasteryGivenObservation + (1 - probMasteryGivenObservation) * m.probTransit;
  return clampParams({
    ...m,
    probMastery: next,
  });
}

export function masteryLabelFromProb(p: number): 'unknown' | 'learning' | 'fragile' | 'mastered' {
  if (p < 0.2) return 'unknown';
  if (p < 0.5) return 'learning';
  if (p < 0.85) return 'fragile';
  return 'mastered';
}
