/**
 * Knowledge graph minimal EduProf.
 * Inspiration : Step-Wise skill tree (prérequis), LearnGraph ConceptNode / PrerequisiteEdge.
 * Contenu : seed minimal + API pour enregistrer des concepts (pas de contenu externe).
 */

import type { EduProfConcept, PrerequisiteStatus, PrerequisiteStrength } from './types.ts';

const concepts = new Map<string, EduProfConcept>();

export function resetKnowledgeGraph(): void {
  concepts.clear();
}

export function upsertConcept(c: EduProfConcept): EduProfConcept {
  const normalized: EduProfConcept = {
    ...c,
    id: c.id.trim(),
    name: c.name.trim(),
    prerequisiteIds: [...new Set((c.prerequisiteIds || []).map((x) => x.trim()).filter(Boolean))],
    prerequisiteStatus: c.prerequisiteStatus || 'unknown',
    lessonIds: c.lessonIds ? [...c.lessonIds] : [],
    exerciseIds: c.exerciseIds ? [...c.exerciseIds] : [],
    quizIds: c.quizIds ? [...c.quizIds] : [],
  };
  concepts.set(normalized.id, normalized);
  return normalized;
}

export function getConcept(id: string): EduProfConcept | undefined {
  return concepts.get(id);
}

export function listConcepts(filter?: {
  levelId?: string;
  subjectId?: string;
}): EduProfConcept[] {
  let all = [...concepts.values()];
  if (filter?.levelId) all = all.filter((c) => c.levelId === filter.levelId);
  if (filter?.subjectId) all = all.filter((c) => c.subjectId === filter.subjectId);
  return all;
}

/** Prérequis directs */
export function getDirectPrerequisites(conceptId: string): EduProfConcept[] {
  const c = concepts.get(conceptId);
  if (!c) return [];
  return c.prerequisiteIds.map((id) => concepts.get(id)).filter((x): x is EduProfConcept => !!x);
}

/**
 * Chaîne de prérequis (ordre topologique simple, profondeur limitée).
 * Si cycle ou statut unknown massif → s'arrête sans inventer.
 */
export function getPrerequisiteChain(conceptId: string, maxDepth = 8): string[] {
  const chain: string[] = [];
  const seen = new Set<string>();
  function walk(id: string, depth: number) {
    if (depth > maxDepth || seen.has(id)) return;
    seen.add(id);
    const c = concepts.get(id);
    if (!c) return;
    for (const pre of c.prerequisiteIds) {
      walk(pre, depth + 1);
      if (!chain.includes(pre)) chain.push(pre);
    }
  }
  walk(conceptId, 0);
  return chain;
}

export function addPrerequisite(
  fromId: string,
  toId: string,
  _strength: PrerequisiteStrength = 'required'
): { ok: boolean; error?: string } {
  const target = concepts.get(toId);
  const from = concepts.get(fromId);
  if (!target || !from) return { ok: false, error: 'concept_not_found' };
  if (fromId === toId) return { ok: false, error: 'self_prerequisite' };
  if (!target.prerequisiteIds.includes(fromId)) {
    target.prerequisiteIds.push(fromId);
    target.prerequisiteStatus = 'known';
    concepts.set(toId, target);
  }
  return { ok: true };
}

/**
 * Seed minimal gabonais (structure, pas de contenu de cours inventé comme officiel).
 * Relations simples et documentées ; prerequisiteStatus = known uniquement si lié explicitement.
 */
export function seedMinimalMathGraph(): void {
  const specs: EduProfConcept[] = [
    {
      id: 'math-arithmetique',
      name: 'Arithmétique de base',
      levelId: 'cm2',
      subjectId: 'mathematiques',
      subjectName: 'Mathématiques',
      difficulty: 2,
      prerequisiteIds: [],
      prerequisiteStatus: 'known',
    },
    {
      id: 'math-fractions',
      name: 'Fractions',
      levelId: '6e',
      subjectId: 'mathematiques',
      subjectName: 'Mathématiques',
      difficulty: 4,
      prerequisiteIds: ['math-arithmetique'],
      prerequisiteStatus: 'known',
    },
    {
      id: 'math-distributivite',
      name: 'Distributivité',
      levelId: '4e',
      subjectId: 'mathematiques',
      subjectName: 'Mathématiques',
      difficulty: 5,
      prerequisiteIds: ['math-arithmetique'],
      prerequisiteStatus: 'known',
    },
    {
      id: 'math-equations',
      name: 'Équations',
      levelId: '3e',
      subjectId: 'mathematiques',
      subjectName: 'Mathématiques',
      difficulty: 6,
      prerequisiteIds: ['math-distributivite', 'math-fractions'],
      prerequisiteStatus: 'known',
    },
    {
      id: 'math-systemes',
      name: 'Systèmes d’équations',
      levelId: '2nde',
      subjectId: 'mathematiques',
      subjectName: 'Mathématiques',
      difficulty: 7,
      prerequisiteIds: ['math-equations'],
      prerequisiteStatus: 'known',
    },
  ];
  for (const s of specs) upsertConcept(s);
}

/** Heuristique légère : lier un lessonId / subject à un concept existant par nom */
export function findConceptsForSubject(
  subjectName?: string | null,
  levelId?: string | null
): EduProfConcept[] {
  if (!subjectName && !levelId) return listConcepts();
  const q = (subjectName || '').toLowerCase();
  return listConcepts().filter((c) => {
    const sn = (c.subjectName || '').toLowerCase();
    const matchSub = !q || sn.includes(q) || q.includes(sn) || (c.subjectId || '').includes(q);
    const matchLevel = !levelId || c.levelId === levelId;
    return matchSub && matchLevel;
  });
}

export function ensureGraphSeeded(): void {
  if (concepts.size === 0) seedMinimalMathGraph();
}
