/**
 * Moteur pédagogique EduProf V4.1 — types.
 * Inspiré conceptuellement de Step-Wise (skills/prereqs), OATutor (BKT), LearnGraph (graph).
 * Implémentation native EduProf — pas d'import des packages externes.
 */

export type PrerequisiteStatus = 'known' | 'unknown';

export type PrerequisiteStrength = 'required' | 'recommended' | 'helpful';

/** Concept / notion dans le graphe EduProf */
export interface EduProfConcept {
  id: string;
  name: string;
  levelId?: string | null;
  seriesId?: string | null;
  subjectId?: string | null;
  subjectName?: string | null;
  difficulty?: number; // 1-10 optionnel
  /** IDs de concepts prérequis directs */
  prerequisiteIds: string[];
  prerequisiteStatus: PrerequisiteStatus;
  lessonIds?: string[];
  exerciseIds?: string[];
  quizIds?: string[];
}

/** Paramètres BKT (modèle Corbett & Anderson, formule type OATutor BKT-brain) */
export interface BktParams {
  /** P(L) — probabilité actuelle de maîtrise ∈ [0,1] */
  probMastery: number;
  /** P(T) — probabilité de transition (apprentissage) après une observation */
  probTransit: number;
  /** P(S) — probabilité de glissement (erreur malgré maîtrise) */
  probSlip: number;
  /** P(G) — probabilité de devinette (succès sans maîtrise) */
  probGuess: number;
}

/** État de maîtrise d'un concept pour un élève */
export interface ConceptMastery {
  userId: string;
  conceptId: string;
  bkt: BktParams;
  /** Observations totales */
  observations: number;
  correctCount: number;
  incorrectCount: number;
  lastUpdatedAt: string;
}

export type MasteryLabel = 'unknown' | 'learning' | 'fragile' | 'mastered';

export interface LearningGap {
  conceptId: string;
  conceptName: string;
  mastery: number;
  label: MasteryLabel;
  reason: string;
}

export type RecommendedActivityKind = 'lesson' | 'exercise' | 'quiz' | 'revision' | 'none';

export interface LearningRecommendation {
  conceptId: string | null;
  conceptName: string | null;
  reason: string;
  mastery: number | null;
  label: MasteryLabel | null;
  prerequisiteGap: LearningGap | null;
  recommendedActivity: RecommendedActivityKind;
  lessonId?: string | null;
}

/** Contexte pédagogique injecté dans Maël (données réelles uniquement) */
export interface MaelPedagogyContext {
  userId: string;
  levelId?: string | null;
  seriesId?: string | null;
  subjectId?: string | null;
  subjectName?: string | null;
  conceptId?: string | null;
  conceptName?: string | null;
  mastery?: number | null;
  masteryLabel?: MasteryLabel | null;
  prerequisitesWeak: LearningGap[];
  gaps: LearningGap[];
  recommendation: LearningRecommendation | null;
  summaryForPrompt: string;
}
