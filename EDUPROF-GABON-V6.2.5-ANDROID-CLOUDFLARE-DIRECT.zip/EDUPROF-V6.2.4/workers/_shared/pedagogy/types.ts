/** Mémoire pédagogique synthétique par élève (pas de dump de conversation). */

export type MasteryState = 'unknown' | 'learning' | 'fragile' | 'mastered';

export interface NotionMemory {
  key: string; // matière|notion normalisée
  subjectId?: string;
  subjectName?: string;
  notion: string;
  lessonId?: string;
  seriesId?: string | null;
  state: MasteryState;
  errorCount: number;
  successCount: number;
  lastErrorType?: string;
  lastSeenAt: string;
  recommendation?: string;
}

export interface ActivityEvent {
  at: string;
  kind: 'explain' | 'exercise' | 'quiz' | 'revision' | 'error' | 'success';
  lessonId?: string;
  subjectId?: string;
  seriesId?: string | null;
  note?: string;
}

export interface PedagogicalMemory {
  userId: string;
  updatedAt?: string;
  levelId?: string | null;
  seriesId?: string | null;
  notions: NotionMemory[];
  recentActivity: ActivityEvent[]; // max ~30
  recommendations: string[]; // max ~10
}

export type Intent =
  | 'greeting'
  | 'identity'
  | 'capabilities'
  | 'help'
  | 'explain'
  | 'summarize'
  | 'revise'
  | 'exercise'
  | 'correction'
  | 'motivation'
  | 'progress'
  | 'recommendation'
  | 'unknown';

export interface PedagogyRequest {
  userId: string;
  question: string;
  levelId?: string | null;
  seriesId?: string | null;
  subjectId?: string | null;
  subjectName?: string | null;
  chapterName?: string | null;
  lessonId?: string | null;
  lessonTitle?: string | null;
  lessonContent?: string | null;
  lessonExample?: string | null;
  lessonKeyPoints?: string[];
  exercises?: { id?: string; question: string; difficulty?: string }[];
  quiz?: { id?: string; question: string }[];
  retrievalOk?: boolean;
  memory: PedagogicalMemory;
}

export interface PedagogyResponse {
  reply: string;
  intent: Intent;
  source: 'local' | 'eduprof' | 'hybrid';
  memoryUpdates?: Partial<PedagogicalMemory>;
  notionTouched?: { notion: string; state?: MasteryState; error?: boolean; success?: boolean };
}
