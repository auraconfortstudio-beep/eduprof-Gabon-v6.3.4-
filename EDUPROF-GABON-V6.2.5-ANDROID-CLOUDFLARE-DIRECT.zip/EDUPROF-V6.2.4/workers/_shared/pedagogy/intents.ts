import type { Intent } from './types.ts';

const PATTERNS: { intent: Intent; re: RegExp }[] = [
  { intent: 'greeting', re: /^(bonjour|bonsoir|salut|hey|hello|coucou|bsr|bjr)\b/i },
  { intent: 'identity', re: /\b(qui es[- ]tu|t[' ]es qui|ton nom|tu es qui|présente[- ]toi)\b/i },
  {
    intent: 'capabilities',
    re: /\b(que peux[- ]tu|qu[' ]est[- ]ce que tu peux|tes (capacité|fonction)|comment (peux[- ]tu|tu peux) m[' ]aider|à quoi tu sers)\b/i,
  },
  { intent: 'help', re: /\b(aide[- ]moi|j[' ]ai besoin d[' ]aide|sos|au secours)\b/i },
  {
    intent: 'explain',
    re: /\b(explique|expliquer|je (ne )?comprends pas|j[' ]ai pas compris|c[' ]est quoi|qu[' ]est[- ]ce que|clarifie|reformule)\b/i,
  },
  { intent: 'summarize', re: /\b(r[eé]sume|r[eé]sum[eé]|synth[eè]se|en bref)\b/i },
  {
    intent: 'recommendation',
    re: /\b(que dois[- ]je r[eé]viser|quoi r[eé]viser|que r[eé]viser|recommandation|sur quoi travailler)\b/i,
  },
  { intent: 'revise', re: /\b(fait[- ]moi r[eé]viser|fais[- ]moi r[eé]viser|quiz[- ]moi|r[eé]visons|r[eé]vision)\b/i },
  {
    intent: 'exercise',
    re: /\b(exercice|exercice|donne[- ]moi (un |des )?exercice|entra[iî]ne[- ]moi|pratique)\b/i,
  },
  {
    intent: 'correction',
    re: /\b(corrige|correction|c[' ]est juste|ma r[eé]ponse|j[' ]ai trouv[eé]|j[' ]ai mis)\b/i,
  },
  { intent: 'motivation', re: /\b(motivation|encourager|d[eé]courag[eé]|j[' ]y arrive pas)\b/i },
  {
    intent: 'progress',
    re: /\b(ma progression|mon niveau|o[uù] j[' ]en suis|mes r[eé]sultats)\b/i,
  },
  
];

export function detectIntent(question: string): Intent {
  const q = (question || '').trim();
  if (!q) return 'unknown';
  for (const { intent, re } of PATTERNS) {
    if (re.test(q)) return intent;
  }
  // Courtes reformulations
  if (/^(oui|ok|d[' ]accord|vas[- ]y|go)\b/i.test(q)) return 'help';
  return 'unknown';
}
