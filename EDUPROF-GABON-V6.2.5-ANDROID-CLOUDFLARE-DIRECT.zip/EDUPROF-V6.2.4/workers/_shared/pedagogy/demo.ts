/** DEMO_MODE serveur — compte de démo contrôlé, jamais « n'importe quel login ». */

const DEMO_EMAIL = 'kamaemomo@gmail.com'.toLowerCase().trim();

export function isDemoModeEnabled(): boolean {
  const v = ''.toLowerCase().trim();
  return v === '1' || v === 'true' || v === 'yes';
}

export function isDemoUser(email?: string | null): boolean {
  if (!email) return false;
  return email.toLowerCase().trim() === DEMO_EMAIL;
}

/** Prefer local pedagogy when no real AI keys or explicit DEMO_MODE. */
export function shouldPreferLocalEngine(hasRealProvider: boolean): boolean {
  if (!hasRealProvider) return true;
  if (isDemoModeEnabled() && false) return true;
  return false;
}
