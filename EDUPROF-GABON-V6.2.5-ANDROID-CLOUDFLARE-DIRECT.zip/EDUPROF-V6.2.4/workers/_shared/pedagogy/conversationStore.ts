/**
 * Conversations de Maël — persistance isolée par userId.
 *
 * Production Cloudflare : KV (binding KV, préfixes conv: / convidx:).
 * Tests / local sans bindings : Map RAM isolée par userId.
 * Dégradation silencieuse si KV indisponible (pas de crash).
 */
import { randomUUID } from 'crypto';
import type {
  Conversation,
  ConversationMessage,
  ConversationSummary,
  ConversationLessonRef,
} from './conversationTypes.ts';
import { MAX_CONVERSATIONS_PER_USER, MAX_MESSAGES_PER_CONVERSATION } from './conversationTypes.ts';
import { currentEnv } from '../../platform/env.ts';

const KV_CONV = 'conv:';
const KV_IDX = 'convidx:';

/**
 * Runtime Worker Cloudflare avec KV disponible.
 * Pas d'héritage Netlify CONTEXT — détection via bindings env.
 */
function hasKvBinding(): boolean {
  const env = currentEnv();
  return typeof env.KV !== 'undefined' && env.KV !== null;
}

/** userId -> (conversationId -> Conversation). Jamais partagée entre users. */
const localDevConversations = new Map<string, Map<string, Conversation>>();

function toSummary(c: Conversation): ConversationSummary {
  const { messages, ...summary } = c;
  return { ...summary, messageCount: messages.length };
}

function titleFromFirstMessage(text: string): string {
  const clean = text.trim().replace(/\s+/g, ' ');
  return clean.length > 48 ? clean.slice(0, 48) + '…' : clean || 'Nouvelle conversation';
}

/** Liste légère (sans les messages) des conversations d'un utilisateur, plus récentes d'abord. */
export async function listConversations(userId: string): Promise<ConversationSummary[]> {
  if (!userId) return [];

  if (!hasKvBinding()) {
    const store = localDevConversations.get(userId);
    if (!store) return [];
    return [...store.values()].map(toSummary).sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
  }

  try {
    const kv = currentEnv().KV;
    if (!kv) return [];
    const raw = await kv.get(`${KV_IDX}${userId}`);
    if (!raw) return [];
    const list = JSON.parse(raw) as ConversationSummary[];
    return list.filter((c) => c.userId === userId).sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
  } catch {
    return [];
  }
}

async function saveIndex(userId: string, list: ConversationSummary[]): Promise<void> {
  if (!hasKvBinding()) return; // en dev l'index se déduit directement de la Map
  try {
    const kv = currentEnv().KV;
    if (!kv) return;
    await kv.put(`${KV_IDX}${userId}`, JSON.stringify(list.slice(0, MAX_CONVERSATIONS_PER_USER)));
  } catch {
    /* dégradation silencieuse */
  }
}

/** Charge une conversation complète — retourne null si absente OU si elle n'appartient pas à userId. */
export async function getConversation(userId: string, id: string): Promise<Conversation | null> {
  if (!userId || !id) return null;

  if (!hasKvBinding()) {
    const c = localDevConversations.get(userId)?.get(id);
    return c && c.userId === userId ? JSON.parse(JSON.stringify(c)) : null;
  }

  try {
    const kv = currentEnv().KV;
    if (!kv) return null;
    const raw = await kv.get(`${KV_CONV}${userId}:${id}`);
    if (!raw) return null;
    const c = JSON.parse(raw) as Conversation;
    return c.userId === userId ? c : null;
  } catch {
    return null;
  }
}

/** Crée une nouvelle conversation isolée pour userId. */
export async function createConversation(
  userId: string,
  opts?: {
    title?: string;
    lessonId?: string | null;
    levelId?: string | null;
    seriesId?: string | null;
    subjectId?: string | null;
    subjectName?: string | null;
    chapterId?: string | null;
    lessonTitle?: string | null;
    initialMessages?: Omit<ConversationMessage, 'id' | 'createdAt'>[];
  },
  /** Texte utilisateur optionnel pour initialiser le titre / premier message. */
  firstUserText?: string
): Promise<Conversation> {
  const now = new Date().toISOString();
  const messages: ConversationMessage[] = (opts?.initialMessages || []).map((m) => ({
    ...m,
    id: randomUUID(),
    createdAt: now,
  }));
  // firstUserText sert uniquement au titre initial (le message est ajouté via appendMessages)
  const firstUser = messages.find((m) => m.role === 'user');
  const titleFromText = firstUserText && firstUserText.trim()
    ? titleFromFirstMessage(firstUserText.trim())
    : null;
  const conv: Conversation = {
    id: randomUUID(),
    userId,
    title: opts?.title || titleFromText || (firstUser ? titleFromFirstMessage(firstUser.content) : 'Nouvelle conversation'),
    createdAt: now,
    updatedAt: now,
    lessonId: opts?.lessonId ?? null,
    levelId: opts?.levelId ?? null,
    seriesId: opts?.seriesId ?? null,
    subjectId: opts?.subjectId ?? null,
    subjectName: opts?.subjectName ?? null,
    chapterId: opts?.chapterId ?? null,
    lessonTitle: opts?.lessonTitle ?? null,
    messageCount: messages.length,
    messages,
  };

  if (!hasKvBinding()) {
    if (!localDevConversations.has(userId)) localDevConversations.set(userId, new Map());
    localDevConversations.get(userId)!.set(conv.id, conv);
    return conv;
  }

  try {
    const kv = currentEnv().KV;
    if (kv) {
      await kv.put(`${KV_CONV}${userId}:${conv.id}`, JSON.stringify(conv));
      const list = await listConversations(userId);
      await saveIndex(userId, [toSummary(conv), ...list]);
    }
  } catch {
    /* la conversation reste utilisable en mémoire pour cette requête même si la persistance échoue */
  }
  return conv;
}

/** Ajoute des messages à une conversation existante et la persiste. Retourne null si non trouvée/non possédée. */
export async function appendMessages(
  userId: string,
  id: string,
  newMessages: Omit<ConversationMessage, 'id' | 'createdAt'>[]
): Promise<Conversation | null> {
  const conv = await getConversation(userId, id);
  if (!conv) return null;

  const now = new Date().toISOString();
  const toAdd: ConversationMessage[] = newMessages.map((m) => ({
    ...m,
    id: randomUUID(),
    createdAt: now,
  }));

  conv.messages = [...conv.messages, ...toAdd].slice(-MAX_MESSAGES_PER_CONVERSATION);
  conv.messageCount = conv.messages.length;
  conv.updatedAt = now;
  if (conv.messages.length && conv.title === 'Nouvelle conversation') {
    const firstUser = conv.messages.find((m) => m.role === 'user');
    if (firstUser) conv.title = titleFromFirstMessage(firstUser.content);
  }

  if (!hasKvBinding()) {
    localDevConversations.get(userId)?.set(id, conv);
    return conv;
  }

  try {
    const kv = currentEnv().KV;
    if (kv) {
      await kv.put(`${KV_CONV}${userId}:${id}`, JSON.stringify(conv));
      const list = (await listConversations(userId)).filter((c) => c.id !== id);
      await saveIndex(userId, [toSummary(conv), ...list]);
    }
  } catch {
    /* la réponse à l'utilisateur ne doit jamais être bloquée par un échec de persistance */
  }
  return conv;
}

/** Supprime une conversation — no-op silencieux si elle n'appartient pas à userId. */
export async function deleteConversation(userId: string, id: string): Promise<boolean> {
  if (!userId || !id) return false;

  if (!hasKvBinding()) {
    return localDevConversations.get(userId)?.delete(id) ?? false;
  }

  const existing = await getConversation(userId, id);
  if (!existing) return false;
  try {
    const kv = currentEnv().KV;
    if (!kv) return false;
    await kv.delete(`${KV_CONV}${userId}:${id}`);
    const list = (await listConversations(userId)).filter((c) => c.id !== id);
    await saveIndex(userId, list);
    return true;
  } catch {
    return false;
  }
}
