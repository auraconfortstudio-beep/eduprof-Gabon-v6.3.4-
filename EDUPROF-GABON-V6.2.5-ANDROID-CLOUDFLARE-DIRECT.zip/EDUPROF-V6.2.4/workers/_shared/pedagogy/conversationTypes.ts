/** Conversations de Maël — historique de messages, isolé par userId. */

/** Référence légère à une pièce jointe (pas de binaire dans le JSON conversation). */
export interface ConversationAttachmentRef {
  id: string;
  fileName: string;
  mimeType: string;
  size: number;
}

export interface ConversationMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  createdAt: string;
  /** 0..N pièces jointes associées au message (métadonnées uniquement). */
  attachments?: ConversationAttachmentRef[];
}

/** Contexte pédagogique d'origine d'une conversation (optionnel). */
export interface ConversationLessonRef {
  lessonId?: string | null;
  levelId?: string | null;
  seriesId?: string | null;
  subjectId?: string | null;
  subjectName?: string | null;
  chapterId?: string | null;
  lessonTitle?: string | null;
}

export interface ConversationSummary extends ConversationLessonRef {
  id: string;
  userId: string;
  title: string;
  createdAt: string;
  updatedAt: string;
  messageCount: number;
}

export interface Conversation extends ConversationSummary {
  messages: ConversationMessage[];
}

export const MAX_CONVERSATIONS_PER_USER = 50;
export const MAX_MESSAGES_PER_CONVERSATION = 200;
