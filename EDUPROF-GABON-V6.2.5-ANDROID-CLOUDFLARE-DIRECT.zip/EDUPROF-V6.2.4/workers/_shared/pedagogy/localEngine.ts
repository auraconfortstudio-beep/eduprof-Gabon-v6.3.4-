/**
 * Moteur pédagogique local — réponses pro sans provider externe.
 * S'appuie sur le contenu EduProf déjà récupéré (jamais inventé comme programme officiel).
 */
import type { PedagogyRequest, PedagogyResponse } from './types.ts';
import { detectIntent } from './intents.ts';
import { buildRecommendations, pushActivity, upsertNotion } from './memoryStore.ts';

function ctxLine(req: PedagogyRequest): string {
  const bits = [
    req.levelId,
    req.seriesId,
    req.subjectName || req.subjectId,
    req.chapterName,
    req.lessonTitle,
  ].filter(Boolean);
  return bits.length ? bits.join(' · ') : 'contexte non précisé';
}

function firstParagraph(text: string, max = 420): string {
  const t = (text || '').replace(/\s+/g, ' ').trim();
  if (!t) return '';
  if (t.length <= max) return t;
  return t.slice(0, max).replace(/\s+\S*$/, '') + '…';
}

function pickExercise(req: PedagogyRequest) {
  return req.exercises?.[0] || null;
}

function pickQuiz(req: PedagogyRequest) {
  return req.quiz?.[0] || null;
}

function explainFromLesson(req: PedagogyRequest): PedagogyResponse {
  if (!req.retrievalOk || !req.lessonContent) {
    return {
      intent: 'explain',
      source: 'local',
      reply:
        `Je n'ai pas le texte complet de cette leçon dans le catalogue EduProf pour l'instant (${ctxLine(req)}).\n\n` +
        `Dis-moi quelle notion précise te bloque, ou ouvre une leçon depuis ton cours : je m'appuierai alors sur le contenu EduProf.`,
    };
  }
  const title = req.lessonTitle || 'cette leçon';
  const obj = req.lessonContent ? firstParagraph(req.lessonContent, 500) : '';
  const keys = (req.lessonKeyPoints || []).slice(0, 4);
  const ex = req.lessonExample ? `\n\nExemple : ${firstParagraph(req.lessonExample, 200)}` : '';
  let reply =
    `Selon le contenu EduProf — **${title}** (${ctxLine(req)}) :\n\n` +
    obj +
    ex;
  if (keys.length) {
    reply += `\n\nPoints clés :\n` + keys.map((k) => `• ${k}`).join('\n');
  }
  reply +=
    `\n\nDis-moi si une partie n'est pas claire, ou demande : « donne-moi un exercice » pour vérifier.`;
  return {
    intent: 'explain',
    source: 'eduprof',
    reply,
    notionTouched: { notion: title, success: false },
  };
}

function exerciseFromLesson(req: PedagogyRequest): PedagogyResponse {
  const ex = pickExercise(req);
  if (!ex) {
    return {
      intent: 'exercise',
      source: 'local',
      reply:
        `Je n'ai pas d'exercice EduProf indexé pour ${ctxLine(req)}.\n` +
        `Ouvre une leçon qui contient des exercices, ou dis-moi la notion à travailler.`,
    };
  }
  return {
    intent: 'exercise',
    source: 'eduprof',
    reply:
      `Voici un exercice tiré de ton cours EduProf (${ctxLine(req)}) :\n\n` +
      `**${ex.question}**` +
      (ex.difficulty ? `\n_Niveau : ${ex.difficulty}_` : '') +
      `\n\nEssaie d'abord. Ensuite envoie ta réponse : je te guiderai étape par étape (sans tout révéler d'un coup).`,
    notionTouched: { notion: req.lessonTitle || 'exercice', success: false },
  };
}

function reviseFromLesson(req: PedagogyRequest): PedagogyResponse {
  const q = pickQuiz(req);
  if (q) {
    return {
      intent: 'revise',
      source: 'eduprof',
      reply:
        `Révision rapide — ${ctxLine(req)} :\n\n` +
        `**Question :** ${q.question}\n\n` +
        `Réponds avec ta proposition. Je corrigerai ensuite.`,
    };
  }
  if (req.lessonKeyPoints?.length) {
    return {
      intent: 'revise',
      source: 'eduprof',
      reply:
        `Pour réviser **${req.lessonTitle || 'la leçon'}**, retiens :\n` +
        req.lessonKeyPoints.slice(0, 5).map((k) => `• ${k}`).join('\n') +
        `\n\nPeux-tu reformuler le point le plus important avec tes mots ?`,
    };
  }
  return explainFromLesson(req);
}

function progressReply(req: PedagogyRequest): PedagogyResponse {
  const mem = req.memory;
  const fragile = mem.notions.filter((n) => n.state === 'fragile');
  const mastered = mem.notions.filter((n) => n.state === 'mastered');
  let reply = `Voici ce que je retiens de ton parcours (mémoire pédagogique) :\n\n`;
  reply += `• Notions fragiles : ${fragile.length ? fragile.map((n) => n.notion).join(', ') : 'aucune enregistrée pour l’instant'}\n`;
  reply += `• Notions maîtrisées (aperçu) : ${mastered.length ? mastered.slice(0, 5).map((n) => n.notion).join(', ') : 'encore peu de données'}\n`;
  reply += `• Activités récentes : ${mem.recentActivity.length}\n\n`;
  reply += `Continue régulièrement : chaque exercice bien compris renforce ta mémoire.`;
  return { intent: 'progress', source: 'local', reply };
}

function recommendationReply(req: PedagogyRequest): PedagogyResponse {
  const recs = buildRecommendations(req.memory);
  if (!recs.length) {
    return {
      intent: 'recommendation',
      source: 'local',
      reply:
        `Je n'ai pas encore assez d'historique d'erreurs pour personnaliser.\n` +
        `Travaille une leçon, tente un exercice, et je pourrai te dire précisément quoi réviser.`,
    };
  }
  return {
    intent: 'recommendation',
    source: 'local',
    reply:
      `D’après ta mémoire pédagogique, priorise :\n\n` +
      recs.map((r, i) => `${i + 1}. ${r}`).join('\n') +
      `\n\nCommence par le point le plus fragile, puis redemande un exercice sur cette notion.`,
  };
}

export function runLocalPedagogy(req: PedagogyRequest): PedagogyResponse {
  const intent = detectIntent(req.question);
  const q = req.question.trim();

  let res: PedagogyResponse;

  switch (intent) {
    case 'greeting':
      res = {
        intent,
        source: 'local',
        reply:
          `Bonjour ! Je suis **Maël**, ton professeur IA sur EduProf Gabon.\n` +
          (req.lessonTitle
            ? `Je vois que tu es sur : **${ctxLine(req)}**.\n`
            : `Choisis une leçon dans ton cours pour que je m’appuie sur le contenu EduProf.\n`) +
          `Dis-moi : expliquer, exercer, réviser, ou « que dois-je réviser ? ».`,
      };
      break;
    case 'identity':
      res = {
        intent,
        source: 'local',
        reply:
          `Je suis **Maël**, le professeur IA d’EduProf Gabon.\n` +
          `J’aide selon ton niveau et ta série, avec le contenu de tes leçons quand il est disponible.\n` +
          `Je ne remplace pas ton enseignant, mais je t’accompagne pas à pas.`,
      };
      break;
    case 'capabilities':
    case 'help':
      res = {
        intent,
        source: 'local',
        reply:
          `Je peux t’aider à :\n` +
          `• **Expliquer** la leçon ouverte (contenu EduProf)\n` +
          `• **Résumer** les points clés\n` +
          `• **Proposer un exercice** déjà présent dans le cours\n` +
          `• **Réviser** avec une question de compréhension\n` +
          `• Te dire **quoi réviser** selon tes difficultés mémorisées\n\n` +
          `Contexte actuel : ${ctxLine(req)}.`,
      };
      break;
    case 'explain':
      res = explainFromLesson(req);
      break;
    case 'summarize':
      if (req.lessonKeyPoints?.length) {
        res = {
          intent,
          source: 'eduprof',
          reply:
            `Résumé EduProf — **${req.lessonTitle || 'leçon'}** :\n` +
            req.lessonKeyPoints.map((k) => `• ${k}`).join('\n') +
            (req.lessonExample ? `\n\nExemple : ${firstParagraph(req.lessonExample, 160)}` : ''),
        };
      } else {
        res = explainFromLesson(req);
      }
      break;
    case 'revise':
      res = reviseFromLesson(req);
      break;
    case 'exercise':
      res = exerciseFromLesson(req);
      break;
    case 'correction':
      res = {
        intent,
        source: 'local',
        reply:
          `Envoie ta réponse complète et, si possible, ton raisonnement.\n` +
          `Je te dirai ce qui est juste, ce qui bloque, et la prochaine étape — sans spoiler inutile.`,
        notionTouched: { notion: req.lessonTitle || 'correction', error: /faux|erreur|bloque|comprends pas/i.test(q) },
      };
      break;
    case 'motivation':
      res = {
        intent,
        source: 'local',
        reply:
          `C’est normal de bloquer : apprendre, c’est essayer plusieurs fois.\n` +
          `Reprenons calmement. Demande « explique-moi » sur la leçon, puis un petit exercice.\n` +
          `Tu progresses dès que tu comprends une étape de plus.`,
      };
      break;
    case 'progress':
      res = progressReply(req);
      break;
    case 'recommendation':
      res = recommendationReply(req);
      break;
    default:
      if (req.retrievalOk && req.lessonContent && q.length < 40) {
        res = explainFromLesson(req);
      } else if (req.retrievalOk && req.lessonContent) {
        res = {
          intent: 'unknown',
          source: 'hybrid',
          reply:
            `J’ai bien le cours **${req.lessonTitle || ''}** sous les yeux.\n\n` +
            firstParagraph(req.lessonContent, 280) +
            `\n\nPrécise : expliquer, résumé, exercice, ou correction de ta réponse.`,
        };
      } else {
        res = {
          intent: 'unknown',
          source: 'local',
          reply:
            `Je peux t’aider sur ton cours EduProf dès qu’une leçon est ouverte.\n` +
            `Essaie : « explique-moi cette leçon », « donne-moi un exercice », « que dois-je réviser ? ».`,
        };
      }
  }

  // Mémoire : activité + notion
  let mem = req.memory;
  mem.levelId = req.levelId || mem.levelId;
  mem.seriesId = req.seriesId || mem.seriesId;
  const kind =
    intent === 'exercise'
      ? 'exercise'
      : intent === 'revise'
        ? 'quiz'
        : intent === 'explain'
          ? 'explain'
          : 'explain';
  mem = pushActivity(mem, {
    kind: kind as 'explain' | 'exercise' | 'quiz',
    lessonId: req.lessonId || undefined,
    subjectId: req.subjectId || undefined,
    seriesId: req.seriesId,
    note: intent,
  });
  if (res.notionTouched) {
    mem = upsertNotion(mem, {
      subjectId: req.subjectId || undefined,
      subjectName: req.subjectName || undefined,
      notion: res.notionTouched.notion,
      lessonId: req.lessonId || undefined,
      seriesId: req.seriesId,
      error: res.notionTouched.error,
      success: res.notionTouched.success,
    });
  }
  buildRecommendations(mem);
  res.memoryUpdates = mem;
  return res;
}

export { detectIntent };
