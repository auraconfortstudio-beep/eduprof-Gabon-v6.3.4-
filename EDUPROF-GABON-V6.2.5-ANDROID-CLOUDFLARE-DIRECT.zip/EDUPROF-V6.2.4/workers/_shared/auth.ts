import bcrypt from 'bcryptjs';
import { SignJWT, jwtVerify } from 'jose';
import type { Role, SessionPayload, UserRecord } from './types';
import { getJwtSecret, isOwnerEmail } from '../platform/env.ts';
import { securityHeaders } from './securityHeaders.ts';
import { getUserById, getUserByEmail, saveUser } from './store';
import { randomUUID } from 'crypto';

/**
 * JWT secret resolution:
 * - Production / Cloudflare: JWT_SECRET env is mandatory (≥ 32 chars). No hardcoded fallback.
 * - Local dev only: ALLOW_INSECURE_JWT_DEV=1 permits a non-production local secret.
 *   Never deploy with ALLOW_INSECURE_JWT_DEV=1.
 */
function isProductionRuntime(): boolean {
  return true;
}

function resolveJwtSecretBytes(): Uint8Array {
  return new TextEncoder().encode(getJwtSecret());
}

const JWT_SECRET = () => resolveJwtSecretBytes();


export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 10);
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

export async function createToken(user: UserRecord): Promise<string> {
  return new SignJWT({ email: user.email, role: user.role } as Omit<SessionPayload, 'sub'>)
    .setProtectedHeader({ alg: 'HS256' })
    .setSubject(user.id)
    .setIssuedAt()
    .setExpirationTime('30d')
    .sign(JWT_SECRET());
}

export async function verifyToken(token: string): Promise<SessionPayload | null> {
  try {
    const { payload } = await jwtVerify(token, JWT_SECRET(), { algorithms: ['HS256'] });
    return {
      sub: payload.sub as string,
      email: payload.email as string,
      role: payload.role as Role,
    };
  } catch {
    return null;
  }
}

export function getBearerToken(headers: Headers | Record<string, string | undefined>): string | null {
  const read = (key: string): string | null => {
    if (headers && typeof (headers as Headers).get === 'function') {
      return (headers as Headers).get(key);
    }
    const h = headers as Record<string, string | undefined>;
    return h[key] || h[key.toLowerCase()] || h[key.toUpperCase()] || null;
  };
  // Authorization standard + secours si un proxy Cloudflare omet le header classique
  const auth =
    read('authorization') ||
    read('Authorization') ||
    read('x-eduprof-authorization') ||
    read('X-EduProf-Authorization');
  if (!auth) return null;
  const v = auth.trim();
  if (v.toLowerCase().startsWith('bearer ')) return v.slice(7).trim() || null;
  // token brut éventuellement envoyé dans X-EduProf-Authorization
  if (v.length > 20 && !v.includes(' ')) return v;
  return null;
}

export async function getAuthUser(headers: Headers | Record<string, string | undefined>): Promise<UserRecord | null> {
  const token = getBearerToken(headers);
  if (!token) return null;
  const payload = await verifyToken(token);
  if (!payload) return null;
  const user = await getUserById(payload.sub);
  if (!user) return null;
  // Refresh role from DB (cannot escalate via token)
  return user;
}

export function isOwner(user: UserRecord): boolean {
  return user.role === 'OWNER' || isOwnerEmail(user.email);
}

export function isAdminOrOwner(user: UserRecord): boolean {
  return user.role === 'ADMIN' || isOwner(user);
}

export async function createUser(params: {
  email: string;
  password: string;
  displayName: string;
  educationLevel?: string;
  educationSeries?: string | null;
  educationFiliere?: string | null;
}): Promise<{ user: UserRecord; error?: string }> {
  const email = params.email.trim().toLowerCase();
  if (!email || !email.includes('@')) return { user: null as any, error: 'Email invalide' };
  if (!params.password || params.password.length < 6) return { user: null as any, error: 'Mot de passe trop court (min 6)' };
  if (!params.displayName?.trim()) return { user: null as any, error: 'Nom requis' };

  const existing = await getUserByEmail(email);
  if (existing) return { user: null as any, error: 'Cet email est déjà utilisé' };

  const now = new Date().toISOString();
  const role: Role = isOwnerEmail(email) ? 'OWNER' : 'USER';
  const user: UserRecord = {
    id: randomUUID(),
    email,
    passwordHash: await hashPassword(params.password),
    displayName: params.displayName.trim(),
    educationLevel: params.educationLevel || 'cm2',
    educationSeries: params.educationSeries ?? null,
    educationFiliere: params.educationFiliere ?? null,
    role,
    isPremium: false,
    premiumUntil: null,
    xp: 0,
    streak: 0,
    lastActivityDate: null,
    createdAt: now,
    updatedAt: now,
  };
  await saveUser(user);
  return { user };
}

export function publicProfile(user: UserRecord) {
  return {
    id: user.id,
    displayName: user.displayName,
    educationLevel: user.educationLevel,
    xp: user.xp,
    isPremium: user.isPremium && (!user.premiumUntil || new Date(user.premiumUntil) > new Date()),
  };
}

export function fullProfile(user: UserRecord) {
  const premiumActive = user.isPremium && (!user.premiumUntil || new Date(user.premiumUntil) > new Date());
  return {
    id: user.id,
    displayName: user.displayName,
    email: user.email,
    educationLevel: user.educationLevel,
    educationSeries: user.educationSeries,
    educationFiliere: user.educationFiliere,
    role: user.role,
    isPremium: premiumActive,
    premiumUntil: user.premiumUntil,
    xp: user.xp,
    streak: user.streak,
    lastActivityDate: user.lastActivityDate,
    createdAt: user.createdAt,
    isDemo: !!user.isDemo,
  };
}

export function corsHeaders() {
  return {
    ...securityHeaders(),
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-EduProf-Authorization',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  };
}

export function jsonResponse(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json', ...corsHeaders() },
  });
}
