import { currentEnv } from './env.ts';
const memBin = new Map<string, ArrayBuffer>();
const memMeta = new Map<string, string>();
export async function r2Put(key: string, data: ArrayBuffer | Uint8Array, contentType?: string): Promise<void> {
  const env = currentEnv();
  if (env.R2) { await env.R2.put(key, data, { httpMetadata: contentType ? { contentType } : undefined }); return; }
  const buf = data instanceof ArrayBuffer ? data : data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength);
  memBin.set(key, buf as ArrayBuffer);
}
export async function r2Get(key: string): Promise<ArrayBuffer | null> {
  const env = currentEnv();
  if (env.R2) { const obj = await env.R2.get(key); return obj ? await obj.arrayBuffer() : null; }
  return memBin.get(key) || null;
}
export async function r2Delete(key: string): Promise<void> {
  const env = currentEnv();
  if (env.R2) { await env.R2.delete(key); return; }
  memBin.delete(key);
}
export async function metaPut(key: string, json: string): Promise<void> {
  const env = currentEnv();
  if (env.KV) { await env.KV.put(`attmeta:${key}`, json); return; }
  memMeta.set(key, json);
}
export async function metaGet(key: string): Promise<string | null> {
  const env = currentEnv();
  if (env.KV) return await env.KV.get(`attmeta:${key}`);
  return memMeta.get(key) || null;
}
export async function metaDelete(key: string): Promise<void> {
  const env = currentEnv();
  if (env.KV) { await env.KV.delete(`attmeta:${key}`); return; }
  memMeta.delete(key);
}
