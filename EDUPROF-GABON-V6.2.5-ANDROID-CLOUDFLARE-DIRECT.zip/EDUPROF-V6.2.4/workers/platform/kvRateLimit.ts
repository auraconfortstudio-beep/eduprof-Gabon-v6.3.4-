import { currentEnv } from './env.ts';
const mem = new Map<string, { count: number; resetAt: number }>();
export async function kvIncr(key: string, windowMs: number): Promise<{ count: number; resetAt: number }> {
  const env = currentEnv();
  const now = Date.now();
  const resetAt = now + windowMs;
  if (env.KV) {
    const raw = await env.KV.get(`rl:${key}`, 'json');
    let count = 1; let exp = resetAt;
    if (raw && typeof raw === 'object' && raw !== null) {
      const o = raw as { count?: number; resetAt?: number };
      if (o.resetAt && o.resetAt > now) { count = (o.count || 0) + 1; exp = o.resetAt; }
    }
    await env.KV.put(`rl:${key}`, JSON.stringify({ count, resetAt: exp }), { expirationTtl: Math.max(60, Math.ceil(windowMs / 1000)) });
    return { count, resetAt: exp };
  }
  const cur = mem.get(key);
  if (!cur || cur.resetAt <= now) { mem.set(key, { count: 1, resetAt }); return { count: 1, resetAt }; }
  cur.count += 1; return { count: cur.count, resetAt: cur.resetAt };
}
export function resetMemRateLimit(): void { mem.clear(); }
