import { currentEnv } from './env.ts';

export function getDb(): D1Database | null {
  return currentEnv().DB || null;
}

export function requireDb(): D1Database {
  const db = getDb();
  if (!db) throw new Error('D1 non disponible');
  return db;
}

export function isPersistentRuntime(): boolean {
  return !!getDb();
}
