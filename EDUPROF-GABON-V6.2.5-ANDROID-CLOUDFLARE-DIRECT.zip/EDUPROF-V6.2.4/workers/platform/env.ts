/**
 * Environnement Cloudflare Worker — propagation request-scoped.
 * Pas de `let currentEnv = env` global mutable.
 * Mécanisme : AsyncLocalStorage (Node / Workers nodejs_compat),
 * sinon pile d'appels locale (reentrant, pour Vite config / fallback).
 */
export interface EduprofEnv {
  DB?: D1Database;
  KV?: KVNamespace;
  R2?: R2Bucket;
  ASSETS?: Fetcher;
  JWT_SECRET?: string;
  OWNER_EMAILS?: string;
  OWNER_EMAIL?: string;
  GEMINI_API_KEY?: string;
  GROQ_API_KEY?: string;
  MISTRAL_API_KEY?: string;
  CEREBRAS_API_KEY?: string;
  OPENAI_API_KEY?: string;
  ANTHROPIC_API_KEY?: string;
  GEMINI_MODEL?: string;
  GROQ_MODEL?: string;
  MISTRAL_MODEL?: string;
  CEREBRAS_MODEL?: string;
  ALLOW_INSECURE_JWT_DEV?: string;
  APP_NAME?: string;
  APP_VERSION?: string;
  AI_RATE_LIMIT_PER_MINUTE?: string;
  AI_RATE_LIMIT_PER_DAY?: string;
  AI_RATE_LIMIT_PER_DAY_DEMO?: string;
  [key: string]: unknown;
}

type AlsStore = { env: EduprofEnv };

interface AlsLike {
  run<T>(store: AlsStore, fn: () => T): T;
  getStore(): AlsStore | undefined;
}

/** Pile reentrante — pas une variable d'environnement de requête partagée entre requêtes concurrentes Worker (single-threaded isolate). */
function createStackAls(): AlsLike {
  const stack: EduprofEnv[] = [];
  return {
    run<T>(store: AlsStore, fn: () => T): T {
      stack.push(store.env);
      try {
        return fn();
      } finally {
        stack.pop();
      }
    },
    getStore(): AlsStore | undefined {
      if (stack.length === 0) return undefined;
      return { env: stack[stack.length - 1]! };
    },
  };
}

function tryNodeAls(): AlsLike | null {
  try {
    const G = globalThis as unknown as { AsyncLocalStorage?: new <T>() => AlsLike };
    if (typeof G.AsyncLocalStorage === 'function') {
      return new G.AsyncLocalStorage<AlsStore>();
    }
  } catch {
    /* ignore */
  }
  try {
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const mod = require('node:async_hooks') as { AsyncLocalStorage: new <T>() => AlsLike };
    if (mod?.AsyncLocalStorage) return new mod.AsyncLocalStorage<AlsStore>();
  } catch {
    /* Vite ESM bundle of config may forbid dynamic require */
  }
  return null;
}

let als: AlsLike | null = null;

function getAls(): AlsLike {
  if (!als) {
    als = tryNodeAls() ?? createStackAls();
  }
  return als;
}

/**
 * Exécute fn dans le contexte request-scoped de `env`.
 * Point d'entrée : workers/index.ts (fetch / scheduled) et tests.
 */
export function runWithEnv<T>(env: EduprofEnv, fn: () => T): T {
  return getAls().run({ env }, fn);
}

/**
 * Env de la requête courante (ALS ou pile) — jamais une globale mutable assignée.
 */
export function currentEnv(): EduprofEnv {
  return getAls().getStore()?.env ?? {};
}

export function getOwnerEmails(env?: EduprofEnv): string[] {
  const e = env ?? currentEnv();
  const raw = typeof e.OWNER_EMAILS === 'string' ? e.OWNER_EMAILS : '';
  const legacy = typeof e.OWNER_EMAIL === 'string' ? e.OWNER_EMAIL : '';
  const list = `${raw},${legacy}`
    .split(',')
    .map((s) => s.trim().toLowerCase())
    .filter((s) => s.length > 3 && s.includes('@') && !s.includes('owner@eduprof-gabon.ga'));
  return [...new Set(list)];
}

export function isOwnerEmail(email: string | null | undefined, env?: EduprofEnv): boolean {
  if (!email) return false;
  const owners = getOwnerEmails(env);
  return owners.length > 0 && owners.includes(email.trim().toLowerCase());
}

export function getJwtSecret(env?: EduprofEnv): string {
  const e = env ?? currentEnv();
  const secret = typeof e.JWT_SECRET === 'string' ? e.JWT_SECRET : '';
  if (secret && secret.length >= 32) return secret;
  if (e.ALLOW_INSECURE_JWT_DEV === '1') return 'dev-only-insecure-jwt-secret-min-32-chars!!';
  throw new Error('JWT_SECRET manquant ou trop court (≥ 32).');
}

export function getSecret(name: string, env?: EduprofEnv): string | undefined {
  const e = env ?? currentEnv();
  const v = e[name];
  return typeof v === 'string' && v.length > 0 ? v : undefined;
}

/** Env de développement local (Vite middleware) — jamais en production Worker. */
export function createDevEnv(overrides: Partial<EduprofEnv> = {}): EduprofEnv {
  return {
    ALLOW_INSECURE_JWT_DEV: '1',
    APP_NAME: 'EduProf Gabon',
    APP_VERSION: '6.2.4',
    ...overrides,
  };
}
