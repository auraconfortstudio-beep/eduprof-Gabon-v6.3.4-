/**
 * EduProf Gabon — /api/ai-tutor
 * Auth → rate limit → retrieval → mémoire → moteur local OU providers.
 */
import { getBearerToken, verifyToken } from './_shared/auth';
import { getUserById } from './_shared/store';
import { checkRateLimit, getClientIp, rateLimitResponse } from './_shared/rateLimit';
import { securityHeaders } from './_shared/securityHeaders.ts';
import { AIOrchestrator } from './_shared/ai/orchestrator';
import {
  buildPedagogicalSystemPrompt,
  detectUnsafeUserIntent,
  safeRefusalMessage,
  MAX_HISTORY_TURNS,
  MAX_QUESTION_LENGTH,
} from './_shared/ai/prompt';
import { createConfiguredProviders } from './_shared/ai/providers/index';
import type { AIMessage } from './_shared/ai/types';
import {
  retrieveLesson,
  formatLessonContextForPrompt,
} from './_shared/lessonRetrieval';
import {
  loadPedagogicalMemory,
  savePedagogicalMemory,
  formatMemoryForPrompt,
  pushActivity,
  buildRecommendations,
} from './_shared/pedagogy/memoryStore.ts';
import { buildMaelPedagogyContext } from './_shared/pedagogy/engine/index.ts';
import { getSecret, currentEnv } from './platform/env.ts';
import { getConversation, createConversation, appendMessages } from './_shared/pedagogy/conversationStore.ts';
import { runLocalPedagogy } from './_shared/pedagogy/localEngine.ts';
import { shouldPreferLocalEngine } from './_shared/pedagogy/demo.ts';
import {
  getAttachmentBinary,
  isImageMime,
  isPdfMime,
  toDataUrl,
  ATTACHMENT_MAX_PER_MESSAGE,
} from './_shared/attachments.ts';
import type { ConversationAttachmentRef } from './_shared/pedagogy/conversationTypes.ts';

const corsHeaders: Record<string, string> = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-EduProf-Authorization',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Content-Type': 'application/json',
};

function json(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), { status, headers: { ...corsHeaders, ...securityHeaders() } });
}


function isProductionRuntime(): boolean {
  return true;
}

export default async (req: Request, _env?: unknown): Promise<Response> => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 204, headers: { ...corsHeaders, ...securityHeaders() } });
  }
  if (req.method !== 'POST') {
    return json({ error: 'Méthode non autorisée' }, 405);
  }

  try {
    // Body d'abord : certains proxys omettent Authorization
    let body: {
      messages?: unknown;
      context?: Record<string, string | null | undefined>;
      token?: string;
      accessToken?: string;
      conversationId?: string;
      attachmentIds?: unknown;
    } = {};
    try {
      body = (await req.json()) as typeof body;
    } catch {
      body = {};
    }

    const token =
      getBearerToken(req.headers) ||
      (typeof body.token === 'string' ? body.token.trim() : '') ||
      (typeof body.accessToken === 'string' ? body.accessToken.trim() : '') ||
      null;

    if (!token) {
      return json({ error: 'Connexion requise pour utiliser le Professeur IA.' }, 401);
    }
    const session = await verifyToken(token);
    if (!session) {
      return json({ error: 'Session invalide ou expirée. Reconnecte-toi.' }, 401);
    }
    // Utilisateur depuis le JWT vérifié (pas de confiance aveugle au body)
    const user = await getUserById(session.sub);
    if (!user) {
      return json({ error: 'Utilisateur introuvable.' }, 401);
    }
    const userId = user.id;

    const perMin = Math.max(1, parseInt(String(getSecret('AI_RATE_LIMIT_PER_MINUTE') || '20'), 10) || 20);
    const perDayDefault = Math.max(1, parseInt(String(getSecret('AI_RATE_LIMIT_PER_DAY') || '150'), 10) || 150);
    // Compte démo : plafond quotidien nettement plus bas, non lié au tarif normal.
    const perDayDemo = Math.max(1, parseInt(String(getSecret('AI_RATE_LIMIT_PER_DAY_DEMO') || '8'), 10) || 8);
    const perDay = user.isDemo ? perDayDemo : perDayDefault;
    const ip = getClientIp(req);

    const rlMin = await checkRateLimit(`ai:user:${userId}:min`, perMin, 60_000);
    if (!rlMin.allowed) {
      return rateLimitResponse(
        'Trop de questions. Attends une minute avant de réessayer.',
        rlMin.retryAfterSec
      );
    }
    const rlDay = await checkRateLimit(`ai:user:${userId}:day`, perDay, 86_400_000);
    if (!rlDay.allowed) {
      return rateLimitResponse(
        'Limite quotidienne atteinte. Reviens demain.',
        rlDay.retryAfterSec
      );
    }
    const rlIp = await checkRateLimit(`ai:ip:${ip}`, perMin * 2, 60_000);
    if (!rlIp.allowed) {
      return rateLimitResponse(
        'Trop de requêtes depuis cette adresse. Réessaie plus tard.',
        rlIp.retryAfterSec
      );
    }

    const raw = Array.isArray(body.messages) ? body.messages : [];
    const ctx = body.context || {};

    const messages: AIMessage[] = [];
    for (const m of raw) {
      if (!m || typeof m !== 'object') continue;
      const role = (m as { role?: string }).role === 'assistant' ? 'assistant' : 'user';
      const content = String((m as { content?: string }).content || '')
        .trim()
        .slice(0, MAX_QUESTION_LENGTH);
      if (!content) continue;
      messages.push({ role, content });
    }
    if (!messages.length) {
      return json({ error: 'messages requis' }, 400);
    }
    const clipped = messages.slice(-MAX_HISTORY_TURNS * 2);

    const lastUser = [...clipped].reverse().find((m) => m.role === 'user');
    const question = lastUser?.content || '';
    const safety = detectUnsafeUserIntent(question);
    if (safety.unsafe) {
      return json({
        reply: safeRefusalMessage(safety.reason || 'prompt_injection'),
        provider: 'safety',
        source: 'safety',
      });
    }

    // ── Pièces jointes (isolation userId) ──────────────────────────
    const rawAttachmentIds = Array.isArray(body.attachmentIds)
      ? (body.attachmentIds as unknown[]).filter((x): x is string => typeof x === 'string' && !!x)
      : [];
    const attachmentIds = rawAttachmentIds.slice(0, ATTACHMENT_MAX_PER_MESSAGE);
    const loadedAttachments: {
      id: string;
      fileName: string;
      mimeType: string;
      size: number;
      base64: string;
    }[] = [];
    for (const aid of attachmentIds) {
      const bin = await getAttachmentBinary(userId, aid);
      if (bin) {
        loadedAttachments.push({
          id: bin.meta.id,
          fileName: bin.meta.fileName,
          mimeType: bin.meta.mimeType,
          size: bin.meta.size,
          base64: bin.base64,
        });
      }
    }
    const attachmentRefs: ConversationAttachmentRef[] = loadedAttachments.map((a) => ({
      id: a.id,
      fileName: a.fileName,
      mimeType: a.mimeType,
      size: a.size,
    }));
    const imageAttachments = loadedAttachments.filter((a) => isImageMime(a.mimeType));
    const pdfAttachments = loadedAttachments.filter((a) => isPdfMime(a.mimeType));
    let attachmentContextNote = '';
    if (loadedAttachments.length) {
      const lines = loadedAttachments.map(
        (a) =>
          `- ${a.fileName} (${a.mimeType}, ${Math.round(a.size / 1024)} Ko)`
      );
      attachmentContextNote =
        `\n\n[Pièces jointes de l'élève]\n` +
        lines.join('\n') +
        (imageAttachments.length
          ? '\nUne ou plusieurs images sont fournies : analyse-les si tu as la capacité vision.'
          : '') +
        (pdfAttachments.length
          ? '\nUn ou plusieurs PDF sont joints. Si tu ne peux pas lire le contenu binaire, dis-le honnêtement et demande à l\'élève de coller le texte ou une photo de page.'
          : '');
    }

    const seriesId =
      (ctx.seriesId as string) ||
      (ctx.series as string) ||
      user.educationSeries ||
      null;
    const levelId = (ctx.level as string) || user.educationLevel || 'cm2';
    const lessonId = (ctx.lessonId as string) || null;
    const subjectId = (ctx.subjectId as string) || null;
    const chapterId = (ctx.chapterId as string) || null;
    const subjectName = (ctx.subjectName as string) || (ctx.subject as string) || null;
    const lessonTitleCtx = (ctx.lessonTitle as string) || null;

    // Conversation : réutilise celle fournie si elle appartient bien à l'utilisateur,
    // sinon en crée une nouvelle automatiquement (jamais bloquant pour la réponse).
    const requestedConvId = typeof body.conversationId === 'string' ? body.conversationId : null;
    let conversationId: string | null = null;
    try {
      const existing = requestedConvId ? await getConversation(userId, requestedConvId) : null;
      if (existing) {
        conversationId = existing.id;
      } else {
        const created = await createConversation(
          userId,
          { lessonId, levelId: typeof levelId === 'string' ? levelId : null, seriesId, subjectId, subjectName, chapterId, lessonTitle: lessonTitleCtx },
          question
        );
        conversationId = created.id;
      }
    } catch {
      conversationId = null; // la conversation est une commodité, jamais une condition de réponse
    }

    async function finish(payload: Record<string, unknown>): Promise<Response> {
      if (conversationId) {
        try {
          await appendMessages(userId, conversationId, [
            {
              role: 'user',
              content: question,
              ...(attachmentRefs.length ? { attachments: attachmentRefs } : {}),
            },
            { role: 'assistant', content: String(payload.reply || '') },
          ]);
        } catch {
          /* la persistance de conversation ne doit jamais faire échouer la réponse */
        }
      }
      return json({ ...payload, conversationId });
    }


    // Retrieval
    let lessonContextBlock: string | null = null;
    let retrievalStatus: 'ok' | 'not_found' | 'series_mismatch' | 'catalog_missing' | 'none' =
      'none';
    let retrievedMeta: Record<string, string> | undefined;
    let lessonPayload: {
      content?: string;
      example?: string;
      keyPoints?: string[];
      exercises?: { id?: string; question: string; difficulty?: string }[];
      quiz?: { id?: string; question: string }[];
      title?: string;
    } = {};

    if (lessonId || (subjectId && seriesId)) {
      const result = retrieveLesson({
        lessonId,
        seriesId,
        subjectId,
        levelId: typeof levelId === 'string' ? levelId : null,
        chapterId,
      });
      if (result.ok) {
        retrievalStatus = 'ok';
        lessonContextBlock = formatLessonContextForPrompt(result.lesson);
        retrievedMeta = {
          lessonId: result.lesson.lessonId,
          seriesId: result.lesson.seriesId || '',
          subjectId: result.lesson.subjectId,
          title: result.lesson.title,
        };
        lessonPayload = {
          content: result.lesson.content,
          example: result.lesson.example,
          keyPoints: result.lesson.keyPoints,
          exercises: result.lesson.exercises,
          quiz: result.lesson.quiz,
          title: result.lesson.title,
        };
      } else {
        retrievalStatus = result.reason;
      }
    }

    // Mémoire isolée userId
    let memory = await loadPedagogicalMemory(userId);
    const maelPedagogyCtx = buildMaelPedagogyContext({
      userId,
      levelId: typeof levelId === 'string' ? levelId : null,
      seriesId: typeof seriesId === 'string' ? seriesId : null,
      subjectId: typeof subjectId === 'string' ? subjectId : null,
      subjectName: typeof subjectName === 'string' ? subjectName : null,
      question: typeof question === 'string' ? question : null,
      xp: typeof user.xp === 'number' ? user.xp : null,
      streak: typeof user.streak === 'number' ? user.streak : null,
    });

    memory.levelId = typeof levelId === 'string' ? levelId : memory.levelId;
    memory.seriesId = seriesId || memory.seriesId;

    const prod = isProductionRuntime();
    const { providers } = createConfiguredProviders((k) => getSecret(k) || (currentEnv()[k] as string | undefined), {
      includeMocksIfEmpty: !prod,
    });
    const realProviders = providers.filter((p) => !String(p.id).startsWith('mock'));
    const hasReal = realProviders.length > 0;
    const preferLocal = shouldPreferLocalEngine(hasReal);

    // Moteur local (toujours disponible) — utilisé si pas de provider réel ou DEMO force local
    if (preferLocal || !hasReal) {
      // Sans provider vision : être honnête sur les images
      if (imageAttachments.length > 0 && !hasReal) {
        const honest =
          "J'ai bien reçu ta photo (« " +
          imageAttachments.map((a) => a.fileName).join(', ') +
          " »). " +
          "Pour l'analyser pixel par pixel j'ai besoin d'un moteur vision (Gemini) configuré côté serveur. " +
          "En attendant, décris-moi l'exercice ou recopie l'énoncé et je t'aide étape par étape" +
          (lessonPayload.title ? ` sur la leçon « ${lessonPayload.title} ».` : '.');
        return finish({
          reply: honest,
          provider: 'mael-local',
          source: 'attachment-no-vision',
          retrievalStatus,
          mode: 'local-no-vision',
          ...(retrievedMeta ? { lesson: retrievedMeta } : {}),
        });
      }
      const local = runLocalPedagogy({
        userId: userId,
        question: question + attachmentContextNote,
        levelId: typeof levelId === 'string' ? levelId : null,
        seriesId,
        subjectId,
        subjectName: (ctx.subjectName as string) || (ctx.subject as string) || null,
        chapterName: (ctx.chapterName as string) || null,
        lessonId,
        lessonTitle: (ctx.lessonTitle as string) || lessonPayload.title || null,
        lessonContent: lessonPayload.content || null,
        lessonExample: lessonPayload.example || null,
        lessonKeyPoints: lessonPayload.keyPoints,
        exercises: lessonPayload.exercises,
        quiz: lessonPayload.quiz,
        retrievalOk: retrievalStatus === 'ok',
        memory,
      });
      if (local.memoryUpdates) {
        await savePedagogicalMemory({ ...local.memoryUpdates, userId: userId });
      }
      return finish({
        reply: local.reply,
        provider: 'mael-local',
        source: local.source,
        intent: local.intent,
        retrievalStatus,
        mode: hasReal ? 'local-preferred' : 'integrated-pedagogy',
        ...(retrievedMeta ? { lesson: retrievedMeta } : {}),
      });
    }

    // Providers externes
    const memoryBlock = formatMemoryForPrompt(memory);
    const systemPrompt = buildPedagogicalSystemPrompt({
      level: levelId,
      className: (ctx.level as string) || user.educationLevel,
      series: seriesId,
      filiere: (ctx.filiere as string) || user.educationFiliere || null,
      subjectName: (ctx.subjectName as string) || (ctx.subject as string) || null,
      subject: subjectId,
      lessonTitle: (ctx.lessonTitle as string) || lessonPayload.title || null,
      lesson: (ctx.lessonTitle as string) || null,
      chapterName: (ctx.chapterName as string) || null,
      lessonContextBlock: [lessonContextBlock, memoryBlock, maelPedagogyCtx.summaryForPrompt ? ('=== MOTEUR PÉDAGOGIQUE (données réelles) ===\n' + maelPedagogyCtx.summaryForPrompt) : ''].filter(Boolean).join('\n\n'),
      retrievalStatus,
    });

    // Enrichir le dernier message user avec le contexte pièces jointes
    const clippedWithAtt = clipped.map((m, i) => {
      if (i === clipped.length - 1 && m.role === 'user' && attachmentContextNote) {
        return { ...m, content: m.content + attachmentContextNote };
      }
      return m;
    });

    // Si images : privilégier Gemini (vision) s'il est dans la liste
    const geminiProvider = realProviders.find((p) => p.id === 'gemini' || String(p.id).includes('gemini'));
    const visionImages = imageAttachments.map((a) => ({
      mimeType: a.mimeType,
      base64: a.base64,
    }));

    const orchestrator = new AIOrchestrator(realProviders, { timeoutMs: 20_000 });
    try {
      let result;
      if (visionImages.length > 0 && geminiProvider) {
        // Appel direct Gemini avec images
        result = {
          content: (
            await geminiProvider.generate({
              systemPrompt:
                systemPrompt +
                '\n\nL\'élève a joint une ou plusieurs images (photo d\'exercice ou document). Analyse-les attentivement, corrige les erreurs, explique les étapes et reste adapté au niveau indiqué.',
              messages: clippedWithAtt,
              maxTokens: 1536,
              temperature: 0.5,
              images: visionImages,
            } as any)
          ).content,
          providerId: geminiProvider.id,
        };
      } else {
        result = await orchestrator.generate({
          systemPrompt,
          messages: clippedWithAtt,
          maxTokens: 1024,
          temperature: 0.7,
        });
        // Si images mais pas de vision réussie via orchestrator
        if (visionImages.length > 0 && !String(result.providerId).includes('gemini')) {
          // message déjà généré sans vision — préfixer honnêteté si besoin
        }
      }
      // Mise à jour mémoire légère (activité)
      memory = pushActivity(memory, {
        kind: 'explain',
        lessonId: lessonId || undefined,
        subjectId: subjectId || undefined,
        seriesId,
        note: 'ai-provider',
      });
      buildRecommendations(memory);
      await savePedagogicalMemory(memory);

      return finish({
        reply: result.content,
        provider: result.providerId,
        source: retrievalStatus === 'ok' ? 'eduprof' : 'ai',
        retrievalStatus,
        mode: 'provider',
        ...(retrievedMeta ? { lesson: retrievedMeta } : {}),
      });
    } catch {
      // Fallback local si tous les providers échouent
      const local = runLocalPedagogy({
        userId: userId,
        question,
        levelId: typeof levelId === 'string' ? levelId : null,
        seriesId,
        subjectId,
        subjectName: (ctx.subjectName as string) || null,
        chapterName: (ctx.chapterName as string) || null,
        lessonId,
        lessonTitle: (ctx.lessonTitle as string) || lessonPayload.title || null,
        lessonContent: lessonPayload.content || null,
        lessonExample: lessonPayload.example || null,
        lessonKeyPoints: lessonPayload.keyPoints,
        exercises: lessonPayload.exercises,
        quiz: lessonPayload.quiz,
        retrievalOk: retrievalStatus === 'ok',
        memory,
      });
      if (local.memoryUpdates) {
        await savePedagogicalMemory({ ...local.memoryUpdates, userId: userId });
      }
      return finish({
        reply: local.reply,
        provider: 'mael-local',
        source: local.source,
        intent: local.intent,
        retrievalStatus,
        mode: 'provider-fallback-local',
        ...(retrievedMeta ? { lesson: retrievedMeta } : {}),
      });
    }
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : String(err);
    console.error('[ai-tutor]', message);
    return json({
      reply:
        "Je rencontre un souci technique. Reformule ta question ou relis la leçon : définition, exemple, puis exercice étape par étape.",
      provider: 'fallback',
      source: 'local',
      errorKind: 'server',
    });
  }
};

