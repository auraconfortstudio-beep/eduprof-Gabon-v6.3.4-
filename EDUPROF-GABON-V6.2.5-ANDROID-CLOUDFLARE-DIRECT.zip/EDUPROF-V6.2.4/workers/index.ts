/**
 * Cloudflare Worker natif — point d'entrée unique.
 * fetch : API + assets SPA
 * scheduled : maintenance institutionnelle (cron)
 */
import type { EduprofEnv } from './platform/env.ts';
import { runWithEnv } from './platform/env.ts';
import { runScheduledMaintenance } from './institutional-maintenance.ts';

export interface Env extends EduprofEnv {}

export default {
  async fetch(request: Request, env: Env, _ctx: ExecutionContext): Promise<Response> {
    return runWithEnv(env, async () => {
      const url = new URL(request.url);

      // API Worker
      if (url.pathname === '/api' || url.pathname.startsWith('/api/')) {
        if (url.pathname === '/api/ai-tutor' || url.pathname.startsWith('/api/ai-tutor/')) {
          const mod = await import('./ai-tutor.ts');
          return mod.default(request, env);
        }
        const mod = await import('./api.ts');
        return mod.default(request, env);
      }

      // Assets SPA (build Vite → dist) via binding ASSETS
      if (env.ASSETS) {
        return env.ASSETS.fetch(request);
      }

      return new Response('EduProf Gabon V6.2.4 — Worker actif (assets non liés)', {
        status: 404,
        headers: { 'content-type': 'text/plain; charset=utf-8' },
      });
    });
  },

  async scheduled(_controller: ScheduledController, env: Env, _ctx: ExecutionContext): Promise<void> {
    await runWithEnv(env, async () => {
      await runScheduledMaintenance(env);
    });
  },
};
