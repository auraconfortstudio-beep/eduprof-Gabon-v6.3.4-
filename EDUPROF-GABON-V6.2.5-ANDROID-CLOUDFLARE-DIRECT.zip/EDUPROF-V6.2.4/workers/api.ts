import {
  createUser,
  createToken,
  getAuthUser,
  verifyPassword,
  isOwner,
  isAdminOrOwner,
  fullProfile,
  publicProfile,
  jsonResponse,
  corsHeaders,
} from './_shared/auth';
import { isOwnerEmail } from './platform/env.ts';
import {
  hasPermission,
  assertEstablishmentAccess,
  listEstablishments,
  getEstablishment,
  getEstablishmentByCode,
  createEstablishment,
  updateEstablishment,
  listActivations,
  listInstitutionalAudit,
  appendInstitutionalAudit,
  parseStudentsCsv,
  activateStudent,
  deactivateStudent,
  renewStudent,
  bulkActivate,
  syncExpiredActivations,
  resolveEstablishmentContext,
  assertTenantWrite,
  listVisibleEstablishments,
  runInstitutionalMaintenance,
  upsertMembership,
  revokeMembership,
  getMembership,
  listMemberships,
  hasActiveMembership,
  InstitutionalRepository,
} from './_shared/institutional/index.ts';
import {
  getUserByEmail,
  getUserById,
  saveUser,
  listAllUsers,
  deleteUser,
  getProgress,
  saveProgress,
  getPremiumRequests,
  savePremiumRequests,
  getAdminLogs,
  appendAdminLog,
  getAnnales,
  saveAnnales,
} from './_shared/store';
import type { PremiumRequest, UserRecord, AnnaleRecord, Role } from './_shared/types';
import {
  getLesson,
  getExerciseCorrectAnswer,
  getQuizQuestions,
  XP_LESSON,
  XP_EXERCISE,
  XP_QUIZ_MAX,
} from './_shared/content';
import {
  recordFailedLogin,
  clearFailedLogin,
  isLoginBlocked,
  getClientIp,
  enforceRateLimit,
  rateLimitResponse,
  RATE_PRESETS,
} from './_shared/rateLimit';
import {
  listConversations,
  getConversation,
  createConversation,
  appendMessages,
  deleteConversation,
} from './_shared/pedagogy/conversationStore.ts';
import {
  saveAttachment,
  getAttachmentMeta,
  getAttachmentBinary,
  deleteAttachment,
  ATTACHMENT_MAX_PER_MESSAGE,
  isAllowedMime,
} from './_shared/attachments.ts';
import { randomUUID } from 'crypto';

const PREMIUM_DAILY = 500;
const PREMIUM_MONTHLY = 4000;


/** Résout /auth/login etc. malgré réécritures legacy de chemin. */
function resolveApiPath(req: Request, url: URL): string {
  const rawCandidates = [
    req.headers.get('x-forwarded-uri'),
    req.headers.get('x-original-url'),
    req.headers.get('x-original-pathname'),
    url.pathname,
  ].filter((v): v is string => !!v && v.length > 0);

  const normalize = (raw: string): string => {
    let p = raw.split('?')[0] || '/';
    p = p.replace(/^\/\.netlify\/functions\/api(?=\/|$)/, ''); // legacy path strip
    if (p.startsWith('/api/') || p === '/api') {
      p = p.slice(4) || '/';
    }
    if (!p.startsWith('/')) p = '/' + p;
    if (p.length > 1 && p.endsWith('/')) p = p.slice(0, -1);
    return p || '/';
  };

  // Prefer the most specific non-root path
  let best = '/';
  for (const raw of rawCandidates) {
    const n = normalize(raw);
    if (n !== '/') return n;
    best = n;
  }
  return best;
}


/** Body JSON typé (évite unknown sans garde). */
type JsonBody = Record<string, unknown>;

async function readJsonBody(req: Request): Promise<JsonBody> {
  try {
    const raw = await req.json();
    if (raw && typeof raw === 'object' && !Array.isArray(raw)) {
      return raw as JsonBody;
    }
  } catch {
    /* body vide ou non JSON */
  }
  return {};
}

function bodyStr(body: JsonBody, key: string, fallback = ''): string {
  const v = body[key];
  if (typeof v === 'string') return v;
  if (typeof v === 'number' || typeof v === 'boolean') return String(v);
  return fallback;
}

function bodyOptStr(body: JsonBody, key: string): string | null {
  const v = body[key];
  if (typeof v === 'string' && v.length > 0) return v;
  return null;
}

function bodyNum(body: JsonBody, key: string, fallback = 0): number {
  const v = body[key];
  if (typeof v === 'number' && Number.isFinite(v)) return v;
  if (typeof v === 'string' && v.trim() !== '') {
    const n = Number(v);
    return Number.isFinite(n) ? n : fallback;
  }
  return fallback;
}

import {
  computeOwnerAnalytics,
  computeEstablishmentAnalytics,
  queryAudit,
  sanitizeAuditForClient,
} from './_shared/analytics/index.ts';
import { buildStudentProgressSummary, getLevelFromXp, awardXpIdempotent, makeEventKey } from './_shared/progression/index.ts';
import {
  createNotification,
  listNotifications,
  markNotificationRead,
  markAllNotificationsRead,
  deleteNotification,
  PushNotificationProvider,
} from './_shared/notifications.ts';
import {
  createTicket,
  getTicket,
  listTicketsForUser,
  listTicketsForEstablishment,
  listAllTickets,
  updateTicketStatus,
  replyToTicket,
  assignTicket,
  canAccessTicket,
  type TicketStatus,
  type TicketCategory,
} from './_shared/support.ts';
import { securityHeaders, publicErrorMessage } from './_shared/securityHeaders.ts';
import {
  getOrCreateRequestId,
  requestIdHeader,
  logError,
  logInfo,
  recordRequest,
  buildHealthReport,
} from './_shared/observability/index.ts';
import { checkInstitutionalAccess } from './_shared/institutional/index.ts';
export default async (req: Request, _env?: unknown): Promise<Response> => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 204, headers: corsHeaders() });
  }

  const url = new URL(req.url);
  /**
   * Normalise le chemin API (legacy path cleanup) :
   * - /api/auth/login
   * - /.workers/api/auth/login  (:splat)
   * - /.workers/api            (sans splat, fallback)
   * Header path original éventuel.
   */
  const path = resolveApiPath(req, url);
  const method = req.method;

  let body: JsonBody = {};
  if (method !== 'GET' && method !== 'HEAD') {
    try {
      body = await readJsonBody(req);
    } catch {
      body = {};
    }
  }

  const requestId = getOrCreateRequestId(req.headers);
  const _t0 = Date.now();

  try {
    // ─── AUTH ───────────────────────────────────────────
    if (path === '/auth/signup' && method === 'POST') {
      const ip = getClientIp(req);
      const blocked = await enforceRateLimit(
        `signup:${ip}`,
        RATE_PRESETS.SIGNUP_IP.limit,
        RATE_PRESETS.SIGNUP_IP.windowMs,
        'Trop de tentatives. Réessayez plus tard.'
      );
      if (blocked) return blocked;
      const email = bodyStr(body, 'email');
      const password = bodyStr(body, 'password');
      const displayName = bodyStr(body, 'displayName');
      const educationLevel = bodyStr(body, 'educationLevel') || undefined;
      const educationSeries = bodyOptStr(body, 'educationSeries');
      const educationFiliere = bodyOptStr(body, 'educationFiliere');
      const { user, error } = await createUser({
        email,
        password,
        displayName,
        educationLevel,
        educationSeries,
        educationFiliere,
      });
      if (error) return jsonResponse({ error }, 400);
      const token = await createToken(user);
      return jsonResponse({ token, user: fullProfile(user) });
    }

    if (path === '/auth/demo' && method === 'POST') {
      const ip = getClientIp(req);
      const blocked = await enforceRateLimit(
        `demo:${ip}`,
        RATE_PRESETS.DEMO_IP.limit,
        RATE_PRESETS.DEMO_IP.windowMs,
        'Trop de démos lancées depuis cette connexion. Réessayez plus tard.'
      );
      if (blocked) return blocked;

      // Compte démo éphémère : email unique généré côté serveur, mot de passe
      // aléatoire jamais communiqué (le visiteur n'est jamais censé se reconnecter
      // avec ces identifiants — le token suffit pour la session démo).
      const demoEmail = `demo-${randomUUID()}@eduprof-gabon.demo`;
      const demoPassword = randomUUID() + randomUUID();
      const { user, error } = await createUser({
        email: demoEmail,
        password: demoPassword,
        displayName: 'Visiteur (démo)',
        educationLevel: 'cm2',
      });
      if (error || !user) return jsonResponse({ error: error || 'Démo indisponible' }, 500);

      // Forcer explicitement les garde-fous : jamais ADMIN/OWNER, jamais Premium,
      // quel que soit ce que createUser aurait pu déduire (défense en profondeur).
      user.role = 'USER';
      user.isPremium = false;
      user.premiumUntil = null;
      user.isDemo = true;
      await saveUser(user);

      const token = await createToken(user);
      return jsonResponse({ token, user: fullProfile(user) });
    }

    if (path === '/auth/login' && method === 'POST') {
      const email = bodyStr(body, 'email');
      const password = bodyStr(body, 'password');
      const emailNorm = (email || '').trim().toLowerCase();
      const ip = getClientIp(req);

      // Lockout progressif existant (email + IP) — non modifié
      const blockedEmail = await isLoginBlocked(emailNorm);
      const blockedIp = await isLoginBlocked(ip);
      if (blockedEmail.blocked || blockedIp.blocked) {
        const sec = blockedEmail.retryAfterSec || blockedIp.retryAfterSec || 60;
        return rateLimitResponse(
          `Trop de tentatives. Réessayez dans ${sec}s.`,
          sec
        );
      }

      const user = await getUserByEmail(emailNorm);
      if (!user || !(await verifyPassword(password || '', user.passwordHash))) {
        await recordFailedLogin(emailNorm);
        await recordFailedLogin(ip);
        return jsonResponse({ error: 'Email ou mot de passe incorrect' }, 401);
      }

      await clearFailedLogin(emailNorm);
      await clearFailedLogin(ip);

      if (isOwnerEmail(user.email) && user.role !== 'OWNER') {
        user.role = 'OWNER';
        await saveUser(user);
      }
      const token = await createToken(user);
      return jsonResponse({ token, user: fullProfile(user) });
    }

    if (path === '/auth/me' && method === 'GET') {
      const user = await getAuthUser(req.headers);
      if (!user) return jsonResponse({ error: 'Non authentifié' }, 401);
      if (user.isPremium && user.premiumUntil && new Date(user.premiumUntil) < new Date()) {
        user.isPremium = false;
        await saveUser(user);
      }
      return jsonResponse({ user: fullProfile(user) });
    }

    // ─── PROFILE ────────────────────────────────────────
    if (path === '/profile' && method === 'PUT') {
      const user = await getAuthUser(req.headers);
      if (!user) return jsonResponse({ error: 'Non authentifié' }, 401);
      const displayName = bodyStr(body, 'displayName');
      const educationLevel = bodyStr(body, 'educationLevel') || undefined;
      const educationSeries = bodyOptStr(body, 'educationSeries');
      const educationFiliere = bodyOptStr(body, 'educationFiliere');
      if (displayName !== undefined)
        user.displayName = String(displayName).trim() || user.displayName;
      if (educationLevel !== undefined) user.educationLevel = String(educationLevel);
      if (educationSeries !== undefined) user.educationSeries = educationSeries;
      if (educationFiliere !== undefined) user.educationFiliere = educationFiliere;
      user.updatedAt = new Date().toISOString();
      await saveUser(user);
      return jsonResponse({ user: fullProfile(user) });
    }

    // ─── LEADERBOARD ────────────────────────────────────
    if (path === '/leaderboard' && method === 'GET') {
      const users = await listAllUsers();
      const level = url.searchParams.get('level');
      let filtered = users;
      if (level) filtered = users.filter((u) => u.educationLevel === level);
      const sorted = filtered
        .map(publicProfile)
        .sort((a, b) => b.xp - a.xp);
      const top = sorted.slice(0, 100).map((p, i) => ({ ...p, rank: i + 1 }));

      let myRank: { rank: number; xp: number; displayName: string } | null = null;
      const authUser = await getAuthUser(req.headers);
      if (authUser) {
        const idx = sorted.findIndex((p) => p.id === authUser.id);
        if (idx >= 0) {
          myRank = {
            rank: idx + 1,
            xp: sorted[idx].xp,
            displayName: sorted[idx].displayName,
          };
        }
      }
      return jsonResponse({ leaderboard: top, myRank });
    }

    // ─── PROGRESS / XP (server is source of truth) ───────
    // ─── CONVERSATIONS MAËL ─────────────────────────────────────
    if (path === '/conversations' && method === 'GET') {
      const user = await getAuthUser(req.headers);
      if (!user) return jsonResponse({ error: 'Non authentifié' }, 401);
      const conversations = await listConversations(user.id);
      return jsonResponse({ conversations });
    }

    if (path === '/conversations/get' && method === 'GET') {
      const user = await getAuthUser(req.headers);
      if (!user) return jsonResponse({ error: 'Non authentifié' }, 401);
      const id = url.searchParams.get('id') || '';
      const conversation = await getConversation(user.id, id);
      if (!conversation) return jsonResponse({ error: 'Conversation introuvable' }, 404);
      return jsonResponse({ conversation });
    }

    if (path === '/conversations' && method === 'POST') {
      const user = await getAuthUser(req.headers);
      if (!user) return jsonResponse({ error: 'Non authentifié' }, 401);
      const body = await readJsonBody(req);
      const conversation = await createConversation(user.id, {
        lessonId: bodyOptStr(body, 'lessonId'),
        levelId: bodyOptStr(body, 'levelId'),
        seriesId: bodyOptStr(body, 'seriesId'),
        subjectId: bodyOptStr(body, 'subjectId'),
        subjectName: bodyOptStr(body, 'subjectName'),
        chapterId: bodyOptStr(body, 'chapterId'),
        lessonTitle: bodyOptStr(body, 'lessonTitle'),
      });
      return jsonResponse({ conversation });
    }

    if (path === '/conversations/delete' && method === 'POST') {
      const user = await getAuthUser(req.headers);
      if (!user) return jsonResponse({ error: 'Non authentifié' }, 401);
      const body = await readJsonBody(req);
      const ok = await deleteConversation(user.id, bodyStr(body, 'id'));
      return jsonResponse({ ok });
    }

    // ─── PIÈCES JOINTES ─────────────────────────────────────────
    if (path === '/attachments/upload' && method === 'POST') {
      const user = await getAuthUser(req.headers);
      if (!user) return jsonResponse({ error: 'Non authentifié' }, 401);
      const body = await readJsonBody(req);
      const fileName = bodyStr(body, 'fileName') || bodyStr(body, 'name') || 'fichier';
      const mimeType = bodyStr(body, 'mimeType') || bodyStr(body, 'type');
      const size = bodyNum(body, 'size');
      const base64Data = bodyStr(body, 'data') || bodyStr(body, 'base64');
      const conversationId = bodyOptStr(body, 'conversationId');
      const lessonId = bodyOptStr(body, 'lessonId');
      if (!base64Data) return jsonResponse({ error: 'Données fichier manquantes.' }, 400);
      const result = await saveAttachment({
        userId: user.id,
        fileName,
        mimeType,
        size,
        base64Data,
        conversationId,
        lessonId,
      });
      if (!result.ok) return jsonResponse({ error: result.error }, 400);
      return jsonResponse({
        attachment: {
          id: result.meta.id,
          fileName: result.meta.fileName,
          mimeType: result.meta.mimeType,
          size: result.meta.size,
          createdAt: result.meta.createdAt,
        },
      });
    }

    if (path === '/attachments/meta' && method === 'GET') {
      const user = await getAuthUser(req.headers);
      if (!user) return jsonResponse({ error: 'Non authentifié' }, 401);
      const id = url.searchParams.get('id') || '';
      const meta = await getAttachmentMeta(user.id, id);
      if (!meta) return jsonResponse({ error: 'Pièce jointe introuvable' }, 404);
      return jsonResponse({
        attachment: {
          id: meta.id,
          fileName: meta.fileName,
          mimeType: meta.mimeType,
          size: meta.size,
          createdAt: meta.createdAt,
        },
      });
    }

    if (path === '/attachments/delete' && method === 'POST') {
      const user = await getAuthUser(req.headers);
      if (!user) return jsonResponse({ error: 'Non authentifié' }, 401);
      const body = await readJsonBody(req);
      const ok = await deleteAttachment(user.id, bodyStr(body, 'id'));
      return jsonResponse({ ok });
    }

    if (path === '/progress' && method === 'GET') {
      const user = await getAuthUser(req.headers);
      if (!user) return jsonResponse({ error: 'Non authentifié' }, 401);
      const progress = await getProgress(user.id);
      return jsonResponse({ progress, profile: fullProfile(user) });
    }

    if (path === '/progress/lesson' && method === 'POST') {
      const user = await getAuthUser(req.headers);
      if (!user) return jsonResponse({ error: 'Non authentifié' }, 401);
      {
        const ip = getClientIp(req);
        const blocked = await enforceRateLimit(
          `apiwrite:${ip}`,
          RATE_PRESETS.API_WRITE_IP.limit,
          RATE_PRESETS.API_WRITE_IP.windowMs
        );
        if (blocked) return blocked;
      }
      const lessonId = typeof body.lessonId === 'string' ? body.lessonId.trim() : '';
      if (!lessonId) return jsonResponse({ error: 'lessonId requis' }, 400);

      const lesson = getLesson(lessonId);
      if (!lesson) {
        return jsonResponse({ error: 'Leçon introuvable ou invalide' }, 400);
      }

      const progress = await getProgress(user.id);
      if (progress.lessons.some((l) => l.lessonId === lessonId)) {
        return jsonResponse({
          completed: true,
          xpAwarded: false,
          xp: user.xp,
          xpGain: 0,
        });
      }

      const xpGain = XP_LESSON;
      progress.lessons.push({ lessonId, completedAt: new Date().toISOString() });
      user.xp += xpGain;
      progress.xpHistory.push({
        amount: xpGain,
        reason: `Leçon ${lessonId}`,
        createdAt: new Date().toISOString(),
      });
      await updateStreak(user);
      await saveUser(user);
      await saveProgress(progress);
      return jsonResponse({
        completed: true,
        xpAwarded: true,
        xp: user.xp,
        xpGain,
      });
    }

    if (path === '/progress/exercise' && method === 'POST') {
      const user = await getAuthUser(req.headers);
      if (!user) return jsonResponse({ error: 'Non authentifié' }, 401);
      {
        const ip = getClientIp(req);
        const blocked = await enforceRateLimit(
          `apiwrite:${ip}`,
          RATE_PRESETS.API_WRITE_IP.limit,
          RATE_PRESETS.API_WRITE_IP.windowMs
        );
        if (blocked) return blocked;
      }
      const exerciseId =
        typeof body.exerciseId === 'string' ? body.exerciseId.trim() : '';
      if (!exerciseId) return jsonResponse({ error: 'exerciseId requis' }, 400);

      const correctAnswer = getExerciseCorrectAnswer(exerciseId);
      if (correctAnswer === null) {
        return jsonResponse({ error: 'Exercice introuvable ou invalide' }, 400);
      }

      // Never trust client wasCorrect — compute from selectedAnswer
      const selected =
        body.selectedAnswer !== undefined && body.selectedAnswer !== null
          ? Number(body.selectedAnswer)
          : NaN;
      if (!Number.isInteger(selected) || selected < 0) {
        return jsonResponse(
          { error: 'selectedAnswer (index entier) requis' },
          400
        );
      }
      const wasCorrect = selected === correctAnswer;

      const progress = await getProgress(user.id);
      if (progress.exercises.some((e) => e.exerciseId === exerciseId)) {
        return jsonResponse({
          recorded: true,
          xpAwarded: false,
          xp: user.xp,
          xpGain: 0,
          wasCorrect,
        });
      }

      progress.exercises.push({
        exerciseId,
        wasCorrect,
        completedAt: new Date().toISOString(),
      });
      let xpGain = 0;
      if (wasCorrect) {
        xpGain = XP_EXERCISE;
        user.xp += xpGain;
        progress.xpHistory.push({
          amount: xpGain,
          reason: `Exercice ${exerciseId}`,
          createdAt: new Date().toISOString(),
        });
      }
      await updateStreak(user);
      await saveUser(user);
      await saveProgress(progress);
      return jsonResponse({
        recorded: true,
        xpAwarded: xpGain > 0,
        xp: user.xp,
        xpGain,
        wasCorrect,
      });
    }

    if (path === '/progress/quiz' && method === 'POST') {
      const user = await getAuthUser(req.headers);
      if (!user) return jsonResponse({ error: 'Non authentifié' }, 401);
      {
        const ip = getClientIp(req);
        const blocked = await enforceRateLimit(
          `apiwrite:${ip}`,
          RATE_PRESETS.API_WRITE_IP.limit,
          RATE_PRESETS.API_WRITE_IP.windowMs
        );
        if (blocked) return blocked;
      }
      const quizId = typeof body.quizId === 'string' ? body.quizId.trim() : '';
      if (!quizId) return jsonResponse({ error: 'quizId requis' }, 400);

      const questions = getQuizQuestions(quizId);
      if (!questions || questions.length === 0) {
        return jsonResponse({ error: 'Quiz introuvable ou invalide' }, 400);
      }

      // Prefer answers array from client; score server-side
      let score = 0;
      const totalQuestions = questions.length;
      if (Array.isArray(body.answers)) {
        for (let i = 0; i < questions.length; i++) {
          const ans = Number(body.answers[i]);
          if (Number.isInteger(ans) && ans === questions[i].correctAnswer) {
            score += 1;
          }
        }
      } else {
        // Fallback: reject client score — require answers
        return jsonResponse(
          { error: 'answers (tableau d\'indices) requis pour scorer le quiz' },
          400
        );
      }

      const progress = await getProgress(user.id);
      if (progress.quizzes.some((q) => q.quizId === quizId)) {
        return jsonResponse({
          recorded: true,
          xpAwarded: false,
          xp: user.xp,
          xpAmount: 0,
          score,
          totalQuestions,
        });
      }

      const pct = totalQuestions > 0 ? score / totalQuestions : 0;
      const xpGain = Math.round(pct * XP_QUIZ_MAX);
      user.xp += xpGain;
      progress.quizzes.push({
        quizId,
        subjectId: typeof body.subjectId === 'string' ? body.subjectId : '',
        score,
        totalQuestions,
        completedAt: new Date().toISOString(),
        xpAwarded: xpGain,
      });
      progress.xpHistory.push({
        amount: xpGain,
        reason: `Quiz ${quizId}`,
        createdAt: new Date().toISOString(),
      });
      await updateStreak(user);
      await saveUser(user);
      await saveProgress(progress);
      return jsonResponse({
        recorded: true,
        xpAwarded: true,
        xp: user.xp,
        xpAmount: xpGain,
        score,
        totalQuestions,
      });
    }

    // ─── PREMIUM ────────────────────────────────────────
    if (path === '/premium/request' && method === 'POST') {
      const user = await getAuthUser(req.headers);
      if (!user) return jsonResponse({ error: 'Non authentifié' }, 401);
      {
        const ip = getClientIp(req);
        const blockedIp = await enforceRateLimit(
          `apiwrite:${ip}`,
          RATE_PRESETS.API_WRITE_IP.limit,
          RATE_PRESETS.API_WRITE_IP.windowMs
        );
        if (blockedIp) return blockedIp;
        const blockedUser = await enforceRateLimit(
          `premiumreq:${user.id}`,
          RATE_PRESETS.PREMIUM_REQUEST_USER.limit,
          RATE_PRESETS.PREMIUM_REQUEST_USER.windowMs,
          'Trop de demandes Premium. Réessayez plus tard.'
        );
        if (blockedUser) return blockedUser;
      }
      const planRaw = bodyStr(body, 'plan');
      const proof = bodyStr(body, 'proof');
      if (planRaw !== 'daily' && planRaw !== 'monthly')
        return jsonResponse({ error: 'Formule invalide' }, 400);
      const plan: 'daily' | 'monthly' = planRaw;
      if (!proof || String(proof).trim().length < 3)
        return jsonResponse({ error: 'Preuve de paiement requise' }, 400);
      const amount = plan === 'daily' ? PREMIUM_DAILY : PREMIUM_MONTHLY;
      const reqs = await getPremiumRequests();
      // Prevent spam: max 5 pending per user
      const pending = reqs.filter(
        (r) => r.userId === user.id && r.status === 'pending'
      );
      if (pending.length >= 5) {
        return jsonResponse({ error: 'Trop de demandes en attente' }, 400);
      }
      const request: PremiumRequest = {
        id: randomUUID(),
        userId: user.id,
        userEmail: user.email,
        userDisplayName: user.displayName,
        plan,
        amount,
        proof: String(proof).trim().slice(0, 500),
        status: 'pending',
        createdAt: new Date().toISOString(),
        processedAt: null,
        processedBy: null,
      };
      reqs.unshift(request);
      await savePremiumRequests(reqs);
      return jsonResponse({ request });
    }

    if (path === '/premium/requests' && method === 'GET') {
      const user = await getAuthUser(req.headers);
      if (!user || !isAdminOrOwner(user))
        return jsonResponse({ error: 'Accès refusé' }, 403);
      const reqs = await getPremiumRequests();
      return jsonResponse({ requests: reqs });
    }

    if (path === '/premium/process' && method === 'POST') {
      const user = await getAuthUser(req.headers);
      if (!user || !isAdminOrOwner(user))
        return jsonResponse({ error: 'Accès refusé' }, 403);
      const requestId = bodyStr(body, 'requestId');
      const action = bodyStr(body, 'action');
      if (!['approve', 'reject'].includes(action))
        return jsonResponse({ error: 'Action invalide' }, 400);
      const reqs = await getPremiumRequests();
      const req2 = reqs.find((r) => r.id === requestId);
      if (!req2) return jsonResponse({ error: 'Demande introuvable' }, 404);
      if (req2.status !== 'pending')
        return jsonResponse({ error: 'Déjà traitée' }, 400);

      req2.status = action === 'approve' ? 'approved' : 'rejected';
      req2.processedAt = new Date().toISOString();
      req2.processedBy = user.id;

      if (action === 'approve') {
        const target = await getUserById(req2.userId);
        if (target) {
          const days = req2.plan === 'daily' ? 1 : 30;
          const base =
            target.premiumUntil && new Date(target.premiumUntil) > new Date()
              ? new Date(target.premiumUntil)
              : new Date();
          base.setDate(base.getDate() + days);
          target.isPremium = true;
          target.premiumUntil = base.toISOString();
          target.updatedAt = new Date().toISOString();
          await saveUser(target);
        }
      }
      await savePremiumRequests(reqs);
      await appendAdminLog({
        id: randomUUID(),
        actorId: user.id,
        actorEmail: user.email,
        action: `premium_${action}`,
        targetUserId: req2.userId,
        details: `${req2.plan} ${req2.amount} FCFA`,
        createdAt: new Date().toISOString(),
      });
      return jsonResponse({ ok: true, request: req2 });
    }

    // ─── ANNALES ────────────────────────────────────────
    if (path === '/annales' && method === 'GET') {
      const items = await getAnnales();
      const authUser = await getAuthUser(req.headers);
      const isStaff = authUser && isAdminOrOwner(authUser);
      const published = isStaff
        ? items
        : items.filter((a) => a.status === 'published');
      // filters
      const exam = url.searchParams.get('exam');
      const year = url.searchParams.get('year');
      const subject = url.searchParams.get('subject');
      const level = url.searchParams.get('level');
      let filtered = published;
      if (exam) filtered = filtered.filter((a) => a.exam === exam);
      if (year) filtered = filtered.filter((a) => a.year === year);
      if (subject)
        filtered = filtered.filter((a) =>
          a.subject.toLowerCase().includes(subject.toLowerCase())
        );
      if (level) filtered = filtered.filter((a) => a.level === level);
      return jsonResponse({ annales: filtered });
    }

    if (path === '/annales' && method === 'POST') {
      const user = await getAuthUser(req.headers);
      if (!user || !isAdminOrOwner(user))
        return jsonResponse({ error: 'Accès refusé' }, 403);
      const exam = bodyStr(body, 'exam');
      const year = bodyStr(body, 'year');
      const subject = bodyStr(body, 'subject');
      const level = bodyStr(body, 'level');
      const series = bodyOptStr(body, 'series');
      const title = bodyStr(body, 'title');
      const description = bodyStr(body, 'description');
      const subjectUrl = bodyOptStr(body, 'subjectUrl');
      const correctionUrl = bodyOptStr(body, 'correctionUrl');
      const status = bodyStr(body, 'status');
      if (!exam || !year || !subject || !level || !title) {
        return jsonResponse({ error: 'Champs obligatoires manquants' }, 400);
      }
      const now = new Date().toISOString();
      const record: AnnaleRecord = {
        id: randomUUID(),
        exam: String(exam).slice(0, 40),
        year: String(year).slice(0, 10),
        subject: String(subject).slice(0, 80),
        level: String(level).slice(0, 40),
        series: series ? String(series).slice(0, 40) : null,
        title: String(title).slice(0, 200),
        description: String(description || '').slice(0, 2000),
        subjectUrl: subjectUrl ? String(subjectUrl).slice(0, 500) : null,
        correctionUrl: correctionUrl ? String(correctionUrl).slice(0, 500) : null,
        status: status === 'published' ? 'published' : 'draft',
        createdAt: now,
        updatedAt: now,
        createdBy: user.id,
      };
      const items = await getAnnales();
      items.unshift(record);
      await saveAnnales(items);
      await appendAdminLog({
        id: randomUUID(),
        actorId: user.id,
        actorEmail: user.email,
        action: 'annale_create',
        targetUserId: null,
        details: `${record.exam} ${record.year} ${record.subject}`,
        createdAt: now,
      });
      return jsonResponse({ annale: record });
    }

    if (path === '/annales/update' && method === 'POST') {
      const user = await getAuthUser(req.headers);
      if (!user || !isAdminOrOwner(user))
        return jsonResponse({ error: 'Accès refusé' }, 403);
      const id = bodyStr(body, 'id');
      const updates: JsonBody = { ...body };
      delete updates.id;
      if (!id) return jsonResponse({ error: 'id requis' }, 400);
      const items = await getAnnales();
      const idx = items.findIndex((a) => a.id === id);
      if (idx < 0) return jsonResponse({ error: 'Annale introuvable' }, 404);
      const cur = items[idx];
      const fields = [
        'exam',
        'year',
        'subject',
        'level',
        'series',
        'title',
        'description',
        'subjectUrl',
        'correctionUrl',
        'status',
      ] as const;
      for (const f of fields) {
        if (updates[f] !== undefined) {
          (cur as any)[f] = updates[f];
        }
      }
      if (cur.status !== 'published' && cur.status !== 'draft') cur.status = 'draft';
      cur.updatedAt = new Date().toISOString();
      items[idx] = cur;
      await saveAnnales(items);
      await appendAdminLog({
        id: randomUUID(),
        actorId: user.id,
        actorEmail: user.email,
        action: 'annale_update',
        targetUserId: null,
        details: id,
        createdAt: cur.updatedAt,
      });
      return jsonResponse({ annale: cur });
    }

    if (path === '/annales/delete' && method === 'POST') {
      const user = await getAuthUser(req.headers);
      if (!user || !isAdminOrOwner(user))
        return jsonResponse({ error: 'Accès refusé' }, 403);
      const id = bodyStr(body, 'id');
      if (!id) return jsonResponse({ error: 'id requis' }, 400);
      let items = await getAnnales();
      const before = items.length;
      items = items.filter((a) => a.id !== id);
      if (items.length === before)
        return jsonResponse({ error: 'Annale introuvable' }, 404);
      await saveAnnales(items);
      await appendAdminLog({
        id: randomUUID(),
        actorId: user.id,
        actorEmail: user.email,
        action: 'annale_delete',
        targetUserId: null,
        details: id,
        createdAt: new Date().toISOString(),
      });
      return jsonResponse({ ok: true });
    }

    // ─── ADMIN ──────────────────────────────────────────
    if (path === '/admin/users' && method === 'GET') {
      const user = await getAuthUser(req.headers);
      if (!user || !isAdminOrOwner(user))
        return jsonResponse({ error: 'Accès refusé' }, 403);
      const users = await listAllUsers();
      const safe = users.map((u) => ({
        id: u.id,
        displayName: u.displayName,
        email: u.email,
        educationLevel: u.educationLevel,
        role: u.role,
        isPremium:
          u.isPremium &&
          (!u.premiumUntil || new Date(u.premiumUntil) > new Date()),
        premiumUntil: u.premiumUntil,
        xp: u.xp,
        streak: u.streak,
        createdAt: u.createdAt,
      }));
      return jsonResponse({ users: safe });
    }

    if (path === '/admin/set-premium' && method === 'POST') {
      const user = await getAuthUser(req.headers);
      if (!user || !isAdminOrOwner(user))
        return jsonResponse({ error: 'Accès refusé' }, 403);
      const targetUserId = bodyStr(body, 'targetUserId');
      const days = bodyNum(body, 'days', 30);
      const isPremiumRaw = body['isPremium'];
      const isPremium = isPremiumRaw === false || isPremiumRaw === 'false' ? false : true;
      const target = await getUserById(targetUserId);
      if (!target) return jsonResponse({ error: 'Utilisateur introuvable' }, 404);
      if (isOwner(target) && !isOwner(user))
        return jsonResponse({ error: "Impossible de modifier l'OWNER" }, 403);

      if (isPremium === false) {
        target.isPremium = false;
        target.premiumUntil = null;
      } else {
        const d = Math.max(1, Number(days) || 30);
        const base =
          target.premiumUntil && new Date(target.premiumUntil) > new Date()
            ? new Date(target.premiumUntil)
            : new Date();
        base.setDate(base.getDate() + d);
        target.isPremium = true;
        target.premiumUntil = base.toISOString();
      }
      target.updatedAt = new Date().toISOString();
      await saveUser(target);
      await appendAdminLog({
        id: randomUUID(),
        actorId: user.id,
        actorEmail: user.email,
        action: isPremium === false ? 'remove_premium' : 'grant_premium',
        targetUserId: target.id,
        details: `days=${days}`,
        createdAt: new Date().toISOString(),
      });
      return jsonResponse({ user: fullProfile(target) });
    }

    if (path === '/admin/set-role' && method === 'POST') {
      const user = await getAuthUser(req.headers);
      if (!user || !isOwner(user))
        return jsonResponse({ error: "Seul l'OWNER peut gérer les rôles" }, 403);
      const targetUserId = bodyStr(body, 'targetUserId');
      const roleRaw = bodyStr(body, 'role');
      if (
        roleRaw !== 'ADMIN' &&
        roleRaw !== 'USER' &&
        roleRaw !== 'STUDENT' &&
        roleRaw !== 'TEACHER' &&
        roleRaw !== 'ESTABLISHMENT_ADMIN'
      )
        return jsonResponse({ error: 'Rôle invalide' }, 400);
      const role: Role = roleRaw as Role;
      const target = await getUserById(targetUserId);
      if (!target) return jsonResponse({ error: 'Utilisateur introuvable' }, 404);
      if (isOwner(target))
        return jsonResponse(
          { error: "Impossible de modifier le rôle de l'OWNER" },
          403
        );
      if (target.id === user.id)
        return jsonResponse(
          { error: 'Impossible de modifier votre propre rôle OWNER' },
          403
        );
      target.role = role;
      if (role === 'ESTABLISHMENT_ADMIN') {
        const estId = bodyStr(body, 'establishmentId');
        if (estId) target.establishmentId = estId;
      }
      target.updatedAt = new Date().toISOString();
      await saveUser(target);
      await appendInstitutionalAudit({
        actorUserId: user.id,
        actorEmail: user.email,
        action: 'ROLE_CHANGED',
        targetUserId: target.id,
        targetEstablishmentId: target.establishmentId || null,
        metadata: { role },
      });
      await appendAdminLog({
        id: randomUUID(),
        actorId: user.id,
        actorEmail: user.email,
        action: 'set_role',
        targetUserId: target.id,
        details: role,
        createdAt: new Date().toISOString(),
      });
      return jsonResponse({ user: fullProfile(target) });
    }

    if (path === '/admin/delete-user' && method === 'POST') {
      const user = await getAuthUser(req.headers);
      if (!user || !isOwner(user))
        return jsonResponse({ error: "Seul l'OWNER peut supprimer" }, 403);
      const targetUserId = bodyStr(body, 'targetUserId');
      const target = await getUserById(targetUserId);
      if (!target) return jsonResponse({ error: 'Utilisateur introuvable' }, 404);
      if (isOwner(target))
        return jsonResponse({ error: "Impossible de supprimer l'OWNER" }, 403);
      if (target.id === user.id)
        return jsonResponse({ error: 'Impossible de vous supprimer vous-même' }, 403);
      await deleteUser(targetUserId);
      await appendAdminLog({
        id: randomUUID(),
        actorId: user.id,
        actorEmail: user.email,
        action: 'delete_user',
        targetUserId,
        details: target.email,
        createdAt: new Date().toISOString(),
      });
      return jsonResponse({ ok: true });
    }

    if (path === '/admin/logs' && method === 'GET') {
      const user = await getAuthUser(req.headers);
      if (!user || !isOwner(user))
        return jsonResponse({ error: 'Accès refusé' }, 403);
      const logs = await getAdminLogs();
      return jsonResponse({ logs });
    }

        // ─── Institutionnel V4.2 ─────────────────────────────────────────
    if (path === '/institutions' && method === 'GET') {
      const user = await getAuthUser(req.headers);
      if (!user || !hasPermission(user, 'establishments.read'))
        return jsonResponse({ error: 'Accès refusé' }, 403);
      await syncExpiredActivations();
      const list = await listVisibleEstablishments(user);
      return jsonResponse({ establishments: list, storageBackend: InstitutionalRepository.backend });
    }

    if (path === '/institutions' && method === 'POST') {
      const user = await getAuthUser(req.headers);
      if (!user || !hasPermission(user, 'establishments.create'))
        return jsonResponse({ error: 'Accès refusé' }, 403);
      const name = bodyStr(body, 'name');
      const code = bodyStr(body, 'code');
      const type = bodyStr(body, 'type', 'lycee');
      if (!name || !code) return jsonResponse({ error: 'name et code requis' }, 400);
      try {
        const est = await createEstablishment({ name, code, type });
        await appendInstitutionalAudit({
          actorUserId: user.id,
          actorEmail: user.email,
          action: 'TENANT_CREATED',
          targetEstablishmentId: est.id,
          metadata: { code: est.code },
        });
        return jsonResponse({ establishment: est });
      } catch (e) {
        return jsonResponse({ error: e instanceof Error ? e.message : 'Erreur' }, 400);
      }
    }

    if (path === '/institutions/update' && method === 'POST') {
      const user = await getAuthUser(req.headers);
      if (!user || !hasPermission(user, 'establishments.update'))
        return jsonResponse({ error: 'Accès refusé' }, 403);
      const id = bodyStr(body, 'id');
      const access = assertEstablishmentAccess(user, id);
      if (!access.ok) return jsonResponse({ error: access.error }, access.status);
      const statusRaw = bodyStr(body, 'status');
      const status =
        statusRaw === 'active' || statusRaw === 'inactive' || statusRaw === 'suspended'
          ? statusRaw
          : undefined;
      const est = await updateEstablishment(id, {
        name: bodyStr(body, 'name') || undefined,
        type: bodyStr(body, 'type') || undefined,
        status,
      });
      if (!est) return jsonResponse({ error: 'Établissement introuvable' }, 404);
      await appendInstitutionalAudit({
        actorUserId: user.id,
        actorEmail: user.email,
        action: 'TENANT_UPDATED',
        targetEstablishmentId: est.id,
      });
      return jsonResponse({ establishment: est });
    }

    if (path === '/activations' && method === 'GET') {
      const user = await getAuthUser(req.headers);
      if (!user || !hasPermission(user, 'activations.read'))
        return jsonResponse({ error: 'Accès refusé' }, 403);
      await syncExpiredActivations();
      const establishmentId = url.searchParams.get('establishmentId') || user.establishmentId || undefined;
      if (establishmentId) {
        const access = assertEstablishmentAccess(user, establishmentId);
        if (!access.ok) return jsonResponse({ error: access.error }, access.status);
      }
      const list = await listActivations(
        user.role === 'ESTABLISHMENT_ADMIN'
          ? { establishmentId: user.establishmentId || undefined }
          : establishmentId
            ? { establishmentId }
            : undefined
      );
      return jsonResponse({ activations: list });
    }

    if (path === '/activations/activate' && method === 'POST') {
      const user = await getAuthUser(req.headers);
      if (!user || !hasPermission(user, 'students.activate'))
        return jsonResponse({ error: 'Accès refusé' }, 403);
      const targetUserId = bodyStr(body, 'targetUserId');
      const establishmentId = bodyStr(body, 'establishmentId') || user.establishmentId || '';
      const days = bodyNum(body, 'days', 30);
      const access = await assertTenantWrite(user, establishmentId);
      if (!access.ok) return jsonResponse({ error: access.error }, access.status);
      const target = await getUserById(targetUserId);
      if (!target) return jsonResponse({ error: 'Élève introuvable' }, 404);
      if (target.establishmentId && target.establishmentId !== establishmentId) {
        return jsonResponse({ error: 'Élève rattaché à un autre établissement' }, 403);
      }
      const r = await activateStudent({ user: target, establishmentId, days, actor: user });
      if (r.ok) {
        await upsertMembership({ userId: target.id, establishmentId, role: 'STUDENT', status: 'ACTIVE', });
      }
      if (!r.ok) return jsonResponse({ error: r.error }, 400);
      await saveUser(target);
      return jsonResponse({ activation: r.activation, user: fullProfile(target) });
    }

    if (path === '/activations/deactivate' && method === 'POST') {
      const user = await getAuthUser(req.headers);
      if (!user || !hasPermission(user, 'students.deactivate'))
        return jsonResponse({ error: 'Accès refusé' }, 403);
      const targetUserId = bodyStr(body, 'targetUserId');
      const establishmentId = bodyStr(body, 'establishmentId') || user.establishmentId || '';
      const access = await assertTenantWrite(user, establishmentId);
      if (!access.ok) return jsonResponse({ error: access.error }, access.status);
      const target = await getUserById(targetUserId);
      if (!target) return jsonResponse({ error: 'Élève introuvable' }, 404);
      if (target.establishmentId && target.establishmentId !== establishmentId) {
        return jsonResponse({ error: 'Élève rattaché à un autre établissement' }, 403);
      }
      await deactivateStudent({ user: target, establishmentId, actor: user, status: 'revoked' });
      await saveUser(target);
      return jsonResponse({ ok: true, user: fullProfile(target) });
    }

    if (path === '/activations/renew' && method === 'POST') {
      const user = await getAuthUser(req.headers);
      if (!user || !hasPermission(user, 'activations.renew'))
        return jsonResponse({ error: 'Accès refusé' }, 403);
      const targetUserId = bodyStr(body, 'targetUserId');
      const establishmentId = bodyStr(body, 'establishmentId') || user.establishmentId || '';
      const days = bodyNum(body, 'days', 30);
      const access = await assertTenantWrite(user, establishmentId);
      if (!access.ok) return jsonResponse({ error: access.error }, access.status);
      const target = await getUserById(targetUserId);
      if (!target) return jsonResponse({ error: 'Élève introuvable' }, 404);
      if (target.establishmentId && target.establishmentId !== establishmentId) {
        return jsonResponse({ error: 'Élève rattaché à un autre établissement' }, 403);
      }
      const r = await renewStudent({ user: target, establishmentId, days, actor: user });
      if (!r.ok) return jsonResponse({ error: r.error }, 400);
      await saveUser(target);
      return jsonResponse({ activation: r.activation, user: fullProfile(target) });
    }

    if (path === '/activations/bulk' && method === 'POST') {
      const user = await getAuthUser(req.headers);
      if (!user || !hasPermission(user, 'students.activate'))
        return jsonResponse({ error: 'Accès refusé' }, 403);
      const establishmentId = bodyStr(body, 'establishmentId') || user.establishmentId || '';
      const days = bodyNum(body, 'days', 30);
      const access = await assertTenantWrite(user, establishmentId);
      if (!access.ok) return jsonResponse({ error: access.error }, access.status);
      const ids = Array.isArray(body['userIds']) ? (body['userIds'] as unknown[]).map(String) : [];
      if (!ids.length) return jsonResponse({ error: 'userIds requis' }, 400);
      const users: Awaited<ReturnType<typeof getUserById>>[] = [];
      for (const id of ids) {
        const u = await getUserById(id);
        if (u) users.push(u);
      }
      const result = await bulkActivate({
        users: users.filter(Boolean) as NonNullable<(typeof users)[0]>[],
        establishmentId,
        days,
        actor: user,
      });
      for (const u of users) {
        if (u) await saveUser(u);
      }
      return jsonResponse(result);
    }

    if (path === '/import/csv/preview' && method === 'POST') {
      const user = await getAuthUser(req.headers);
      if (!user || !hasPermission(user, 'csv.import'))
        return jsonResponse({ error: 'Accès refusé' }, 403);
      const csv = bodyStr(body, 'csv');
      const parsed = parseStudentsCsv(csv);
      return jsonResponse(parsed);
    }

    if (path === '/import/csv/confirm' && method === 'POST') {
      const user = await getAuthUser(req.headers);
      if (!user || !hasPermission(user, 'csv.import'))
        return jsonResponse({ error: 'Accès refusé' }, 403);
      const csv = bodyStr(body, 'csv');
      const parsed = parseStudentsCsv(csv);
      if (!parsed.ok) return jsonResponse({ error: 'CSV invalide', ...parsed }, 400);
      const created: string[] = [];
      const failed: { line: number; reason: string }[] = [];
      for (const row of parsed.rows) {
        const est = await getEstablishmentByCode(row.establishmentCode);
        if (!est) {
          failed.push({ line: row.line, reason: 'Établissement inconnu' });
          continue;
        }
        const access = await assertTenantWrite(user, est.id);
        if (!access.ok) {
          failed.push({ line: row.line, reason: access.error });
          continue;
        }
        const email =
          row.email ||
          `${row.studentId.toLowerCase().replace(/[^a-z0-9]/g, '.')}@${est.code.toLowerCase()}.edu.ga`;
        try {
          const existing = await getUserByEmail(email);
          if (existing) {
            failed.push({ line: row.line, reason: 'Élève déjà existant' });
            continue;
          }
          const { user: nu, error } = await createUser({
            email,
            password: `Tmp-${row.studentId}-${Date.now().toString(36)}`,
            displayName: `${row.firstName} ${row.lastName}`.trim(),
            educationLevel: row.level,
          });
          if (error || !nu) {
            failed.push({ line: row.line, reason: error || 'Création impossible' });
            continue;
          }
          nu.role = 'STUDENT';
          nu.establishmentId = est.id;
          nu.accessStatus = 'pending';
          await saveUser(nu);
          await upsertMembership({
            userId: nu.id,
            establishmentId: est.id,
            role: 'STUDENT',
            status: 'ACTIVE',
            
          });
          created.push(nu.id);
          await appendInstitutionalAudit({
            actorUserId: user.id,
            actorEmail: user.email,
            action: 'STUDENT_IMPORTED',
            targetUserId: nu.id,
            targetEstablishmentId: est.id,
            metadata: { studentId: row.studentId },
          });
        } catch (e) {
          failed.push({ line: row.line, reason: e instanceof Error ? e.message : 'Erreur' });
        }
      }
      return jsonResponse({ created, failed, createdCount: created.length, failedCount: failed.length });
    }

    if (path === '/institutional/audit' && method === 'GET') {
      const user = await getAuthUser(req.headers);
      if (!user || !hasPermission(user, 'audit.read'))
        return jsonResponse({ error: 'Accès refusé' }, 403);
      const requested = url.searchParams.get('establishmentId');
      const ctx = await resolveEstablishmentContext(user, requested);
      if (!ctx.ok) return jsonResponse({ error: ctx.error }, ctx.status);
      const logs = await listInstitutionalAudit({
        establishmentId: ctx.ctx.establishmentId || undefined,
        limit: 100,
      });
      return jsonResponse({ logs });
    }

    if (path === '/institutional/dashboard' && method === 'GET') {
      const user = await getAuthUser(req.headers);
      if (!user || (!hasPermission(user, 'establishments.read') && !hasPermission(user, 'students.read')))
        return jsonResponse({ error: 'Accès refusé' }, 403);
      await syncExpiredActivations();
      let ests = await listEstablishments();
      if (user.role === 'ESTABLISHMENT_ADMIN') {
        ests = ests.filter((e) => e.id === user.establishmentId);
      }
      const acts = await listActivations(
        user.role === 'ESTABLISHMENT_ADMIN'
          ? { establishmentId: user.establishmentId || undefined }
          : undefined
      );
      const active = acts.filter((a) => a.status === 'active').length;
      const expired = acts.filter((a) => a.status === 'expired').length;
      const soon = acts.filter((a) => {
        if (a.status !== 'active' || !a.expiresAt) return false;
        const ms = new Date(a.expiresAt).getTime() - Date.now();
        return ms > 0 && ms < 7 * 86400000;
      }).length;
      return jsonResponse({
        establishments: ests.length,
        activations: acts.length,
        active,
        expired,
        expiringSoon: soon,
        recentAudit: await listInstitutionalAudit({
          establishmentId: user.role === 'ESTABLISHMENT_ADMIN' ? user.establishmentId || undefined : undefined,
          limit: 10,
        }),
      });
    }

    
    if (path === '/institutional/maintenance' && method === 'POST') {
      const user = await getAuthUser(req.headers);
      if (!user || (user.role !== 'OWNER' && user.role !== 'ADMIN'))
        return jsonResponse({ error: 'Accès refusé' }, 403);
      const summary = await runInstitutionalMaintenance({ actorUserId: user.id, recordAudit: true });
      return jsonResponse({ summary });
    }

    if (path === '/memberships' && method === 'GET') {
      const user = await getAuthUser(req.headers);
      if (!user || !hasPermission(user, 'students.read'))
        return jsonResponse({ error: 'Accès refusé' }, 403);
      const requested = url.searchParams.get('establishmentId');
      const ctx = await resolveEstablishmentContext(user, requested);
      if (!ctx.ok) return jsonResponse({ error: ctx.error }, ctx.status);
      const list = await listMemberships(
        ctx.ctx.establishmentId ? { establishmentId: ctx.ctx.establishmentId } : undefined
      );
      return jsonResponse({ memberships: list });
    }

    
    if (path === '/analytics/overview' && method === 'GET') {
      const user = await getAuthUser(req.headers);
      if (!user) return jsonResponse({ error: 'Non authentifié' }, 401);
      const periodRaw = url.searchParams.get('period') || 'all';
      const period =
        periodRaw === '7d' || periodRaw === '30d' || periodRaw === '90d' || periodRaw === 'all'
          ? periodRaw
          : 'all';
      const requested = url.searchParams.get('establishmentId');
      if (user.role === 'OWNER' || user.role === 'ADMIN') {
        if (requested) {
          const ctx = await resolveEstablishmentContext(user, requested);
          if (!ctx.ok) return jsonResponse({ error: ctx.error }, ctx.status);
          const data = await computeEstablishmentAnalytics(requested, period);
          return jsonResponse({ analytics: data });
        }
        const data = await computeOwnerAnalytics(period);
        return jsonResponse({ analytics: data });
      }
      if (user.role === 'ESTABLISHMENT_ADMIN') {
        const ctx = await resolveEstablishmentContext(user, requested);
        if (!ctx.ok) return jsonResponse({ error: ctx.error }, ctx.status);
        if (!ctx.ctx.establishmentId)
          return jsonResponse({ error: 'Établissement requis' }, 403);
        const data = await computeEstablishmentAnalytics(ctx.ctx.establishmentId, period);
        return jsonResponse({ analytics: data });
      }
      return jsonResponse({ error: 'Accès refusé' }, 403);
    }

    if (path === '/analytics/audit' && method === 'GET') {
      const user = await getAuthUser(req.headers);
      if (!user || !hasPermission(user, 'audit.read'))
        return jsonResponse({ error: 'Accès refusé' }, 403);
      const requested = url.searchParams.get('establishmentId');
      const ctx = await resolveEstablishmentContext(user, requested);
      if (!ctx.ok) return jsonResponse({ error: ctx.error }, ctx.status);
      const result = await queryAudit({
        establishmentId: ctx.ctx.establishmentId || undefined,
        actorUserId: url.searchParams.get('actorUserId') || undefined,
        action: url.searchParams.get('action') || undefined,
        targetUserId: url.searchParams.get('targetUserId') || undefined,
        from: url.searchParams.get('from') || undefined,
        to: url.searchParams.get('to') || undefined,
        page: Number(url.searchParams.get('page') || 1),
        pageSize: Number(url.searchParams.get('pageSize') || 20),
      });
      return jsonResponse({
        ...result,
        items: result.items.map(sanitizeAuditForClient),
      });
    }

    if (path === '/student/progress' && method === 'GET') {
      const user = await getAuthUser(req.headers);
      if (!user) return jsonResponse({ error: 'Non authentifié' }, 401);
      const targetId = url.searchParams.get('userId') || user.id;
      if (targetId !== user.id) {
        // admin peut voir élèves de son tenant uniquement
        if (!hasPermission(user, 'students.read'))
          return jsonResponse({ error: 'Accès refusé' }, 403);
        const target = await getUserById(targetId);
        if (!target) return jsonResponse({ error: 'Utilisateur introuvable' }, 404);
        if (user.role === 'ESTABLISHMENT_ADMIN') {
          if (!target.establishmentId || target.establishmentId !== user.establishmentId)
            return jsonResponse({ error: 'Accès refusé' }, 403);
        }
        const progress = await getProgress(target.id);
        const summary = buildStudentProgressSummary(target, progress);
        return jsonResponse({ summary });
      }
      const progress = await getProgress(user.id);
      const summary = buildStudentProgressSummary(user, progress);
      return jsonResponse({ summary });
    }

    
    if (path === '/notifications' && method === 'GET') {
      const user = await getAuthUser(req.headers);
      if (!user) return jsonResponse({ error: 'Non authentifié' }, 401);
      const page = Number(url.searchParams.get('page') || 1);
      const pageSize = Number(url.searchParams.get('pageSize') || 20);
      const unreadOnly = url.searchParams.get('unreadOnly') === '1';
      // Isolation : uniquement les notifs de l'utilisateur authentifié
      const data = listNotifications(user.id, {
        page,
        pageSize,
        unreadOnly,
        establishmentId: user.role === 'ESTABLISHMENT_ADMIN' ? user.establishmentId || undefined : undefined,
      });
      return jsonResponse({ ...data, push: PushNotificationProvider });
    }

    if (path === '/notifications/read' && method === 'POST') {
      const user = await getAuthUser(req.headers);
      if (!user) return jsonResponse({ error: 'Non authentifié' }, 401);
      const id = bodyStr(body, 'id');
      if (!id) return jsonResponse({ error: 'id requis' }, 400);
      const ok = markNotificationRead(user.id, id);
      return jsonResponse({ ok });
    }

    if (path === '/notifications/read-all' && method === 'POST') {
      const user = await getAuthUser(req.headers);
      if (!user) return jsonResponse({ error: 'Non authentifié' }, 401);
      const count = markAllNotificationsRead(user.id);
      return jsonResponse({ count });
    }

    if (path === '/notifications/create' && method === 'POST') {
      const user = await getAuthUser(req.headers);
      if (!user || (!hasPermission(user, 'students.update') && user.role !== 'OWNER' && user.role !== 'ADMIN'))
        return jsonResponse({ error: 'Accès refusé' }, 403);
      const targetUserId = bodyStr(body, 'targetUserId');
      if (!targetUserId) return jsonResponse({ error: 'targetUserId requis' }, 400);
      const target = await getUserById(targetUserId);
      if (!target) return jsonResponse({ error: 'Cible introuvable' }, 404);
      if (user.role === 'ESTABLISHMENT_ADMIN') {
        if (!target.establishmentId || target.establishmentId !== user.establishmentId)
          return jsonResponse({ error: 'Accès refusé' }, 403);
      }
      const typeRaw = bodyStr(body, 'type', 'SYSTEM');
      const n = createNotification({
        userId: targetUserId,
        establishmentId: target.establishmentId,
        type: typeRaw as 'SYSTEM',
        title: bodyStr(body, 'title', 'Notification'),
        message: bodyStr(body, 'message', ''),
      });
      return jsonResponse({ notification: n });
    }

    
    if (path === '/support/tickets' && method === 'GET') {
      const user = await getAuthUser(req.headers);
      if (!user) return jsonResponse({ error: 'Non authentifié' }, 401);
      if (user.role === 'OWNER' || user.role === 'ADMIN') {
        return jsonResponse({ tickets: listAllTickets() });
      }
      if (user.role === 'ESTABLISHMENT_ADMIN' && user.establishmentId) {
        return jsonResponse({ tickets: listTicketsForEstablishment(user.establishmentId) });
      }
      return jsonResponse({ tickets: listTicketsForUser(user.id) });
    }

    if (path === '/support/tickets' && method === 'POST') {
      const user = await getAuthUser(req.headers);
      if (!user) return jsonResponse({ error: 'Non authentifié' }, 401);
      const blockedSupport = await enforceRateLimit(
        `support:${user.id}`,
        RATE_PRESETS.SUPPORT_USER.limit,
        RATE_PRESETS.SUPPORT_USER.windowMs,
        'Trop de tickets support. Réessayez plus tard.'
      );
      if (blockedSupport) return blockedSupport;
      const subject = bodyStr(body, 'subject');
      const message = bodyStr(body, 'message');
      if (!subject || !message) return jsonResponse({ error: 'subject et message requis' }, 400);
      const catRaw = bodyStr(body, 'category', 'OTHER');
      const categories = ['ACCOUNT','ACCESS','COURSE','QUIZ','AI','ATTACHMENT','TECHNICAL','OTHER'];
      const category = (categories.includes(catRaw) ? catRaw : 'OTHER') as TicketCategory;
      const ticket = createTicket({
        userId: user.id,
        establishmentId: user.establishmentId,
        subject,
        message,
        category,
      });
      return jsonResponse({ ticket });
    }

    if (path === '/support/tickets/get' && method === 'GET') {
      const user = await getAuthUser(req.headers);
      if (!user) return jsonResponse({ error: 'Non authentifié' }, 401);
      const id = url.searchParams.get('id') || '';
      const ticket = getTicket(id);
      if (!ticket) return jsonResponse({ error: 'Ticket introuvable' }, 404);
      if (!canAccessTicket(ticket, user)) return jsonResponse({ error: 'Accès refusé' }, 403);
      return jsonResponse({ ticket });
    }

    if (path === '/support/tickets/status' && method === 'POST') {
      const user = await getAuthUser(req.headers);
      if (!user) return jsonResponse({ error: 'Non authentifié' }, 401);
      if (user.role !== 'OWNER' && user.role !== 'ADMIN' && user.role !== 'ESTABLISHMENT_ADMIN')
        return jsonResponse({ error: 'Accès refusé' }, 403);
      const id = bodyStr(body, 'id');
      const statusRaw = bodyStr(body, 'status');
      const allowed: TicketStatus[] = ['OPEN','IN_PROGRESS','WAITING_USER','RESOLVED','CLOSED'];
      if (!allowed.includes(statusRaw as TicketStatus))
        return jsonResponse({ error: 'Statut invalide' }, 400);
      const ticket = getTicket(id);
      if (!ticket) return jsonResponse({ error: 'Ticket introuvable' }, 404);
      if (!canAccessTicket(ticket, user)) return jsonResponse({ error: 'Accès refusé' }, 403);
      const updated = updateTicketStatus(id, statusRaw as TicketStatus, user.id);
      return jsonResponse({ ticket: updated });
    }

    if (path === '/support/tickets/reply' && method === 'POST') {
      const user = await getAuthUser(req.headers);
      if (!user) return jsonResponse({ error: 'Non authentifié' }, 401);
      const id = bodyStr(body, 'id');
      const message = bodyStr(body, 'message');
      if (!id || !message) return jsonResponse({ error: 'id et message requis' }, 400);
      const ticket = getTicket(id);
      if (!ticket) return jsonResponse({ error: 'Ticket introuvable' }, 404);
      if (!canAccessTicket(ticket, user)) return jsonResponse({ error: 'Accès refusé' }, 403);
      const updated = replyToTicket(id, user.id, message);
      return jsonResponse({ ticket: updated });
    }

    
    if (path === '/health' && method === 'GET') {
      const report = buildHealthReport();
      return jsonResponse(report, report.status === 'ok' ? 200 : 503);
    }

    if (path === '/metrics' && method === 'GET') {
      const user = await getAuthUser(req.headers);
      if (!user || (user.role !== 'OWNER' && user.role !== 'ADMIN'))
        return jsonResponse({ error: 'Accès refusé' }, 403);
      return jsonResponse(buildHealthReport());
    }

    
    if (path === '/access/status' && method === 'GET') {
      const user = await getAuthUser(req.headers);
      if (!user) return jsonResponse({ error: 'Non authentifié' }, 401);
      const gate = await checkInstitutionalAccess(user);
      return jsonResponse({
        allowed: gate.allowed,
        status: gate.status,
        reason: gate.reason || null,
        establishmentId: gate.establishmentId || null,
        expiresAt: gate.expiresAt || null,
      });
    }

    return jsonResponse({ error: 'Route introuvable', path }, 404);
  } catch (err: unknown) {
    logError(err instanceof Error ? err.message : 'Erreur serveur', { route: 'api', code: 'UNHANDLED' });
    recordRequest({ route: 'api', status: 500, durationMs: 0, ts: Date.now(), error: true });
    return jsonResponse({ error: publicErrorMessage(err) }, 500);
  }
};

async function updateStreak(user: UserRecord) {
  const today = new Date().toISOString().slice(0, 10);
  if (user.lastActivityDate === today) return;
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  const yStr = yesterday.toISOString().slice(0, 10);
  if (user.lastActivityDate === yStr) {
    user.streak = (user.streak || 0) + 1;
  } else {
    user.streak = 1;
  }
  user.lastActivityDate = today;
}
