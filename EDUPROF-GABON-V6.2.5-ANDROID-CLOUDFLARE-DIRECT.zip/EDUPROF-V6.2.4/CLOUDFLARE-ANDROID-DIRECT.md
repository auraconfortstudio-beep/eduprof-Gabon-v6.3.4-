# EduProf Gabon V6.2.5 — déploiement Android / Cloudflare

Cette archive est préparée pour éviter GitHub et Netlify.

## Important
Cloudflare Direct Upload accepte un ZIP ou un dossier **déjà construit** pour Pages. Il ne compile pas le projet source pendant un drag-and-drop. Le build doit donc être produit avant l'upload.

### Android / Termux
Depuis le dossier du projet :

```bash
bash scripts/deploy-android.sh
```

Le script installe les dépendances et génère `dist/`.

Ensuite dans Cloudflare :

**Workers & Pages → Create application → Pages → Direct Upload**

Puis sélectionner `dist/` ou son ZIP.

### Backend
Le projet reste un Worker Cloudflare natif avec D1/KV/R2/Cron. Les bindings et secrets ne doivent pas être mis dans le ZIP : ils sont configurés côté Cloudflare.

Secrets attendus :
- `JWT_SECRET`
- `OWNER_EMAILS`
- `GEMINI_API_KEY`
- `GROQ_API_KEY`
- `MISTRAL_API_KEY`
- `CEREBRAS_API_KEY`

Ne jamais écrire les valeurs de ces secrets dans Git, dans le frontend ou dans cette archive.

### Owner
Le code serveur utilise `OWNER_EMAILS`. Une inscription avec une adresse présente dans ce secret reçoit automatiquement le rôle `OWNER`. Les autres comptes restent `USER`.
